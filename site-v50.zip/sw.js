/* Lumi Words — Service Worker
 * 目标：断网/弱网也能打开页面与内置内容；接口请求（Supabase / AI）一律不缓存。
 * 策略：
 *   1) 同源静态资源（html/css/js/json/png/mp3）：缓存优先 + 后台更新（stale-while-revalidate）
 *   2) 跨域请求（Supabase REST / Edge Function）：直连，不缓存，失败就失败（由页面队列补交）
 *   3) 页面导航：网络优先，失败回退缓存的 today.html / 首页
 */
'use strict';

var CACHE = 'eng45-v53j';
var BUILD = '20261127bk';
var PRECACHE = [
  'assets/core/plan.js',
  'assets/core/difficulty.js', 'assets/core/difficulty-ui.js', 'assets/core/difficulty-placement.js', 'assets/difficulty.css',
  'today.html', 'review.html', 'lesson.html', 'test.html', 'stats.html', 'settings.html', 'login.html', 'mistakes.html',
  'usage.html',
  'chat.html', 'a3-voice.html',
  'assets/core/a3/entry.js', 'assets/core/a3/ios-audio.js', 'assets/core/a3/ui.js',
  'assets/core/a3/realtime-turns.js', 'assets/core/a3/pcm-playback.js',
  'assets/core/a3/qwen-events.js', 'assets/core/a3/onset.js',
  'assets/core/a3/upload.js', 'assets/core/a3/call.js',
  'assets/core/a3/pcm-capture-worklet.js', 'assets/core/a3/voice.css',
  'books.html',
  'memory.html',
  'word-mistakes.html', 'practice.html', 'my-words.html', 'a4-voice.html', 'write.html', 'assets/write.js', 'article.html',
  'assets/core/a4/voice.js',
  'assets/word-mistakes.js', 'assets/practice.js', 'assets/my-words.js', 'assets/article.js',
  'index.html',
  'assets/app.css',
  'assets/ui-v2.css',
  'assets/icons/favicon-32.png',
  'assets/icons/logo-96.png',
  'assets/icons/apple-touch-icon.png',
  'assets/icons/icon-192.png',
  'assets/icons/icon-512.png',
  'assets/vendor/supabase-js-2.js',
  'assets/core/config.js',
  'assets/core/md.js',
  'assets/core/db.js',
  'assets/core/auth.js',
  'assets/core/offline-cache.js',
  'assets/core/ai.js',
  'assets/core/speech.js',
  'assets/core/voice.js',
  'assets/core/realtime-voice.js',
  'assets/core/queue.js',
  'assets/core/learning.js',
  'assets/core/content-repair.js',
  'assets/core/lesson.js',
  'assets/core/pwa.js',
  'assets/core/mistake-review.js',
  'assets/core/review-due.js',
  'assets/core/adaptive.js',
  'assets/study.js', 'assets/books.js', 'assets/lesson.js', 'assets/test.js', 'assets/ask.js', 'assets/stats.js', 'assets/settings.js', 'assets/app.js', 'assets/usage.js', 'assets/mistakes.js', 'assets/chat.js', 'assets/memory.js',
  'assets/audio/words/credits.html',
  ...['action', 'answer', 'book', 'control', 'day', 'english', 'example', 'friend', 'good', 'home', 'listen']
    .map(word => 'assets/audio/words/en-us/' + word + '.mp3'),
  'data/builtin-lessons.js',
  'manifest.json'
];

self.addEventListener('install', function (e) {
  e.waitUntil(
    caches.open(CACHE).then(function (c) {
      return Promise.all(PRECACHE.map(function (u) {
        return c.add(new Request(u + '?v=' + BUILD, { cache: 'reload' })).catch(function () { /* 单个失败不影响安装 */ });
      }));
    }).then(function () { return self.skipWaiting(); })
  );
});

self.addEventListener('activate', function (e) {
  e.waitUntil(
    caches.keys().then(function (keys) {
      return Promise.all(keys.filter(function (k) { return k !== CACHE; }).map(function (k) { return caches.delete(k); }));
    }).then(function () { return self.clients.claim(); })
  );
});

async function cachedAudioRange(request) {
  const hit = await caches.match(request, { ignoreSearch: true });
  const match = /^bytes=(\d*)-(\d*)$/.exec(request.headers.get('range') || '');
  if (!hit || hit.status !== 200 || !match || (!match[1] && !match[2])) return fetch(request);
  const blob = await hit.blob();
  const start = match[1] ? Number(match[1]) : Math.max(0, blob.size - Number(match[2]));
  const end = match[1] && match[2] ? Math.min(blob.size - 1, Number(match[2])) : blob.size - 1;
  if (start > end) return new Response(null, { status: 416, headers: { 'Content-Range': 'bytes */' + blob.size } });
  return new Response(blob.slice(start, end + 1), {
    status: 206,
    headers: { 'Content-Type': 'audio/mpeg', 'Accept-Ranges': 'bytes',
      'Content-Range': 'bytes ' + start + '-' + end + '/' + blob.size, 'Content-Length': String(end - start + 1) }
  });
}

function isStatic(url) {
  return /\.(?:html|css|js|json|png|jpg|jpeg|svg|webp|ico|mp3|woff2?)(?:$|\?)/i.test(url.pathname) || url.pathname === '/' ;
}

// 导航请求的 redirect 模式是 manual。直接 fetch(req) 会得到 opaque redirect（status 0），
// respondWith 返回它就等于让浏览器跳到一个取不到内容的地址 → iPhone 从主屏打开是白屏。
// 必须用 redirect:'follow' 重新发一次，拿到最终页面。
function fetchFollow(req) {
  try {
    return fetch(req.url, {
      redirect: 'follow',
      credentials: 'same-origin',
      headers: { 'Accept': (req.headers && req.headers.get('accept')) || 'text/html,application/xhtml+xml' }
    });
  } catch (err) {
    return fetch(req);
  }
}

function cacheNav(req, res) {
  if (!res) return;
  // status 0（opaque / opaque redirect）与 3xx 不能存，存了下次拿它当页面同样白屏
  if (res.status !== 200 || res.type === 'opaqueredirect') return;
  var copy = res.clone();
  caches.open(CACHE).then(function (c) { c.put(req, copy); }).catch(function () {});
}

// 导航响应只要「跟随过重定向」（response.redirected === true）就不能直接交给浏览器：
// 导航请求的 redirect mode 是 manual，浏览器会报
// "a redirected response was used for a request whose redirect mode is not follow"
// （表现为 ERR_FAILED / iPhone 主屏白屏）。缓存里取到的、以及刚从网络取到的响应都要过这一层。
function normalizeNav(res) {
  if (!res) return Promise.resolve(null);
  if (res.type === 'opaqueredirect' || res.status === 0) return Promise.resolve(null);
  if (res.status !== 200) return Promise.resolve(res);
  if (!res.redirected) return Promise.resolve(res);
  var ct = res.headers.get('content-type') || 'text/html; charset=utf-8';
  return res.blob().then(function (b) {
    return new Response(b, { status: 200, headers: { 'Content-Type': ct } });
  }).catch(function () { return null; });
}

function serveNav(hit) {
  return normalizeNav(hit);
}

// 断网兜底必须「尽量给对页面」：/lesson 这类干净路径要映射回 lesson.html，
// 否则离线把任意页面都喂成 today.html，用户会以为跳错了页面。
function pathVariants(req) {
  var out = [];
  try {
    var u = new URL(req.url);
    var p = u.pathname.replace(/^\/+/, '');
    if (p && p.indexOf('.') < 0) out.push(p + '.html');   // /lesson -> lesson.html
    if (p === '') out.push('today.html');                  // / -> today.html
  } catch (e) {}
  return out;
}

function offlineFallback(req) {
  var variants = pathVariants(req);
  var chain = Promise.resolve(null);
  chain = chain.then(function () {
    return caches.match(req, { ignoreSearch: true }).then(serveNav);
  });
  variants.forEach(function (v) {
    chain = chain.then(function (hit) {
      if (hit) return hit;
      return caches.match(v).then(serveNav);
    });
  });
  return chain.then(function (hit) {
    if (hit) return hit;
    return caches.match('today.html').then(serveNav);
  }).then(function (hit) {
    if (hit) return hit;
    return caches.match('index.html').then(serveNav);
  }).then(function (hit) {
    if (hit) return hit;
    return new Response(
      '<!doctype html><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1">' +
      '<body style="font:16px/1.8 -apple-system,sans-serif;padding:32px;background:#f6f5f1">' +
      '<h2 style="font-size:18px">现在打不开页面</h2>' +
      '<p style="color:#6b6b62">可能是没网，或这一页还没缓存过。你本机没交上去的学习记录不会丢，联网后会自己补交。</p>' +
      '<p><button onclick="location.reload()" style="padding:10px 18px;border:0;border-radius:10px;background:#2f6b4f;color:#fff;font-size:15px">重试</button></p>' +
      '</body>',
      { status: 200, headers: { 'Content-Type': 'text/html; charset=utf-8' } }
    );
  });
}

self.addEventListener('fetch', function (e) {
  var req = e.request;
  if (req.method !== 'GET') return;               // 写操作永不经过缓存
  var url = new URL(req.url);
  if (url.origin !== self.location.origin) return; // 跨域（Supabase / AI）直连

  // 页面导航：网络优先（跟随重定向），断网回退缓存
  if (req.mode === 'navigate') {
    e.respondWith(
      fetchFollow(req).then(function (res) {
        cacheNav(req, res);
        return normalizeNav(res);
      }).catch(function () {
        return offlineFallback(req);
      })
    );
    return;
  }

  if (!isStatic(url)) return;

  if (/\.mp3$/i.test(url.pathname) && req.headers.has('range')) {
    e.respondWith(cachedAudioRange(req));
    return;
  }

  // 代码类（js/css）：网络优先，断网回退缓存。
  // 理由：缓存优先会让用户升级后还跑旧逻辑（改 bug 不生效），代码文件很小、每次都取新版更稳妥。
  var isCode = /.(?:js|css)(?:$|\?)/i.test(url.pathname);
  if (isCode) {
    e.respondWith(
      fetch(req).then(function (res) {
        if (res && res.status === 200) {
          var copy = res.clone();
          caches.open(CACHE).then(function (c) { c.put(req, copy); }).catch(function () {});
        }
        return res;
      }).catch(function () {
        return caches.match(req, { ignoreSearch: true }).then(function (hit) {
          if (hit) return hit;
          return new Response('/* offline: not cached */', { status: 504, headers: { 'Content-Type': 'text/javascript; charset=utf-8' } });
        });
      })
    );
    return;
  }

  // 其它静态资源（html 片段 / 图片 / 音频）：缓存优先 + 后台更新
  e.respondWith(
    caches.match(req, { ignoreSearch: true }).then(function (hit) {
      var net = fetch(req).then(function (res) {
        if (res && res.status === 200) {
          var copy = res.clone();
          caches.open(CACHE).then(function (c) { c.put(req, copy); }).catch(function () {});
        }
        return res;
      }).catch(function () { return hit; });
      return hit || net;
    })
  );
});

self.addEventListener('message', function (e) {
  if (e.data && e.data.type === 'skip-waiting') self.skipWaiting();
});
