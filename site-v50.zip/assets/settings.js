/* ============================================================
 * assets/settings.js —— 设置页：账号 / 预算 / 功能开关 / 数据导出 / 本机队列 / 退出
 * 只读展示为主；不在这里开放预算修改（要改走数据库，防止误操作击穿 30 元上限）
 * ============================================================ */
(function () {
  'use strict';
  var user = null;
  function el(id) { return document.getElementById(id); }
  function esc(s) {
    return String(s == null ? '' : s).replace(/[&<>"]/g, function (c) {
      return { '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;' }[c];
    });
  }
  function toast(msg) {
    var t = el('toast'); if (!t) return alert(msg);
    t.textContent = msg; t.classList.add('on');
    clearTimeout(toast._t);
    toast._t = setTimeout(function () { t.classList.remove('on'); }, 2600);
  }
  function kv(label, value) {
    return '<div class="kv"><span class="muted small">' + label + '</span><span>' + esc(value) + '</span></div>';
  }

  /* ---------------- 单词发音（第一批） ----------------
   * 用浏览器自带语音合成：零费用、不发请求。偏好只存本机（换设备重新设）。
   */
  function sp() { return (window.Speech && window.Speech.prefs) ? window.Speech.prefs() : { on: true, auto: false, rate: 1 }; }
  function speechCard() {
    return '<div class="card"><h3 style="margin:0 0 8px">单词发音</h3>' +
      '<p class="muted small">用手机或电脑自带的语音朗读，不联网、不花 AI 费用。iPhone 需要点一下喇叭才会发声。</p>' +
      '<div class="kv"><span class="muted small">发音开关</span><span><button class="btn ghost sm" id="spOn" data-act="sp-toggle">开</button></span></div>' +
      '<div class="kv"><span class="muted small">语速</span><span><button class="btn ghost sm" id="spRate" data-act="sp-rate">正常 1.0×</button></span></div>' +
      '<div class="kv"><span class="muted small">答题前自动朗读</span><span><button class="btn ghost sm" id="spAuto" data-act="sp-auto">关</button></span></div>' +
      '<div class="kv"><span class="muted small">连续语音对话</span><span><button class="btn ghost sm" id="contOn" data-act="cont-toggle">关</button></span></div>' +
      '<p class="muted small">开启后，在 AI 英语老师里用语音提问，回答播完会自动重新打开麦克风，可以连续对话。安静 8 秒会自动退出；再点 🎤 也能结束。</p>' +
      '<div class="row mt12"><button class="btn ghost block" data-act="sp-test">🔊 试听一句</button></div>' +
      '<div id="spInfo" class="muted small mt8"></div>' +
      '</div>';
  }
  function updateSpeechUI() {
    var p = sp();
    var on = el('spOn'), rate = el('spRate'), auto = el('spAuto'), info = el('spInfo'), cont = el('contOn');
    if (on) on.textContent = p.on ? '开' : '关';
    if (cont) { var cv = false; try { cv = localStorage.getItem('lumi_cont_voice') === '1'; } catch (e) { } cont.textContent = cv ? '开' : '关'; }
    if (rate) rate.textContent = (Math.abs(p.rate - 0.85) < 0.01 ? '慢速 0.85×' : '正常 1.0×');
    if (auto) auto.textContent = p.auto ? '开' : '关';
    if (!info) return;
    var st = (window.Speech && window.Speech.status) ? window.Speech.status() : { supported: false, count: 0, enVoices: [] };
    if (!st.supported) { info.textContent = '这个浏览器不支持朗读，建议用 iPhone Safari 或新版 Edge。'; return; }
    var msg = '本机可用语音 ' + st.count + ' 个';
    if (st.enVoices && st.enVoices.length) msg += '（英语：' + st.enVoices.slice(0, 2).join('、') + (st.enVoices.length > 2 ? ' 等' : '') + '）';
    if (!st.count) msg = '语音列表还没加载好，点「试听一句」后应该会出现。';
    info.textContent = msg;
  }

  /* ---------------- 每天提醒 ----------------
   * 不申请通知权限、不依赖服务端：生成一条每天重复的日历事件（.ics），
   * 由手机/电脑自带日历负责到点提醒。时间只存本机。
   */
  function reminderTime() {
    try { var v = localStorage.getItem('lumi_reminder_time'); if (/^\d{2}:\d{2}$/.test(v || '')) return v; } catch (e) { }
    return '20:00';
  }
  function pad2(n) { return (n < 10 ? '0' : '') + n; }
  function reminderIcs(time) {
    var hm = String(time || '20:00').split(':');
    var hh = Math.max(0, Math.min(23, parseInt(hm[0], 10) || 0));
    var mm = Math.max(0, Math.min(59, parseInt(hm[1], 10) || 0));
    var start = new Date();
    start.setHours(hh, mm, 0, 0);
    if (start.getTime() <= Date.now()) start.setDate(start.getDate() + 1);
    var dt = start.getFullYear() + pad2(start.getMonth() + 1) + pad2(start.getDate()) + 'T' + pad2(hh) + pad2(mm) + '00';
    var stamp = new Date().toISOString().replace(/[-:]/g, '').replace(/\.\d{3}/, '');
    var uid = 'lumi-reminder-' + ((user && user.id) || 'local') + '@lumi';
    return ['BEGIN:VCALENDAR', 'VERSION:2.0', 'PRODID:-//Lumi Words//Study Reminder//CN', 'CALSCALE:GREGORIAN', 'METHOD:PUBLISH',
      'BEGIN:VEVENT', 'UID:' + uid, 'DTSTAMP:' + stamp, 'DTSTART:' + dt,
      'RRULE:FREQ=DAILY', 'SUMMARY:Lumi Words 学习提醒',
      'DESCRIPTION:打开 Lumi Words，按自己的节奏学习英语。',
      'BEGIN:VALARM', 'TRIGGER:-PT0M', 'ACTION:DISPLAY', 'DESCRIPTION:打开 Lumi Words 开始学习',
      'END:VALARM', 'END:VEVENT', 'END:VCALENDAR', ''].join('\r\n');
  }
  function downloadIcs(text) {
    var blob = new Blob([text], { type: 'text/calendar;charset=utf-8' });
    var url = URL.createObjectURL(blob);
    var a = document.createElement('a');
    a.href = url; a.download = 'lumi-study-reminder.ics';
    document.body.appendChild(a);
    a.click();
    setTimeout(function () { try { URL.revokeObjectURL(url); a.remove(); } catch (e) { } }, 1500);
  }
  function reminderCard() {
    var t = reminderTime();
    return '<div class="card"><h3 style="margin:0 0 8px">每天提醒</h3>' +
      '<p class="muted small">选一个固定时间，添加到手机或电脑日历。到点由系统日历提醒，关掉 Lumi Words 也会响；不申请通知权限，也不花 AI 费用。</p>' +
      '<div class="kv"><span class="muted small">提醒时间</span><span><input id="rmTime" type="time" step="300" value="' + t + '" style="max-width:132px"></span></div>' +
      '<div class="row mt12"><button class="btn block" data-act="rm-ics">添加到日历（每天重复）</button></div>' +
      '<p class="muted small mt8">iPhone 下载后点「添加」；安卓用日历打开下载的文件。提醒时间以添加时的选择为准。</p>' +
      '</div>';
  }

  function render(prof, budget, pending) {
    var f = (window.APP_CONFIG && window.APP_CONFIG.FEATURES) || {};
    var labels = {
      AI_GENERATE: 'AI 生成学习内容', AI_CHAT: 'AI 对话', SPEECH_TTS: '语音朗读（TTS）',
      SPEECH_ASR: '语音识别（ASR）', WEEKLY_TEST: '每周测试', NEWS_MATERIAL: '新闻素材'
    };
    var h = [];
    h.push('<div class="v2-pagehead"><p class="v2-eyebrow">Your space</p><h1 class="v2-h1">设置</h1><p>账号、预算与学习数据都在这里。预算上限固定，避免误改击穿 30 元/月。</p></div>');
    h.push('<div class="card v2-profile">' +
      '<span class="v2-profile-avatar">L</span>' +
      '<div class="v2-profile-main"><b>' + esc(user.email || 'Lumi Words 学习者') + '</b>' +
      '<span>' + esc((prof && prof.plan ? prof.plan : 'free') + ' 套餐' + (prof && prof.created_at ? ' · ' + String(prof.created_at).slice(0, 10) + ' 加入' : '')) + '</span></div>' +
      '<span class="v2-profile-state">' + (prof && prof.memory_enabled !== false ? '记忆开启' : '记忆关闭') + '</span></div>');

    h.push('<div class="card"><h3 style="margin:0 0 8px">账号</h3>');
    h.push(kv('用户 ID', user.id));
    if (prof) {
      h.push(kv('角色', prof.role || 'owner'));
      h.push(kv('注册时间', prof.created_at ? String(prof.created_at).slice(0, 10) : '—'));
    }
    h.push('</div>');

    h.push('<div class="card"><h3 style="margin:0 0 8px">预算（只读）</h3>');
    if (prof) {
      h.push(kv('每月上限', (prof.monthly_budget_cny != null ? prof.monthly_budget_cny : 30) + ' 元'));
      h.push(kv('每日上限', (prof.daily_budget_cny != null ? prof.daily_budget_cny : 5) + ' 元'));
    }
    if (budget) {
      var lim = Number(budget.limit_cny) || 0;
      var spent = Number(budget.spent_cny) || 0;
      var resv = Number(budget.reserved_cny) || 0;
      h.push(kv('本月账本', budget.month_key || ''));
      h.push(kv('已用 / 上限', ((spent + resv).toFixed(4)) + ' / ' + lim.toFixed(2) + ' 元'));
      var pct = lim > 0 ? Math.min(100, Math.round((spent + resv) * 100 / lim)) : 0;
      h.push('<div class="meter ' + (pct >= 100 ? 'danger' : pct >= 80 ? 'warn' : '') + ' mt8"><span style="width:' + pct + '%"></span></div>');
    } else {
      h.push('<p class="muted small">本月还没有 AI 调用记录。</p>');
    }
    h.push('<p class="muted small mt8">达到月上限后 AI 会自动停止，内置内容照常可用；下月 1 日恢复。</p>');
    h.push('</div>');

    h.push('<div class="card"><h3 style="margin:0 0 8px">功能开关（本版本预置）</h3>');
    Object.keys(labels).forEach(function (k) {
      var on = f[k] === true;
      h.push('<div class="kv"><span class="muted small">' + labels[k] + '</span><span>' + (on ? '开' : '关') + '</span></div>');
    });
    h.push('<p class="muted small mt8">语音优先用手机或电脑自带能力，不花 AI 费用；服务端付费语音只对测试白名单账号开放。AI 生成与对话仍受每月预算上限限制。</p>');
    h.push('</div>');

    h.push(speechCard());
    h.push(reminderCard());

    if (f.AI_CHAT === true) {
      h.push('<div class="card"><h3 style="margin:0 0 8px">AI 英语老师</h3>');
      h.push('<p class="muted small">用中文或英文提问：解释单词和句子、讲语法、英文陪聊。每次回答按实际用量计费，明细在「AI 用量」里。</p>');
      h.push('<div class="row mt12"><a class="btn block" href="chat.html">打开 AI 英语老师</a></div>');
      h.push('<p class="muted small mt8">对话只保存在你自己的账号下。AI 是否参考学习记录，由下面的「学习档案与教学记忆」开关决定。</p>');
      h.push('</div>');
    }

    var memOn = !!(prof && prof.memory_enabled !== false);
    h.push('<div class="card"><h3 style="margin:0 0 8px">学习档案与教学记忆</h3>');
    h.push('<p class="muted small">AI 老师可以参考你的到期词、近 14 天正确率、薄弱词和错题，让你确认过的长期目标与偏好也会带上。你可以随时查看、修改、删除或关闭；系统推断必须经你确认才会生效。</p>');
    h.push(kv('当前状态', memOn ? '开启 · AI 会参考学习记录' : '关闭 · AI 不读取学习档案'));
    h.push('<div class="row mt12"><a class="btn ghost block" href="memory.html">管理学习档案</a></div>');
    h.push('</div>');

    h.push('<div class="card"><h3 style="margin:0 0 8px">词书</h3>');
    h.push('<p class="muted small">看看现在学的是哪一本，随时换书，或者把四级/六级/雅思加进计划。换书只改变以后的新词从哪本出，已经学过的词、复习安排、错题和统计都不会被重置。</p>');
    h.push('<div class="row mt12"><a class="btn block" href="books.html">打开词书中心（📚）</a></div>');
    h.push('</div>');

    h.push('<div class="card"><h3 style="margin:0 0 8px">数据</h3>');
    h.push(kv('本机待补交', pending + ' 条'));
    h.push('<div class="row mt12"><button class="btn block" data-act="export">导出我的学习数据（JSON）</button></div>');
    h.push('<div class="row mt8"><button class="btn ghost block" data-act="restore">从备份文件恢复（只补缺）</button></div>');
    h.push('<input type="file" id="restoreFile" accept="application/json,.json" style="display:none">');
    h.push('<div id="restoreReport"></div>');
    h.push('<div class="row mt8"><button class="btn ghost block" data-act="flush">立即补交本机记录</button></div>');
    h.push('<p class="muted small mt8">导出内容：词进度、学习会话、答题事件、四模块内容与成绩、错题、周测、AI 用量。不包含密码和密钥。</p>');
    h.push('<p class="muted small mt8">恢复只补当前账号缺的记录（错题、周测、模块进度）：已存在的跳过，较新的不覆盖。词进度和答题记录不恢复——它们由学习过程重新生成，硬塞回去会让复习安排错乱。</p>');
    h.push('</div>');

    h.push('<div class="card"><h3 style="margin:0 0 8px">关于</h3>');
    h.push(kv('版本', (window.APP_CONFIG && window.APP_CONFIG.APP_VERSION) || '未知'));
    h.push(kv('数据模式', window.DB.mode === 'mock' ? '本地 Mock' : '云端（Supabase）'));
    h.push('<div class="row mt12"><a class="btn ghost block" href="usage.html">看 AI 用量明细</a></div>');
    h.push('<div class="row mt8"><button class="btn ghost block" data-act="logout">退出登录</button></div>');
    h.push('</div>');
    el('view').innerHTML = h.join('');
    updateSpeechUI();
  }

  async function collect() {
    var uid = user.id;
    var safe = function (p) { return p.catch(function () { return []; }); };
    var r = await Promise.all([
      safe(window.DB.select('word_progress', { user_id: uid, limit: 2000 })),
      safe(window.DB.select('study_session', { user_id: uid, order: 'started_at.desc', limit: 500 })),
      safe(window.DB.select('study_event', { user_id: uid, order: 'created_at.desc', limit: 1000 })),
      safe(window.DB.select('lesson_content', { user_id: uid, order: 'lesson_date.desc', limit: 200 })),
      safe(window.DB.select('mistakes', { user_id: uid, order: 'created_at.desc', limit: 500 })),
      safe(window.DB.select('weekly_tests', { user_id: uid, order: 'week_start.desc', limit: 100 })),
      safe(window.DB.select('daily_ai_usage', { user_id: uid, order: 'usage_date.desc', limit: 100 })),
      safe(window.DB.select('daily_task', { user_id: uid, order: 'study_date.desc', limit: 200 }))
    ]);
    return {
      exported_at: new Date().toISOString(),
      user: { id: user.id, email: user.email || '' },
      word_progress: r[0], study_session: r[1], study_event: r[2], lesson_content: r[3],
      mistakes: r[4], weekly_tests: r[5], daily_ai_usage: r[6], daily_task: r[7]
    };
  }

  async function doExport() {
    toast('正在整理数据…');
    try {
      var data = await collect();
      var text = JSON.stringify(data, null, 2);
      var blob = new Blob([text], { type: 'application/json' });
      var a = document.createElement('a');
      a.href = URL.createObjectURL(blob);
      a.download = 'english-learning-backup-' + new Date().toISOString().slice(0, 10) + '.json';
      document.body.appendChild(a); a.click(); document.body.removeChild(a);
      setTimeout(function () { URL.revokeObjectURL(a.href); }, 4000);
      toast('已导出（' + Math.round(text.length / 1024) + ' KB）');
    } catch (err) { toast('导出失败：' + ((err && err.message) || '未知')); }
  }

  /* ---------------- 从备份恢复（只补缺） ----------------
   * 能恢复：mistakes（按用户+题面判重）、weekly_tests（按 week_start）、
   *        lesson_content（按 lesson_date+module，只在云端还没做完时写入）
   * 不恢复：word_progress / study_event / study_session / daily_ai_usage / daily_task
   *        —— 词进度由 RPC 重新计算，事件与账本是审计记录，导回去会与真实学习过程冲突。
   */
  var DATE_RE = /^\d{4}-\d{2}-\d{2}$/;
  var ISO_RE = /^\d{4}-\d{2}-\d{2}T\d{2}:\d{2}:\d{2}/;

  function isObj(x) { return !!x && typeof x === 'object' && !Array.isArray(x); }
  function tsOf(v) {
    if (!v) return 0;
    var s = String(v);
    if (!ISO_RE.test(s)) return 0;
    var t = Date.parse(s);
    return isFinite(t) ? t : 0;
  }
  function strField(v, max) {
    if (v == null) return '';
    return String(v).slice(0, max || 500);
  }
  // 错题判重键必须与写入时的规范化规则完全一致（kind 默认 word、题面截 500），
  // 否则同一道题会被当成两道题反复插入。
  function mKey(kind, refId, q) {
    return String(kind || 'word') + '|' + String(refId || '') + '|' + strField(q, 500);
  }
  function isDupErr(e) {
    var m = (e && e.message) || '';
    return /duplicate key|23505|already exists|已存在/i.test(m);
  }
  // 恢复期间账号被切换（例如另一个标签页退出/换号）必须立刻停手，绝不能把 A 的备份写进 B 的账号
  function assertSameAccount(uid) {
    return Promise.resolve(window.DB.auth.getUserId()).then(function (now) {
      if (!now || now !== uid) throw new Error('登录账号已变化，本次恢复已停止');
      return true;
    });
  }
  function takeArr(data, name, cap) {
    if (data[name] == null) return [];
    if (!Array.isArray(data[name])) throw new Error('备份文件格式不正确：' + name + ' 不是数组');
    return data[name].slice(0, cap);
  }

  async function restoreFrom(text) {
    var data;
    try { data = JSON.parse(text); } catch (e) { throw new Error('备份文件不是合法的 JSON'); }
    if (!isObj(data)) throw new Error('备份文件内容不正确（顶层不是对象）');
    if (!data.exported_at || !tsOf(data.exported_at)) throw new Error('这个文件不是本系统导出的备份（缺少 exported_at）');
    if (data.user != null && !isObj(data.user)) throw new Error('备份文件格式不正确：user 字段异常');

    var uid = user.id;
    var rep = {
      mistakes: { add: 0, skip: 0, fail: 0, invalid: 0 },
      weekly_tests: { add: 0, skip: 0, fail: 0, invalid: 0 },
      lesson_content: { add: 0, skip: 0, fail: 0, invalid: 0 }
    };
    var oldM = takeArr(data, 'mistakes', 5000);
    var oldW = takeArr(data, 'weekly_tests', 200);
    var oldL = takeArr(data, 'lesson_content', 400);

    // 先把云端三张表的现状一次读完：任何一张读失败就整体中止，绝不「读不到＝当没有」把备份全量插一遍
    var curM = [], curW = [], curL = [];
    try {
      await assertSameAccount(uid);
      curM = await window.DB.select('mistakes', { user_id: uid, limit: 5000 });
      curW = await window.DB.select('weekly_tests', { user_id: uid, limit: 200 });
      curL = await window.DB.select('lesson_content', { user_id: uid, limit: 1000 });
    } catch (e) {
      if (e && /登录账号已变化/.test(e.message || '')) throw e;
      throw new Error('无法读取云端已有数据，本次恢复已停止（没有写入任何数据）');
    }

    // 1) 错题：按 (kind, ref_id, question) 判断是否已有；再叠加确定性 id 兜底（双保险）
    if (oldM.length) {
      var seen = {};
      (curM || []).forEach(function (r) { seen[mKey(r.kind, r.ref_id, r.question)] = true; });
      var canId = window.Learn && typeof window.Learn.mistakeId === 'function';
      for (var i = 0; i < oldM.length; i++) {
        var m = oldM[i];
        if (!isObj(m)) { rep.mistakes.invalid++; continue; }
        var kind = (m.kind && String(m.kind)) || 'word';
        var q = strField(m.question, 500);
        if (!q) { rep.mistakes.invalid++; continue; }
        var key = mKey(kind, m.ref_id, q);
        if (seen[key]) { rep.mistakes.skip++; continue; }
        var row = {
          kind: kind,
          ref_id: m.ref_id == null ? null : String(m.ref_id).slice(0, 100),
          question: q,
          user_answer: strField(m.user_answer, 500),
          correct_answer: strField(m.correct_answer, 500),
          explain_zh: strField(m.explain_zh, 1000),
          resolved: m.resolved === true
        };
        if (canId) row.id = window.Learn.mistakeId(uid, kind, row.ref_id, q);
        // 写到一半换号也要停：每批前复核一次
        if (i > 0 && i % 20 === 0) { try { await assertSameAccount(uid); } catch (e) { throw e; } }
        try {
          row.user_id = uid;
          await window.DB.insert('mistakes', [row]);
          seen[key] = true; rep.mistakes.add++;
        } catch (e) {
          if (isDupErr(e)) { seen[key] = true; rep.mistakes.skip++; } else { rep.mistakes.fail++; }
        }
      }
    }

    // 2) 周测：同一周只保留云端已有的那份；分数必须是 0~100 的整数
    if (oldW.length) {
      var haveW = {};
      (curW || []).forEach(function (r) { haveW[String(r.week_start || '').slice(0, 10)] = true; });
      for (var j = 0; j < oldW.length; j++) {
        var w = oldW[j];
        if (!isObj(w)) { rep.weekly_tests.invalid++; continue; }
        var ws = String(w.week_start || '').slice(0, 10);
        if (!DATE_RE.test(ws)) { rep.weekly_tests.invalid++; continue; }
        var sc = Number(w.score);
        if (!isFinite(sc) || sc < 0 || sc > 100) { rep.weekly_tests.invalid++; continue; }
        if (haveW[ws]) { rep.weekly_tests.skip++; continue; }
        var detail = isObj(w.detail) ? w.detail : {};
        try {
          await assertSameAccount(uid);
          await window.DB.insert('weekly_tests', [{ user_id: uid, week_start: ws, score: Math.round(sc), detail: detail }]);
          haveW[ws] = true; rep.weekly_tests.add++;
        } catch (e) {
          if (isDupErr(e)) { haveW[ws] = true; rep.weekly_tests.skip++; } else { rep.weekly_tests.fail++; }
        }
      }
    }

    // 3) 模块进度：只在「云端没做完」且「备份比云端新」时写入，避免旧备份覆盖新进度
    if (oldL.length) {
      var byKey = {};
      function lessonKey(date, module, variant) {
        return [String(date || '').slice(0, 10), module, variant || 'legacy'].join('|');
      }
      (curL || []).forEach(function (r) { byKey[lessonKey(r.lesson_date, r.module, r.difficulty_variant)] = r; });
      for (var k = 0; k < oldL.length; k++) {
        var l = oldL[k];
        if (!isObj(l)) { rep.lesson_content.invalid++; continue; }
        var ld = String(l.lesson_date || '').slice(0, 10);
        var mod = String(l.module || '').slice(0, 40);
        if (!DATE_RE.test(ld) || !mod) { rep.lesson_content.invalid++; continue; }
        if (!isObj(l.result)) { rep.lesson_content.invalid++; continue; }
        if (l.result.done !== true) { rep.lesson_content.skip++; continue; }     // 只恢复「已完成」的模块
        var cur = byKey[lessonKey(ld, mod, l.difficulty_variant)];
        if (!cur) { rep.lesson_content.skip++; continue; }                       // 云端没有这一天：不硬塞
        if (isObj(cur.result) && cur.result.done === true) { rep.lesson_content.skip++; continue; }
        var bt = tsOf(l.updated_at), ct = tsOf(cur.updated_at);
        var curVer = Number(cur.client_ver || 0);
        if (!isFinite(curVer)) curVer = 0;
        if (!bt) { rep.lesson_content.skip++; continue; }                        // 备份没时间戳：保守跳过
        // 新旧判断必须同时看 updated_at 和 client_ver：实时写入会推进 client_ver，
        // 而 updated_at 可能是历史遗留值；只看其中一个都可能让旧备份覆盖新进度。
        var curBest = Math.max(ct || 0, curVer);
        if (bt <= curBest) { rep.lesson_content.skip++; continue; }
        // 版本号直接用备份时间：不能把旧备份「抬」成比云端更大的版本（那会反过来覆盖新进度）
        var ver = bt;
        try {
          await assertSameAccount(uid);
          var hit = await window.DB.update('lesson_content',
            { result: l.result, client_ver: ver },
            { id: cur.id, user_id: uid, 'client_ver.lt': ver }, { select: true });
          if (hit && hit.length) rep.lesson_content.add++;
          else rep.lesson_content.skip++;
        } catch (e) { rep.lesson_content.fail++; }
      }
    }
    return rep;
  }

  function showRestoreReport(rep, fileName) {
    var box = el('restoreReport');
    if (!box) return;
    function line(name, label) {
      var r = rep[name];
      return '<div class="kv"><span class="muted small">' + label + '</span><span>补 ' + r.add + ' · 跳过 ' + r.skip +
        (r.fail ? ' · 失败 ' + r.fail : '') + (r.invalid ? ' · 忽略 ' + r.invalid : '') + '</span></div>';
    }
    box.innerHTML = '<div class="card tight mt12"><h3 style="margin:0 0 6px">恢复完成</h3>' +
      '<p class="muted small">文件：' + esc(fileName || '') + '</p>' +
      line('mistakes', '错题') + line('weekly_tests', '周测成绩') + line('lesson_content', '模块进度') + '</div>';
  }

  async function doRestore(file) {
    if (!file) return;
    if (file.size > 2 * 1024 * 1024) return toast('备份文件超过 2 MB，为避免页面卡死已停止导入');
    toast('正在读取备份…');
    try {
      var text = await file.text();
      var rep = await restoreFrom(text);
      var total = rep.mistakes.add + rep.weekly_tests.add + rep.lesson_content.add;
      await boot();                       // 先刷新页面，再显示报告（否则报告会被重渲染冲掉）
      showRestoreReport(rep, file.name);
      toast(total ? '恢复完成：补回 ' + total + ' 条记录' : '没有需要补的记录（都已在云端）');
    } catch (err) {
      toast('恢复失败：' + ((err && err.message) || '未知'));
    }
  }

  async function boot() {
    el('view').innerHTML = '<div class="card"><p class="muted">正在读取设置…</p></div>';
    user = await window.AppAuth.requireLogin();
    if (!user) return;
    el('userName').textContent = (window.AppAuth.displayName(user) || '') + ' · 已登录';
    var prof = null, budget = null, pending = 0;
    try { var ps = await window.DB.select('profiles', { id: user.id }); prof = ps && ps[0]; } catch (e) {}
    try { var bs = await window.DB.select('budget_monthly', { user_id: user.id, order: 'month_key.desc', limit: 1 }); budget = bs && bs[0]; } catch (e) {}
    try { if (window.Learn && window.Learn.pendingCount) pending = await window.Learn.pendingCount(); } catch (e) {}
    render(prof || null, budget || null, pending);
  }

  document.addEventListener('change', function (ev) {
    if (ev.target && ev.target.id === 'restoreFile') {
      var f = ev.target.files && ev.target.files[0];
      if (f) doRestore(f);
    }
  });

  document.addEventListener('click', function (ev) {
    var t = ev.target.closest('[data-act]');
    if (!t) return;
    var act = t.getAttribute('data-act');
    if (act === 'export') return doExport();
    if (act === 'restore') {
      var fi = el('restoreFile');
      if (!fi) return toast('页面还没准备好，请刷新重试');
      fi.value = ''; fi.click();
      return;
    }
    if (act === 'sp-toggle') {
      var p1 = window.Speech ? window.Speech.savePrefs({ on: !sp().on }) : null;
      updateSpeechUI();
      return toast(p1 && p1.on ? '已打开发音' : '已关闭发音');
    }
    if (act === 'sp-rate') {
      var p2 = window.Speech ? window.Speech.savePrefs({ rate: Math.abs(sp().rate - 0.85) < 0.01 ? 1 : 0.85 }) : null;
      updateSpeechUI();
      return toast(p2 && p2.rate < 1 ? '已切换为慢速' : '已切换为正常语速');
    }
    if (act === 'sp-auto') {
      var p3 = window.Speech ? window.Speech.savePrefs({ auto: !sp().auto }) : null;
      updateSpeechUI();
      return toast(p3 && p3.auto ? '答题前会自动读一遍' : '答题前不再自动朗读');
    }
    if (act === 'cont-toggle') {
      var cv = false; try { cv = localStorage.getItem('lumi_cont_voice') === '1'; } catch (e) { }
      try { localStorage.setItem('lumi_cont_voice', cv ? '0' : '1'); } catch (e) { }
      updateSpeechUI();
      return toast(cv ? '已关闭连续语音对话' : '已开启：语音回答播完会自动开麦');
    }
    if (act === 'rm-ics') {
      var rt = el('rmTime');
      var val = rt ? rt.value : '';
      if (!/^\d{2}:\d{2}$/.test(val)) return toast('请先选择提醒时间');
      try { localStorage.setItem('lumi_reminder_time', val); } catch (e) { }
      downloadIcs(reminderIcs(val));
      return toast('已生成每日提醒：' + val + '，请在日历里确认添加');
    }
    if (act === 'sp-test') {
      if (!window.Speech || !window.Speech.supported()) return toast('这个浏览器不支持朗读');
      var said = window.Speech.say(window.Speech.testSentence, { force: true });
      updateSpeechUI();
      return toast(said ? '正在朗读：' + window.Speech.testSentence : '朗读失败，点一下页面再试');
    }
    if (act === 'logout') return window.AppAuth.logout();
    if (act === 'flush') {
      if (!window.Learn || !window.Learn.flush) return toast('本机队列未加载');
      window.Learn.flush().then(function (r) {
        var n = r && r.sent ? r.sent.length : 0;
        var d = r && r.dead ? r.dead.length : 0;
        toast(n ? '已补交 ' + n + ' 条' + (d ? '（另有 ' + d + ' 条被服务端拒绝）' : '') : '没有可补交的记录');
        boot();
      })
        .catch(function (e) { toast('补交失败：' + ((e && e.message) || '未知')); });
    }
  });
  
  // 语音列表是异步加载的（尤其 iPhone 首次），加载完刷新一下提示文字
  if (window.speechSynthesis) {
    try {
      window.speechSynthesis.addEventListener('voiceschanged', function () { try { updateSpeechUI(); } catch (e) {} });
    } catch (e) {}
  }
  // 顶栏退出按钮：settings.html 不加载 app.js，必须在这里单独绑定，否则点击无反应
  var btnLogoutTop = document.getElementById('btnLogout');
  if (btnLogoutTop) btnLogoutTop.addEventListener('click', function () { window.AppAuth.logout(); });

  window.addEventListener('error', function (e) { toast('页面脚本错误：' + (e && e.message ? e.message : '未知')); });
  document.addEventListener('DOMContentLoaded', boot);
  if (document.readyState !== 'loading') boot();
})();
