/* 知识点掌握页：只读展示，全部用规则数据，不调 AI。
   数据来源：knowledge_catalog()（静态目录）+ kp_scan(30)（我的证据与状态） */
(function () {
  'use strict';

  var S = { catalog: null, scan: null, days: 30, busy: false };

  var STATE_ZH = {
    new: '还没开始',
    learning: '学习中',
    reviewing: '待巩固',
    mastered: '已掌握'
  };
  var MODULE_ZH = { grammar: '语法', spelling: '拼写', word: '词形与搭配' };
  var MODULE_ORDER = ['grammar', 'spelling', 'word'];

  function $(id) { return document.getElementById(id); }

  function esc(s) {
    return String(s == null ? '' : s).replace(/[&<>"']/g, function (c) {
      return ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' })[c];
    });
  }

  function toast(msg) {
    var t = $('toast');
    if (!t) return;
    t.textContent = msg;
    t.classList.add('show');
    clearTimeout(toast._t);
    toast._t = setTimeout(function () { t.classList.remove('show'); }, 2200);
  }

  function dayLabel(iso) {
    if (!iso) return '';
    return String(iso).slice(0, 10);
  }

  function rows() {
    var cat = Array.isArray(S.catalog) ? S.catalog : [];
    var scan = (S.scan && Array.isArray(S.scan.items)) ? S.scan.items : [];
    var byCode = {};
    scan.forEach(function (x) { byCode[x.code] = x; });
    return cat.map(function (c) {
      var s = byCode[c.code] || {};
      return {
        code: c.code,
        name: c.name || c.code,
        module: c.module || 'grammar',
        rule: c.rule || '',
        check: c.check || '',
        example: c.example || '',
        state: s.state || 'new',
        use_ok: Number(s.use_ok || 0),
        use_bad: Number(s.use_bad || 0),
        evidence: Number(s.evidence || 0),
        streak: Number(s.streak || 0),
        cross: Number(s.cross_evidence || 0),
        next: s.next_check_on || ''
      };
    });
  }

  function kpCard(r) {
    var h = '<div class="kp-item" data-kp="' + esc(r.code) + '">';
    h += '<div class="kp-top"><b>' + esc(r.name) + '</b>';
    h += '<span class="kp-state kp-' + esc(r.state) + '">' + esc(STATE_ZH[r.state] || r.state) + '</span></div>';
    if (r.rule) h += '<div class="kp-rule">' + esc(r.rule) + '</div>';
    if (r.check) h += '<div class="kp-check">小提醒：' + esc(r.check) + '</div>';
    if (r.example) h += '<div class="kp-ex">例：' + esc(r.example) + '</div>';
    var bits = [];
    if (r.use_ok) bits.push('用对 ' + r.use_ok + ' 次');
    if (r.use_bad) bits.push('用错 ' + r.use_bad + ' 次');
    if (r.cross) bits.push('其它模块 ' + r.cross + ' 次');
    if (!bits.length) bits.push('还没有记录，练一次就有数据');
    h += '<div class="kp-meta">' + esc(bits.join(' · ')) + (r.next ? ' · 下次检查 ' + esc(dayLabel(r.next)) : '') + '</div>';
    h += '<div class="kp-acts"><a class="btn ghost sm" href="drill.html?kp=' + encodeURIComponent(r.code) + '">';
    h += (r.state === 'new' ? '开始练' : (r.state === 'mastered' ? '再练一遍' : '继续练')) + '</a></div>';
    h += '</div>';
    return h;
  }

  function bodyHtml() {
    var all = rows();
    var counts = { new: 0, learning: 0, reviewing: 0, mastered: 0 };
    all.forEach(function (r) { counts[r.state] = (counts[r.state] || 0) + 1; });
    var h = '<section class="card kp-head">';
    h += '<div class="kp-h-top"><b>知识点掌握</b><span class="muted">近 ' + S.days + ' 天</span></div>';
    h += '<p class="muted kp-note">只有真正用对才记为掌握证据；写错记薄弱证据。拼写类靠听写和默写，语法与搭配要在写作里用对才算数。</p>';
    h += '<div class="kp-counts">';
    ['mastered', 'reviewing', 'learning', 'new'].forEach(function (k) {
      h += '<span class="kp-c kp-c-' + k + '">' + esc(STATE_ZH[k]) + ' ' + (counts[k] || 0) + '</span>';
    });
    h += '</div></section>';

    MODULE_ORDER.forEach(function (m) {
      var list = all.filter(function (r) { return r.module === m; });
      if (!list.length) return;
      list.sort(function (a, b) {
        var rank = { learning: 0, reviewing: 1, new: 2, mastered: 3 };
        var d = (rank[a.state] == null ? 9 : rank[a.state]) - (rank[b.state] == null ? 9 : rank[b.state]);
        if (d) return d;
        return (b.use_bad + b.use_ok) - (a.use_bad + a.use_ok);
      });
      h += '<section class="card kp-group"><div class="kp-g-title">' + esc(MODULE_ZH[m] || m) + '</div>';
      list.forEach(function (r) { h += kpCard(r); });
      h += '</section>';
    });
    h += '<p class="muted kp-foot">这些状态只根据你自己的作答记录计算，没有让 AI 打分。状态为「已掌握」的知识点如果又写错，会自动退回「待巩固」。</p>';
    return h;
  }

  function render() {
    var view = $('view');
    if (!view) return;
    view.innerHTML = S.busy ? '<div class="card"><p class="muted">正在整理你的知识点…</p></div>' : bodyHtml();
  }

  function load() {
    S.busy = true; render();
    var jobs = [];
    jobs.push(window.DB.rpc('knowledge_catalog', {}).then(function (d) { S.catalog = d || []; }).catch(function () { S.catalog = S.catalog || []; }));
    jobs.push(window.DB.rpc('kp_scan', { p_days: S.days }).then(function (d) { S.scan = d || null; }).catch(function () { S.scan = S.scan || null; }));
    Promise.all(jobs).then(function () {
      S.busy = false; render();
    }).catch(function () { S.busy = false; render(); });
  }

  function bind() {
    var view = $('view');
    if (!view) return;
    view.addEventListener('click', function (ev) {
      var a = ev.target.closest('[data-act]');
      if (!a) return;
      if (a.getAttribute('data-act') === 'reload') { load(); toast('已重新整理'); }
    });
  }

  function boot() {
    window.AppAuth.requireLogin().then(function (user) {
      var n = $('userName');
      if (n) n.textContent = (user && (user.email || '').split('@')[0]) || '';
      bind();
      load();
    }).catch(function () { /* auth 会自己跳登录页 */ });
    var lo = $('btnLogout');
    if (lo) lo.addEventListener('click', function () { window.AppAuth.logout(); });
  }

  if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', boot);
  else boot();
})();