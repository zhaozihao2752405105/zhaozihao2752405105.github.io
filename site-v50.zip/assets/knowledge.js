/* 知识点掌握页：只展示规则数据（状态、用对/用错、下次检查），不调 AI */
(function () {
  'use strict';
  var S = { list: [], due: [], filter: 'all', busy: false };

  var STATE = {
    new: { name: '未开始', cls: 'new' },
    learning: { name: '学习中', cls: 'learning' },
    reviewing: { name: '待巩固', cls: 'reviewing' },
    mastered: { name: '已掌握', cls: 'mastered' }
  };

  function $(s, r) { return (r || document).querySelector(s); }
  function esc(s) {
    return String(s == null ? '' : s).replace(/[&<>"']/g, function (c) {
      return ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' })[c];
    });
  }
  function toast(t) {
    var el = document.getElementById('toast');
    if (!el) { el = document.createElement('div'); el.id = 'toast'; el.className = 'toast'; document.body.appendChild(el); }
    el.textContent = t; el.classList.add('on');
    clearTimeout(el._t); el._t = setTimeout(function () { el.classList.remove('on'); }, 2200);
  }

  function stateOf(it) { return (STATE[it.state] || STATE.new); }

  function itemHtml(it) {
    var st = stateOf(it);
    var parts = [];
    parts.push('<div class="kp-item" data-kp="' + esc(it.code) + '">');
    parts.push('<div class="kp-top"><b>' + esc(it.name) + '</b><span class="kp-state ' + st.cls + '">' + st.name + '</span></div>');
    if (it.rule) parts.push('<div class="kp-rule">' + esc(it.rule) + '</div>');
    var meta = [];
    if (it.use_ok) meta.push('用对 ' + it.use_ok);
    if (it.use_bad) meta.push('用错 ' + it.use_bad);
    if (it.streak) meta.push('连续 ' + it.streak);
    if (it.last_check_at) meta.push('上次复查 ' + String(it.last_check_at).slice(5, 10));
    if (it.next_check_on) meta.push('下次检查 ' + String(it.next_check_on).slice(0, 10));
    if (it.due) meta.push('已到期');
    if (meta.length) parts.push('<div class="kp-meta">' + meta.join(' · ') + '</div>');
    parts.push('<div class="kp-acts"><a class="btn ghost sm" href="drill.html?kp=' + encodeURIComponent(it.code) + '">专项练习</a>');
    if (it.due) {
      parts.push('<button type="button" class="btn sm" data-act="kpcheck" data-ok="1" data-kp="' + esc(it.code) + '">复查：写对了</button>');
      parts.push('<button type="button" class="btn ghost sm" data-act="kpcheck" data-ok="0" data-kp="' + esc(it.code) + '">复查：还没记牢</button>');
    }
    parts.push('</div></div>');
    return parts.join('');
  }

  function filtered() {
    if (S.filter === 'all') return S.list;
    if (S.filter === 'due') return S.list.filter(function (x) { return x.due; });
    return S.list.filter(function (x) { return x.module === S.filter; });
  }

  function render() {
    var list = filtered();
    var box = $('#kpList');
    if (!list.length) {
      if (S.err) {
        box.innerHTML = '<p class="muted">没读到知识点状态，点重试或刷新页面。</p><p class="muted" style="font-size:11px">' + esc(S.err) + '</p>' +
          '<p><button type="button" class="btn sm" data-act="kprefresh">重试</button>' +
          ' <a class="btn ghost sm" href="today.html">回今日</a></p>';
      } else {
        box.innerHTML = '<p class="muted">这个分类还没有记录。做几次听写或写作批改，这里就会长出你自己的薄弱点。</p>';
      }
    } else {
      var dueFirst = list.slice().sort(function (a, b) { return (b.due ? 1 : 0) - (a.due ? 1 : 0); });
      box.innerHTML = dueFirst.map(itemHtml).join('');
    }

    var due = S.list.filter(function (x) { return x.due; });
    var sec = $('#kpDue'), lst = $('#kpDueList'), sub = $('#kpDueSub');
    if (!due.length) { sec.hidden = true; }
    else {
      sec.hidden = false;
      sub.textContent = due.length + ' 个知识点到了该复查的时间';
      lst.innerHTML = due.map(itemHtml).join('');
    }
  }

  function load() {
    if (S.busy) return Promise.resolve();
    S.busy = true;
    return Promise.all([
      window.DB.rpc('kp_list', { p_days: 0 }).catch(function (e) { S.errMsg = 'kp_list: ' + ((e && e.message) || e); return null; }),
      window.DB.rpc('kp_due', { p_limit: 8 }).catch(function (e) { S.errMsg2 = 'kp_due: ' + ((e && e.message) || e); return null; })
    ]).then(function (res) {
      S.err = res[0] ? '' : [S.errMsg, S.errMsg2].filter(Boolean).join(' / ') || '读取失败（可能是登录过期或网络中断）';
      var a = res[0] && (res[0].items ? res[0] : (res[0].data || null));
      if (a && Array.isArray(a.items)) S.list = a.items;
      var b = res[1] && (res[1].items ? res[1] : (res[1].data || null));
      S.due = (b && b.items) || [];
      S.busy = false;
      render();
    }).catch(function () {
      S.busy = false;
      $('#kpList').innerHTML = '<p class="muted">暂时读不到记录，稍后再试。</p>';
    });
  }

  function checked(kp, ok) {
    window.DB.rpc('kp_checked', { p_kp: kp, p_ok: !!ok }).then(function (r) {
      var d = r && (r.data || r);
      if (d && d.ok) {
        toast((ok ? '记下了：这次写对' : '记下了：这次还没记牢') +
          (d.evidence_added ? '，已记一条复查记录' : '，今天已经记过，不重复累加') +
          ' · 下次复查 ' + String(d.next_check_on || '').slice(0, 10));
        return load();
      }
      toast('记录失败，稍后再试');
    }).catch(function () { toast('记录失败，稍后再试'); });
  }

  document.addEventListener('click', function (ev) {
    var t = ev.target.closest('[data-act]');
    if (!t) return;
    var act = t.getAttribute('data-act');
    if (act === 'kpf') {
      S.filter = t.getAttribute('data-f') || 'all';
      Array.prototype.forEach.call(document.querySelectorAll('#kpSeg .kp-btn'), function (b) {
        b.classList.toggle('on', b === t);
      });
      render();
      return;
    }
    if (act === 'kprefresh') {
      S.err = '';
      $('#kpList').innerHTML = '<p class="muted">正在读取…</p>';
      load();
      return;
    }
    if (act === 'kpcheck') {
      ev.preventDefault();
      checked(t.getAttribute('data-kp'), t.getAttribute('data-ok') === '1');
    }
  });

  window.addEventListener('DOMContentLoaded', function () {
    if (!window.AppAuth || !window.AppAuth.requireLogin) { load(); return; }
    try {
      if (window.AppAuth.requireLogin() === false) {
        $('#kpList').innerHTML = '<p class="muted">请先登录，再查看知识点状态。</p>' +
          '<p><a class="btn sm" href="login.html">去登录</a></p>';
        return;
      }
    } catch (e) { /* 忽略：继续尝试读取 */ }
    load();
  });
})();