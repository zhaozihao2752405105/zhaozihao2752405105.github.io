/* ============================================================
 * write.js — 写作训练：按九级难度出题 + AI 批改（error/style/acceptable）
 * 批改只标记客观错误并按 confidence>=0.90 入「语法错题本」，
 * 不因与参考答案不同就判错；查词/统计不耗 AI。
 * ============================================================ */
(function () {
  'use strict';

  var S = {
    level: 3,
    scene: 'daily',
    wmode: 'essay',
    task: null,
    text: '',
    busy: false,
    result: null,
    saved: 0
  };

  var SCENES = [
    ['daily', '日常'], ['work', '工作'], ['study', '学习'], ['travel', '旅行'], ['diary', '日记'], ['rewrite', '改写'], ['free', '随手写']
  ];
  var LV = [
    [1, 'L1'], [2, 'L2'], [3, 'L3'], [4, 'L4'], [5, 'L5'], [6, 'L6'], [7, 'L7'], [8, 'L8'], [9, 'L9']
  ];
  var LS_TASK = 'lumi.write.task.v1';
  var LS_TEXT = 'lumi.write.text.v1';

  function el(id) { return document.getElementById(id); }
  function esc(s) {
    return String(s == null ? '' : s).replace(/[&<>"']/g, function (c) {
      return ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' })[c];
    });
  }
  function words(t) {
    var m = String(t || '').trim().match(/[A-Za-z][A-Za-z'\-]*/g);
    return m ? m.length : 0;
  }
  function store(k, v) { try { localStorage.setItem(k, JSON.stringify(v)); } catch (e) { /* 忽略 */ } }
  function read(k) { try { return JSON.parse(localStorage.getItem(k) || 'null'); } catch (e) { return null; } }

  /* ---------- 出题 ---------- */
  function taskHtml() {
    var t = S.task;
    if (t && t.zh && t.ref_en) {
      var hrefs = '<section class="card w-task">' +
        '<div class="w-task-top"><b>把这句话翻成英文</b><span class="w-task-lv">L' + S.level + '</span></div>' +
        '<div class="w-zh">' + esc(t.zh) + '</div>';
      if (Array.isArray(t.notes) && t.notes.length) {
        hrefs += '<div class="w-tips">' + t.notes.map(function (x) { return '<span class="w-tip">' + esc(x) + '</span>'; }).join('') + '</div>';
      }
      hrefs += '<textarea id="wText" class="w-text" rows="4" spellcheck="false" autocomplete="off" autocorrect="off" autocapitalize="none" placeholder="Write the English sentence…">' + esc(S.text) + '</textarea>' +
        '<div class="w-bar"><span id="wCount" class="w-count">' + words(S.text) + ' 词</span>' +
        '<button type="button" class="btn sm" data-act="grade">让 Lumi 批改</button></div>' +
        '</section>';
      return hrefs;
    }
    if (!t) {
      return '<section class="card w-card"><p class="muted">还没有题目，点「换一题」让 Lumi 出一道。</p>' +
        '<button type="button" class="btn" data-act="newtask">换一题</button></section>';
    }
    var h = '<section class="card w-task">' +
      '<div class="w-task-top"><b>' + esc(t.prompt_zh || '') + '</b><span class="w-task-lv">L' + S.level + '</span></div>' +
      '<div class="w-task-en">' + esc(t.prompt_en || '') + '</div>';
    if (Array.isArray(t.tips) && t.tips.length) {
      h += '<div class="w-tips">' + t.tips.map(function (x) { return '<span class="w-tip">' + esc(x) + '</span>'; }).join('') + '</div>';
    }
    if (Array.isArray(t.zh_hints) && t.zh_hints.length) {
      h += '<div class="w-hints"><div class="w-hints-k">可以顺手翻译这几句：</div>' +
        t.zh_hints.map(function (x) { return '<div class="w-hint-line">' + esc(x) + '</div>'; }).join('') + '</div>';
    }
    h += '<div class="w-meta">建议 ' + (t.min_words || 40) + '–' + (t.max_words || 80) + ' 词</div>';
    h += '<textarea id="wText" class="w-text" rows="7" spellcheck="false" autocomplete="off" autocorrect="off" autocapitalize="none" placeholder="Write here in English…">' + esc(S.text) + '</textarea>';
    h += '<div class="w-bar"><span id="wCount" class="w-count">' + words(S.text) + ' 词</span>' +
      '<button type="button" class="btn sm" data-act="grade">让 Lumi 批改</button></div>';
    h += '</section>';
    return h;
  }

  /* ---------- 批改结果 ---------- */
  function typeZh(t) {
    return ({ error: '错误', style: '更自然', acceptable: '也可以' })[t] || '建议';
  }

  function markedHtml(text, items) {
    var list = (items || []).filter(function (it) {
      return typeof it.start === 'number' && typeof it.end === 'number' && it.end > it.start && it.end <= text.length;
    }).sort(function (a, b) { return a.start - b.start; });
    var out = '', pos = 0;
    list.forEach(function (it) {
      if (it.start < pos) return;
      out += esc(text.slice(pos, it.start));
      out += '<mark class="w-mk ' + esc(it.type || 'style') + '">' + esc(text.slice(it.start, it.end)) + '</mark>';
      pos = it.end;
    });
    out += esc(text.slice(pos));
    return out;
  }

  function resultHtml() {
    var r = S.result;
    if (!r) return '';
    var items = Array.isArray(r.items) ? r.items : [];
    var h = '<section class="card w-res">' +
      '<div class="w-res-head"><b>批改结果</b><span class="small muted">' + (S.saved ? ('已记入语法错题本 ' + S.saved + ' 条') : '只标客观错误，写法差异不扣分') + '</span></div>' +
      '<p class="w-overall">' + esc(r.overall_zh || '') + '</p>';
    h += '<div class="w-orig">' + markedHtml(S.text, items) + '</div>';
    if (items.length) {
      h += '<div class="w-items">';
      items.forEach(function (it) {
        var conf = typeof it.confidence === 'number' ? Math.round(it.confidence * 100) + '%' : '';
        h += '<div class="w-item t-' + esc(it.type || 'style') + '">' +
          '<div class="w-item-top"><span class="w-badge">' + typeZh(it.type) + '</span>' +
          '<span class="w-pair"><s>' + esc(it.original || '') + '</s> → <b>' + esc(it.suggestion || '') + '</b></span>' +
          (conf ? '<span class="w-conf">把握 ' + conf + '</span>' : '') + '</div>' +
          '<div class="w-why">' + esc(it.reason_zh || '') + '</div>' +
          '</div>';
      });
      h += '</div>';
    }
    if (S.task && S.task.ref_en) {
      h += '<div class="w-ref"><div class="w-rewrite-k">参考译法</div>' +
        '<div class="w-rewrite-en">' + esc(S.task.ref_en) + '</div>' +
        '<button type="button" class="btn ghost sm" data-act="sayref">听一遍</button></div>';
    }
    if (r.rewrite_en) {
      h += '<div class="w-rewrite"><div class="w-rewrite-k">更自然的整段写法</div>' +
        '<div class="w-rewrite-en">' + esc(r.rewrite_en) + '</div>' +
        (r.rewrite_zh ? '<div class="w-rewrite-zh">' + esc(r.rewrite_zh) + '</div>' : '') +
        '<button type="button" class="btn ghost sm" data-act="sayrewrite">听一遍</button></div>';
    }
    h += '<div class="w-acts"><button type="button" class="btn ghost sm" data-act="newtask">换一题</button>' +
      '<button type="button" class="btn ghost sm" data-act="edit">再改改</button></div>';
    h += '</section>';
    return h;
  }

  function render() {
    var h = '<section class="v2-welcome"><div class="v2-welcome-date">写作训练</div><h1>写一段，改一遍。</h1>' +
      '<p>按你的难度出题，批改只标客观错误；写法和参考不同不算错。</p></section>';
    h += '<div class="card v2-levels"><div class="v2-levels-tip">练什么</div><div class="v2-seg w-seg">';
    [['essay', '作文'], ['translate', '中译英']].forEach(function (m) {
      var on = S.wmode === m[0] ? ' aria-pressed="true"' : ' aria-pressed="false"';
      h += '<button type="button" class="v2-seg-btn" data-act="wmode" data-wm="' + m[0] + '"' + on + '>' + m[1] + '</button>';
    });
    h += '</div><div class="v2-levels-tip mt10">难度</div><div class="v2-seg w-seg">';
    LV.forEach(function (p) {
      var on = S.level === p[0] ? ' aria-pressed="true"' : ' aria-pressed="false"';
      h += '<button type="button" class="v2-seg-btn" data-act="level" data-lv="' + p[0] + '"' + on + '>' + p[1] + '</button>';
    });
    h += '</div>';
    if (S.wmode !== 'translate') {
      h += '<div class="v2-levels-tip mt10">场景</div><div class="v2-seg w-seg">';
    SCENES.forEach(function (p) {
      var on = S.scene === p[0] ? ' aria-pressed="true"' : ' aria-pressed="false"';
      h += '<button type="button" class="v2-seg-btn" data-act="scene" data-sc="' + p[0] + '"' + on + '>' + p[1] + '</button>';
    });
      h += '</div>';
    }
    h += '</div>';
    h += taskHtml();
    h += resultHtml();
    h += '<p class="small muted w-tip">写作练习不占背单词的复习安排；只有被标为「错误」且把握 ≥ 90% 的条目会进语法错题本。</p>';
    el('view').innerHTML = h;
    var ta = el('wText');
    if (ta) {
      ta.addEventListener('input', function () {
        S.text = ta.value;
        var c = el('wCount');
        if (c) c.textContent = words(S.text) + ' 词';
        store(LS_TEXT, S.text);
      });
    }
  }

  /* ---------- 动作 ---------- */
  async function newTask() {
    if (S.busy) return;
    S.busy = true;
    var btn = document.querySelector('[data-act="newtask"]');
    if (btn) { btn.disabled = true; btn.textContent = '正在出题…'; }
    var r = null;
    try {
      r = await window.AI.invoke('writing', {
        mode: S.wmode === 'translate' ? 'translate' : 'task',
        level: S.level,
        scene: S.scene,
        focus_words: (window.LumiPlan && window.LumiPlan.focusWords) ? window.LumiPlan.focusWords('writing', S.level, 4) : undefined
      }, {});
    } catch (e) { r = null; }
    S.busy = false;
    var d = r && r.data ? r.data : (r && r.body && r.body.data ? r.body.data : null);
    if (!d || (!d.prompt_zh && !d.zh)) {
      render();
      alert((r && (r.message || (r.body && r.body.message))) || '出题暂时不可用，稍后再试。');
      return;
    }
    S.task = d;
    S.result = null;
    S.saved = 0;
    store(LS_TASK, { level: S.level, scene: S.scene, wmode: S.wmode, task: d });
    render();
  }

  async function grade() {
    if (S.busy) return;
    var ta = el('wText');
    var text = ta ? ta.value : S.text;
    S.text = text;
    if (words(text) < 8) { alert('至少写 8 个英文单词再批改。'); return; }
    S.busy = true;
    var btn = document.querySelector('[data-act="grade"]');
    if (btn) { btn.disabled = true; btn.textContent = '正在批改…'; }
    var r = null;
    try {
      r = await window.AI.invoke('writing', {
        mode: 'grade',
        level: S.level,
        prompt: (S.task && (S.task.prompt_en || S.task.prompt_zh || ('把这句中文翻成英文：' + (S.task.zh || '')))) || '',
        text: text
      }, {});
    } catch (e) { r = null; }
    S.busy = false;
    var d = r && r.data ? r.data : (r && r.body && r.body.data ? r.body.data : null);
    if (!d || !d.overall_zh) {
      render();
      alert((r && (r.message || (r.body && r.body.message))) || '批改暂时不可用，稍后再试。');
      return;
    }
    S.result = d;
    S.saved = 0;
    render();
    try {
      await window.DB.rpc('log_writing_session', {
        p_level: S.level,
        p_scene: S.scene,
        p_chars: text.replace(/\s+/g, ' ').trim().length,
        p_errors: (d.items || []).filter(function (x) { return x && x.type === 'error'; }).length
      });
    } catch (e) { /* 记录失败不影响批改结果 */ }
    await saveErrors(text, d.items || []);
  }

  async function saveErrors(text, items) {
    var list = items.filter(function (it) {
      return it && it.type === 'error' && typeof it.confidence === 'number' && it.confidence >= 0.9 &&
        it.suggestion && it.original && String(it.suggestion) !== String(it.original);
    }).slice(0, 6);
    var n = 0;
    for (var i = 0; i < list.length; i++) {
      var it = list[i];
      var seg = (typeof it.start === 'number' && typeof it.end === 'number') ? text.slice(it.start, it.end) : '';
      if (seg !== it.original) continue;
      try {
        var r = await window.DB.rpc('log_writing_mistake', {
          p_original: String(it.original).slice(0, 120),
          p_suggestion: String(it.suggestion).slice(0, 120),
          p_reason: String(it.reason_zh || '').slice(0, 240),
          p_level: S.level
        });
        if (r && r.ok && !r.skipped) n++;
      } catch (e) { /* 忽略 */ }
    }
    S.saved = n;
    var box = document.querySelector('.w-res-head .small');
    if (box) box.textContent = n ? ('已记入语法错题本 ' + n + ' 条') : '只标客观错误，写法差异不扣分';
  }

  /* ---------- 事件 ---------- */
  document.addEventListener('click', async function (ev) {
    var t = ev.target && ev.target.closest ? ev.target.closest('[data-act]') : null;
    if (!t) return;
    var act = t.getAttribute('data-act');
    if (act === 'level') {
      S.level = Number(t.getAttribute('data-lv')) || 3;
      S.task = null; S.result = null;
      render();
      return;
    }
    if (act === 'wmode') {
      var wm = t.getAttribute('data-wm') || 'essay';
      if (wm === S.wmode) return;
      S.wmode = wm; S.task = null; S.result = null; S.text = '';
      store(LS_TASK, null);
      render();
      return;
    }
    if (act === 'sayref') {
      if (window.Speech && S.task && S.task.ref_en) window.Speech.say(S.task.ref_en, { lang: 'en-US', force: true });
      return;
    }
    if (act === 'scene') {
      S.scene = t.getAttribute('data-sc') || 'daily';
      S.task = null; S.result = null;
      render();
      return;
    }
    if (act === 'newtask') { ev.preventDefault(); await newTask(); return; }
    if (act === 'grade') { ev.preventDefault(); await grade(); return; }
    if (act === 'edit') {
      S.result = null;
      render();
      return;
    }
    if (act === 'sayrewrite') {
      if (!S.result || !S.result.rewrite_en) return;
      if (window.Speech && window.Speech.say) {
        try { window.Speech.say(S.result.rewrite_en, { lang: 'en-US', rate: 0.95, force: true }); } catch (e) { /* 忽略 */ }
      }
      return;
    }
  });

  /* ---------- 启动 ---------- */
  (async function boot() {
    el('view').innerHTML = '<div class="card"><p class="muted">正在准备…</p></div>';
    var user = null;
    try { user = await window.AppAuth.requireLogin(); } catch (e) { user = null; }
    if (!user) return;
    var name = '';
    try { name = window.AppAuth.displayName(user) || ''; } catch (e) { name = ''; }
    var u = el('userName');
    if (u) u.textContent = (name ? name + ' · ' : '') + '已登录';
    var saved = read(LS_TASK);
    var savedText = read(LS_TEXT);
    if (typeof savedText === 'string') S.text = savedText;
    if (saved && saved.task) {
      S.level = saved.level || 3;
      S.scene = saved.scene || 'daily';
      S.task = saved.task;
    } else {
      try {
        var ctx = await window.DB.rpc('learning_context', {});
        if (ctx && ctx.levels && ctx.levels.words) S.level = Math.max(1, Math.min(9, ctx.levels.words));
      } catch (e) { /* 忽略 */ }
    }
    render();
  })();
})();