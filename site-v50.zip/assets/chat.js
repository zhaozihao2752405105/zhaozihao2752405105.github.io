/* ============================================================
 * assets/chat.js —— 第 14 步 P1：AI 英语老师（独立聊天页）
 * 约束：唯一 AI 出口是 DB.chatStream（底层仍是 ai-gateway）；B1 起按需附带本人学习档案（DB.learnerProfile），不读取他人数据。
 * 消息由网关写入 conversation_messages，前端只读；前端只写 conversation_sessions。
 * ============================================================ */
(function () {
  'use strict';
  var S = {
    user: null,
    sid: null,            // 当前会话 id；null = 还没建（第一次发消息时创建）
    mode: 'tutor',        // tutor | friend
    level: 1,
    hist: [],             // [{role:'user'|'assistant', content}] 发送上下文
    sessions: [],
    busy: false,
    stream: null,
    started: false,
    autoRead: false,      // AI 回复自动朗读（本机音色，localStorage 记住）
    rec: null,            // 正在进行的录音句柄
    voice: 'idle',        // idle|opening|recording|recognizing|thinking|speaking
    voiceTimer: null,
    voiceTurn: false,     // 本次提问来自语音：回答完要语音回复
    cont: false,          // 连续语音对话：回答播完自动重新开麦（设置页开关）
    contArmed: false,     // 这一轮由语音发起，播完可以接着听
    contTimer: null
  };
  var ERR = {
    not_authenticated: '登录已过期，请回登录页重新登录。',
    month_limit: '本月 AI 预算已用完，下月 1 日自动恢复。学习记录不受影响。',
    daily_limit: '今天的 AI 额度已用完，明天会自动恢复；可以先做单词和学习内容。',
    rate_limited: '刚才调用太频繁，等 1 分钟再问。',
    in_progress: '上一条还在生成，稍等一下。',
    estimate_too_high: '这次内容太长，请分几次问。',
    provider_unavailable: 'AI 服务暂时不可用，已自动停止扣费，过一会儿重试。',
    stream_broken: '网络中断，这次回答不完整；重发一次即可。',
    network: '连不上 AI 服务，请检查网络。',
    session_required: '会话不存在，已为你新建一个。',
    session_not_owned: '会话不存在，已为你新建一个。',
    gateway_misconfigured: '服务端还没配好 AI 密钥，请联系管理员（见教程 B3 步）。'
  };
  function el(id) { return document.getElementById(id); }
  function esc(s) {
    return String(s == null ? '' : s).replace(/[&<>"]/g, function (c) {
      return { '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;' }[c];
    });
  }
  function toast(msg) {
    var t = el('toast'); if (!t) return;
    t.textContent = msg; t.classList.add('on');
    clearTimeout(toast._t);
    toast._t = setTimeout(function () { t.classList.remove('on'); }, 2800);
  }
  function newId() {
    var s = 'chat-' + Date.now().toString(36) + '-' + Math.random().toString(36).slice(2, 8);
    return s.length >= 8 ? s : s + '-0000';
  }
  function hashSid() {
    var m = /(?:^|[#&])s=([^&]+)/.exec(location.hash || '');
    return m ? decodeURIComponent(m[1]) : '';
  }
  function setHash(id) {
    var h = id ? '#s=' + encodeURIComponent(id) : '';
    if ((location.hash || '') !== h) history.replaceState(null, '', location.pathname + location.search + h);
  }
  function fmtTime(s) {
    if (!s) return '';
    var d = new Date(s); if (isNaN(d.getTime())) return '';
    function p2(n) { return n < 10 ? '0' + n : '' + n; }
    return (d.getMonth() + 1) + '-' + p2(d.getDate()) + ' ' + p2(d.getHours()) + ':' + p2(d.getMinutes());
  }
  function scrollBottom(force) {
    var m = el('chatMain'); if (!m) return;
    var near = (m.scrollHeight - m.scrollTop - m.clientHeight) < 160;
    if (force || near) m.scrollTop = m.scrollHeight + 400;
  }

  /* ---------- 消息气泡 ---------- */
  var list, inp, btnSend, btnStop, btnMode, btnHist, histPanel, histList, btnNew, btnMic, btnAuto;

  function clearList() { try { window.Voice && Voice.stop(); } catch (e) {} list.innerHTML = ''; }
  function addBubble(role, text) {
    var wrap = document.createElement('div');
    wrap.className = 'msg ' + (role === 'user' ? 'me' : 'ai');
    var b = document.createElement('div');
    b.className = 'bubble';
    b.textContent = text || '';
    wrap.appendChild(b);
    var meta = document.createElement('div');
    meta.className = 'meta';
    wrap.appendChild(meta);
    list.appendChild(wrap);
    scrollBottom(true);
    return { wrap: wrap, bubble: b, meta: meta };
  }
  function setBubbleText(node, text) {
    node.bubble.textContent = text;
    scrollBottom(false);
  }

  /* ---------- 朗读 / 语音输入（浏览器本机能力，不产生费用） ---------- */
  function canSpeak() { return !!(window.Voice && Voice.ttsSupported); }

  // 统一朗读入口：在线语音可用就走网关（真人音色、中英混读），否则用本机音色
  function speakAny(text, opts) {
    opts = opts || {};
    if (window.Voice.serverTTSReady()) return Voice.serverSpeak(text, opts);
    return Voice.speak(text, opts) ? { total: 1 } : null;
  }

  function attachSpeak(node, text) {
    if (!node || !node.meta || !text || !canSpeak()) return;
    var b = document.createElement('button');
    b.type = 'button';
    b.className = 'speak-btn';
    b.textContent = '🔊 朗读';
    b.addEventListener('click', function () {
      if (window.Voice.speaking()) {
        Voice.stop();
        b.textContent = '🔊 朗读';
        return;
      }
      var h = speakAny(text, {
        rate: 0.92,
        onState: function (st, p) {
          if (st === 'end' || st === 'error') b.textContent = '🔊 朗读';
          if (st === 'start' && b.textContent !== '■ 停止') b.textContent = '■ 停止';
          if (st === 'error' && p && p.code === 'blocked') toast('浏览器拦截了播放，请再点一次');
        }
      });
      if (h) b.textContent = '■ 停止';
    });
    node.meta.appendChild(b);
  }

  function updateAutoBtn() {
    if (!btnAuto) return;
    btnAuto.textContent = S.autoRead ? '朗读：开' : '朗读：关';
    btnAuto.classList.toggle('on', !!S.autoRead);
    btnAuto.title = S.autoRead
      ? 'AI 回复会自动朗读（点击关闭）'
      : 'AI 回复不自动朗读（点击打开；用浏览器本机音色，不花钱）';
  }

  function toggleAuto() {
    S.autoRead = !S.autoRead;
    try { localStorage.setItem('lumi_autoread', S.autoRead ? '1' : '0'); } catch (e) {}
    updateAutoBtn();
    if (!S.autoRead) { try { window.Voice && Voice.stop(); } catch (e) {} }
    toast(S.autoRead ? '以后 AI 回复会自动朗读' : '已关闭自动朗读');
  }

  function micLabel(label, description) {
    if (!btnMic) return;
    btnMic.textContent = label;
    btnMic.title = description;
    btnMic.setAttribute('aria-label', description);
  }

  function micReset() {
    S.rec = null;
    if (btnMic) btnMic.classList.remove('on');
    micLabel('语音', '开始语音输入');
  }

  /* ---------- 语音对话（A2）：一次录音 → 识别 → 自动提问 → 语音回复 ---------- */
  var VOICE_ERR = {
    'not-allowed': '没有麦克风权限：请在浏览器地址栏左侧允许麦克风',
    'no_mic': '没有找到麦克风',
    'too_short': '说话时间太短，说完停顿约 1.2 秒再试',
    'no_speech': '没有听到说话声，点「语音」再说一次',
    'unsupported': '这个浏览器不支持录音，可以直接打字；iPhone 可用键盘话筒键',
    'mic_failed': '麦克风打开失败，检查是否被其他程序占用',
    'recorder_failed': '录音机启动失败，换一个浏览器试试',
    'network': '语音识别需要联网，检查一下网络',
    'timeout': '语音服务响应超时，请再点麦克风试一次',
    'speech_daily_limit': '今天的语音次数已用完，明天自动恢复；还可以打字聊天'
  };

  function voiceBarEl() { return el('voiceBar'); }

  function placeVoiceBar() {
    var b = el('voiceBar'), c = document.querySelector('.composer');
    if (!b || !c) return;
    // 用输入框的实际上边缘定位，输入框因底栏/Netlify 徽标抬升时状态条跟着走。
    var r = c.getBoundingClientRect();
    var bottom = window.innerHeight - r.top + 8;
    b.style.bottom = Math.max(8, Math.round(bottom)) + 'px';
    // 提示条与语音状态条不叠在一起：状态条出现时，toast 抬到状态条上方
    var t = el('toast');
    if (t) {
      var br = b.getBoundingClientRect();
      t.style.bottom = Math.max(8, window.innerHeight - br.top + 10) + 'px';
    }
  }

  function setVoice(st, msg) {
    S.voice = st;
    var bar = voiceBarEl();
    if (S.voiceTimer) { clearInterval(S.voiceTimer); S.voiceTimer = null; }
    if (btnMic) { btnMic.classList.remove('on'); btnMic.classList.remove('busy'); }
    if (st === 'opening') micLabel('取消', '取消打开麦克风');
    else if (st === 'recording') micLabel('说完', '结束录音并发送');
    else if (st === 'speaking') micLabel('打断', '打断朗读并开始录音');
    else if (st === 'recognizing' || st === 'thinking') micLabel('等待', '正在处理语音');
    else micLabel('语音', '开始语音输入');
    if (!bar) return;
    if (st === 'idle') {
      bar.classList.add('hide'); bar.innerHTML = '';
      var tt = el('toast'); if (tt) tt.style.bottom = '';
      return;
    }
    bar.classList.remove('hide');
    placeVoiceBar();
    if (st === 'opening') { bar.innerHTML = '<span>' + esc(msg || '正在打开麦克风…') + '</span> <button type="button" class="linkbtn" data-vact="cancel">取消</button>'; return; }
    if (st === 'recording') {
      if (btnMic) btnMic.classList.add('on');
      bar.innerHTML = '<span class="dot-rec"></span><span>录音中 <b id="vsec">0.0</b> / 15 秒 · 说完停顿约 1.2 秒自动发送</span>' +
        ' <button type="button" class="linkbtn" data-vact="cancel">取消</button>';
      var t0 = Date.now();
      S.voiceTimer = setInterval(function () {
        var s = el('vsec');
        if (!s) return;
        s.textContent = ((Date.now() - t0) / 1000).toFixed(1);
      }, 100);
      return;
    }
    if (st === 'recognizing') { bar.innerHTML = '<span>' + esc(msg || '正在识别这段语音…') + '</span>'; return; }
    if (st === 'thinking') { bar.innerHTML = '<span>' + esc(msg || 'AI 正在想，稍等…') + '</span> <button type="button" class="linkbtn" data-vact="stop">停止</button>'; return; }
    if (st === 'speaking') { bar.innerHTML = '<span>' + esc(msg || '正在朗读回复…') + '</span> <button type="button" class="linkbtn" data-vact="stopvoice">停止朗读</button>'; return; }
  }

  function cancelVoice() {
    S.contArmed = false;
    if (S.contTimer) { clearTimeout(S.contTimer); S.contTimer = null; }
    if (S.rec) { try { S.rec.abort(); } catch (e) {} }
    micReset();
    setVoice('idle');
  }

  // AI 回答的语音回复：在线语音失败时退回本机音色，并说明原因
  function speakReply(text) {
    setVoice('speaking');
    try { window.VoiceLoop && VoiceLoop.noteSpeakStart(); } catch (e) { }
    armBarge();
    speakAny(text, {
      rate: 0.92,
      onState: function (st, p) {
        if (st === 'end') {
          setVoice('idle');
          try { window.VoiceLoop && VoiceLoop.disarm(); } catch (e) { }
          maybeContinue();
          return;
        }
        if (st !== 'error') return;
        setVoice('idle');
        var code = (p && p.code) || '';
        if (code === 'blocked') { toast('浏览器拦截了自动播放，点回复下面的「🔊 朗读」听'); return; }
        if (code === 'speech_daily_limit' || code === 'month_limit' || code === 'site_limit') {
          toast((p && p.message) || '在线语音额度用完了，这条改用本机音色朗读');
        } else {
          toast('在线语音不可用，改用本机音色');
        }
        try {
          Voice.speak(text, { rate: 0.92, onState: function (s) { if (s === 'end' || s === 'error') setVoice('idle'); } });
          setVoice('speaking');
        } catch (e) {}
      }
    });
  }

  /* ---------- A3 免提：朗读期间监听开口，直接打断 ---------- */
  function loopOn() {
    return !!(window.VoiceLoop && VoiceLoop.enabled() && VoiceLoop.supported());
  }

  // 用户开口打断：停音频、停生成、立刻转回录音（不用再点麦克风）
  function bargeIn() {
    try { if (window.VoiceLoop) VoiceLoop.noteBargeDone(); } catch (e) { }
    try { window.Voice && Voice.stop && Voice.stop(); } catch (e) { }
    if (S.busy) { try { stop(); } catch (e) { } }
    setVoice('idle');
    S.contArmed = true;
    setTimeout(function () { if (S.voice === 'idle' && !S.busy) startVoiceTurn(); }, 60);
  }

  // 朗读期间的监听开/关；开关关着就完全不碰麦克风
  function armBarge() {
    if (!loopOn()) return;
    try {
      VoiceLoop.arm({
        threshold: 0.022,
        needMs: 260,
        guardMs: 420,
        onBarge: bargeIn
      });
    } catch (e) { }
  }

  // 连续对话：一轮语音问答播完，等 0.45 秒再自动开麦；关掉开关立即停止
  function maybeContinue() {
    if (!S.cont || !S.contArmed || S.busy) return;
    if (S.contTimer) { clearTimeout(S.contTimer); }
    // 免提模式下不等：播完立刻可以接着说
    var delay = loopOn() ? 0 : 450;
    S.contTimer = setTimeout(function () {
      S.contTimer = null;
      if (!S.cont || !S.contArmed || S.busy || S.voice !== 'idle') return;
      S.contArmed = false;
      startVoiceTurn();
    }, delay);
  }

  function startVoiceTurn() {
    if (S.contTimer) { clearTimeout(S.contTimer); S.contTimer = null; }
    try { window.VoiceLoop && VoiceLoop.disarm(); } catch (e) { }
    if (window.Voice && Voice.primeAudio) { try { Voice.primeAudio(); } catch (e) { } }
    if (!(window.Voice && Voice.serverASRReady && Voice.serverASRReady())) return legacyMic();
    if (S.voice === 'opening') { cancelVoice(); return; }
    if (S.voice === 'recording') { try { S.rec.stop(); } catch (e) {} return; }
    if (S.voice === 'thinking') { toast('等 AI 回答完，或点「停止」'); return; }
    if (S.voice === 'recognizing') { toast('还在识别上一段，稍等'); return; }
    // 打断：朗读中点麦克风 = 停掉当前音频（如果还在生成就一并停掉），然后直接开始录音。
    // 不在这里 return，否则用户要再点一次才能说话。
    if (S.voice === 'speaking') {
      try { Voice.stop(); } catch (e) {}
      setVoice('idle');
      if (S.busy) stop();
    }
    if (S.busy) { toast('等 AI 回答完再说，或点「停止」'); return; }
    // 语音提问默认开自动朗读：否则录完只有文字回答，语音对话不成立
    if (!S.autoRead) {
      S.autoRead = true;
      try { localStorage.setItem('lumi_autoread', '1'); } catch (e) {}
      updateAutoBtn();
      toast('语音对话已开启自动朗读（点顶栏「朗读：开」可关闭）');
    }
    setVoice('opening');
    S.rec = Voice.serverRecord({
      maxMs: 15000,
      onState: function (st) { if (st === 'recording') setVoice('recording'); },
      onText: function (text, meta) {
        S.rec = null;
        S.contArmed = !!S.cont;
        if (window.VoiceLoop) { try { VoiceLoop.noteUserSpeechEnd(); } catch (e) { } }
        if (!text) { setVoice('idle'); toast('没听清，点击麦克风再说一次'); return; }
        inp.value = text; resizeInp();
        S.voiceTurn = true;
        setVoice('thinking');
        send();
      },
      onError: function (code, message, status) {
        S.rec = null; setVoice('idle'); S.contArmed = false;
        if (code === 'cancelled') return;
        if (code === 'speech_daily_limit') { toast(message || VOICE_ERR[code]); return; }
        toast(VOICE_ERR[code] || message || ('语音识别失败：' + code));
      }
    });
    if (!S.rec) setVoice('idle');
  }

  function micToggle() {
    if (window.Voice && Voice.serverASRReady && Voice.serverASRReady()) return startVoiceTurn();
    return legacyMic();
  }

  // 浏览器本机听写（没有服务端语音时的降级路径）
  function legacyMic() {
    if (!(window.Voice && Voice.asrSupported)) {
      toast('这个浏览器不支持语音输入，可以直接打字；iPhone 可用键盘右下角的话筒键');
      return;
    }
    if (S.rec) { try { S.rec.stop(); } catch (e) {} return; }
    var base = (inp.value || '').trim();
    S.rec = Voice.listen({
      lang: 'en-US',
      onStart: function () {
        if (btnMic) btnMic.classList.add('on');
        micLabel('说完', '结束听写');
        toast('在听…说完会自动变成文字');
      },
      onPartial: function (t) {
        inp.value = base ? base + ' ' + t : t;
        resizeInp();
      },
      onEnd: function (t) {
        micReset();
        if (t) { inp.value = base ? base + ' ' + t : t; }
        resizeInp();
        try { inp.focus(); } catch (e) {}
      },
      onError: function (code) {
        micReset();
        if (code === 'cancelled') return;
        var map = {
          'not-allowed': '没有麦克风权限：请在浏览器地址栏左侧允许麦克风',
          'service-not-allowed': '浏览器不允许语音识别，可以直接打字',
          'no-speech': '没听到声音，再说一次',
          'audio-capture': '没有找到麦克风',
          'network': '语音识别需要联网，检查一下网络',
          'unsupported': '这个浏览器不支持语音输入'
        };
        toast(map[code] || ('语音输入失败：' + code));
      }
    });
  }
  function welcome() {
    clearList();
    var box = document.createElement('div');
    box.className = 'card chat-welcome';
    box.innerHTML = '<h3 style="margin:0 0 6px">我是你的 AI 英语老师</h3>' +
      '<p class="muted small" style="margin:0 0 10px">可以直接用中文或英文问我：解释单词和句子、陪我练口语、分析我的问题、讲语法。' +
      (window.Voice && Voice.serverASRReady && Voice.serverASRReady()
        ? '点输入框旁的「语音」开始对话，说完稍作停顿即可发送，也可以点「说完」。朗读时点「打断」可以继续说。<br>'
        : '点输入框旁的「语音」可进行英文听写（需浏览器支持），确认文字后点发送。<br>') +
      '老师会参考你的学习记录（最近错题、到期词、近 14 天正确率）来回答；只读你自己的数据，可在<a href="memory.html">学习档案</a>里查看或关闭。</p>' +
      '<div class="chips" id="chips">' +
      '<button class="chip" data-q="Explain the word arrange with an example.">解释 arrange</button>' +
      '<button class="chip" data-q="Please chat with me about my weekend in simple English.">简单英语陪聊</button>' +
      '<button class="chip" data-q="为什么我总是记不住单词？给我一个能坚持的方法。">背单词方法</button>' +
      '<button class="chip" data-q="Explain the present simple tense in Chinese, with 3 examples.">一般现在时</button>' +
      (window.VoiceLoop && VoiceLoop.supported()
        ? '<button class="chip" id="chipRtv">免提模式：' + (VoiceLoop.enabled() ? '开' : '关') + '</button>'
        : '') +
      '</div>';
    list.appendChild(box);
    Array.prototype.forEach.call(box.querySelectorAll('.chip'), function (c) {
      c.addEventListener('click', function () {
        inp.value = c.getAttribute('data-q') || '';
        resizeInp(); inp.focus();
      });
    });
    var rtv = box.querySelector('#chipRtv');
    if (rtv) {
      rtv.addEventListener('click', function () {
        var on = !VoiceLoop.enabled();
        VoiceLoop.setEnabled(on);
        rtv.textContent = '免提模式：' + (on ? '开' : '关');
        toast(on ? '免提模式已开：AI 说话时直接开口就能打断，播完自动接着听' : '免提模式已关');
      });
    }
    scrollBottom(true);
  }

  /* ---------- 会话 ---------- */
  async function ensureSession() {
    if (S.sid) return S.sid;
    var uid = S.user && S.user.id;
    if (!uid) throw new Error('未登录');
    var res = await DB.insert('conversation_sessions', { user_id: uid, mode: S.mode, status: 'active' });
    var row = (res && res[0]) || null;
    if (!row || !row.id) throw new Error('会话创建失败');
    S.sid = row.id;
    setHash(S.sid);
    S.sessions.unshift(row);
    return S.sid;
  }

  async function loadSessions() {
    try {
      var rows = await DB.select('conversation_sessions', { order: 'last_message_at.desc.nullslast', limit: 30 });
      S.sessions = (rows || []).filter(function (r) { return r && r.status !== 'deleted'; });
    } catch (e) { S.sessions = []; }
    renderHistList();
  }

  function renderHistList() {
    if (!histList) return;
    var rows = S.sessions || [];
    if (!rows.length) { histList.innerHTML = '<p class="muted small" style="padding:10px">还没有历史对话。</p>'; return; }
    var h = '';
    rows.forEach(function (r) {
      var t = r.title || '（新对话）';
      var act = (r.id === S.sid) ? ' active' : '';
      h += '<div class="hist-item' + act + '" data-id="' + esc(r.id) + '">' +
        '<div class="hist-main"><div class="hist-t">' + esc(t) + '</div>' +
        '<div class="muted small">' + esc(fmtTime(r.last_message_at || r.started_at)) + ' · ' + (r.mode === 'friend' ? '陪聊' : '老师') + '</div></div>' +
        '<button class="icon-btn hist-del" data-del="' + esc(r.id) + '" title="删除">✕</button>' +
        '</div>';
    });
    histList.innerHTML = h;
  }

  function openHistPanel() { if (histPanel) { histPanel.classList.remove('hide'); renderHistList(); } }
  function closeHistPanel() { if (histPanel) histPanel.classList.add('hide'); }

  async function openSession(id) {
    if (S.busy) { toast('还在生成，先点「停止」或稍等'); return; }
    var sid = String(id || '');
    if (!sid || sid === S.sid) return;
    clearList();
    list.innerHTML = '<div class="card center"><p class="muted">正在打开…</p></div>';
    var sess = (S.sessions || []).filter(function (r) { return r.id === sid; })[0];
    try {
      if (!sess) {
        var arr = await DB.select('conversation_sessions', { id: sid, limit: 1 });
        sess = (arr && arr[0]) || null;
      }
      if (!sess) { toast('这个对话找不到了'); newChat(); return; }
      S.sid = sid; S.mode = (sess.mode === 'friend') ? 'friend' : 'tutor'; updateModeBtn();
      setHash(sid);
      var msgs = await DB.select('conversation_messages', { session_id: sid, order: 'created_at.asc', limit: 100 });
      clearList();
      S.hist = [];
      var shown = 0;
      (msgs || []).forEach(function (m) {
        if (!m || !m.content) return;
        if (m.role !== 'user' && m.role !== 'assistant') return;
        var bn = addBubble(m.role, m.content);
        if (m.role === 'assistant') attachSpeak(bn, m.content);
        S.hist.push({ role: m.role, content: m.content });
        shown++;
      });
      if (!shown) welcome();
      else scrollBottom(true);
    } catch (e) {
      clearList();
      list.innerHTML = '<div class="card center"><p class="muted">打开失败：' + esc(e && e.message ? e.message : '未知错误') + '</p>' +
        '<button class="btn ghost mt12" id="btnRetryOpen">重试</button></div>';
      var b = el('btnRetryOpen'); if (b) b.addEventListener('click', function () { S.sid = ''; openSession(sid); });
    }
  }

  function newChat(goHash) {
    if (S.busy) { toast('还在生成，先点「停止」或稍等'); return; }
    S.sid = null; S.hist = [];
    if (goHash !== false) setHash('');
    welcome();
    renderHistList();
    updateComposer();
    if (inp) inp.focus();
  }

  async function archiveCurrent() {
    if (!S.sid) { newChat(); closeHistPanel(); return; }
    if (S.busy) { toast('还在生成，先点「停止」'); return; }
    try { await DB.update('conversation_sessions', { status: 'archived' }, { id: S.sid }); } catch (e) {}
    toast('已结束这个对话');
    closeHistPanel();
    newChat();
    await loadSessions();
  }

  async function deleteSession(id) {
    if (!id) return;
    try { var ok = window.confirm('删除这个对话？删除后聊天记录一起删除，不能恢复。'); if (!ok) return; } catch (e) {}
    try {
      await DB.remove('conversation_sessions', { id: id });
      S.sessions = (S.sessions || []).filter(function (r) { return r.id !== id; });
      if (S.sid === id) newChat();
      renderHistList();
      toast('已删除');
    } catch (e) { toast('删除失败：' + (e && e.message ? e.message : '未知错误')); }
  }

  /* ---------- 发送 ---------- */
  // 学习档案缓存：B1 个性化教学用；只缓存成功结果，失败不缓存。
  // 必须按 uid 隔离：同一浏览器换账号后不能把上一个账号的到期词/错题带给 AI（B1 补充要求）。
  var PROFILE_CACHE = { uid: null, at: 0, data: null };
  function clearProfileCache() { PROFILE_CACHE = { uid: null, at: 0, data: null }; }
  window.addEventListener('app:session-changed', clearProfileCache);
  async function getLearnerProfile() {
    var uid = null;
    try { uid = await DB.auth.getUserId(); } catch (e) { uid = null; }
    if (!uid) { clearProfileCache(); return null; }
    var now = Date.now();
    if (PROFILE_CACHE.uid === uid && PROFILE_CACHE.data && now - PROFILE_CACHE.at < 600000) return PROFILE_CACHE.data;
    if (PROFILE_CACHE.uid !== uid) clearProfileCache();
    var p = await DB.learnerProfile();
    if (p) { PROFILE_CACHE = { uid: uid, at: now, data: p }; }
    return p;
  }

  function buildContext(text) {
    var out = [];
    var hist = (S.hist || []).filter(function (m) { return !m.stopped; }).slice(-10);
    hist.forEach(function (m) { out.push({ role: m.role, content: String(m.content || '').slice(0, 1200) }); });
    out.push({ role: 'user', content: String(text).slice(0, 1200) });
    return out.slice(-11);
  }

  function updateComposer() {
    if (btnSend) btnSend.classList.toggle('hide', !!S.busy);
    if (btnStop) btnStop.classList.toggle('hide', !S.busy);
    if (inp) inp.disabled = false;
  }
  function resizeInp() {
    if (!inp) return;
    inp.style.height = 'auto';
    inp.style.height = Math.min(120, Math.max(24, inp.scrollHeight)) + 'px';
  }

  async function send() {
    if (S.busy) return;
    if ((S.voiceTurn || S.autoRead) && window.Voice && Voice.primeAudio) { try { Voice.primeAudio(); } catch (e) { } }
    var text = (inp.value || '').trim();
    if (!text) return;
    if (text.length > 1200) { text = text.slice(0, 1200); toast('单条最多 1200 字，已截断'); }
    // 上一条回复还在朗读时发新消息：先停掉旧音频，避免两条声音叠在一起
    if (S.voice === 'speaking') { try { Voice.stop(); } catch (e) {} setVoice('idle'); }
    var chips = el('chips'); if (chips) { var w = chips.closest('.chat-welcome'); if (w) w.remove(); }
    // 用户消息
    inp.value = ''; resizeInp();
    addBubble('user', text);
    S.hist.push({ role: 'user', content: text });
    var node = addBubble('assistant', '');
    node.bubble.classList.add('typing');
    S.busy = true; updateComposer();
    // 本次发送的代次：用户停止后马上再发，旧请求的收尾不能覆盖新请求的状态
    var myGen = (S.gen = (S.gen || 0) + 1);
    var aborted = false;
    S.markAborted = function () { aborted = true; };
    var acc = '';
    var done = false;
    // 语音提问 / 自动朗读：在生成开始时就建流式朗读句柄，边生成边按句合成。
    // 旧路径只在 onDone 整段朗读，首句要等整段生成完。
    var voiceAsk = !!S.voiceTurn;
    S.voiceTurn = false;
    if (!voiceAsk) S.contArmed = false;
    var wantSpeech = voiceAsk || !!S.autoRead;
    var speakStream = null, speakStarted = false, speakFailed = false;
    try { await ensureSession(); }
    catch (e) {
      if (speakStream) { try { speakStream.stop(); } catch (_e) {} speakStream = null; S.speakStream = null; }
      S.busy = false; updateComposer();
      node.bubble.classList.remove('typing');
      node.meta.textContent = '会话创建失败：' + (e && e.message ? e.message : '未知错误');
      node.meta.classList.add('err');
      return;
    }
    // B1：带上学习档案（到期词、近 7 天出勤、常错词、未解决错题），让老师能按真实进度回答。
    // 读取失败就按无档案继续聊，不阻塞发送；10 分钟内复用，避免每条消息都查一遍。
    var profile = null;
    try { profile = await getLearnerProfile(); } catch (e) { profile = null; }
    var reqId = newId();
    if (wantSpeech && window.Voice && Voice.streamSpeak) {
      try {
        speakStream = Voice.streamSpeak({
          onState: function (st, p) {
            if (st === 'start') {
              speakStarted = true; setVoice('speaking');
              try { window.VoiceLoop && VoiceLoop.noteSpeakStart(); } catch (e) { }
              armBarge();
              return;
            }
            if (st === 'end') {
              setVoice('idle'); S.speakStream = null;
              try { window.VoiceLoop && VoiceLoop.disarm(); } catch (e) { }
              maybeContinue(); return;
            }
            if (st === 'error') {
              speakFailed = true; setVoice('idle'); S.speakStream = null;
              try { window.VoiceLoop && VoiceLoop.disarm(); } catch (e) { }
              if (p && p.code === 'blocked') toast('浏览器拦截了自动播放，点回复下面的「🔊 朗读」听');
            }
          }
        });
      } catch (e) { speakStream = null; }
    }
    S.speakStream = speakStream;
    var st = null;
    // 空闲看门狗：90 秒没有任何数据就按「超时」处理，要和「主动停止」「断网」区分开
    var idleTimer = null;
    var armIdle = function () {
      if (idleTimer) clearTimeout(idleTimer);
      idleTimer = setTimeout(function () {
        if (done || aborted) return;
        aborted = true;
        if (st && st.abort) { try { st.abort(); } catch (e) {} }
        if (speakStream) { try { speakStream.stop(); } catch (e) {} speakStream = null; S.speakStream = null; }
        node.bubble.classList.remove('typing');
        node.bubble.textContent = acc || '（没有收到回复）';
        node.meta.classList.add('err');
        node.meta.textContent = '等待超时：90 秒没有收到 AI 回复，请检查网络后重试。';
        S.busy = false; updateComposer();
      }, 90000);
    };
    try {
      // 同步拿到句柄（含 abort），再等 promise：否则生成期间点「停止」拿不到句柄，
      // 请求不会真的中断（P1-10 实测缺陷，2026-11-20）。
      st = DB.chatStream({
        requestId: reqId,
        sessionId: S.sid,
        mode: S.mode,
        level: S.level,
        messages: buildContext(text),
        profile: profile,
        onMeta: function (m) {
          armIdle();
          if (m && m.duplicate) node.meta.textContent = '（这条之前已经生成过，直接回放）';
        },
        onDelta: function (d) {
          armIdle();
          if (aborted) return;
          acc += d;
          node.bubble.classList.remove('typing');
          setBubbleText(node, acc);
          if (speakStream) speakStream.push(d);
        },
        onDone: function (m) {
          if (aborted) return; // 用户已停止：不把这次结果当作正常完成
          done = true;
          if (idleTimer) { clearTimeout(idleTimer); idleTimer = null; }
          node.bubble.classList.remove('typing');
          if (!acc) setBubbleText(node, '（没有生成内容）');
          var bits = [];
          var u = (m && m.usage) || {};
          if (u.cost_cny != null) bits.push('本次约 ' + Number(u.cost_cny).toFixed(4) + ' 元');
          if (m && m.meta && m.meta.saved === false) bits.push('未保存到云端，刷新后会丢');
          if (m && m.meta && m.meta.billing) bits.push(m.meta.billing === 'settled' ? '已结算' : m.meta.billing);
          node.meta.textContent = bits.join(' · ');
          attachSpeak(node, acc);
          if (speakStream) {
            speakStream.end();
            // 流式首句还没出声就失败：退回整段朗读（有本机音色兜底），避免「只看到文字没声音」
            if (speakFailed && !speakStarted) { S.speakStream = null; speakStream = null; speakReply(acc); }
          } else if (wantSpeech) {
            // 语音提问或自动朗读：整段朗读（没有服务端语音时走本机音色）
            speakReply(acc);
          }
          S.hist.push({ role: 'assistant', content: acc });
          if (S.hist.length > 24) S.hist = S.hist.slice(-24);
        },
        onError: function (code, message) {
          if (idleTimer) { clearTimeout(idleTimer); idleTimer = null; }
          if (aborted) return;
          node.bubble.classList.remove('typing');
          node.meta.classList.add('err');
          var friendly = ERR[code] || (message || 'AI 生成失败，请重试');
          node.meta.textContent = friendly;
          if (speakStream) { try { speakStream.stop(); } catch (e) {} S.speakStream = null; }
          if (!acc) node.bubble.textContent = '（这次没有生成成功）';
          if (code === 'not_authenticated') {
            node.meta.innerHTML += ' <a href="login.html">去登录</a>';
          }
        }
      });
      S.stream = st;
      armIdle();
      await st.promise;
    } catch (e) {
      if (speakStream) { try { speakStream.stop(); } catch (_e) {} speakStream = null; S.speakStream = null; }
      node.bubble.classList.remove('typing');
      node.meta.textContent = '发送失败：' + (e && e.message ? e.message : '未知错误');
    }
    if (idleTimer) { clearTimeout(idleTimer); idleTimer = null; }
    if (S.gen !== myGen) return; // 已被新一次发送接管
    if (!done && !aborted && !acc) {
      // onError 已写过提示，这里只兜底网络中断
      if (!node.meta.textContent) node.meta.textContent = '没有收到回复，请重试。';
    }
    S.busy = false; S.stream = null;
    updateComposer();
    scrollBottom(false);
    loadSessions();
  }

  function stop() {
    S.contArmed = false;
    if (S.contTimer) { clearTimeout(S.contTimer); S.contTimer = null; }
    if (!S.busy) return; // 已经完成/已停止
    // 这条提问没有对应回答：从后续上下文里排除，避免下一条请求被"上一题没答"带偏
    for (var i = (S.hist || []).length - 1; i >= 0; i--) {
      if (S.hist[i].role === 'user') { S.hist[i].stopped = true; break; }
    }
    if (S.markAborted) { try { S.markAborted(); } catch (e) {} }
    if (S.stream && S.stream.abort) { try { S.stream.abort(); } catch (e) {} }
    if (S.speakStream) { try { S.speakStream.stop(); } catch (e) {} S.speakStream = null; }
    S.busy = false; S.stream = null;
    updateComposer();
    var nodes = list.querySelectorAll('.msg.ai .typing');
    Array.prototype.forEach.call(nodes, function (n) { n.classList.remove('typing'); });
    var last = list.querySelector('.msg.ai:last-child .meta');
    if (last && !last.textContent) last.textContent = '已停止生成（这条不会保存成完整回答）';
  }

  /* ---------- 模式 ---------- */
  function updateModeBtn() {
    if (!btnMode) return;
    btnMode.textContent = S.mode === 'friend' ? '陪聊' : '老师';
    btnMode.title = S.mode === 'friend' ? '当前：英文陪聊（点击切换到老师讲解）' : '当前：老师讲解（点击切换到英文陪聊）';
  }
  async function toggleMode() {
    S.mode = (S.mode === 'friend') ? 'tutor' : 'friend';
    updateModeBtn();
    try { await DB.update('profiles', { preferred_mode: S.mode }, { id: S.user.id }); } catch (e) {}
    if (S.sid && !S.busy) {
      try { await DB.update('conversation_sessions', { mode: S.mode }, { id: S.sid }); } catch (e) {}
      var last = list.querySelector('.msg.ai:last-child .meta');
      if (last && !last.textContent) last.textContent = '下一条起使用「' + (S.mode === 'friend' ? '陪聊' : '老师') + '」模式';
    }
  }

  /* ---------- 事件 ---------- */
  function bind() {
    btnSend.addEventListener('click', send);
    btnStop.addEventListener('click', stop);
    btnMode.addEventListener('click', toggleMode);
    if (btnMic) btnMic.addEventListener('click', micToggle);
    var bar = voiceBarEl();
    if (bar) bar.addEventListener('click', function (ev) {
      var t = ev.target.closest ? ev.target.closest('[data-vact]') : null;
      if (!t) return;
      var act = t.getAttribute('data-vact');
      if (act === 'cancel') return cancelVoice();
      if (act === 'stop') { stop(); setVoice('idle'); return; }
      if (act === 'stopvoice') { Voice.stop(); setVoice('idle'); return; }
    });
    if (btnAuto) btnAuto.addEventListener('click', toggleAuto);
    btnNew.addEventListener('click', function () { newChat(); });
    if (btnHist) btnHist.addEventListener('click', openHistPanel);
    if (el('btnHistClose')) el('btnHistClose').addEventListener('click', closeHistPanel);
    if (histList) {
      histList.addEventListener('click', function (ev) {
        var del = ev.target.closest('[data-del]');
        if (del) { ev.stopPropagation(); deleteSession(del.getAttribute('data-del')); return; }
        var item = ev.target.closest('.hist-item');
        if (item && item.getAttribute('data-id')) { closeHistPanel(); openSession(item.getAttribute('data-id')); }
      });
    }
    inp.addEventListener('input', resizeInp);
    var composing = false;
    inp.addEventListener('compositionstart', function () { composing = true; });
    inp.addEventListener('compositionend', function () { composing = false; });
    inp.addEventListener('keydown', function (ev) {
      if (ev.key !== 'Enter') return;
      if (ev.shiftKey || composing || ev.isComposing) return;
      if (window.innerWidth <= 600) return;   // 手机上回车换行，用「发送」按钮
      ev.preventDefault(); send();
    });
    window.addEventListener('resize', function () { if (S.voice !== 'idle') placeVoiceBar(); });
    document.addEventListener('visibilitychange', function () {
      if (document.hidden) {
        try { window.Voice && window.Voice.stop(); } catch (e) {}
        if (S.rec) { try { S.rec.abort(); } catch (e) {} micReset(); }
        setVoice('idle');
        return;
      }
      scrollBottom(false);
    });
    window.addEventListener('pagehide', function () {
      try { window.Voice && window.Voice.stop(); } catch (e) {}
      if (S.rec) { try { S.rec.abort(); } catch (e) {} micReset(); }
      setVoice('idle');
    });
  }

  function boot() {
    list = el('msgList'); inp = el('inp'); btnSend = el('btnSend'); btnStop = el('btnStop');
    btnMode = el('btnMode'); btnHist = el('btnHist'); histPanel = el('histPanel'); histList = el('histList');
    btnNew = el('btnNew');
    btnMic = el('btnMic'); btnAuto = el('btnAuto');
    try { S.autoRead = localStorage.getItem('lumi_autoread') === '1'; } catch (e) {}
    try { S.cont = localStorage.getItem('lumi_cont_voice') === '1'; } catch (e) {}
    updateAutoBtn();
    start().catch(function (e) {
      if (list) list.innerHTML = '<div class="card center"><p class="muted">页面初始化失败：' + esc(e && e.message ? e.message : '未知错误') + '</p></div>';
      console.error(e);
    });
  }

  async function start() {
    var cfg = window.APP_CONFIG || {};
    if (!(cfg.FEATURES && cfg.FEATURES.AI_CHAT === true)) {
      list.innerHTML = '<div class="card center"><h3>AI 英语老师还没开启</h3>' +
        '<p class="muted small">需要先在 assets/core/config.js 里把 FEATURES.AI_CHAT 设为 true。</p></div>';
      return;
    }
    try { S.user = await window.AppAuth.requireLogin(); }
    catch (e) {
      list.innerHTML = '<div class="card center"><p class="muted">暂时无法读取登录状态，请刷新重试。</p></div>';
      return;
    }
    if (!S.user || !S.user.id) {
      if (!document.getElementById('auth-retry')) list.innerHTML = '<div class="card center"><p class="muted">正在确认登录状态…</p></div>';
      return;
    }
    // 打开 Chat 就预热网关：首次语音/文字请求不再吃 4–6 秒冷启动。
    if (DB.warm) { try { DB.warm(); } catch (e) {} }
    // 付费语音是灰度能力：先向服务端确认本账号是否在名单内，再挂麦克风/朗读路径。
    try { if (window.Voice && Voice.initServerAccess) await Voice.initServerAccess(); } catch (e) { }
    try {
      var ps = await DB.select('profiles', { id: S.user.id, limit: 1 });
      if (ps && ps[0] && ps[0].preferred_mode) S.mode = ps[0].preferred_mode === 'friend' ? 'friend' : 'tutor';
    } catch (e) {}
    updateModeBtn();
    bind();
    // 历史面板底部操作
    if (histPanel) {
      var foot = document.createElement('div');
      foot.className = 'hist-foot';
      foot.innerHTML = '<button class="btn ghost sm" id="btnArchive">结束当前对话</button>' +
        '<button class="btn sm" id="btnNew2">新建对话</button>';
      histPanel.appendChild(foot);
      el('btnArchive').addEventListener('click', archiveCurrent);
      el('btnNew2').addEventListener('click', function () { closeHistPanel(); newChat(); });
    }
    await loadSessions();
    var sid = hashSid();
    if (sid) await openSession(sid);
    else welcome();
    updateComposer();
    resizeInp();
  }

  if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', boot);
  else boot();
})();