/* ============================================================
 * assets/stats.js —— 学习统计（30 天）：全部实时聚合，不写 daily_stats
 * 数据来源：study_session（时长）/ study_event（答题）/ word_progress（词量）
 *           lesson_content（四模块）/ mistakes（错题）/ weekly_tests / daily_ai_usage
 * ============================================================ */
(function () {
  'use strict';
  var user = null;
  function el(id) { return document.getElementById(id); }
  function esc(s) {
    return String(s == null ? '' : s).replace(/[&<>"]/g, function (c) {
      return { '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;' }[c];
    });
  }
  function p2(n) { return (n < 10 ? '0' : '') + n; }
  function ymd(d) { return d.getFullYear() + '-' + p2(d.getMonth() + 1) + '-' + p2(d.getDate()); }
  function dkey(s) { return String(s || '').slice(0, 10); }
  function fmtMin(sec) { return Math.round((Number(sec) || 0) / 60); }
  function money(n) { return (Math.round((Number(n) || 0) * 10000) / 10000).toFixed(4); }

  function toast(msg) {
    var t = el('toast'); if (!t) return alert(msg);
    t.textContent = msg; t.classList.add('show');
    clearTimeout(toast._t);
    toast._t = setTimeout(function () { t.classList.remove('show'); }, 2200);
  }

  // 近 30 天柱状图（纯 SVG，不引图表库）：柱高=当天学习分钟数
  function chartSvg(series) {
    var W = 300, H = 88, gap = 1, n = series.length || 1;
    var bw = (W - gap * (n - 1)) / n;
    var max = 1;
    series.forEach(function (r) { if (r.min > max) max = r.min; });
    var out = ['<svg class="chart" viewBox="0 0 ' + W + ' ' + (H + 16) + '" preserveAspectRatio="none" role="img" aria-label="近 30 天每天学习分钟数">'];
    out.push('<line x1="0" y1="' + H + '" x2="' + W + '" y2="' + H + '" stroke="#D8D3E8" stroke-width="1" />');
    series.forEach(function (r, i) {
      var hgt = r.min > 0 ? Math.max(3, Math.round(r.min * (H - 4) / max)) : 0;
      var x = i * (bw + gap);
      var y = H - hgt;
      var title = r.date + '：' + r.min + ' 分钟' + (r.ev ? '，答题 ' + r.ev + ' 次' : '');
      out.push('<rect x="' + x.toFixed(1) + '" y="' + y + '" width="' + bw.toFixed(1) + '" height="' + hgt + '" rx="1.5" fill="' + (r.min > 0 ? '#7C6EDB' : '#E7E3F2') + '"><title>' + esc(title) + '</title></rect>');
    });
    // 横轴只标首尾两个日期，避免小屏挤成一团
    if (series.length) {
      out.push('<text x="0" y="' + (H + 12) + '" font-size="8" fill="#716880">' + esc(series[0].date.slice(5)) + '</text>');
      out.push('<text x="' + W + '" y="' + (H + 12) + '" font-size="8" fill="#716880" text-anchor="end">' + esc(series[series.length - 1].date.slice(5)) + '</text>');
    }
    out.push('</svg>');
    return out.join('');
  }

  function kpi(n, label, sub) {
    return '<div class="kpi"><div class="n">' + n + '</div><div class="l">' + label + (sub ? ' <span class="muted small">' + sub + '</span>' : '') + '</div></div>';
  }

  function pct(x) { return Math.round((Number(x) || 0) * 100); }

  function abilityHtml(ab) {
    if (!ab || ab.ok === false) return '';
    var v = ab.vocabulary || {}, g = ab.grammar || {}, li = ab.listening || {};
    var rd = ab.reading || {}, wr = ab.writing || {}, sp = ab.speaking || {}, sl = ab.spelling || {};
    var dims = [];

    var vEvidence = Number(v.attempts) || 0;
    dims.push({
      k: '词汇', ev: vEvidence,
      score: vEvidence >= 10 ? Math.round(pct(v.accuracy) * 0.7 + Math.min(1, (Number(v.tracked) || 0) / 300) * 30) : null,
      line: '学过 ' + (v.tracked || 0) + ' 个词 · 正确率 ' + (v.accuracy == null ? '—' : pct(v.accuracy) + '%') + ' · 用过提示 ' + pct(v.hint_rate) + '%'
    });

    var gEv = (Number(g.lessons) || 0) + (Number(g.mistakes) || 0);
    dims.push({
      k: '语法', ev: gEv,
      score: gEv >= 3 ? Math.round(Math.min(100, 60 + (Number(g.lessons) || 0) * 4 + (Number(g.mistakes) ? (Number(g.resolved) || 0) * 100 / Number(g.mistakes) : 0) * 0.3)) : null,
      line: '语法课 ' + (g.lessons || 0) + ' 次 · 错题 ' + (g.mistakes || 0) + ' 条（已解决 ' + (g.resolved || 0) + '）'
    });

    var liEv = (Number(li.dictations) || 0) + (Number(li.lessons) || 0);
    dims.push({
      k: '听力', ev: liEv,
      score: liEv >= 5 ? Math.round(pct(li.accuracy) * 0.8 + Math.min(1, (Number(li.lessons) || 0) / 10) * 20) : null,
      line: '听写 ' + (li.dictations || 0) + ' 次 · 正确率 ' + (li.accuracy == null ? '—' : pct(li.accuracy) + '%') + ' · 听力课 ' + (li.lessons || 0) + ' 次'
    });

    var rdEv = (Number(rd.lessons) || 0) + (Number(rd.mistakes) || 0);
    dims.push({
      k: '阅读', ev: rdEv,
      score: rdEv >= 3 ? Math.round(Math.min(100, 55 + (Number(rd.lessons) || 0) * 6 + (Number(rd.resolved) || 0) * 4)) : null,
      line: '阅读课 ' + (rd.lessons || 0) + ' 次 · 阅读错题 ' + (rd.mistakes || 0) + ' 条'
    });

    var wrEv = (Number(wr.mistakes) || 0);
    dims.push({
      k: '写作', ev: wrEv,
      score: wrEv >= 3 ? Math.round(Math.min(100, 55 + wrEv * 5)) : null,
      line: wrEv ? ('批改出的语法点 ' + wrEv + ' 条（已解决 ' + (wr.resolved || 0) + '）') : '还没有写作批改记录'
    });

    var spEv = (Number(sp.voice_sessions) || 0) + (Number(sp.lessons) || 0);
    dims.push({
      k: '口语', ev: spEv,
      score: spEv >= 2 ? Math.round(Math.min(100, 55 + spEv * 6 + Math.min(20, (Number(sp.voice_seconds) || 0) / 60))) : null,
      line: '口语课 ' + (sp.lessons || 0) + ' 次 · 实时对话 ' + (sp.voice_sessions || 0) + ' 次（' + Math.round((Number(sp.voice_seconds) || 0) / 60) + ' 分钟）'
    });

    var h = '<div class="card"><div class="rowline"><h3 style="margin:0">能力档案</h3><span class="muted small">近 ' + (ab.days || 30) + ' 天真实表现</span></div>';
    h += '<div class="ab-grid">';
    dims.forEach(function (x) {
      var ready = x.score != null;
      h += '<div class="ab-item' + (ready ? '' : ' is-empty') + '">' +
        '<div class="ab-top"><b>' + x.k + '</b><span class="ab-score">' + (ready ? x.score : '暂未评估') + '</span></div>' +
        (ready ? '<div class="ab-bar"><i style="width:' + Math.max(4, Math.min(100, x.score)) + '%"></i></div>' : '') +
        '<div class="ab-line">' + esc(x.line) + '</div>' +
        (ready ? '' : '<div class="ab-need">数据还不够，多练几次就会显示</div>') +
        '</div>';
    });
    h += '</div>';
    h += '<p class="muted small" style="margin:10px 0 0">这一页只用你自己的学习记录算分，没有让 AI 打分；数据不足就写「暂未评估」。</p>';
    h += '</div>';
    return h;
  }

  function render(state) {
    var box = el('view');
    if (state.loading) { box.innerHTML = '<div class="card"><p class="muted">正在读取学习记录…</p></div>'; return; }
    if (state.err) { box.innerHTML = '<div class="card"><p class="warn-text">读取失败：' + esc(state.err) + '</p><div class="row mt8"><button class="btn ghost block" data-act="reload">重试</button></div></div>'; return; }
    var d = state.d;
    var h = [];
    h.push('<div class="v2-pagehead"><p class="v2-eyebrow">Your progress</p><h1 class="v2-h1">学习统计</h1><p>每天一点，30 天看得见。数据直接从学习记录汇总。</p></div>');
    h.push('<div class="card v2-stats-hero"><div class="rowline"><h2 style="margin:0">学习概览</h2><span class="muted small">' + d.today + '</span></div>');
    h.push('<div class="kpis mt12">');
    h.push(kpi(d.streak, '连续学习', '天'));
    h.push(kpi(d.activeDays, '累计学习', '天'));
    h.push(kpi(d.totalMin, '累计时长', '分钟'));
    h.push(kpi(d.learned, '学过的词', '个'));
    h.push(kpi(d.rate + '%', '词量正确率', d.finals + ' 次判定'));
    h.push(kpi(d.monthCost, '本月 AI 花费', '元'));
    h.push('</div></div>');

    var hasStudy = d.activeDays > 0;
    h.push('<div class="card"><div class="rowline"><h3 style="margin:0">每天学习分钟</h3><span class="muted small">' + (hasStudy ? '近 30 天 · 最高 ' + d.chartMax + ' 分钟' : '近 30 天') + '</span></div>');
    if (!hasStudy) {
      h.push('<div class="v2-chart-empty"><b>还没有学习数据</b><p class="muted small">开始学习后，这里会按天显示实际学习时长。</p><a class="btn ghost sm" href="today.html">开始今天的学习 →</a></div>');
    } else {
      h.push(chartSvg(d.chart));
      h.push('<p class="muted small" style="margin:6px 0 0">把鼠标/手指放在柱子上看当天数字。空白柱=那天没学。</p>');
    }
    h.push('</div>');

    h.push('<div class="card"><h3 style="margin:0 0 8px">近 30 天</h3>');
    if (!d.rows.length) {
      h.push('<p class="muted">还没有学习记录。去「今日」学一组单词，这里就会有数据。</p>');
    } else {
      h.push('<div class="table-wrap"><table><thead><tr><th>日期</th><th class="num">分钟</th><th class="num">答题</th><th class="num">正确率</th></tr></thead><tbody>');
      d.rows.forEach(function (r) {
        h.push('<tr><td>' + r.date + '</td><td class="num">' + r.min + '</td><td class="num">' + r.ev + '</td><td class="num">' + (r.ev ? r.rate + '%' : '—') + '</td></tr>');
      });
      h.push('</tbody></table></div>');
    }
    h.push('</div>');

    h.push('<div class="card"><h3 style="margin:0 0 8px">四模块（近 14 天）</h3>');
    if (!d.lessonRows.length) {
      h.push('<p class="muted">还没有完成过语法/听力/阅读/口语。去「今日」学完单词后点「继续四模块」。</p>');
    } else {
      h.push('<div class="table-wrap"><table><thead><tr><th>日期</th><th>已完成模块</th></tr></thead><tbody>');
      d.lessonRows.forEach(function (r) {
        h.push('<tr><td>' + r.date + '</td><td>' + r.mods.join('、') + '</td></tr>');
      });
      h.push('</tbody></table></div>');
    }
    h.push('</div>');

    var MODE_ZH = { read:'认知（看得懂）', choice:'词义选择（看得懂）', dictate:'听写（听得出）',
      follow:'跟写（拼得出）', recall:'默写（拼得出）', spell:'拼写（拼得出）', selftest:'自测（自评）',
      practice:'自由练习', legacy:'未标注模式' };
    h.push('<div class="card"><div class="rowline"><h3 style="margin:0">各模式掌握度</h3><span class="muted small">近 30 天</span></div>');
    if (!modeRows.length) {
      h.push('<p class="muted small">还没有按模式记录的作答。新版本的每道作答都会记下用的是哪种模式。</p>');
    } else {
      h.push('<div class="table-wrap"><table><thead><tr><th>模式</th><th class="num">作答</th><th class="num">正确率</th><th class="num">用过提示</th></tr></thead><tbody>');
      modeRows.forEach(function (m) {
        var tot = Number(m.total) || 0, ok = Number(m.correct) || 0, hi = Number(m.hinted) || 0;
        h.push('<tr><td>' + esc(MODE_ZH[m.mode] || m.mode) + '</td><td class="num">' + tot + '</td><td class="num">' +
          (tot ? Math.round(ok * 100 / tot) + '%' : '—') + '</td><td class="num">' + (hi || '—') + '</td></tr>');
      });
      h.push('</tbody></table></div>');
      h.push('<p class="muted small" style="margin:8px 0 0">看得懂 ≠ 听得出 ≠ 拼得出：分开看，才知道哪一项还虚。</p>');
    }
    h.push('</div>');

    var abHtml = abilityHtml(d.ability);
    if (abHtml) h.push(abHtml);

    h.push('<div class="card"><h3 style="margin:0 0 8px">每周测试</h3>');
    if (!d.tests.length) {
      h.push('<p class="muted">还没有测试记录。<a href="test.html">去做本周测试 →</a></p>');
    } else {
      h.push('<div class="table-wrap"><table><thead><tr><th>周起始</th><th class="num">得分</th><th class="num">题数</th></tr></thead><tbody>');
      d.tests.forEach(function (t) {
        var det = t.detail || {};
        h.push('<tr><td>' + esc(t.week_start) + '</td><td class="num">' + t.score + '</td><td class="num">' + (det.total || '—') + '</td></tr>');
      });
      h.push('</tbody></table></div>');
    }
    h.push('</div>');

    h.push('<div class="card"><div class="rowline"><h3 style="margin:0">最近错题（' + d.mistakesTotal + ' 条）</h3><a class="muted small" href="mistakes.html">打开错题本 →</a></div>');
    if (!d.mistakes.length) {
      h.push('<p class="muted">暂时没有错题。答错的词、语法题会自动记到这里。</p>');
    } else {
      h.push('<div class="plainlist">');
      d.mistakes.forEach(function (m) {
        h.push('<div class="kwrow"><div><b>' + esc(m.question) + '</b><div class="muted small">你的答案：' + esc(m.user_answer || '—') + '　正确：' + esc(m.correct_answer || '—') + '</div></div><span class="muted small">' + dkey(m.created_at) + '</span></div>');
      });
      h.push('</div>');
    }
    h.push('</div>');

    h.push('<div class="note mt12">统计是实时从学习记录聚合的（会话时长、答题事件、词进度、四模块内容、错题），不会再写一份 daily_stats，避免两套数字打架。</div>');
    h.push('<div class="row mt12"><button class="btn ghost block" data-act="reload">刷新统计</button></div>');
    box.innerHTML = h.join('');
  }

  async function load(showLoading) {
    var state = { loading: !!showLoading, err: null, d: null };
    if (showLoading) render(state);
    try {
      user = await window.AppAuth.requireLogin();
      if (!user) return;
      el('userName').textContent = (window.AppAuth.displayName(user) || '') + ' · 已登录';
      var uid = user.id;
      var safe = function (p) { return p.catch(function () { return []; }); };
      var res = await Promise.all([
        safe(window.DB.select('study_session', { user_id: uid, order: 'started_at.desc', limit: 200 })),
        safe(window.DB.select('study_event', { user_id: uid, order: 'created_at.desc', limit: 600 })),
        safe(window.DB.select('word_progress', { user_id: uid, limit: 1000 })),
        safe(window.DB.select('lesson_content', { user_id: uid, order: 'lesson_date.desc', limit: 80 })),
        safe(window.DB.select('mistakes', { user_id: uid, order: 'created_at.desc', limit: 100 })),
        safe(window.DB.select('daily_ai_usage', { user_id: uid, order: 'usage_date.desc', limit: 30 })),
        safe(window.DB.select('weekly_tests', { user_id: uid, order: 'week_start.desc', limit: 12 })),
        safe(window.DB.rpc('word_mode_breakdown', { p_days: 30 })),
        safe(window.DB.rpc('ability_profile', { p_days: 30 }))
      ]);
      var sessions = res[0] || [], events = res[1] || [], wp = res[2] || [], lessons = res[3] || [];
      var mis = res[4] || [], usage = res[5] || [], tests = res[6] || [];
      var bd = res[7] || {};
      var modeRows = (bd && bd.ok && bd.rows) ? bd.rows : [];
      var ability = res[8] || {};
      var dayMap = {};
      sessions.forEach(function (s) {
        var k = dkey(s.started_at); if (!k) return;
        if (!dayMap[k]) dayMap[k] = { sec: 0, ev: 0, ok: 0, bad: 0 };
        dayMap[k].sec += Number(s.duration_sec) || 0;
      });
      events.forEach(function (e) {
        var k = dkey(e.created_at); if (!k) return;
        if (!dayMap[k]) dayMap[k] = { sec: 0, ev: 0, ok: 0, bad: 0 };
        if (e.is_final) {
          dayMap[k].ev += 1;
          if (e.result === 'correct') dayMap[k].ok += 1; else dayMap[k].bad += 1;
        }
      });
      var keys = Object.keys(dayMap).sort();
      // 有效学习日：先按天聚合，再过滤（秒数>0 或 有最终事件）。不能简单丢掉 duration=0 的日期——
      // 同一天可能有真实学习事件而会话时长为 0。历史空会话不删，靠这个口径保证累计天数不虚增。
      var validKeys = keys.filter(function (k) { var o = dayMap[k]; return (o.sec > 0) || (o.ev > 0); });
      var today = new Date(); var todayStr = ymd(today);
      var rows = validKeys.slice(-30).reverse().map(function (k) {
        var o = dayMap[k]; var n = o.ok + o.bad;
        return { date: k, min: fmtMin(o.sec), ev: n, rate: n ? Math.round(o.ok * 100 / n) : 0 };
      });
      // 30 天完整日历序列（没学的日子补 0 柱）
      var chart = [], chartMax = 0;
      for (var ci = 29; ci >= 0; ci--) {
        var ck = ymd(new Date(today.getTime() - ci * 86400000));
        var co = dayMap[ck] || { sec: 0, ev: 0 };
        var cmin = fmtMin(co.sec);
        if (cmin > chartMax) chartMax = cmin;
        chart.push({ date: ck, min: cmin, ev: co.ev || 0 });
      }
      var totalSec = sessions.reduce(function (a, s) { return a + (Number(s.duration_sec) || 0); }, 0);
      var finals = events.filter(function (e) { return e.is_final; });
      var okCount = finals.filter(function (e) { return e.result === 'correct'; }).length;
      var streak = 0;
      for (var i = 0; i < 400; i++) {
        var d0 = new Date(today.getTime() - i * 86400000);
        var k0 = ymd(d0);
        if (dayMap[k0] && (dayMap[k0].sec > 0 || dayMap[k0].ev > 0)) { streak += 1; }
        else { if (i === 0) continue; break; }
      }
      var month = todayStr.slice(0, 7);
      var monthCost = 0;
      usage.forEach(function (u) { if (String(u.usage_date || '').slice(0, 7) === month) monthCost += Number(u.total_cost_cny) || 0; });
      var byLesson = {};
      lessons.forEach(function (l) {
        var r = l.result || {};
        if (!r.done) return;
        var k = dkey(l.lesson_date); if (!k) return;
        if (!byLesson[k]) byLesson[k] = [];
        var label = { grammar: '语法', listening: '听力', reading: '阅读', writing: '写作', speaking: '口语' }[l.module] || l.module;
        if (byLesson[k].indexOf(label) < 0) byLesson[k].push(label);
      });
      var lessonRows = Object.keys(byLesson).sort().slice(-14).reverse().map(function (k) { return { date: k, mods: byLesson[k] }; });
      var d = {
        today: todayStr,
        streak: streak,
        activeDays: validKeys.length,
        totalMin: fmtMin(totalSec),
        learned: wp.length,
        rate: finals.length ? Math.round(okCount * 100 / finals.length) : 0,
        finals: finals.length,
        monthCost: money(monthCost),
        chart: chart,
        chartMax: chartMax,
        rows: rows,
        lessonRows: lessonRows,
        tests: tests,
        mistakesTotal: mis.length,
        mistakes: mis.slice(0, 10),
        ability: ability
      };
      render({ loading: false, err: null, d: d });
    } catch (err) {
      render({ loading: false, err: (err && err.message) || String(err), d: null });
    }
  }

  document.addEventListener('click', function (ev) {
    var t = ev.target.closest('[data-act]');
    if (!t) return;
    var act = t.getAttribute('data-act');
    if (act === 'reload') load(true);
  });
  var btnLogout = document.getElementById('btnLogout');
  if (btnLogout) btnLogout.addEventListener('click', function () { window.AppAuth.logout(); });
  window.addEventListener('error', function (e) { toast('页面脚本错误：' + (e && e.message ? e.message : '未知')); });
  window.addEventListener('unhandledrejection', function (e) { toast('请求失败：' + ((e && e.reason && e.reason.message) || '未知')); });

  function boot() { load(true); }
  document.addEventListener('DOMContentLoaded', boot);
  if (document.readyState !== 'loading') boot();
})();
