/* ============================================================
 * assets/core/speech.js —— 单词发音（浏览器内置语音合成）
 * 阶段：单词模块升级「第一批：发音」
 * 设计要点：
 *   1) 零成本、零文件：用系统/浏览器自带的 speechSynthesis，不发请求、不花 AI 预算。
 *   2) iPhone Safari 限制：必须在用户点击事件里直接调 speak()，不允许进页面自动播；
 *      连续点击先 cancel 上一个，避免叠音。
 *   3) 拿不到语音列表时（部分浏览器首次为空）监听 voiceschanged，并在 400ms 后补读一次。
 *   4) 偏好存在 localStorage：开关 / 语速 / 答题前自动朗读；不同步云端（换手机重新设即可）。
 *   5) 如果以后要换成真人录音 MP3：Speech.say() 内部先试 new Audio('assets/audio/us/<word>.mp3')，
 *      失败再回退到这里即可，页面代码不用改。
 * ============================================================ */
window.Speech = (function () {
  'use strict';

  var PREF_KEY = 'eng_speech_prefs_v1';
  var DEFAULT = { on: true, auto: false, rate: 1 };

  function supported() {
    return typeof window !== 'undefined' &&
      'speechSynthesis' in window &&
      typeof window.SpeechSynthesisUtterance === 'function';
  }

  function prefs() {
    var p = { on: DEFAULT.on, auto: DEFAULT.auto, rate: DEFAULT.rate };
    try {
      var raw = window.localStorage.getItem(PREF_KEY);
      if (raw) {
        var o = JSON.parse(raw);
        if (o && typeof o === 'object') {
          if (o.on === false || o.on === true) p.on = o.on;
          if (o.auto === false || o.auto === true) p.auto = o.auto;
          var r = Number(o.rate);
          if (isFinite(r) && r >= 0.5 && r <= 1.5) p.rate = r;
        }
      }
    } catch (e) { /* localStorage 不可用（隐私模式）时用默认值 */ }
    return p;
  }

  function savePrefs(patch) {
    var p = prefs();
    if (patch && typeof patch === 'object') {
      if (patch.on === true || patch.on === false) p.on = patch.on;
      if (patch.auto === true || patch.auto === false) p.auto = patch.auto;
      var r = Number(patch.rate);
      if (isFinite(r) && r >= 0.5 && r <= 1.5) p.rate = r;
    }
    try { window.localStorage.setItem(PREF_KEY, JSON.stringify(p)); } catch (e) {}
    return p;
  }

  var voices = [];
  var voiceHooked = false;

  function loadVoices() {
    if (!supported()) return voices;
    try {
      var v = window.speechSynthesis.getVoices();
      if (v && v.length) voices = v;
    } catch (e) {}
    return voices;
  }

  function hookVoices() {
    if (voiceHooked || !supported()) return;
    voiceHooked = true;
    loadVoices();
    try {
      if (typeof window.speechSynthesis.addEventListener === 'function') {
        window.speechSynthesis.addEventListener('voiceschanged', loadVoices);
      } else {
        window.speechSynthesis.onvoiceschanged = loadVoices;
      }
    } catch (e) {}
  }

  // 择优挑一个英语女声/标准音色：先比语言完全匹配，再比已知好听的音色名，最后随便一个 en-*
  var PREFERRED = ['samantha', 'ava', 'allison', 'karen', 'moira', 'google us english',
    'microsoft aria', 'microsoft zira', 'microsoft jenny', 'microsoft michelle',
    'daniel', 'aaron', 'arthur', 'tom'];

  function pickVoice(lang) {
    var list = voices.length ? voices : loadVoices();
    if (!list || !list.length) return null;
    var want = String(lang || 'en-US').toLowerCase();
    var exact = [], sameBase = [];
    for (var i = 0; i < list.length; i++) {
      var v = list[i];
      if (!v || !v.lang) continue;
      var l = String(v.lang).toLowerCase();
      if (l === want) exact.push(v);
      else if (l.indexOf(want.slice(0, 2)) === 0) sameBase.push(v);
    }
    var pool = exact.length ? exact : sameBase;
    if (!pool.length) return null;
    for (var k = 0; k < PREFERRED.length; k++) {
      for (var j = 0; j < pool.length; j++) {
        if (String(pool[j].name || '').toLowerCase().indexOf(PREFERRED[k]) >= 0) return pool[j];
      }
    }
    return pool[0];
  }

  var lastWord = '';
  var retryTimer = null;

  function stop() {
    if (!supported()) return;
    try { window.speechSynthesis.cancel(); } catch (e) {}
    if (retryTimer) { clearTimeout(retryTimer); retryTimer = null; }
  }

  // 需要在「用户点击」的同一个调用栈里执行（iPhone Safari 的硬性要求）
  function say(text, opt) {
    if (!supported()) return false;
    var p = prefs();
    if (opt && opt.force !== true && p.on !== true) return false;
    var t = String(text == null ? '' : text).replace(/\s+/g, ' ').trim();
    if (!t) return false;
    hookVoices();
    stop();
    lastWord = t;
    var lang = (opt && opt.lang) || 'en-US';
    var utter;
    try {
      utter = new window.SpeechSynthesisUtterance(t);
    } catch (e) {
      return false;
    }
    utter.lang = lang;
    var v = pickVoice(lang);
    if (v) utter.voice = v;
    utter.rate = (opt && opt.rate) || p.rate || 1;
    utter.pitch = 1;
    utter.volume = 1;
    try {
      window.speechSynthesis.speak(utter);
    } catch (e) {
      return false;
    }
    // 首次调用时语音列表可能还没加载好（Chrome/部分安卓），补读一次。
    // iPhone 上这一步可能因离开手势而无声，属已知限制：再点一次喇叭即可。
    if (!voices || !voices.length) {
      retryTimer = setTimeout(function () {
        retryTimer = null;
        if (voices && voices.length) say(lastWord, opt);
      }, 400);
    }
    return true;
  }

  // 只读状态，给设置页显示
  function status() {
    var list = loadVoices();
    var names = [];
    for (var i = 0; i < list.length && names.length < 6; i++) {
      if (list[i] && /^en/i.test(list[i].lang || '')) names.push(list[i].name + ' (' + list[i].lang + ')');
    }
    return { supported: supported(), count: list.length, enVoices: names, prefs: prefs() };
  }

  return {
    supported: supported,
    prefs: prefs,
    savePrefs: savePrefs,
    say: say,
    stop: stop,
    status: status,
    // 设置页「试听」用：读一句包含本系统常见领域词的短句
    testSentence: 'The pressure sensor measures the system pressure.'
  };
})();
