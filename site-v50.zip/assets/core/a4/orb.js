// A4 实时对话的动态圆球：用 Canvas 画一层层柔和的渐变光团，
// 靠音频能量（麦克风 RMS / 老师说话的字流）驱动呼吸与流动，尽量接近 ChatGPT 语音球的手感：
// 慢速有机形变 + 平滑过渡，不做硬边、不做突兀跳动。
(function () {
  'use strict';

  var PALETTE = {
    idle:       [[168, 176, 210], [206, 198, 232]],
    connecting: [[126, 160, 240], [168, 140, 246]],
    listening:  [[34, 195, 166], [78, 141, 245]],
    thinking:   [[140, 120, 246], [86, 176, 246]],
    speaking:   [[122, 90, 248], [232, 106, 208]],
    live:       [[122, 90, 248], [120, 170, 246]]
  };

  function rgba(c, a) { return 'rgba(' + c[0] + ',' + c[1] + ',' + c[2] + ',' + a.toFixed(3) + ')'; }
  function lerp(a, b, t) { return a + (b - a) * t; }

  function create(canvas) {
    if (!canvas || !canvas.getContext) return null;
    var ctx = canvas.getContext('2d');
    var size = 0 , dpr = 1;
    var state = 'idle';
    var level = 0, targetLevel = 0;       // 0..1 平滑后的能量
    var glow = 0, targetGlow = 0;
    var t0 = performance.now();
    var raf = 0;
    var colors = PALETTE.idle.map(function (c) { return c.slice(); });

    function resize() {
      var rect = canvas.getBoundingClientRect();
      var css = Math.max(rect.width, rect.height, 1);
      dpr = Math.min(window.devicePixelRatio || 1, 2);
      size = css;
      canvas.width = Math.round(css * dpr);
      canvas.height = Math.round(css * dpr);
      ctx.setTransform(dpr, 0, 0, dpr, 0, 0);
    }

    function paint(now) {
      var t = (now - t0) / 1000;
      var half = size / 2;
      level += (targetLevel - level) * 0.14;
      glow += (targetGlow - glow) * 0.08;
      var pal = PALETTE[state] || PALETTE.idle;
      var i;
      for (i = 0; i < 2; i++) {
        colors[i][0] = lerp(colors[i][0], pal[i][0], 0.06);
        colors[i][1] = lerp(colors[i][1], pal[i][1], 0.06);
        colors[i][2] = lerp(colors[i][2], pal[i][2], 0.06);
      }
      ctx.clearRect(0, 0, size, size);
      ctx.globalCompositeOperation = 'lighter';

      // 外层光晕：慢慢收放，能量大时更亮更散
      var haloR = half * (0.92 + 0.05 * Math.sin(t * 0.7) + level * 0.16 + glow * 0.1);
      var halo = ctx.createRadialGradient(half, half, half * 0.18, half, half, haloR);
      halo.addColorStop(0, rgba(colors[0], 0.30 + level * 0.12));
      halo.addColorStop(0.55, rgba(colors[1], 0.14 + level * 0.08));
      halo.addColorStop(1, rgba(colors[1], 0));
      ctx.fillStyle = halo;
      ctx.beginPath(); ctx.arc(half, half, haloR, 0, Math.PI * 2); ctx.fill();

      // 内核：几个柔和光团在缓慢的公转上叠加，形成流动感
      var lobes = 5;
      var baseR = half * (0.52 + level * 0.10);
      for (i = 0; i < lobes; i++) {
        var ph = (i / lobes) * Math.PI * 2;
        var spin = t * (0.30 + i * 0.045);
        var wob = 0.16 + 0.05 * Math.sin(t * 0.9 + i);
        var cx = half + Math.cos(spin + ph) * half * wob * (0.7 + level * 0.8);
        var cy = half + Math.sin(spin * 1.17 + ph * 1.3) * half * wob * (0.7 + level * 0.8);
        var r = baseR * (0.78 + 0.22 * Math.sin(t * 1.3 + i * 1.7) + level * 0.16);
        var g = ctx.createRadialGradient(cx, cy, r * 0.1, cx, cy, r);
        var c0 = i % 2 ? colors[1] : colors[0];
        g.addColorStop(0, rgba(c0, 0.42 + level * 0.16));
        g.addColorStop(0.6, rgba(c0, 0.16));
        g.addColorStop(1, rgba(c0, 0));
        ctx.fillStyle = g;
        ctx.beginPath(); ctx.arc(cx, cy, r, 0, Math.PI * 2); ctx.fill();
      }

      // 中心一团高光，让球看起来是实心的
      var coreR = half * (0.34 + level * 0.05);
      var core = ctx.createRadialGradient(half - coreR * 0.18, half - coreR * 0.24, coreR * 0.05, half, half, coreR);
      core.addColorStop(0, 'rgba(255,255,255,' + (0.78 + level * 0.12).toFixed(3) + ')');
      core.addColorStop(0.45, rgba(colors[0], 0.42));
      core.addColorStop(1, rgba(colors[0], 0));
      ctx.fillStyle = core;
      ctx.beginPath(); ctx.arc(half, half, coreR, 0, Math.PI * 2); ctx.fill();

      ctx.globalCompositeOperation = 'source-over';
      raf = requestAnimationFrame(paint);
    }

    function start() { if (!raf) { resize(); raf = requestAnimationFrame(paint); } }
    function stop() { if (raf) { cancelAnimationFrame(raf); raf = 0; } }

    window.addEventListener('resize', function () { if (raf) resize(); });

    return {
      setState: function (next) { if (PALETTE[next]) state = next; start(); },
      getState: function () { return state; },
      // 0..1 的瞬时能量（麦克风大小 / 老师说话强度），内部会平滑
      setLevel: function (v) {
        v = Math.max(0, Math.min(1, Number(v) || 0));
        targetLevel = v;
        targetGlow = state === 'speaking' ? Math.min(1, v * 1.3) : v * 0.5;
      },
      // 老师音频分片到达时喂一点能量，不需要真的解码音频
      pulse: function (amount) {
        var a = Math.max(0, Math.min(1, Number(amount) || 0));
        targetLevel = Math.min(1, Math.max(targetLevel * 0.86, a));
        targetGlow = Math.min(1, targetGlow * 0.9 + a * 0.5);
      },
      start: start,
      stop: stop,
      resize: resize
    };
  }

  window.LumiA4Orb = { create: create };
})();
