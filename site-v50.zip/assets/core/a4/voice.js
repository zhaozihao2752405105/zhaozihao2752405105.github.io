/* A4 实时对话：浏览器原生 WebRTC 直连 Qwen-Omni-Realtime。
 * 服务端只做三件事：鉴权/名单/预算 + 换 Answer SDP（Edge Function a4-webrtc）。长期 Key 永不下发。
 * 媒体（麦克风与模型语音）走 WebRTC 轨道，不再由 Edge Function 转发。
 */
(function () {
  'use strict';
  var cfg = window.CONFIG || window.LUMI_CONFIG || {};
  var SUPABASE_URL = String(cfg.SUPABASE_URL || '').replace(/\/+$/, '');
  var ENDPOINT = SUPABASE_URL + '/functions/v1/a4-webrtc';
  var MAX_SECONDS = 600;            // 服务端也会给上限；这里做客户端硬闸
  var statusEl = document.getElementById('a4Status');
  var timerEl = document.getElementById('a4Timer');
  var orb = document.getElementById('a4Orb');
  var startBtn = document.getElementById('a4Start');
  var endBtn = document.getElementById('a4End');
  var clearBtn = document.getElementById('a4Clear');
  var historyEl = document.getElementById('a4History');
  var draftEl = document.getElementById('a4Draft');
  var noteEl = document.getElementById('a4Note');
  var remoteEl = document.getElementById('a4Remote');

  var S = {
    pc: null, mic: null, sender: null, dc: null, lease: null,
    connected: false, sessionReady: false, updateSent: false, starting: false,
    timer: null, elapsed: 0, usage: { textIn: 0, audioIn: 0, textOut: 0, audioOut: 0 },
    lastInputId: null, renewTimer: null, reconnects: 0, closing: false
  };

  function setStatus(text, state) {
    statusEl.textContent = text;
    if (state && orb) orb.dataset.state = state;
  }
  function setButtons(running) {
    startBtn.disabled = running;
    endBtn.disabled = !running;
    clearBtn.disabled = !running && !historyEl.children.length;
  }
  function fmt(sec) {
    var m = Math.floor(sec / 60), s = sec % 60;
    return (m < 10 ? '0' : '') + m + ':' + (s < 10 ? '0' : '') + s;
  }
  function appendLine(who, text) {
    if (!text) return;
    var li = document.createElement('li');
    li.className = 'a4-line';
    var tag = document.createElement('b');
    tag.textContent = who === 'me' ? '我' : 'Lumi';
    li.appendChild(tag);
    li.appendChild(document.createTextNode(text));
    historyEl.appendChild(li);
    historyEl.scrollTop = historyEl.scrollHeight;
  }

  var MSG = {
    login_required: '登录状态失效了，请重新登录后再试。',
    voice_forbidden: '实时对话还在内测，当前账号暂时用不了；其他练习不受影响。',
    session_busy: '还有一段对话正在结束，请等两三秒再开始。',
    budget_rejected: '今天的语音额度用完了，明天再试；普通练习不受影响。',
    provider_rejected: '语音服务暂时不可用，请稍后再试。',
    provider_unreachable: '连不上语音服务，检查一下网络再试。',
    server_not_configured: '服务端还没配置好，请联系管理员。',
    mic_denied: '没有麦克风权限。请在系统设置里允许 Lumi Words 使用麦克风。',
    network: '网络中断了，对话已经停下；网络恢复后点「开始对话」重新连接。'
  };

  function setNote(text) { noteEl.textContent = text; }

  function startTimer() {
    stopTimer();
    S.elapsed = 0;
    timerEl.hidden = false;
    timerEl.textContent = '已聊 ' + fmt(0);
    S.timer = setInterval(function () {
      S.elapsed += 1;
      timerEl.textContent = '已聊 ' + fmt(S.elapsed);
      var left = MAX_SECONDS - S.elapsed;
      if (left === 60) setStatus('还有 1 分钟，可以继续聊；到时会自动结束，再点开始就好。', 'live');
      if (left <= 0) { setStatus('这一段到 10 分钟了，已自动结束。点「开始对话」继续。', 'idle'); stop(false); }
    }, 1000);
  }
  function stopTimer() { if (S.timer) { clearInterval(S.timer); S.timer = null; } }

  function bindChannel(ch) {
    if (!ch) return;
    ch.onopen = function () { if (ch.label === 'oai-events') S.dc = ch; sendUpdate(); };
    ch.onclose = function () { /* 关闭由整体流程处理 */ };
    ch.onmessage = function (ev) {
      var e; try { e = JSON.parse(ev.data); } catch (x) { return; }
      onEvent(e, ch);
    };
    if (ch.readyState === 'open') ch.onopen();
  }

  function send(obj) {
    if (S.dc && S.dc.readyState === 'open') S.dc.send(JSON.stringify(obj));
  }

  function speakingGuidance() {
    try {
      var D = window.LumiDifficulty;
      if (!D) return '';
      var lv = D.requestLevel(D.preference ? D.preference(null, 'speaking') : null) || 4;
      return D.guidance ? D.guidance('speaking', lv) : '';
    } catch (e) { return ''; }
  }

  function sendUpdate() {
    if (S.updateSent || !S.sessionReady) return;
    S.updateSent = true;
    var guide = speakingGuidance();
    send({
      type: 'session.update',
      session: {
        modalities: ['text', 'audio'],
        voice: 'Tina',
        turn_detection: { type: 'server_vad', silence_duration_ms: 700 },
        instructions: 'You are Lumi, a warm English conversation tutor for a Chinese learner. ' +
          'Answer in short spoken English (1-2 sentences), then add one very short Chinese hint in brackets only when the learner seems stuck. ' +
          'Keep the conversation going with one simple question.' + (guide ? ' ' + guide : '')
      }
    });
  }

  function onEvent(e) {
    var type = e.type;
    if (type === 'session.created') { S.sessionReady = true; sendUpdate(); return; }
    if (type === 'session.updated') { setStatus('可以开始说了。', 'live'); return; }
    if (type === 'input_audio_buffer.speech_started') { orb.dataset.state = 'listening'; draftEl.textContent = ''; return; }
    if (type === 'input_audio_buffer.speech_stopped') { orb.dataset.state = 'thinking'; return; }
    if (type === 'conversation.item.input_audio_transcription.delta') {
      draftEl.textContent = (draftEl.textContent || '') + (e.delta || '');
      return;
    }
    if (type === 'conversation.item.input_audio_transcription.completed') {
      appendLine('me', e.transcript || draftEl.textContent || '');
      draftEl.textContent = '';
      return;
    }
    if (type === 'response.created') { orb.dataset.state = 'speaking'; return; }
    if (type === 'response.audio_transcript.delta') {
      draftEl.textContent = (draftEl.textContent || '') + (e.delta || '');
      return;
    }
    if (type === 'response.audio_transcript.done') {
      appendLine('lumi', e.transcript || draftEl.textContent || '');
      draftEl.textContent = '';
      return;
    }
    if (type === 'response.done') {
      orb.dataset.state = 'live';
      var u = (e.response && e.response.usage) || {};
      var id = u.input_tokens_details || {}, od = u.output_tokens_details || {};
      S.usage.textIn += Number(id.text_tokens) || 0;
      S.usage.audioIn += Number(id.audio_tokens) || 0;
      S.usage.textOut += Number(od.text_tokens) || 0;
      S.usage.audioOut += Number(od.audio_tokens) || 0;
      return;
    }
    if (type === 'error') {
      var msg = (e.error && e.error.message) || '';
      var code = (e.error && e.error.code) || '';
      if (code === 'response_idle_timeout' || /idle_timeout|session was closed/i.test(msg)) {
        scheduleReconnect('空闲太久服务端关了会话，正在重新接上…');
        return;
      }
      if (/already active|conversation/i.test(msg)) return; // 可忽略的并发提示
      setNote('服务端提示：' + (msg || '未知错误'));
    }
  }

  async function token() {
    var t = await window.DB.auth.getAccessToken();
    if (!t) throw new Error('login_required');
    return t;
  }

  function waitIce(pc) {
    return new Promise(function (resolve) {
      if (pc.iceGatheringState === 'complete') return resolve();
      var done = false;
      var finish = function () { if (!done) { done = true; resolve(); } };
      setTimeout(finish, 4000);   // 4 秒够拿到 host/srflx，srflx 慢也不阻塞
      pc.addEventListener('icegatheringstatechange', function () { if (pc.iceGatheringState === 'complete') finish(); });
      pc.addEventListener('icecandidate', function (e) { if (!e.candidate) finish(); });
    });
  }

  async function start() {
    if (S.starting || S.connected) return;
    S.starting = true;
    setButtons(true);
    setStatus('正在连接…', 'connecting');
    setNote('第一次会请求麦克风权限。');
    try {
      var jwt = await token();
      S.mic = await navigator.mediaDevices.getUserMedia({
        audio: { echoCancellation: true, noiseSuppression: true, autoGainControl: true, channelCount: 1 }
      });
    } catch (err) {
      S.starting = false; setButtons(false);
      var denied = err && (err.name === 'NotAllowedError' || err.name === 'SecurityError');
      setStatus(denied ? MSG.mic_denied : MSG.network, 'idle');
      setNote('');
      return;
    }

    var pc = new RTCPeerConnection({ iceServers: [{ urls: 'stun:stun.l.google.com:19302' }] });
    S.pc = pc;
    var remoteStream = new MediaStream();
    pc.ontrack = function (ev) {
      if (ev.track.kind === 'audio') {
        remoteStream.addTrack(ev.track);
        remoteEl.srcObject = remoteStream;
        remoteEl.play().catch(function () { setNote('点一下页面任意位置即可听到声音。'); });
      }
    };
    pc.ondatachannel = function (ev) { bindChannel(ev.channel); };
    bindChannel(pc.createDataChannel('oai-events'));

    var tx = pc.addTransceiver(S.mic.getAudioTracks()[0], { direction: 'sendrecv' });
    S.sender = tx.sender;

    pc.onconnectionstatechange = function () {
      if (pc.connectionState === 'connected') {
        S.connected = true; S.starting = false;
        setStatus('可以开始说了。', 'live');
        setNote('说完停一下就好，不用点任何按钮。');
        startTimer();
        S.reconnects = 0;
        startRenew();
      } else if (pc.connectionState === 'failed' || pc.connectionState === 'disconnected') {
        if ((S.connected || S.starting) && !S.closing) {
          scheduleReconnect(MSG.network);
        }
      }
    };

    try {
      var offer = await pc.createOffer();
      await pc.setLocalDescription(offer);
      await waitIce(pc);
      S.lease = (window.crypto && crypto.randomUUID) ? crypto.randomUUID()
        : '00000000-0000-4000-8000-' + String(Date.now()).slice(-12);
      var res = await fetch(ENDPOINT + '?requestId=' + encodeURIComponent(S.lease), {
        method: 'POST',
        headers: { 'Content-Type': 'application/sdp', Authorization: 'Bearer ' + jwt },
        body: pc.localDescription.sdp
      });
      if (!res.ok) {
        var data = {};
        try { data = await res.json(); } catch (x) {}
        var key = String(data.error || 'network');
        throw new Error(MSG[key] ? key : 'provider_rejected');
      }
      var maxSec = Number(res.headers.get('X-A4-Max-Seconds'));
      if (maxSec > 0) MAX_SECONDS = Math.min(MAX_SECONDS, maxSec);
      var answer = (await res.text()).trim().replace(/\r?\n/g, '\r\n') + '\r\n';
      await pc.setRemoteDescription({ type: 'answer', sdp: answer });
      setStatus('已连上，正在准备老师…', 'connecting');
    } catch (err) {
      S.starting = false;
      var code = err && err.message;
      setStatus(MSG[code] || MSG.network, 'idle');
      setNote('');
      stop(true);
    }
  }

  // 每 90 秒续一次租约：服务端顺手查本月剩余额度，不足 0.01 元就拒绝，客户端立刻收尾。
  function startRenew() {
    stopRenew();
    S.renewTimer = setInterval(function () {
      if (!S.lease) return;
      var lease = S.lease;
      token().then(function (jwt) {
        return fetch(ENDPOINT + '?action=renew', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json', Authorization: 'Bearer ' + jwt },
          body: JSON.stringify({ leaseId: lease })
        });
      }).then(function (res) {
        return res.json().catch(function () { return {}; }).then(function (data) {
          if (res.ok && data && data.ok) return;
          var code = String((data && data.error) || 'network');
          setNote(MSG[code] || MSG.network);
          stop(false);
        });
      }).catch(function () { /* 单次续租失败先不打断，下一轮再试 */ });
    }, 90000);
  }
  function stopRenew() { if (S.renewTimer) { clearInterval(S.renewTimer); S.renewTimer = null; } }

  // 服务端会因为「5 分钟没有生成回复」主动关会话（response_idle_timeout），
  // 网络抖动也会把 Transceiver 打断。两者都做透明重连，最多 3 次，字幕与用量不清空。
  function scheduleReconnect(reasonText) {
    if (S.closing || !S.lease) return;
    if (S.reconnects >= 3) { setNote(reasonText || '连接断开，请重新开始。'); stop(false); return; }
    S.reconnects += 1;
    var lease = S.lease;
    stopRenew();
    try { if (S.pc) S.pc.close(); } catch (e) {}
    try { if (S.mic) S.mic.getTracks().forEach(function (t) { t.stop(); }); } catch (e) {}
    S.pc = null; S.mic = null; S.dc = null; S.connected = false; S.sessionReady = false;
    S.updateSent = false; S.starting = false; S.lease = null;
    token().then(function (jwt) {
      return fetch(ENDPOINT + '?action=abort', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json', Authorization: 'Bearer ' + jwt },
        body: JSON.stringify({ leaseId: lease })
      });
    }).catch(function () {});
    setStatus('连接断了一下，正在自动接回…', 'connecting');
    stopTimer();
    setTimeout(function () { start(); }, 500);
  }

  function stop(silent) {
    var wasOpen = S.lease;
    var seconds = S.elapsed;
    S.closing = true;
    stopRenew();
    stopTimer();
    try { if (S.mic) S.mic.getTracks().forEach(function (t) { t.stop(); }); } catch (e) {}
    try { if (S.pc) S.pc.close(); } catch (e) {}
    S.pc = null; S.mic = null; S.dc = null; S.connected = false; S.sessionReady = false;
    S.updateSent = false; S.starting = false;
    S.lease = null;
    setButtons(false);
    if (!silent) setStatus('已结束。点「开始对话」再来一段。', 'idle');
    orb.dataset.state = 'idle';
    timerEl.hidden = true;
    setTimeout(function () { S.closing = false; }, 1200);
    if (wasOpen) {
      // 结算：服务端按真实用量扣费并释放租约；失败也不影响本地体验
      token().then(function (jwt) {
        return fetch(ENDPOINT + '?action=settle', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json', Authorization: 'Bearer ' + jwt },
          body: JSON.stringify({ leaseId: wasOpen, seconds: seconds, usage: S.usage })
        });
      }).catch(function () {});
    }
  }

  startBtn.addEventListener('click', start);
  endBtn.addEventListener('click', function () { stop(false); });
  clearBtn.addEventListener('click', function () { historyEl.innerHTML = ''; draftEl.textContent = ''; });

  // 启动自检：登录 + 灰度名单
  (async function boot() {
    try {
      var uid = await window.DB.auth.getUserId();
      if (!uid) {
        setStatus('还没登录，去登录后再回来。', 'idle');
        startBtn.disabled = true;
        var a = document.createElement('a');
        a.href = 'login.html?next=a4-voice.html';
        a.textContent = '去登录';
        a.className = 'btn';
        startBtn.parentNode.insertBefore(a, startBtn.nextSibling);
        return;
      }
      var jwt = await token();
      var res = await fetch(SUPABASE_URL + '/rest/v1/rpc/voice_access', {
        method: 'POST',
        headers: { apikey: cfg.ANON_KEY, Authorization: 'Bearer ' + jwt, 'Content-Type': 'application/json' },
        body: '{}'
      });
      var access = await res.json().catch(function () { return {}; });
      if (!access || access.allowed !== true) {
        setStatus(MSG.voice_forbidden, 'idle');
        startBtn.disabled = true;
        return;
      }
      setStatus('准备好了。点「开始对话」，允许麦克风后直接说话。', 'idle');
    } catch (err) {
      setStatus('准备好了。点「开始对话」试试。', 'idle');
    }
  })();

  window.addEventListener('pagehide', function () { if (S.lease) stop(true); });
})();