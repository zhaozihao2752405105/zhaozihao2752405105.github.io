/* A4 实时对话：浏览器原生 WebRTC 直连 Qwen-Omni-Realtime。
 * 服务端只做三件事：鉴权/名单/预算 + 换 Answer SDP（Edge Function a4-webrtc）。长期 Key 永不下发。
 * 媒体（麦克风与模型语音）走 WebRTC 轨道，不再由 Edge Function 转发。
 */
(function () {
  'use strict';
  var cfg = window.APP_CONFIG || window.CONFIG || window.LUMI_CONFIG || {};
  var SUPABASE_URL = String(cfg.SUPABASE_URL || '').replace(/\/+$/, '');
  var ANON_KEY = String(cfg.ANON_KEY || cfg.SUPABASE_ANON_KEY || '');
  var ENDPOINT = SUPABASE_URL + '/functions/v1/a4-webrtc';
  var MAX_SECONDS = 600;            // 服务端也会给上限；这里做客户端硬闸
  var statusEl = document.getElementById('a4Status');
  var timerEl = document.getElementById('a4Timer');
  var orb = document.getElementById('a4Orb');
  var orbView = (window.LumiA4Orb && document.getElementById('a4OrbCv'))
    ? window.LumiA4Orb.create(document.getElementById('a4OrbCv')) : null;
  function setOrb(state) {
    if (orb) orb.dataset.state = state;
    if (orbView) orbView.setState(state);
  }
  var startBtn = document.getElementById('a4Start');
  var endBtn = document.getElementById('a4End');
  var clearBtn = document.getElementById('a4Clear');
  var historyEl = document.getElementById('a4History');
  var draftEl = document.getElementById('a4Draft');
  var noteEl = document.getElementById('a4Note');
  var remoteEl = document.getElementById('a4Remote');

  // iOS 静音拨片：WebRTC 的远端声音走的是录音音频单元，拨到静音时会被苹果直接静掉。
  // 两条对策都在用户点击（手势）链里做：把 audioSession 设成 play-and-record，
  // 并让一个零样本的 <audio> 循环播放，把音频通路固定在「媒体播放」上。
  var keepAliveEl = null;
  function silentWav() {
    try { if (window.LumiA3 && LumiA3.silentMediaSource) return LumiA3.silentMediaSource(); } catch (e) {}
    var bytes = new Uint8Array(44 + 1600), view = new DataView(bytes.buffer);
    [[0, 'RIFF'], [8, 'WAVEfmt '], [36, 'data']].forEach(function (pair) {
      for (var i = 0; i < pair[1].length; i++) bytes[pair[0] + i] = pair[1].charCodeAt(i);
    });
    view.setUint32(4, bytes.length - 8, true); view.setUint32(16, 16, true);
    view.setUint16(20, 1, true); view.setUint16(22, 1, true);
    view.setUint32(24, 8000, true); view.setUint32(28, 16000, true);
    view.setUint16(32, 2, true); view.setUint16(34, 16, true);
    view.setUint32(40, 1600, true);
    var out = '';
    for (var k = 0; k < bytes.length; k++) out += String.fromCharCode(bytes[k]);
    return 'data:audio/wav;base64,' + btoa(out);
  }
  function iosAudioKeepAlive(on) {
    try {
      if (navigator.audioSession) navigator.audioSession.type = on ? 'play-and-record' : 'auto';
    } catch (e) {}
    if (!on) {
      if (keepAliveEl) { try { keepAliveEl.pause(); } catch (e) {} }
      return;
    }
    try {
      if (!keepAliveEl) {
        keepAliveEl = document.createElement('audio');
        keepAliveEl.loop = true;
        keepAliveEl.playsInline = true;
        keepAliveEl.preload = 'auto';
        keepAliveEl.hidden = true;
        keepAliveEl.src = silentWav();
        document.body.appendChild(keepAliveEl);
      }
      var job = keepAliveEl.play();
      if (job && job.catch) job.catch(function () {});
    } catch (e) {}
  }

  var S = {
    pc: null, mic: null, sender: null, dc: null, lease: null,
    connected: false, sessionReady: false, updateSent: false, starting: false,
    timer: null, elapsed: 0, usage: { textIn: 0, audioIn: 0, textOut: 0, audioOut: 0 },
    lastInputId: null, renewTimer: null, reconnects: 0, closing: false,
    said: [], heard: []
  };

  function setStatus(text, state) {
    statusEl.textContent = text;
    if (state && orb) orb.dataset.state = state;
  }
  function setButtons(running) {
    startBtn.disabled = running;
    endBtn.disabled = !running;
    clearBtn.disabled = !running && !historyEl.children.length;
  }
  function fmt(sec) {
    var m = Math.floor(sec / 60), s = sec % 60;
    return (m < 10 ? '0' : '') + m + ':' + (s < 10 ? '0' : '') + s;
  }
  var RECALL = [];
  // 字幕容器是 .a4-captions（<ol> 自己不滚动），而且用户往上翻的时候不能强行拽回底部。
  function capbox() {
    return (historyEl && historyEl.closest) ? (historyEl.closest('.a4-captions') || historyEl.parentNode) : historyEl;
  }
  function nearBottom(box) {
    if (!box) return true;
    return box.scrollHeight - box.scrollTop - box.clientHeight < 48;
  }
  var stickBottom = true;
  function scrollCaps(force) {
    var box = capbox();
    if (!box) return;
    if (!force && !stickBottom) return;
    box.scrollTop = box.scrollHeight;
    stickBottom = true;
    hideJump();
  }
  var jumpBtn = null;
  function hideJump() { if (jumpBtn) { jumpBtn.hidden = true; } }
  function ensureJump() {
    if (jumpBtn) return jumpBtn;
    var box = capbox();
    if (!box || !box.parentNode) return null;
    jumpBtn = document.createElement('button');
    jumpBtn.type = 'button';
    jumpBtn.className = 'a4-jump';
    jumpBtn.textContent = '↓ 回到最新';
    jumpBtn.hidden = true;
    jumpBtn.addEventListener('click', function () { scrollCaps(true); });
    box.parentNode.insertBefore(jumpBtn, box.nextSibling);
    return jumpBtn;
  }
  function watchCaps() {
    var box = capbox();
    if (!box || box.dataset.stickReady) return;
    box.dataset.stickReady = '1';
    box.addEventListener('scroll', function () {
      stickBottom = nearBottom(box);
      var b = ensureJump();
      if (b) b.hidden = stickBottom;
    }, { passive: true });
    ensureJump();
  }

  function appendLine(who, text) {
    if (!text) return;
    RECALL.push((who === 'me' ? 'Learner: ' : 'Lumi: ') + String(text).slice(0, 160));
    if (who === 'me') S.said.push(String(text).slice(0, 400));
    else S.heard.push(String(text).slice(0, 400));
    if (RECALL.length > 8) RECALL.splice(0, RECALL.length - 8);
    // 只有最新一句高亮，旧的退成普通样式
    var prev = historyEl.querySelectorAll('.a4-line.is-last');
    for (var i = 0; i < prev.length; i++) prev[i].classList.remove('is-last');
    var li = document.createElement('li');
    li.className = 'a4-line is-last' + (who === 'me' ? ' is-me' : ' is-lumi');
    var tag = document.createElement('b');
    tag.textContent = who === 'me' ? '我' : 'Lumi';
    li.appendChild(tag);
    li.appendChild(document.createTextNode(text));
    historyEl.appendChild(li);
    watchCaps();
    scrollCaps(true);
  }

  // 麦克风电平（只读本地采集，不额外录音、不上传）
  var micRaf = 0, micCtx = null, micAnalyser = null;
  function startMicMeter() {
    if (!orbView || !S.mic || micAnalyser) return;
    try {
      var AC = window.AudioContext || window.webkitAudioContext;
      if (!AC) return;
      micCtx = new AC();
      var src = micCtx.createMediaStreamSource(S.mic);
      micAnalyser = micCtx.createAnalyser();
      micAnalyser.fftSize = 512;
      micAnalyser.smoothingTimeConstant = 0.7;
      src.connect(micAnalyser);
      var buf = new Uint8Array(micAnalyser.frequencyBinCount);
      var tick = function () {
        if (!micAnalyser || !orbView) return;
        micAnalyser.getByteTimeDomainData(buf);
        var sum = 0;
        for (var i = 0; i < buf.length; i++) { var d = (buf[i] - 128) / 128; sum += d * d; }
        var rms = Math.sqrt(sum / buf.length);
        // 说话时大约 0.02–0.25，压缩成 0..1 并放大对小声的敏感度
        var lv = Math.min(1, Math.pow(rms * 5.2, 0.85));
        if (orbView.getState() !== 'speaking') orbView.setLevel(lv);
        micRaf = requestAnimationFrame(tick);
      };
      tick();
    } catch (e) { /* 电平表失败不影响通话 */ }
  }
  function stopMicMeter() {
    if (micRaf) { cancelAnimationFrame(micRaf); micRaf = 0; }
    micAnalyser = null;
    if (micCtx) { try { micCtx.close(); } catch (e) {} micCtx = null; }
  }

  var MSG = {
    login_required: '登录状态失效了，请重新登录后再试。',
    voice_forbidden: '实时对话还在内测，当前账号暂时用不了；其他练习不受影响。',
    session_busy: '还有一段对话正在结束，请等两三秒再开始。',
    budget_rejected: '今天的语音额度用完了，明天再试；普通练习不受影响。',
    provider_rejected: '语音服务暂时不可用，请稍后再试。',
    provider_unreachable: '连不上语音服务，检查一下网络再试。',
    server_not_configured: '服务端还没配置好，请联系管理员。',
    mic_denied: '没有麦克风权限。请在系统设置里允许 Lumi Words 使用麦克风。',
    mic_hint: '浏览器地址栏左侧的图标里可以重新允许麦克风。',
    network: '网络中断了，对话已经停下；网络恢复后点「开始对话」重新连接。'
  };

  function setNote(text) { noteEl.textContent = text; }

  // 连接分段计时：权限 / 换 SDP / 媒体连通 / 首音。出问题时能一眼看出卡在哪一段。
  var MARKS = {};
  function mark(name) {
    if (!S.t0 || MARKS[name] != null) return;
    MARKS[name] = Math.round(Date.now() - S.t0);
  }
  function stageLine() {
    var parts = [];
    if (MARKS.token != null) parts.push('登录 ' + (MARKS.token / 1000).toFixed(1) + 's');
    if (MARKS.mic != null) parts.push('麦克风 ' + (MARKS.mic / 1000).toFixed(1) + 's');
    if (MARKS.sdp != null) parts.push('换线 ' + (MARKS.sdp / 1000).toFixed(1) + 's');
    if (MARKS.media != null) parts.push('媒体 ' + (MARKS.media / 1000).toFixed(1) + 's');
    if (MARKS.voice != null) parts.push('首音 ' + (MARKS.voice / 1000) .toFixed(1) + 's');
    return parts.length ? '连接分段 ' + parts.join(' · ') : '';
  }

  function startTimer() {
    stopTimer();
    S.elapsed = 0;
    timerEl.hidden = false;
    timerEl.textContent = '已聊 ' + fmt(0);
    S.timer = setInterval(function () {
      S.elapsed += 1;
      timerEl.textContent = '已聊 ' + fmt(S.elapsed);
      var left = MAX_SECONDS - S.elapsed;
      if (left === 60) setStatus('还有 1 分钟，可以继续聊；到时会自动结束，再点开始就好。', 'live');
      if (left <= 0) { setStatus('这一段到 10 分钟了，已自动结束。点「开始对话」继续。', 'idle'); stop(false); }
    }, 1000);
  }
  function stopTimer() { if (S.timer) { clearInterval(S.timer); S.timer = null; } }

  function bindChannel(ch) {
    if (!ch) return;
    ch.onopen = function () { if (ch.label === 'oai-events') S.dc = ch; sendUpdate(); };
    ch.onclose = function () { /* 关闭由整体流程处理 */ };
    ch.onmessage = function (ev) {
      // 上游可能发字符串、Blob 或 ArrayBuffer；只认字符串会把字幕和状态全丢掉。
      function parse(text) {
        var e; try { e = JSON.parse(text); } catch (x) { return; }
        onEvent(e, ch);
      }
      var raw = ev.data;
      if (typeof raw === 'string') return parse(raw);
      if (raw && typeof raw.text === 'function') { raw.text().then(parse).catch(function () {}); return; }
      if (raw instanceof ArrayBuffer) {
        try { parse(new TextDecoder('utf-8').decode(raw)); } catch (x) {}
      }
    };
    if (ch.readyState === 'open') ch.onopen();
  }

  function send(obj) {
    if (S.dc && S.dc.readyState === 'open') S.dc.send(JSON.stringify(obj));
  }

  function speakingGuidance() {
    try {
      var D = window.LumiDifficulty;
      if (!D) return '';
      var lv = D.requestLevel(D.preference ? D.preference(null, 'speaking') : null) || 4;
      return D.guidance ? D.guidance('speaking', lv) : '';
    } catch (e) { return ''; }
  }

  function focusWordsLine() {
    try {
      var P = window.LumiPlan;
      if (!P || !P.focusWords) return '';
      var lv = 4;
      try { var D = window.LumiDifficulty; if (D && D.requestLevel) lv = D.requestLevel(D.preference ? D.preference(null, 'speaking') : null) || 4; } catch (e) {}
      var list = P.focusWords('speaking', lv, 4) || [];
      if (!list.length) return '';
      return 'If it fits naturally, work these words the learner is studying into the conversation: ' + list.join(', ') + '. Never force them or change the topic.';
    } catch (e) { return ''; }
  }

  function sendUpdate() {
    if (S.updateSent || !S.sessionReady) return;
    S.updateSent = true;
    var guide = speakingGuidance();
    var focusLine = focusWordsLine();
    var recall = RECALL.length
      ? ' Earlier in this lesson (keep continuity, do not repeat these questions): ' + RECALL.slice(-6).join(' | ') + '.'
      : '';
    send({
      type: 'session.update',
      session: {
        modalities: ['text', 'audio'],
        voice: 'Tina',
        turn_detection: { type: 'server_vad', silence_duration_ms: 700 },
        instructions: 'You are Lumi, a warm English conversation tutor for a Chinese learner. ' +
          'Answer in short spoken English (1-2 sentences), then add one very short Chinese hint in brackets only when the learner seems stuck. ' +
          'Keep the conversation going with one simple question.' + (guide ? ' ' + guide : '') + (focusLine ? ' ' + focusLine : '') + recall
      }
    });
  }

  function onEvent(e) {
    var type = e.type;
    if (type === 'session.created') { S.sessionReady = true; sendUpdate(); return; }
    if (type === 'session.updated') { setStatus('可以开始说了。', 'live'); return; }
    if (type === 'input_audio_buffer.speech_started') { setOrb('listening'); draftEl.textContent = ''; return; }
    if (type === 'input_audio_buffer.speech_stopped') { setOrb('thinking'); return; }
    if (type === 'conversation.item.input_audio_transcription.delta') {
      if (typeof scrollCaps === 'function') setTimeout(function () { scrollCaps(); }, 0);
      draftEl.textContent = (draftEl.textContent || '') + (e.delta || '');
      return;
    }
    if (type === 'conversation.item.input_audio_transcription.completed') {
      appendLine('me', e.transcript || draftEl.textContent || '');
      draftEl.textContent = '';
      return;
    }
    if (type === 'response.created') { setOrb('speaking'); return; }
    if (type === 'response.audio.delta') {
      if (orbView) {
        var dl = String(e.delta || '');
        orbView.pulse(Math.min(1, dl.length / 2600));
      }
      if (MARKS.voice == null) {
        mark('voice');
        var line = stageLine();
        if (line) setDiag([line]);
      }
    }
    if (type === 'response.audio_transcript.delta') {
      draftEl.textContent = (draftEl.textContent || '') + (e.delta || '');
      return;
    }
    if (type === 'response.audio_transcript.done') {
      appendLine('lumi', e.transcript || draftEl.textContent || '');
      draftEl.textContent = '';
      return;
    }
    if (type === 'response.done') {
      setOrb('live');
      var u = (e.response && e.response.usage) || {};
      var id = u.input_tokens_details || {}, od = u.output_tokens_details || {};
      S.usage.textIn += Number(id.text_tokens) || 0;
      S.usage.audioIn += Number(id.audio_tokens) || 0;
      S.usage.textOut += Number(od.text_tokens) || 0;
      S.usage.audioOut += Number(od.audio_tokens) || 0;
      return;
    }
    if (type === 'error') {
      var msg = (e.error && e.error.message) || '';
      var code = (e.error && e.error.code) || '';
      if (code === 'response_idle_timeout' || /idle_timeout|session was closed/i.test(msg)) {
        scheduleReconnect('空闲太久服务端关了会话，正在重新接上…');
        return;
      }
      if (/already active|conversation/i.test(msg)) return; // 可忽略的并发提示
      setNote('服务端提示：' + (msg || '未知错误'));
    }
  }

  async function token() {
    var t = await window.DB.auth.getAccessToken();
    if (!t) throw new Error('login_required');
    return t;
  }

  var ICE_DIAG = '';
  function updateIceDiag(kinds) {
    var parts = [];
    ['host','srflx','prflx','relay'].forEach(function (k) { if (kinds[k]) parts.push(k + ':' + kinds[k]); });
    ICE_DIAG = parts.length ? '候选 ' + parts.join(' ') : '候选 无';
    setDiag([ICE_DIAG]);
  }


  // 百炼返回的 Answer SDP 把 a=setup / ice-ufrag / ice-pwd / fingerprint / candidate 写在「会话层」，
  // 而浏览器要求这些属性只能出现在 m= 段内，直接 setRemoteDescription 会抛
  // 「Failed to parse SessionDescription. a=setup:passive Invalid SDP line」，连接就永远建不起来。
  // 这里把会话层的媒体属性下放到各 m 段（段内已有同名属性的丢弃），其余原样保留。
  function normalizeAnswer(raw) {
    var lines = String(raw || '').replace(/\r?\n/g, '\n').split('\n');
    var idx = -1;
    for (var i = 0; i < lines.length; i++) { if (lines[i].indexOf('m=') === 0) { idx = i; break; } }
    if (idx < 0) return String(raw || '');
    var sess = lines.slice(0, idx), rest = lines.slice(idx);
    var moved = [], media = /^a=(setup|ice-ufrag|ice-pwd|fingerprint|candidate):/;
    sess = sess.filter(function (l) { if (media.test(l)) { moved.push(l); return false; } return true; });
    var has = {};
    rest.forEach(function (l) { var m = media.exec(l); if (m) has[m[1]] = true; });
    var inject = moved.filter(function (l) { return !has[media.exec(l)[1]]; });
    var out = [], pending = false;
    rest.forEach(function (l) {
      if (l.indexOf('m=') === 0) { out.push(l); pending = true; return; }
      if (pending) { inject.forEach(function (x) { out.push(x); }); inject = []; pending = false; }
      out.push(l);
    });
    if (inject.length) out = out.concat(inject);
    return sess.concat(out).join('\r\n') + '\r\n';
  }

  function waitIce(pc) {
    return new Promise(function (resolve) {
      if (pc.iceGatheringState === 'complete') return resolve();
      var done = false;
      var finish = function () { if (!done) { done = true; resolve(); } };
      // 早发出、早连通：拿到公网候选（srflx/relay）后最多再等 1.2 秒就发 offer，
      // 不再死等 6.5 秒；手机网络确实慢时也有 3 秒硬上限兜底。
      setTimeout(finish, 3000);
      var t0 = Date.now();
      var publicSeen = 0;
      pc.addEventListener('icegatheringstatechange', function () { if (pc.iceGatheringState === 'complete') finish(); });
      pc.addEventListener('icecandidate', function (e) {
        if (!e.candidate) return finish();
        var c = String(e.candidate.candidate || '');
        if (/ typ (srflx|relay)/.test(c)) {
          publicSeen = publicSeen || Date.now();
          var wait = Math.max(0, 1200 - (Date.now() - publicSeen));
          setTimeout(finish, wait);
        }
      });
    });
  }

  async function start() {
    if (S.starting || S.connected) return;
    S.starting = true;
    setButtons(true);
    // 连接过程分阶段提示：慢的时候用户能看出卡在哪一步，而不是干等一个「正在连接…」
    S.t0 = Date.now();
    setStatus('正在连接…', 'connecting');
    setNote('第一次会请求麦克风权限。');
    stopTick();
    S.tick = setInterval(function () {
      if (!S.starting) { stopTick(); return; }
      var sec = Math.round((Date.now() - S.t0) / 100) / 10;
      setStatus('正在连接… ' + sec.toFixed(1) + ' 秒' + (sec > 6 ? '（网络有点慢，继续等）' : ''), 'connecting');
    }, 300);
    try {
      // 登录换 token 与麦克风授权互不依赖，并行做能把首连时间砍掉一半
      var jwtP = token();
      var micP = Promise.race([
        navigator.mediaDevices.getUserMedia({
          audio: { echoCancellation: true, noiseSuppression: true, autoGainControl: true, channelCount: 1 }
        }),
        new Promise(function (_, rej) {
          setTimeout(function () { rej(new Error('mic_timeout')); }, 10000);
        })
      ]);
      micP.catch(function () {});   // 避免 mic 先失败时出现未处理的 rejection
      var jwt = await jwtP;
      mark('token');
      S.mic = await micP;
      mark('mic');
      startMicMeter();
      iosAudioKeepAlive(true);   // 必须在点击后的手势链里调用，iOS 才认
    } catch (err) {
      S.starting = false; setButtons(false);
      var timedOut = err && err.message === 'mic_timeout';
      var denied = timedOut || (err && (err.name === 'NotAllowedError' || err.name === 'SecurityError'));
      var iosHint = /iPhone|iPad|iPod/i.test(navigator.userAgent || '');
      stopTick();
      setStatus(denied ? (timedOut ? '没拿到麦克风：系统没有弹出授权，也没有给声音。请点地址栏左侧的图标允许麦克风后再试。' : MSG.mic_denied) : MSG.network, 'idle');
      setNote(denied
        ? (iosHint ? '打开 设置 → Safari → 麦克风，选「允许」；从主屏打开的 App 则在 设置 → Lumi Words 里打开。' : MSG.mic_hint)
        : '');
      return;
    }

    // STUN 决定能不能在 NAT 后面拿到 srflx 候选：手机在国内网络直连 Google 的 STUN 常被拦，
    // 所以优先用国内可达的公共 STUN，Google 只做兜底。
    var pc = new RTCPeerConnection({
      iceServers: [
        { urls: ['stun:stun.qq.com:3478', 'stun:stun.miwifi.com:3478'] },
        { urls: ['stun:stun.chat.bilibili.com:3478', 'stun:stun.l.google.com:19302'] }
      ],
      iceCandidatePoolSize: 2
    });
    S.pc = pc;
    var remoteStream = new MediaStream();
    pc.ontrack = function (ev) {
      if (ev.track.kind === 'audio') {
        remoteStream.addTrack(ev.track);
        remoteEl.srcObject = remoteStream;
        remoteEl.play().catch(function () { setNote('点一下页面任意位置即可听到声音。'); });
      }
    };
    pc.ondatachannel = function (ev) { bindChannel(ev.channel); };
    var iceKinds = {};
    pc.onicecandidate = function (ev) {
      if (!ev.candidate) { updateIceDiag(iceKinds); return; }
      var c = String(ev.candidate.candidate || '');
      var m = / typ (\w+)/.exec(c);
      if (m) { iceKinds[m[1]] = (iceKinds[m[1]] || 0) + 1; }
    };
    bindChannel(pc.createDataChannel('oai-events'));

    var tx = pc.addTransceiver(S.mic.getAudioTracks()[0], { direction: 'sendrecv' });
    S.sender = tx.sender;

    pc.onconnectionstatechange = function () {
      if (pc.connectionState === 'connected') {
        S.connected = true; S.starting = false;
        mark('media');
        setStatus('可以开始说了。', 'live');
        setNote('说完停一下就好，不用点任何按钮。');
        startTimer();
        S.reconnects = 0;
        startRenew();
        var sl = stageLine();
        if (sl) setDiag([sl]);
      } else if (pc.connectionState === 'failed' || pc.connectionState === 'disconnected') {
        if ((S.connected || S.starting) && !S.closing) {
          var noSrflx = ICE_DIAG && ICE_DIAG.indexOf('srflx') < 0 && ICE_DIAG.indexOf('relay') < 0;
          setDiag([noSrflx ? '连接失败（只拿到内网候选，可能被运营商 NAT 拦了）' : '连接失败']);
          scheduleReconnect(MSG.network);
        }
      }
    };

    try {
      var offer = await pc.createOffer();
      await pc.setLocalDescription(offer);
      await waitIce(pc);
      S.lease = (window.crypto && crypto.randomUUID) ? crypto.randomUUID()
        : '00000000-0000-4000-8000-' + String(Date.now()).slice(-12);
      var res = await fetch(ENDPOINT + '?requestId=' + encodeURIComponent(S.lease), {
        method: 'POST',
        headers: { 'Content-Type': 'application/sdp', Authorization: 'Bearer ' + jwt },
        body: pc.localDescription.sdp
      });
      if (!res.ok) {
        var data = {};
        try { data = await res.json(); } catch (x) {}
        var key = String(data.error || 'network');
        throw new Error(MSG[key] ? key : 'provider_rejected');
      }
      var maxSec = Number(res.headers.get('X-A4-Max-Seconds'));
      if (maxSec > 0) MAX_SECONDS = Math.min(MAX_SECONDS, maxSec);
      var answer = normalizeAnswer(await res.text());
      try {
        await pc.setRemoteDescription({ type: 'answer', sdp: answer });
      } catch (sdpErr) {
        // 万一格式还是被拒，至少把原因写进诊断行，而不是只显示「连不上」
        setDiag(['换线失败：' + (sdpErr && sdpErr.message ? sdpErr.message : String(sdpErr))]);
        throw sdpErr;
      }
      mark('sdp');
      stopTick();
      var cost = S.t0 ? ((Date.now() - S.t0) / 1000).toFixed(1) + ' 秒' : '';
      setStatus('已连上' + (cost ? '（' + cost + '）' : '') + '，正在准备老师…', 'connecting');
    } catch (err) {
      S.starting = false;
      stopTick();
      var code = err && err.message;
      setStatus(MSG[code] || MSG.network, 'idle');
      setNote('');
      stop(true);
    }
  }

  function stopTick() {
    if (S.tick) { clearInterval(S.tick); S.tick = null; }
  }

  // 每 90 秒续一次租约：服务端顺手查本月剩余额度，不足 0.01 元就拒绝，客户端立刻收尾。
  function startRenew() {
    stopRenew();
    S.renewTimer = setInterval(function () {
      if (!S.lease) return;
      var lease = S.lease;
      token().then(function (jwt) {
        return fetch(ENDPOINT + '?action=renew', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json', Authorization: 'Bearer ' + jwt },
          body: JSON.stringify({ leaseId: lease })
        });
      }).then(function (res) {
        return res.json().catch(function () { return {}; }).then(function (data) {
          if (res.ok && data && data.ok) return;
          var code = String((data && data.error) || 'network');
          setNote(MSG[code] || MSG.network);
          stop(false);
        });
      }).catch(function () { /* 单次续租失败先不打断，下一轮再试 */ });
    }, 90000);
  }
  function stopRenew() { if (S.renewTimer) { clearInterval(S.renewTimer); S.renewTimer = null; } }

  // 服务端会因为「5 分钟没有生成回复」主动关会话（response_idle_timeout），
  // 网络抖动也会把 Transceiver 打断。两者都做透明重连，最多 3 次，字幕与用量不清空。
  function scheduleReconnect(reasonText) {
    if (S.closing || !S.lease) return;
    if (S.reconnects >= 3) { setNote(reasonText || '连接断开，请重新开始。'); stop(false); return; }
    S.reconnects += 1;
    var lease = S.lease;
    stopRenew();
    try { if (S.pc) S.pc.close(); } catch (e) {}
    stopMicMeter();
    try { if (S.mic) S.mic.getTracks().forEach(function (t) { t.stop(); }); } catch (e) {}
    S.pc = null; S.mic = null; S.dc = null; S.connected = false; S.sessionReady = false;
    S.updateSent = false; S.starting = false; S.lease = null;
    token().then(function (jwt) {
      return fetch(ENDPOINT + '?action=abort', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json', Authorization: 'Bearer ' + jwt },
        body: JSON.stringify({ leaseId: lease })
      });
    }).catch(function () {});
    var wait = Math.min(4000, 400 * Math.pow(2, S.reconnects - 1));
    setStatus('连接断了一下，正在自动接回（第 ' + S.reconnects + '/3 次）…', 'connecting');
    stopTimer();
    setTimeout(function () { start(); }, wait);
  }


  // ---------- 结束小结（纯本地 + 现有词库，不调用 AI） ----------
  var STOP = {};
  ('a,an,the,i,me,my,you,your,he,she,it,we,they,us,them,and,or,but,so,because,if,when,while,that,this,these,those,'
    + 'is,am,are,was,were,be,been,being,do,does,did,have,has,had,will,would,can,could,shall,should,may,might,must,'
    + 'not,no,yes,ok,okay,well,very,really,just,also,too,then,than,there,here,what,which,who,whom,whose,how,why,'
    + 'about,for,with,without,from,into,onto,in,on,at,to,of,off,by,as,up,down,out,over,under,again,before,after,'
    + 'good,great,nice,like,want,know,think,say,tell,ask,get,got,go,went,come,came,make,made,take,took,see,saw,look,'
    + 'today,now,later,maybe,please,thanks,thank,hello,hi,yeah,yep,nope,sure,one,two,three,thing,things,lot,'
    + 'a.m,p.m,lumi,teacher,english,practice,practise,learn,learning,study,speak,speaking,say,saying').split(',').forEach(function (w) { STOP[w] = 1; });

  function candidates() {
    var seen = {}, out = [];
    S.said.forEach(function (line) {
      String(line).toLowerCase().replace(/[^a-z'\-\s]/g, ' ').split(/\s+/).forEach(function (w) {
        w = w.replace(/^['\-]+|['\-]+$/g, '');
        if (w.length < 4 || w.length > 20 || STOP[w] || seen[w]) return;
        seen[w] = 1; out.push(w);
      });
    });
    return out.slice(0, 40);
  }

  function sumHtml(words, turns) {
    var mm = Math.floor(S.elapsed / 60), ss = S.elapsed % 60;
    var h = '<p class="a4-sum-line">说了 ' + turns + ' 轮，用时 ' + mm + ' 分 ' + ss + ' 秒。</p>';
    if (!words.length) {
      h += '<p class="a4-sum-line muted">这一段没有出现新的、和词库里对得上的词。多说几句、用上刚学的词，这里就会有可收藏的内容。</p>';
      return h;
    }
    h += '<p class="a4-sum-line">对话里可以用起来的词（来自真实词库）：</p><p class="a4-sum-chips">';
    words.forEach(function (w) {
      h += '<span class="a4-sum-chip" title="' + (w.meaning || '').replace(/"/g, '&quot;') + '">' + w.word + '</span>';
    });
    h += '</p>';
    return h;
  }

  async function summarize(turns) {
    var box = document.getElementById('a4Sum');
    var body = document.getElementById('a4SumBody');
    var saveBtn = document.getElementById('a4SumSave');
    if (!box || !body) return;
    box.hidden = false;
    body.innerHTML = '<p class="a4-sum-line muted">正在对照词库…</p>';
    if (saveBtn) saveBtn.hidden = true;
    var found = [];
    var list = candidates();
    for (var i = 0; i < list.length && found.length < 8 && i < 14; i++) {
      try {
        var r = await window.DB.rpc('word_lookup', { p_word: list[i] });
        if (r && r.ok && r.word_id) found.push({ word: r.word, meaning: r.meaning || '', word_id: r.word_id });
      } catch (e) { /* 忽略单个查询失败 */ }
    }
    body.innerHTML = sumHtml(found, turns);
    if (saveBtn && found.length) {
      saveBtn.hidden = false;
      saveBtn.onclick = async function () {
        saveBtn.disabled = true;
        saveBtn.textContent = '正在收…';
        try {
          var book = await window.DB.rpc('create_personal_wordbook', { p_title: '对话生词' });
          var id = book && (book.id || book.book_id);
          if (!id) throw new Error('no_book');
          var res = await window.DB.rpc('add_personal_book_words', {
            p_book_id: id,
            p_words: found.map(function (x) { return x.word; })
          });
          saveBtn.textContent = '已收进「对话生词」';
          setNote('已收进个人词书「对话生词」，可以在「自由练习」里选它复习。');
          if (res && res.added != null) setNote('已收进「对话生词」（新增 ' + res.added + ' 个词），可以在「自由练习」里选它复习。');
        } catch (e) {
          saveBtn.disabled = false;
          saveBtn.textContent = '收进词书';
          setNote('收进词书失败，稍后再试。');
        }
      };
    }
  }

  function stop(silent) {
    iosAudioKeepAlive(false);
    var wasOpen = S.lease;
    var seconds = S.elapsed;
    S.closing = true;
    stopRenew();
    stopTimer();
    stopTick();
    S.starting = false;
    stopMicMeter();
    try { if (S.mic) S.mic.getTracks().forEach(function (t) { t.stop(); }); } catch (e) {}
    try { if (S.pc) S.pc.close(); } catch (e) {}
    S.pc = null; S.mic = null; S.dc = null; S.connected = false; S.sessionReady = false;
    S.updateSent = false; S.starting = false;
    S.lease = null;
    setButtons(false);
    if (!silent) setStatus('已结束。点「开始对话」再来一段。', 'idle');
    setOrb('idle');
    timerEl.hidden = true;
    setTimeout(function () { S.closing = false; }, 1200);
    if (!silent && S.said.length) {
      var turns = Math.min(S.said.length, S.heard.length);
      try { summarize(turns); } catch (e) {}
    }
    if (wasOpen) {
      // 结算：服务端按真实用量扣费并释放租约；失败也不影响本地体验
      token().then(function (jwt) {
        return fetch(ENDPOINT + '?action=settle', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json', Authorization: 'Bearer ' + jwt },
          body: JSON.stringify({ leaseId: wasOpen, seconds: seconds, usage: S.usage })
        });
      }).catch(function () {});
    }
  }


  var DIAG = [];
  function setDiag(parts) {
    DIAG = DIAG.filter(function (x) { return parts.indexOf(x) < 0; }).concat(parts);
    var el = document.getElementById('a4Ver');
    if (!el) return;
    el.textContent = [cfg.APP_VERSION || ''].concat(DIAG).filter(Boolean).join(' · ');
  }

  function showUpdateHint() {
    var el = document.getElementById('a4Ver');
    if (!el) return;
    el.textContent = (cfg.APP_VERSION ? cfg.APP_VERSION + ' · ' : '') + '语音打不开？点这里更新缓存';
    el.classList.add('warn');
  }

  // 旧 Service Worker 缓存会让手机一直停在老页面：给一个手动更新的入口。
  (function bindVersion() {
    var el = document.getElementById('a4Ver');
    if (!el) return;
    setDiag([]);
    el.addEventListener('click', async function () {
      try {
        if (navigator.serviceWorker) {
          var regs = await navigator.serviceWorker.getRegistrations();
          for (var i = 0; i < regs.length; i++) await regs[i].unregister();
        }
        if (window.caches) {
          var keys = await caches.keys();
          for (var j = 0; j < keys.length; j++) await caches.delete(keys[j]);
        }
      } catch (e) {}
      location.reload();
    });
  })();

  startBtn.addEventListener('click', function () {
    S.said = []; S.heard = []; S.reconnects = 0; S.elapsed = 0;
    var box0 = document.getElementById('a4Sum');
    if (box0) box0.hidden = true;
    start();
  });
  endBtn.addEventListener('click', function () { stop(false); });
  clearBtn.addEventListener('click', function () { historyEl.innerHTML = ''; draftEl.textContent = ''; });

  // 启动自检：登录 + 灰度名单
  (async function boot() {
    try {
      var uid = await window.DB.auth.getUserId();
      if (!uid) {
        setStatus('还没登录，去登录后再回来。', 'idle');
        startBtn.disabled = true;
        var a = document.createElement('a');
        a.href = 'login.html?next=a4-voice.html';
        a.textContent = '去登录';
        a.className = 'btn';
        startBtn.parentNode.insertBefore(a, startBtn.nextSibling);
        return;
      }
      setDiag(['已登录 ' + String(uid).slice(0, 8)]);
      var jwt = await token();
      function askAccess() {
        return fetch(SUPABASE_URL + '/rest/v1/rpc/voice_access', {
          method: 'POST',
          headers: { apikey: ANON_KEY, Authorization: 'Bearer ' + jwt, 'Content-Type': 'application/json' },
          body: '{}'
        });
      }
      var res = await askAccess();
      if (!res.ok) { await new Promise(function (r) { setTimeout(r, 400); }); res = await askAccess(); }
      var access = {};
      try { access = await res.json(); } catch (e) { access = {}; }
      // 只有服务端明确说「不在名单」才拦；网络抖动/接口异常不拦，真正的拦截在边缘函数里。
      setDiag([res.ok ? (access && access.allowed === false ? '语音未开通' : '语音已开通') : ('权限查询失败（HTTP ' + res.status + '）')]);
      if (res.ok && access && access.allowed === false) {
        setStatus(MSG.voice_forbidden, 'idle');
        startBtn.disabled = true;
        showUpdateHint();
        return;
      }
      setStatus('准备好了。点「开始对话」，允许麦克风后直接说话。', 'idle');
    } catch (err) {
      setStatus('准备好了。点「开始对话」试试。', 'idle');
    }
  })();

  window.addEventListener('pagehide', function () { if (S.lease) stop(true); });
})();