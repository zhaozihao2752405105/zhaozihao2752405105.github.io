/* Lumi Words · 键盘避让（iOS 原生 App 与 Safari 都用得上）
 * iOS 的 WKWebView / Safari 弹键盘时只缩 visualViewport，不动 layout viewport，
 * 所以 position:fixed;bottom:0 的输入框会被键盘挡住。这里把两者之差写成 --kb，
 * 让输入区和消息区一起抬高。桌面与没有 visualViewport 的环境保持 0，不影响布局。
 */
(function () {
  'use strict';
  var root = document.documentElement;
  if (!root || !window.visualViewport) return;
  var vv = window.visualViewport;
  var last = -1;
  function sync() {
    var gap = Math.round(window.innerHeight - vv.height - vv.offsetTop);
    if (gap < 0) gap = 0;
    if (gap > 0 && gap < 40) gap = 0;      /* 地址栏伸缩之类的抖动不算键盘 */
    if (gap === last) return;
    last = gap;
    root.style.setProperty('--kb', gap + 'px');
    if (gap > 0) root.classList.add('kb-open');
    else root.classList.remove('kb-open');
  }
  vv.addEventListener('resize', sync);
  vv.addEventListener('scroll', sync);
  window.addEventListener('orientationchange', function () { setTimeout(sync, 120); });
  window.addEventListener('resize', sync);
  sync();
  /* 输入框获得焦点后等键盘动画结束再量一次 */
  document.addEventListener('focusin', function (ev) {
    var t = ev.target;
    if (!t || (t.tagName !== 'TEXTAREA' && t.tagName !== 'INPUT')) return;
    setTimeout(sync, 260);
    setTimeout(sync, 520);
  }, true);
  document.addEventListener('focusout', function () { setTimeout(sync, 160); }, true);
})();