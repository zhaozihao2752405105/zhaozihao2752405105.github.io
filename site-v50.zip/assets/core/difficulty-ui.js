(function (root) {
  'use strict';
  const core = root.LumiDifficulty;
  let cached;
  let epoch = 0;
  let owner;
  let reading;

  async function request(action, module, data = {}) {
    const version = epoch;
    const result = await root.DB.rpc('lumi_difficulty', { p_action: action, p_module: module, p_data: data });
    if (version !== epoch || !result?.prefs) throw new Error('难度设置暂不可用');
    if (!cached || result.prefs.revision >= cached.revision) cached = result.prefs;
    if (owner) root.OfflineCache?.putMeta(owner, { difficulty: cached });
    return result;
  }

  async function read() {
    if (!reading || reading.epoch !== epoch) {
      const task = { epoch, promise: request('read', 'global').catch(() => null) };
      reading = task;
      void task.promise.finally(() => { if (reading === task) reading = null; });
    }
    const version = epoch;
    const result = await reading.promise;
    const ok = version === epoch && result?.ok === true;
    const prefs = ok ? cached : null;
    const output = { ok, sources: {}, prefs };
    for (const module of Object.keys(core.modules)) {
      const current = core.preference(prefs, module);
      output[module] = current.level;
      output.sources[module] = current.mode === 'manual' ? 'manual' : 'auto';
    }
    output.source = [output.sources.listening, output.sources.reading].includes('manual') ? 'manual' : 'auto';
    return output;
  }

  function contentParams(value) { return { level: core.level(value).number, difficulty_version: core.VERSION }; }
  function moduleChoice(prefs, scope) {
    return scope === 'global' ? prefs.global : prefs.modules?.[scope] || { mode: 'inherit' };
  }
  function label(value) {
    const row = core.level(value);
    return 'Lv.' + row.number + ' ' + row.label;
  }
  function create(tag, text, className) {
    const node = document.createElement(tag);
    if (text) node.textContent = text;
    if (className) node.className = className;
    return node;
  }
  function button(text, handler, secondary = false) {
    const element = create('button', text, secondary ? 'btn ghost' : 'btn');
    element.type = 'button';
    element.addEventListener('click', handler);
    return element;
  }

  function mount(node, scopes, { changed = () => {} } = {}) {
    if (!node) return Promise.resolve(null);
    const status = create('p', '', 'small muted');
    status.setAttribute('role', 'status');
    const fields = create('div');
    const heading = create('h2', '学习难度');
    node.replaceChildren(heading, fields, status);
    node.classList.add('card', 'lumi-difficulty');
    let prefs;
    let busy = false;

    async function update(scope, option) {
      if (busy || !prefs) return;
      busy = true;
      render();
      status.textContent = '正在保存…';
      try {
        const result = await request('set', scope, option === 'inherit' || option === 'smart'
          ? { mode: option, revision: prefs.revision }
          : { mode: 'manual', level: Number(option), revision: prefs.revision });
        prefs = result.prefs;
        if (!result.ok) status.textContent = '另一处已更新难度，请确认后重选。';
        else {
          status.textContent = '已保存，下一份新内容生效。';
          changed(prefs);
        }
      } catch {
        status.textContent = '难度未保存，请联网后重试。';
      } finally {
        busy = false;
        render();
      }
    }

    function render() {
      fields.replaceChildren();
      for (const scope of scopes) {
        const wrap = create('label', scope === 'global' ? '全局' : core.modules[scope], 'lumi-difficulty-field');
        const select = create('select');
        select.disabled = busy;
        const current = moduleChoice(prefs, scope);
        const options = scope === 'global' ? [] : [['inherit', '继承全局 · ' + label(prefs.global.level)]];
        options.push(['smart', '智能适应'], ...core.levels.map(row => [String(row.number), label(row.number)]));
        for (const [value, text] of options) {
          const item = create('option', text);
          item.value = value;
          select.append(item);
        }
        select.value = current.mode === 'manual' ? String(current.level) : current.mode;
        select.addEventListener('change', () => update(scope, select.value));
        wrap.append(select);
        if (current.mode === 'smart') wrap.append(create('small', '当前 ' + label(core.preference(prefs, scope).level), 'muted'));
        fields.append(wrap);
      }
      if (prefs.undo && (scopes.includes('global') || scopes.includes(prefs.undo.module))) {
        const undo = button('撤销最近一次升降级', async () => {
          if (busy) return;
          busy = true;
          render();
          try {
            const result = await request('undo', prefs.undo.module, { revision: prefs.revision });
            prefs = result.prefs;
            status.textContent = result.ok ? '已撤销。' : '该调整已变化，无法撤销。';
            if (result.ok) changed(prefs);
          } catch { status.textContent = '撤销失败，请重试。'; }
          finally { busy = false; render(); }
        }, true);
        undo.disabled = busy;
        fields.append(undo);
      }
    }
    return read().then(result => {
      if (!node.isConnected) return null;
      if (!result.ok) { status.textContent = '当前无法同步学习难度。'; return null; }
      prefs = result.prefs;
      render();
      return prefs;
    });
  }

  function normalizeStats(stats = {}) {
    const integer = value => Number.isInteger(value) && value >= 0 ? Math.min(value, 1000) : 0;
    const independent = integer(stats.independent);
    return { independent, correct: Math.min(independent, integer(stats.correct)),
      hints: integer(stats.hints), repeated: integer(stats.repeated) };
  }

  async function report({ module, level, unitKey, stats, mount: target, summary } = {}) {
    if (!Object.hasOwn(core.modules, module) || !core.number(level) || typeof unitKey !== 'string' ||
      unitKey.length < 1 || unitKey.length > 120) return { ok: false, reason: 'invalid_unit' };
    const data = { level: Number(level), unit_key: unitKey, sample: normalizeStats(stats) };
    let result;
    try {
      result = await request('record', module, data);
      if (!result.ok) throw new Error('未保存学习单元');
    } catch {
      if (target && target.isConnected) target.textContent = '难度反馈暂未同步。';
      return { ok: false, reason: 'unavailable' };
    }
    if (!target || !target.isConnected) return result;
    renderFeedback(target, module, data, summary, result);
    return result;
  }

  function renderFeedback(target, module, data, summary, result) {
    const heading = create('h2', '本次学习完成');
    const status = create('p', '', 'small muted');
    status.setAttribute('role', 'status');
    const votes = create('div', '', 'row');
    const proposal = create('div');
    const ratingLabels = { easy: '太简单', suitable: '难度合适', hard: '太困难' };
    let busy = false;

    function render() {
      votes.replaceChildren();
      proposal.replaceChildren();
      if (result.adjusted) { status.textContent = '本次难度已调整。'; return; }
      if (!result.rating) {
        for (const [rating, text] of Object.entries(ratingLabels)) {
          const item = button(text, async () => {
            if (busy) return;
            busy = true;
            render();
            try {
              const answer = await request('record', module, { ...data, rating });
              if (!answer.ok) throw new Error('未保存学习单元');
              result = answer;
              status.textContent = result.rating === 'suitable' ? '保持当前难度。' : '';
            } catch { status.textContent = '反馈未保存，请重试。'; }
            finally { busy = false; render(); }
          }, true);
          item.disabled = busy;
          votes.append(item);
        }
      }
      const current = core.preference(result.prefs, module);
      const next = current.level === data.level ? core.suggestion(current, result.rating, result.units) : null;
      if (!next) return;
      proposal.append(create('p', (result.rating ? '建议调整' : '根据最近学习结果，建议调整') + '：' +
        label(next.from) + ' → ' + label(next.to)));
      const confirm = button('确认调整', async () => {
        if (busy) return;
        busy = true;
        render();
        try {
          const answer = await request('confirm', module, { unit_key: data.unit_key, level: next.to, revision: result.prefs.revision });
          result = { ...result, prefs: answer.prefs, adjusted: answer.ok };
          status.textContent = answer.ok ? '已调整，下一份新内容生效。' : '难度已变化，本次未调整。';
        } catch { status.textContent = '调整未保存，请重试。'; }
        finally { busy = false; render(); }
      });
      const cancel = button('保持当前难度', () => {
        proposal.replaceChildren();
        status.textContent = '保持当前难度。';
      }, true);
      confirm.disabled = cancel.disabled = busy;
      proposal.append(confirm, cancel);
    }
    target.classList.add('card', 'lumi-difficulty');
    const score = data.sample.independent ? (' · ' + data.sample.correct + '/' + data.sample.independent + ' 正确') : '';
    target.replaceChildren(heading, create('p', (summary ? summary + ' · ' : '') + label(data.level) + score),
      votes, proposal, status);
    render();
  }

  async function setGlobal(level, revision) {
    return request('set', 'global', { mode: 'manual', level, revision });
  }
  async function saveExamTarget(target, revision) {
    return request('goal', 'global', { target, revision });
  }
  root.Difficulty = Object.freeze({ read, mount, report, contentParams, label, setGlobal, saveExamTarget,
    normalizeStats, current: () => cached });
  root.DB?.auth?.onChange(session => {
    const uid = session?.user?.id || null;
    if (owner !== undefined && uid !== owner) {
      cached = null;
      epoch++;
    }
    owner = uid;
  });
  if (typeof document !== 'undefined') {
    document.addEventListener('DOMContentLoaded', () => {
      const settings = document.getElementById('difficultySettings');
      if (settings) mount(settings, ['global', ...Object.keys(core.modules)]);
    });
  }
})(globalThis);
