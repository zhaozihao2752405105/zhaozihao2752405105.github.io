/* Shared by the browser, AI gateway and realtime tutor. */
(function (root) {
  'use strict';
  const VERSION = 'lumi-d1';
  const modules = Object.freeze({ words: '单词', grammar: '语法', listening: '听力', reading: '阅读', writing: '写作', speaking: 'AI 口语' });
  const rows = [
    ['小学英语', 'everyday concrete words', 'short simple present sentences', 'basic statements and short stories; literal facts', 'slow, clear everyday instructions or a brief exchange', 'listen for names, numbers and concrete details', 'describe a familiar person or object in short sentences', 65, 100, 40, 70, .72, 3],
    ['初中英语', 'frequent words for school and daily life', 'simple past/future, modals and basic conjunctions', 'daily-life articles; identify explicitly stated facts and sequence', 'school or daily-life dialogues in the style of lower-secondary practice', 'identify time, place, purpose and direct details', 'write a brief message or recount a familiar event', 100, 160, 70, 115, .80, 3],
    ['高中英语', 'common academic and social vocabulary', 'relative clauses, varied tenses and common subordinate clauses', 'developed narrative or exposition; summarize and infer author intent', 'complete dialogue or monologue in the style of upper-secondary practice', 'follow changes in viewpoint and infer speaker intent', 'develop a clear narrative or viewpoint with supporting reasons', 170, 240, 110, 165, .88, 4],
    ['大学英语四级', 'campus, news and general academic vocabulary', 'passive voice, non-finite clauses and paragraph cohesion', 'campus or general-interest article; match information to paragraphs, identify main idea', 'news, campus conversation or a short report', 'match information, track sequence and identify a report’s main point', 'write a structured short opinion or practical response', 210, 285, 145, 200, .95, 4],
    ['大学英语六级', 'broader academic vocabulary and common abstract collocations', 'embedded clauses, concession and nuanced modality', 'argument or report; compare viewpoints and interpret evidence', 'long conversation, short lecture or discussion of viewpoints', 'follow an argument through examples, qualify speaker claims and make inferences', 'write a reasoned argument with an example and a counterpoint', 250, 330, 170, 230, 1.00, 5],
    ['考研英语', 'formal academic vocabulary and challenging collocations', 'long embedded clauses, complex modification and discourse relations', 'argumentative text; parse long sentences, logical relations, attitude and deeper inference', 'supplementary listening for complex sentences and reasoning; never present it as an official postgraduate written-exam listening section', 'interpret logical relations, implied stance and complex sentences', 'develop a compact argument or summarize an issue with coherent paragraph structure', 285, 365, 180, 245, 1.00, 5],
    ['英语专业四级', 'wide general vocabulary and precise idiomatic usage', 'advanced grammar, register choices and sentence transformation', 'complex text; infer references and connect information across paragraphs', 'integrated comprehension with a short dictation opportunity', 'include a marked dictation excerpt as well as inference and comprehension', 'write a structured response with precise register and supporting detail', 300, 390, 205, 260, 1.03, 5],
    ['英语专业八级', 'advanced vocabulary, nuanced register and figurative phrasing', 'complex discourse, stylistic variation and rhetorical structures', 'advanced text; analyze register, rhetoric and implied meaning', 'advanced interview, panel or lecture with several linked ideas', 'infer implication and attitude, separate evidence from commentary and synthesize ideas', 'synthesize multiple viewpoints with controlled tone and nuanced argumentation', 335, 425, 225, 290, 1.08, 5],
    ['高阶英语', 'precise abstract and academic vocabulary defined in context when useful', 'flexible complex structures and sophisticated discourse', 'sustained argument or academic text; evaluate assumptions and evidence critically', 'natural-paced deep interview or academic discussion of abstract ideas', 'evaluate competing claims and synthesize evidence across the recording', 'develop and qualify a sustained argument or academic response', 380, 480, 250, 330, 1.13, 6]
  ];
  const levels = Object.freeze(rows.map(([label, vocabulary, grammar, reading, listening, questions, writing,
    readMin, readMax, listenMin, listenMax, rate, count], index) => Object.freeze({
    id: 'lv' + (index + 1), number: index + 1, label, vocabulary, grammar, reading, listening, questions, writing,
    readMin, readMax, listenMin, listenMax, rate, count
  })));
  const thresholds = Object.freeze({ streak: 3, minAnswers: 3, high: .85, low: .60, maxHintsForUpgrade: 1 });
  const examTargets = Object.freeze({ none: '暂不设置', zhongkao: '中考', gaokao: '高考', cet4: '四级',
    cet6: '六级', kaoyan1: '考研英语一', kaoyan2: '考研英语二', tem4: '专四', tem8: '专八', ielts: '雅思', toefl: '托福' });
  const number = value => ((typeof value === 'number' || /^[1-9]$/.test(String(value))) &&
    Number.isInteger(Number(value)) && Number(value) >= 1 && Number(value) <= levels.length) ? Number(value) : null;
  const level = value => levels[(number(value) || 2) - 1];
  const legacy = value => ({ 1: 2, 2: 4, 3: 6 })[value] || null;

  function preference(prefs, module) {
    const global = prefs?.global || { mode: 'smart', level: 2 };
    const own = module !== 'global' ? prefs?.modules?.[module] : null;
    const chosen = own?.mode === 'inherit' || !own ? global : own;
    return { mode: chosen.mode === 'manual' ? 'manual' : 'smart', level: level(chosen.level).number,
      inherited: module !== 'global' && (!own || own.mode === 'inherit') };
  }

  function suggestion(current, rating, history = []) {
    if (rating === 'suitable') return null;
    let delta = rating === 'easy' ? 1 : rating === 'hard' ? -1 : 0;
    if (!delta && current.mode === 'smart') {
      const recent = history.filter(unit => unit.level === current.level &&
        unit.independent >= thresholds.minAnswers).slice(0, thresholds.streak);
      if (recent.length === thresholds.streak && recent.every(unit =>
        unit.correct / unit.independent >= thresholds.high && unit.hints <= thresholds.maxHintsForUpgrade && unit.repeated === 0)) delta = 1;
      else if (recent.length === thresholds.streak && recent.every(unit => unit.correct / unit.independent < thresholds.low)) delta = -1;
    }
    const next = number(current.level + delta);
    return delta && next ? { from: current.level, to: next } : null;
  }

  function variant(value) { return VERSION + ':' + level(value).number; }
  function fromVariant(key) {
    return typeof key === 'string' && key.startsWith(VERSION + ':') ? number(key.slice(VERSION.length + 1)) : null;
  }
  function requestLevel(value) { return number(value) || null; }

  function guidance(module, value) {
    const row = level(value);
    const intro = 'Lumi custom learning level ' + row.number + ' (' + row.label + '); simulated practice, not authentic exam questions or a formal equivalence. Vocabulary: ' + row.vocabulary + '. Grammar: ' + row.grammar + '.';
    if (module === 'listening') return intro + ' Material: ' + row.listening + '. Aim for ' + row.listenMin + '–' + row.listenMax +
      ' words and ' + row.count + ' questions. Tasks: ' + row.questions + '.';
    if (module === 'reading') return intro + ' Material: ' + row.reading + '. Aim for ' + row.readMin + '–' + row.readMax +
      ' words and ' + row.count + ' questions. Difficulty must also change the reasoning required.';
    if (module === 'writing') return intro + ' Writing task: ' + row.writing + '.';
    if (module === 'speaking') return intro + ' Start with a topic the learner chooses or an everyday example. Pace: about ' +
      Math.round(125 * row.rate) + ' words per minute when speaking English. Adapt length and explanation depth; allow Chinese explanations and mixed speech at every level.';
    return intro + ' Teach one level-appropriate point with examples. Use concise explanations and varied questions.';
  }

  const api = Object.freeze({ VERSION, modules, levels, thresholds, examTargets, number, level, legacy, preference, suggestion,
    variant, fromVariant, requestLevel, guidance });
  root.LumiDifficulty = api;
  if (typeof module !== 'undefined' && module.exports) module.exports = api;
})(globalThis);
