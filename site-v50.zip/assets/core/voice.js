/* Lumi · 浏览器语音能力（TTS 朗读 + ASR 听写）
 * 全部走浏览器内置能力：不调用任何付费接口，不产生费用。
 * 兼容性：speechSynthesis 全平台可用；SpeechRecognition 仅 Chrome/Edge/部分 Safari。
 */
(function () {
  'use strict';

  var CJK_RE = /[\u3400-\u9fff\u3000-\u303f\uff01-\uff60]/;
  var HAS_TTS = typeof window !== 'undefined' && 'speechSynthesis' in window && typeof window.SpeechSynthesisUtterance === 'function';
  var SR = typeof window !== 'undefined' ? (window.SpeechRecognition || window.webkitSpeechRecognition || null) : null;

  var P = { active: false, queue: [], i: 0, token: 0, onState: null, retried: false };

  function voicesNow() {
    try { return window.speechSynthesis.getVoices() || []; } catch (e) { return []; }
  }

  function warm(cb) {
    if (!HAS_TTS) { cb([]); return; }
    var vs = voicesNow();
    if (vs.length) { cb(vs); return; }
    var done = false;
    function fire() {
      if (done) return;
      done = true;
      try { window.speechSynthesis.onvoiceschanged = null; } catch (e) { }
      cb(voicesNow());
    }
    try { window.speechSynthesis.onvoiceschanged = fire; } catch (e) { }
    setTimeout(fire, 1500);
  }

  // 优先本机离线音色（断网也有声），同语言内优先自然度更高的名字
  function pickVoice(vs, wantZh) {
    var local = [], online = [], i, v, lang;
    for (i = 0; i < (vs || []).length; i++) {
      v = vs[i]; lang = String(v.lang || '').toLowerCase();
      if (wantZh ? lang.indexOf('zh') !== 0 : lang.indexOf('en') !== 0) continue;
      if (!wantZh && lang.indexOf('zh') === 0) continue;
      (/online/i.test(String(v.name || '')) || v.localService === false) ? online.push(v) : local.push(v);
    }
    var pool = local.length ? local : online;
    if (!pool.length) return null;
    var pref = wantZh ? ['zh-cn', 'zh-hans', 'zh-tw', 'zh-hk', 'zh'] : ['en-us', 'en-gb', 'en-au', 'en-ca', 'en'];
    for (i = 0; i < pref.length; i++) {
      for (var j = 0; j < pool.length; j++) {
        if (String(pool[j].lang || '').toLowerCase().indexOf(pref[i]) === 0) return pool[j];
      }
    }
    return pool[0] || null;
  }

  // 中英混排：中文用中文音色、英文用英文音色，读起来才不像机器人
  function segments(text) {
    var src = String(text || '').replace(/```[\s\S]*?```/g, ' 代码已略 ').replace(/[#*_`>]/g, '').replace(/\s+/g, ' ').trim();
    var out = [], cur = '', curZh = null, i, ch, zh;
    for (i = 0; i < src.length; i++) {
      ch = src.charAt(i);
      zh = CJK_RE.test(ch);
      if (curZh === null) { curZh = zh; cur = ch; continue; }
      if (zh === curZh) { cur += ch; continue; }
      if (cur.trim()) out.push({ zh: curZh, text: cur.trim() });
      curZh = zh; cur = ch;
    }
    if (cur.trim()) out.push({ zh: curZh, text: cur.trim() });
    return out;
  }

  function splitSentences(t) {
    var src = String(t || '').replace(/\s+/g, ' ').trim(), out = [], cur = '', i, ch, next;
    for (i = 0; i < src.length; i++) {
      ch = src.charAt(i); cur += ch;
      next = src.charAt(i + 1);
      if ('.!?;'.indexOf(ch) >= 0 && (next === '' || next === ' ')) { if (cur.trim()) out.push(cur.trim()); cur = ''; }
    }
    if (cur.trim()) out.push(cur.trim());
    return out.length ? out : [src];
  }

  function isIOS() {
    var ua = String((navigator && navigator.userAgent) || '');
    if (/iP(hone|ad|od)/.test(ua)) return true;
    return /Macintosh/.test(ua) && typeof document !== 'undefined' && 'ontouchend' in document;
  }

  function buildQueue(text, rate) {
    var segs = segments(text), q = [], vs = voicesNow(), i, s, parts, k;
    for (i = 0; i < segs.length; i++) {
      s = segs[i];
      parts = splitSentences(s.text);
      for (k = 0; k < parts.length; k++) q.push({ zh: s.zh, text: parts[k], rate: rate });
    }
    return q;
  }

  function emit(state, payload) {
    if (typeof P.onState === 'function') { try { P.onState(state, payload); } catch (e) { } }
  }

  function next(token) {
    if (!P.active || token !== P.token) return;
    if (P.i >= P.queue.length) { P.active = false; emit('end'); return; }
    var item = P.queue[P.i++];
    var u = new SpeechSynthesisUtterance(item.text);
    var wantZh = item.zh;
    u.lang = wantZh ? 'zh-CN' : 'en-US';
    if (!isIOS()) {
      var v = pickVoice(voicesNow(), wantZh);
      if (v) { u.voice = v; u.lang = v.lang; }
    }
    u.rate = item.rate || (wantZh ? 0.98 : 0.92);
    u.pitch = 1;
    u.onstart = function () { if (token === P.token) emit('start', { index: P.i, total: P.queue.length }); };
    u.onend = function () { next(token); };
    u.onerror = function (ev) {
      if (token !== P.token) return;
      var code = (ev && ev.error) || 'unknown';
      if (code === 'interrupted' || code === 'canceled') return;
      P.active = false;
      emit('error', { code: code });
    };
    try { window.speechSynthesis.speak(u); }
    catch (e) { P.active = false; emit('error', { code: 'speak_failed' }); }
  }

  function speak(text, opts) {
    opts = opts || {};
    if (!HAS_TTS) { emit('error', { code: 'unsupported' }); return false; }
    stop();
    P.token++; P.queue = buildQueue(text, opts.rate); P.i = 0; P.active = true; P.retried = false;
    P.onState = opts.onState || null;
    var ss = window.speechSynthesis;
    try { ss.cancel(); } catch (e) { }
    try { if (ss.paused) ss.resume(); } catch (e) { }
    if (!P.queue.length) { P.active = false; return false; }
    var token = P.token;
    emit('begin', { total: P.queue.length });
    next(token);
    // iOS/Edge 首次偶发静音：1.4 秒还没开始就重排一次（这一次仍在手势解锁后）
    setTimeout(function () {
      if (!P.active || token !== P.token || P.retried) return;
      if (P.i > 1) return;
      P.retried = true;
      try { ss.cancel(); } catch (e) { }
      P.i = 0;
      next(token);
    }, 1400);
    return true;
  }

  function stop() {
    P.active = false; P.token++; P.queue = []; P.i = 0;
    try { stopServerAudio(); } catch (e) { }
    try { stopStreamAudio(); } catch (e) { }
    try { if (HAS_TTS) window.speechSynthesis.cancel(); } catch (e) { }
  }

  function speaking() { return !!P.active || serverSpeaking(); }

  /* ---------- 语音输入（听写） ---------- */
  /* 首次使用前明确告知：会请求麦克风权限，且识别可能由浏览器厂商的在线服务完成。 */
  var ASR_NOTE_KEY = 'lumi_asr_notice_v1';
  function asrConsent() {
    var ok = false;
    try { if (window.localStorage.getItem(ASR_NOTE_KEY) === '1') return true; } catch (e) { }
    try {
      ok = window.confirm('语音输入说明：\n\n1) 点击后才会请求麦克风权限，只有你说话时才录音。\n2) 语音识别由浏览器提供，录音可能会上传到浏览器厂商的在线识别服务处理。\n3) 随时可以点停止，或直接打字输入。\n\n继续使用语音输入吗？');
    } catch (e) { ok = true; }
    if (ok) { try { window.localStorage.setItem(ASR_NOTE_KEY, '1'); } catch (e) { } }
    return ok;
  }

  function listen(opts) {
    opts = opts || {};
    if (!SR) { if (opts.onError) opts.onError('unsupported'); return null; }
    if (!asrConsent()) { if (opts.onError) opts.onError('cancelled'); return null; }
    var rec;
    try { rec = new SR(); } catch (e) { if (opts.onError) opts.onError('init_failed'); return null; }
    rec.lang = opts.lang || 'en-US';
    rec.interimResults = true;
    rec.continuous = false;
    rec.maxAlternatives = 1;
    var finalText = '', started = false, ended = false;
    function finish() {
      if (ended) return;
      ended = true;
      if (opts.onEnd) { try { opts.onEnd(finalText); } catch (e) { } }
    }
    rec.onstart = function () { started = true; if (opts.onStart) { try { opts.onStart(); } catch (e) { } } };
    rec.onresult = function (ev) {
      var interim = '', i, res;
      for (i = ev.resultIndex; i < ev.results.length; i++) {
        res = ev.results[i];
        if (res.isFinal) finalText += res[0].transcript; else interim += res[0].transcript;
      }
      if (opts.onPartial) { try { opts.onPartial((finalText + interim).trim()); } catch (e) { } }
    };
    rec.onerror = function (ev) {
      var code = (ev && ev.error) || 'error';
      ended = true;
      if (opts.onError) { try { opts.onError(code); } catch (e) { } }
    };
    rec.onend = function () { finish(); };
    var h = {
      stop: function () { try { rec.stop(); } catch (e) { } },
      abort: function () { try { rec.abort(); } catch (e) { } },
      text: function () { return finalText; }
    };
    try { rec.start(); } catch (e) { if (opts.onError) opts.onError('start_failed'); return null; }
    setTimeout(function () { if (!started && !ended && opts.onError) { try { opts.onError('no_start'); } catch (e) { } } }, 4000);
    return h;
  }


  /* ---------- 服务端语音（付费：走网关鉴权/限流/预算，Key 不进前端） ---------- */
  var HAS_AUDIO = typeof window !== 'undefined' && typeof window.Audio === 'function';
  var BT = String.fromCharCode(96);
  var A = { token: 0, el: null, onState: null, q: [], i: 0, t0: 0,
    stats: { asrMs: 0, asrSeconds: 0, asrCost: 0, ttsMs: 0, ttsChunks: 0, ttsCost: 0, lastError: '' } };
  var TTS_CACHE = {}, TTS_ORDER = [], TTS_MAX = 16;
  // 服务端语音灰度：初始一律关闭，登录后由 initServerAccess() 向服务端确认。
  // 只有 voice_access() 返回 allowed=true 的账号才走付费的 asr/tts；
  // 其他账号继续用浏览器本机音色/听写，不产生费用。
  var ACCESS = { on: false, checked: false, p: null };

  function featOn() {
    try { return !!(window.APP_CONFIG && window.APP_CONFIG.FEATURES && window.APP_CONFIG.FEATURES.VOICE_SERVER === true); } catch (e) { return false; }
  }
  function initServerAccess(force) {
    if (!featOn()) { ACCESS.on = false; ACCESS.checked = true; return Promise.resolve(false); }
    if (ACCESS.p && !force) return ACCESS.p;
    ACCESS.p = new Promise(function (resolve) {
      if (!(window.DB && window.DB.rpc)) { ACCESS.on = false; ACCESS.checked = true; resolve(false); return; }
      window.DB.rpc('voice_access', {}).then(function (r) {
        var row = Array.isArray(r) ? r[0] : r;
        ACCESS.on = !!(row && row.ok === true && row.allowed === true);
        ACCESS.checked = true;
        resolve(ACCESS.on);
      }).catch(function () {
        ACCESS.on = false; ACCESS.checked = true; resolve(false);
      });
    });
    return ACCESS.p;
  }
  function serverTTSReady() { return featOn() && ACCESS.on && HAS_AUDIO && !!(window.DB && window.DB.aiInvoke); }
  function serverASRReady() {
    return featOn() && ACCESS.on && !!(window.DB && window.DB.aiInvoke) &&
      !!(navigator.mediaDevices && navigator.mediaDevices.getUserMedia) &&
      typeof window.MediaRecorder === 'function';
  }
  function newRid() {
    try { return (window.crypto && crypto.randomUUID) ? crypto.randomUUID() : 'v' + Date.now() + Math.random().toString(16).slice(2); }
    catch (e) { return 'v' + Date.now(); }
  }
  function emitA(state, payload) { if (typeof A.onState === 'function') { try { A.onState(state, payload); } catch (e) { } } }

  // 清掉 Markdown/代码块，只留能读出来的话；按句子切成 <=580 字的小段（网关单次上限 600）
  function chunksForSpeech(text) {
    var FENCE = new RegExp(BT + '{3}[\\s\\S]*?' + BT + '{3}', 'g');
    var SYM = new RegExp('[#*_' + BT + '>|]', 'g');
    var s = String(text || '')
      .replace(FENCE, ' ')
      .replace(/!\[[^\]]*\]\([^)]*\)/g, ' ')
      .replace(/\[([^\]]*)\]\(([^)]*)\)/g, '$1')
      .replace(/https?:\/\/\S+/g, ' ')
      .replace(SYM, ' ')
      .replace(/\s+/g, ' ')
      .trim();
    if (!s) return [];
    var out = [], cur = '', parts = splitSentences(s), i, p;
    for (i = 0; i < parts.length; i++) {
      p = parts[i];
      while (p.length > 580) {
        if (cur.trim()) { out.push(cur.trim()); cur = ''; }
        out.push(p.slice(0, 580));
        p = p.slice(580);
      }
      if ((cur + ' ' + p).trim().length > 580) { if (cur.trim()) out.push(cur.trim()); cur = p; }
      else cur = (cur ? cur + ' ' : '') + p;
    }
    if (cur.trim()) out.push(cur.trim());
    return out;
  }

  function cacheGet(k) { return TTS_CACHE[k] || null; }
  function cachePut(k, url) {
    if (TTS_CACHE[k]) return TTS_CACHE[k];
    TTS_CACHE[k] = url; TTS_ORDER.push(k);
    while (TTS_ORDER.length > TTS_MAX) {
      var old = TTS_ORDER.shift();
      try { URL.revokeObjectURL(TTS_CACHE[old]); } catch (e) { }
      delete TTS_CACHE[old];
    }
    return url;
  }
  function b64ToBlob(b64, mime) {
    var bin = atob(b64), len = bin.length, u8 = new Uint8Array(len);
    for (var i = 0; i < len; i++) u8[i] = bin.charCodeAt(i);
    return new Blob([u8], { type: mime || 'audio/mpeg' });
  }

  function stopServerAudio() {
    A.token++; A.q = []; A.i = 0;
    if (A.el) {
      try { A.el.onended = null; A.el.onerror = null; A.el.pause(); } catch (e) { }
      try { A.el.src = ''; } catch (e) { }
      A.el = null;
    }
  }

  function serverSpeaking() { return !!((A.el && !A.el.paused) || (ST.el && !ST.el.paused)); }

  function playChunk(url, token) {
    var el = new Audio();
    A.el = el;
    el.preload = 'auto';
    el.onended = function () {
      if (token !== A.token) return;
      A.el = null; A.i++;
      nextChunk(token);
    };
    el.onerror = function () {
      if (token !== A.token) return;
      A.el = null;
      emitA('error', { code: 'audio_error' });
    };
    el.src = url;
    var pr = null;
    try { pr = el.play(); } catch (e) { emitA('error', { code: 'play_failed' }); return; }
    if (pr && pr.catch) {
      pr.catch(function (err) {
        if (token !== A.token) return;
        A.el = null;
        // iOS/Safari 在非手势回调里 play() 会被拦：交给调用方决定是否改用本机音色
        emitA('error', { code: (err && err.name === 'NotAllowedError') ? 'blocked' : 'play_failed' });
      });
    }
  }

  function nextChunk(token) {
    if (token !== A.token) return;
    if (A.i >= A.q.length) { A.el = null; emitA('end'); return; }
    var say = A.q[A.i];
    var hit = cacheGet(say);
    if (hit) { emitA('start', { index: A.i + 1, total: A.q.length }); playChunk(hit, token); return; }
    emitA('loading', { index: A.i + 1, total: A.q.length });
    var wd = setTimeout(function () {
      if (token !== A.token) return;
      A.token++;
      emitA('error', { code: 'timeout' });
    }, 40000);
    window.DB.aiInvoke('tts', { text: say, voice: 'loongbella_v3.1', format: 'mp3' }, newRid()).then(function (r) {
      if (token !== A.token) return;
      var body = (r && r.body) || {};
      var d = body.data || {};
      if (r.status !== 200 || body.ok !== true || (!d.audio && !d.audio_url)) {
        emitA('error', { code: body.code || ('tts_' + r.status), message: body.message || '', status: r.status });
        return;
      }
      // 两种情况：gateway 能下载音频就回 base64（可进本机缓存）；从生产区域下不动北京 OSS 时
      // 回有时效的签名 URL，浏览器直接播放。签名 URL 不进缓存（会过期），但同一次朗读内可复用。
      var url;
      try {
        if (d.audio) url = cachePut(say, URL.createObjectURL(b64ToBlob(d.audio, d.mime || 'audio/mpeg')));
        else {
          var u = String(d.audio_url || '');
          if (!/^https?:\/\//i.test(u)) throw new Error('bad_audio_url');
          url = u;
        }
      }
      catch (e) { emitA('error', { code: 'decode_failed' }); return; }
      if (token !== A.token) return;
      if (!A.stats.ttsMs && A.t0) A.stats.ttsMs = Date.now() - A.t0;
      A.stats.ttsChunks++;
      A.stats.ttsCost += Number((body.usage && body.usage.cost_cny) || 0);
      emitA('start', { index: A.i + 1, total: A.q.length });
      playChunk(url, token);
    }).catch(function (e) {
      if (token === A.token) emitA('error', { code: 'network', message: String((e && e.message) || e) });
    });
  }

  // 服务端朗读：同步返回句柄；状态走 opts.onState('begin'|'loading'|'start'|'end'|'error')
  function serverSpeak(text, opts) {
    opts = opts || {};
    var chunks = chunksForSpeech(text);
    stop();
    A.t0 = Date.now();
    if (!chunks.length) return null;
    var token = ++A.token;
    A.onState = opts.onState || null;
    A.q = chunks; A.i = 0;
    emitA('begin', { total: chunks.length });
    nextChunk(token);
    return { stop: function () { stopServerAudio(); emitA('end'); }, total: chunks.length };
  }

  /* ---------- 流式朗读：边生成边按句合成，首句先播，后续预取 ---------- */
  // A3 第一版：文本仍由 chatStream 流式返回；这里把增量切成句子，逐句 TTS 并预取下一句。
  // 不是 WebSocket 全双工；打断由「点麦克风」触发（chat.js 在同一手势里停播并开始录音）。
  var ST = { token: 0, q: [], i: 0, el: null, ended: false, pumping: false, onState: null, started: false, t0: 0, raw: '', inFence: false,
    pcm: false, actx: null, nextAt: 0, sources: [], timers: [], firstAudioAt: 0 };

  // PCM 流式播放：服务商 24kHz / 单声道 / 16-bit little-endian；逐块建 AudioBuffer 并排到时间轴上。
  function audioCtxSupported() {
    return typeof window !== 'undefined' && !!(window.AudioContext || window.webkitAudioContext);
  }
  function pcmReady() {
    return serverTTSReady() && !!(window.DB && window.DB.ttsStream) && audioCtxSupported();
  }
  function getAudioCtx() {
    if (!ST.actx) {
      var C = window.AudioContext || window.webkitAudioContext;
      ST.actx = new C();
    }
    if (ST.actx.state === 'suspended') { try { ST.actx.resume(); } catch (e) { } }
    return ST.actx;
  }
  // iOS/Safari 只有在用户手势里创建的 AudioContext 才能稍后自动播放。
  // 发送、点麦克风、点「听示范」时先解锁并保留同一个 ctx；后续流式 PCM 直接排期。
  function primeAudio() {
    if (!audioCtxSupported()) return null;
    try {
      var ctx = getAudioCtx();
      if (ctx.state === 'suspended') { try { ctx.resume(); } catch (e) { } }
      return ctx;
    } catch (e) { return null; }
  }
  function schedulePcm(bytes) {
    var ctx = ST.actx;
    if (!ctx || !bytes || bytes.length < 2) return;
    var n = Math.floor(bytes.length / 2);
    if (!n) return;
    var view = new DataView(bytes.buffer, bytes.byteOffset, bytes.byteLength);
    var buf = ctx.createBuffer(1, n, 24000);
    var ch = buf.getChannelData(0);
    for (var i = 0; i < n; i++) ch[i] = view.getInt16(i * 2, true) / 32768;
    var src = ctx.createBufferSource();
    src.buffer = buf; src.connect(ctx.destination);
    var at = Math.max(ctx.currentTime + 0.08, ST.nextAt || 0);
    src.start(at);
    ST.nextAt = at + buf.duration;
    ST.sources.push(src);
    src.onended = function () {
      var k = ST.sources.indexOf(src);
      if (k >= 0) ST.sources.splice(k, 1);
    };
    if (!ST.firstAudioAt) { ST.firstAudioAt = Date.now(); A.stats.ttsMs = ST.firstAudioAt - ST.t0; }
  }

  function emitStream(state, payload) {
    if (typeof ST.onState === 'function') { try { ST.onState(state, payload); } catch (e) { } }
  }
  function stopStreamAudio() {
    ST.token++; ST.q = []; ST.i = 0; ST.ended = false; ST.pumping = false; ST.raw = ''; ST.inFence = false;
    for (var i = 0; i < ST.timers.length; i++) { try { clearTimeout(ST.timers[i]); } catch (e) { } }
    ST.timers = [];
    for (var j = 0; j < ST.sources.length; j++) { try { ST.sources[j].stop(); } catch (e) { } }
    ST.sources = []; ST.nextAt = 0; ST.firstAudioAt = 0;
    if (ST.el) {
      try { ST.el.onended = null; ST.el.onerror = null; ST.el.pause(); } catch (e) { }
      try { ST.el.src = ''; } catch (e) { }
      ST.el = null;
    }
  }
  function streamCut(s, first) {
    var i, ch, next, prev;
    for (i = 0; i < s.length; i++) {
      ch = s.charAt(i); next = s.charAt(i + 1);
      if ('。！？!?；;\n'.indexOf(ch) >= 0) return i + 1;
      if (ch === '.' && next && /\s/.test(next)) {
        prev = s.slice(Math.max(0, i - 5), i).toLowerCase();
        if (/\d$/.test(s.charAt(i - 1))) continue;
        if (/(e\.g|i\.e|mr|mrs|dr|vs|etc)$/.test(prev)) continue;
        return i + 1;
      }
    }
    // 第一句不等句号：只要出现逗号/破折号/冒号，就先合成这一小段，
    // 让首段语音尽早开始（长句仍按标点切；后续句子不这样做，避免把整段读得支离破碎）。
    if (first && s.length >= 16) {
      for (i = 8; i < s.length; i++) {
        ch = s.charAt(i);
        if ('，,、—–:：'.indexOf(ch) >= 0) {
          if (s.slice(0, i).trim().length >= 8) return i + 1;
        }
      }
    }
    // 长句在逗号/顿号处先切，避免等一整段
    if (s.length >= 150) {
      for (i = 120; i < s.length; i++) {
        ch = s.charAt(i);
        if ('，,、'.indexOf(ch) >= 0) return i + 1;
      }
      return 150;
    }
    return -1;
  }
  function streamEnqueue(text) {
    if (!text) return;
    var say = chunksForSpeech(text).join(' ').trim();
    if (!say) return;
    ST.q.push({ text: say, state: 'idle', url: '', p: null, err: null });
    var idx = ST.q.length - 1;
    // 只预取「当前句 + 下一句」，避免一次并发 3 个 TTS 触发上游限流
    if (idx <= ST.i + 1) ensureStream(idx);
    pumpStream(ST.token);
  }
  function streamFeed(delta) {
    if (!delta) return;
    ST.raw += String(delta);
    var raw = ST.raw, idx;
    ST.raw = '';
    // 代码块不朗读；跨增量也保持围栏状态
    while (raw) {
      idx = raw.indexOf(BT + BT + BT);
      if (ST.inFence) {
        if (idx < 0) { ST.raw = raw.slice(-2); return; }
        raw = raw.slice(idx + 3); ST.inFence = false; continue;
      }
      if (idx < 0) { streamTake(raw, false); return; }
      // 围栏前的普通文字先读完（即使没句号，也是完整的一段前言）
      streamTake(raw.slice(0, idx), true);
      raw = raw.slice(idx + 3); ST.inFence = true;
    }
  }
  function streamTake(buf, final) {
    var cut, piece;
    while (buf) {
      cut = streamCut(buf, ST.q.length === 0);
      if (cut < 0) {
        if (final) { streamEnqueue(buf); ST.raw = ''; }
        else { ST.raw = buf; }
        return;
      }
      piece = buf.slice(0, cut); buf = buf.slice(cut);
      streamEnqueue(piece);
    }
    ST.raw = '';
  }
  function ensureStream(idx) {
    if (idx < 0 || idx >= ST.q.length) return null;
    var it = ST.q[idx];
    if (it.p) return it.p;
    if (ST.pcm) return ensurePcmStream(it);
    var hit = cacheGet(it.text);
    if (hit) { it.url = hit; it.state = 'ready'; it.p = Promise.resolve(it); return it.p; }
    it.state = 'loading';
    var token = ST.token;
    it.p = new Promise(function (resolve) {
      var wd = setTimeout(function () {
        if (token !== ST.token || it.state === 'ready') return;
        it.err = 'timeout';
        resolve(it);
      }, 40000);
      window.DB.aiInvoke('tts', { text: it.text, voice: 'loongbella_v3.1', format: 'mp3' }, newRid()).then(function (r) {
        if (token !== ST.token) { clearTimeout(wd); resolve(it); return; }
        var body = (r && r.body) || {}, d = body.data || {};
        if (r.status === 200 && body.ok === true && (d.audio || d.audio_url)) {
          try {
            if (d.audio) it.url = cachePut(it.text, URL.createObjectURL(b64ToBlob(d.audio, d.mime || 'audio/mpeg')));
            else {
              var u = String(d.audio_url || '');
              if (!/^https?:\/\//i.test(u)) throw new Error('bad_audio_url');
              it.url = u;
            }
            it.state = 'ready';
            A.stats.ttsChunks++;
            A.stats.ttsCost += Number((body.usage && body.usage.cost_cny) || 0);
            if (!A.stats.ttsMs && ST.t0) A.stats.ttsMs = Date.now() - ST.t0;
          } catch (e) { it.err = 'decode_failed'; }
        } else {
          it.err = body.code || ('tts_' + r.status);
        }
        clearTimeout(wd); resolve(it);
      }).catch(function (e) {
        clearTimeout(wd);
        it.err = 'network';
        resolve(it);
      });
    });
    return it.p;
  }
  // PCM 流：第一块音频到达并排进时间轴后即 resolve，后续块继续在后台追加；
  // 整句读完（onDone）后再按音频结束时间推进到下一句，避免后一句的块插到前一句中间。
  function ensurePcmStream(it) {
    var token = ST.token;
    it.state = 'loading';
    it.p = new Promise(function (resolve) {
      var settled = false;
      var finish = function () {
        if (settled) return;
        settled = true; clearTimeout(wd); resolve(it);
      };
      var wd = setTimeout(function () {
        if (token !== ST.token || it.ready) return;
        it.err = 'timeout'; finish();
      }, 40000);
      try {
        it.handle = window.DB.ttsStream({
          text: it.text,
          voice: 'loongbella_v3.1',
          requestId: newRid(),
          onMeta: function (m) { it.sampleRate = (m && m.sampleRate) || 24000; },
          onAudio: function (bytes) {
            if (token !== ST.token) return;
            try { schedulePcm(bytes); } catch (e) { it.err = 'decode_failed'; }
            if (!it.ready) A.stats.ttsChunks++;
            it.ready = true; it.state = 'ready';
            finish();
          },
          onDone: function (m) {
            it.done = true;
            it.bytes = (m && m.bytes) || 0;
            if (!it.ready) { it.err = 'tts_empty'; finish(); return; }
            schedulePcmEnd(it, token);
          },
          onError: function (code) {
            it.err = code || 'tts_error';
            if (!it.ready) { it.state = 'error'; finish(); }
            else { schedulePcmEnd(it, token); }
          }
        });
      } catch (e) {
        it.err = 'tts_start_failed'; finish();
      }
    });
    return it.p;
  }
  function schedulePcmEnd(it, token) {
    if (token !== ST.token) return;
    if (it.endTimer) return;
    var ctx = ST.actx;
    var wait = ctx ? Math.max(0, (ST.nextAt - ctx.currentTime) * 1000) + 60 : 0;
    it.endTimer = setTimeout(function () {
      if (token !== ST.token) return;
      ST.i++; ST.pumping = false; pumpStream(token);
    }, wait);
    ST.timers.push(it.endTimer);
  }
  function playStreamItem(it, token) {
    if (token !== ST.token) return;
    if (ST.pcm) {
      if (it.err && !it.ready) {
        ST.pumping = false;
        emitStream('error', { code: it.err || 'audio_error' });
        stopStreamAudio();
        return;
      }
      if (!ST.started) {
        ST.started = true;
        if (!A.stats.ttsMs && ST.t0) A.stats.ttsMs = Date.now() - ST.t0;
        emitStream('start', { index: ST.i + 1, streaming: true, pcm: true });
      }
      if (it.done) schedulePcmEnd(it, token);
      return;
    }
    if (it.err || !it.url) {
      ST.pumping = false;
      emitStream('error', { code: it.err || 'audio_error' });
      stopStreamAudio();
      return;
    }
    var el = new Audio();
    ST.el = el;
    el.preload = 'auto';
    el.onended = function () {
      if (token !== ST.token) return;
      ST.el = null; ST.i++; ST.pumping = false;
      pumpStream(token);
    };
    el.onerror = function () {
      if (token !== ST.token) return;
      ST.el = null; ST.pumping = false;
      emitStream('error', { code: 'audio_error' });
      stopStreamAudio();
    };
    el.src = it.url;
    var pr = null;
    try { pr = el.play(); } catch (e) { ST.pumping = false; emitStream('error', { code: 'play_failed' }); return; }
    if (pr && pr.catch) {
      pr.catch(function (err) {
        if (token !== ST.token) return;
        ST.pumping = false;
        emitStream('error', { code: (err && err.name === 'NotAllowedError') ? 'blocked' : 'play_failed' });
      });
    }
    if (!ST.started) { ST.started = true; if (!A.stats.ttsMs && ST.t0) A.stats.ttsMs = Date.now() - ST.t0; }
    emitStream(it.first ? 'start' : 'start', { index: ST.i + 1, streaming: true });
  }
  function pumpStream(token) {
    if (token !== ST.token || ST.pumping) return;
    ST.pumping = true;
    if (ST.i >= ST.q.length) {
      ST.pumping = false;
      if (ST.ended) emitStream('end');
      return;
    }
    var it = ST.q[ST.i];
    ensureStream(ST.i).then(function () {
      if (token !== ST.token) { ST.pumping = false; return; }
      ensureStream(ST.i + 1);
      if (it.err && !it.ready) { ST.pumping = false; emitStream('error', { code: it.err }); stopStreamAudio(); return; }
      if (it.state === 'ready') playStreamItem(it, token);
      else ST.pumping = false;
    });
  }
  // 返回句柄：push(增量) / end() / stop()；状态 begin|loading|start|end|error
  function streamSpeak(opts) {
    opts = opts || {};
    if (!serverTTSReady()) return null;
    stop();
    ST.pcm = pcmReady();
    if (ST.pcm) {
      try { getAudioCtx(); } catch (e) { ST.pcm = false; }
    }
    ST.sources = []; ST.timers = []; ST.nextAt = 0; ST.firstAudioAt = 0;
    var token = ++ST.token;
    ST.q = []; ST.i = 0; ST.ended = false; ST.pumping = false; ST.raw = ''; ST.inFence = false;
    ST.started = false; ST.t0 = Date.now(); ST.onState = opts.onState || null;
    emitStream('begin', { streaming: true });
    var handle = {
      push: function (d) { if (token === ST.token) streamFeed(d); },
      end: function () {
        if (token !== ST.token) return;
        if (!ST.inFence && ST.raw) streamTake(ST.raw, true);
        ST.raw = '';
        ST.ended = true;
        pumpStream(token);
      },
      stop: function () {
        if (token !== ST.token) return;
        stopStreamAudio();
        emitStream('end', { stopped: true });
      },
      active: function () { return token === ST.token; }
    };
    return handle;
  }

  /* ---------- 服务端语音识别：录音（<=15 秒）→ 网关 ASR → 文字 ---------- */
  var ASR_SERVER_KEY = 'lumi_asr_server_v1';
  function serverConsent() {
    var ok = false;
    try { if (window.localStorage.getItem(ASR_SERVER_KEY) === '1') return true; } catch (e) { }
    try {
      ok = window.confirm('语音对话说明：\n\n1) 点麦克风才会开始录音，最多录 15 秒，说完再点一下发送。\n2) 录音会先发到 Lumi 的服务器，再交给语音识别服务转成文字；默认不长期保存原始录音。\n3) 每次语音识别与朗读都会产生少量费用（计入你的每月额度）。\n4) 识别结果会先填进输入框再自动发送，你可以先改文字。\n\n继续使用语音对话吗？');
    } catch (e) { ok = true; }
    if (ok) { try { window.localStorage.setItem(ASR_SERVER_KEY, '1'); } catch (e) { } }
    return ok;
  }

  var R = { token: 0, rec: null, stream: null, chunks: [], t0: 0, stopAt: 0, timer: null };

  function pickRecMime() {
    var cands = ['audio/webm;codecs=opus', 'audio/webm', 'audio/ogg;codecs=opus', 'audio/mp4'];
    if (typeof window.MediaRecorder !== 'function' || !window.MediaRecorder.isTypeSupported) return '';
    for (var i = 0; i < cands.length; i++) { try { if (MediaRecorder.isTypeSupported(cands[i])) return cands[i]; } catch (e) { } }
    return '';
  }
  function fmtOfMime(mime) {
    var m = String(mime || '').toLowerCase();
    if (m.indexOf('webm') >= 0) return 'webm';
    if (m.indexOf('mp4') >= 0) return 'm4a';
    if (m.indexOf('ogg') >= 0) return 'ogg';
    if (m.indexOf('mpeg') >= 0) return 'mp3';
    if (m.indexOf('wav') >= 0) return 'wav';
    return 'webm';
  }
  function dropStream(stream) {
    try { (stream || R.stream).getTracks().forEach(function (t) { t.stop(); }); } catch (e) { }
  }
  /* 自动断句（endpointing）：说话后停顿约 1.2 秒自动结束录音，不用手动点停止。
   * 只用 AnalyserNode 判断音量，不上传音频；识别仍然只走一次 ASR。 */
  var VAD = { ctx: null, src: null, an: null, timer: null, spoke: false, voiceMs: 0, lastVoice: 0, started: 0 };
  function vadStop() {
    if (VAD.timer) { clearInterval(VAD.timer); VAD.timer = null; }
    try { if (VAD.src) VAD.src.disconnect(); } catch (e) { }
    try { if (VAD.ctx && VAD.ctx.state !== 'closed') VAD.ctx.close(); } catch (e) { }
    VAD.ctx = null; VAD.src = null; VAD.an = null; VAD.spoke = false; VAD.voiceMs = 0;
  }
  function startVad(stream, token, rec, opts) {
    var AC = window.AudioContext || window.webkitAudioContext;
    if (!AC) return;
    try { VAD.ctx = new AC(); } catch (e) { return; }
    try { VAD.ctx.resume(); } catch (e) { }
    try {
      VAD.src = VAD.ctx.createMediaStreamSource(stream);
      VAD.an = VAD.ctx.createAnalyser();
      VAD.an.fftSize = 1024;
      VAD.an.smoothingTimeConstant = 0.5;
      VAD.src.connect(VAD.an);
    } catch (e) { vadStop(); return; }
    var buf = new Float32Array(VAD.an.fftSize);
    VAD.started = Date.now(); VAD.spoke = false; VAD.voiceMs = 0; VAD.lastVoice = 0;
    VAD.timer = setInterval(function () {
      if (!VAD.an) return;
      if (token !== R.token) { vadStop(); return; }
      try { VAD.an.getFloatTimeDomainData(buf); } catch (e) { return; }
      var sum = 0, i;
      for (i = 0; i < buf.length; i++) { sum += buf[i] * buf[i]; }
      var rms = Math.sqrt(sum / buf.length);
      var now = Date.now();
      if (rms > 0.015) {
        VAD.voiceMs += 100;
        VAD.lastVoice = now;
        if (VAD.voiceMs >= 250) VAD.spoke = true;
      }
      if (VAD.spoke && now - VAD.lastVoice >= 1200) {
        vadStop();
        try { if (rec.state !== 'inactive') rec.stop(); } catch (e) { }
        return;
      }
      if (!VAD.spoke && now - VAD.started >= 8000) {
        vadStop();
        token = ++R.token;
        try { rec.onstop = null; if (rec.state !== 'inactive') rec.stop(); } catch (e) { }
        dropStream(); recReset();
        if (opts.onError) opts.onError('no_speech');
      }
    }, 100);
  }
  function recReset() {
    vadStop();
    if (R.timer) { clearTimeout(R.timer); R.timer = null; }
    if (R.wd) { clearTimeout(R.wd); R.wd = null; }
    R.rec = null; R.chunks = []; R.t0 = 0;
  }

  function serverRecord(opts) {
    opts = opts || {};
    if (!serverASRReady()) { if (opts.onError) opts.onError('unsupported'); return null; }
    if (R.rec) return null;
    if (!serverConsent()) { if (opts.onError) opts.onError('cancelled'); return null; }
    var token = ++R.token;
    var maxMs = Math.min(15000, Math.max(3000, opts.maxMs || 15000));
    var handle = {
      stop: function () { if (token !== R.token) return; try { if (R.rec && R.rec.state !== 'inactive') R.rec.stop(); } catch (e) { } },
      abort: function () {
        if (token !== R.token) return;
        token = ++R.token;
        try { if (R.rec && R.rec.state !== 'inactive') { R.rec.onstop = null; R.rec.stop(); } } catch (e) { }
        dropStream(); recReset();
        if (opts.onState) { try { opts.onState('cancelled'); } catch (e) { } }
      },
      active: function () { return !!R.rec; }
    };
    if (opts.onState) { try { opts.onState('opening'); } catch (e) { } }
    navigator.mediaDevices.getUserMedia({ audio: { channelCount: 1, echoCancellation: true, noiseSuppression: true, autoGainControl: true } })
      .then(function (stream) {
        if (token !== R.token) { dropStream(stream); return; }
        R.stream = stream;
        var mime = pickRecMime();
        var rec;
        try { rec = mime ? new MediaRecorder(stream, { mimeType: mime }) : new MediaRecorder(stream); }
        catch (e) { dropStream(stream); if (opts.onError) opts.onError('recorder_failed'); return; }
        R.rec = rec; R.chunks = []; R.t0 = Date.now();
        rec.ondataavailable = function (ev) { if (ev.data && ev.data.size) R.chunks.push(ev.data); };
        rec.onerror = function () {
          if (token !== R.token) return;
          dropStream(); recReset();
          if (opts.onError) opts.onError('recorder_error');
        };
        rec.onstop = function () {
          if (token !== R.token) { dropStream(); recReset(); return; }
          var ms = Date.now() - R.t0;
          R.stopAt = Date.now();
          var type = rec.mimeType || mime || 'audio/webm';
          var blob = new Blob(R.chunks, { type: type });
          dropStream();
          if (R.timer) { clearTimeout(R.timer); R.timer = null; }
          R.rec = null;
          if (ms < 600 || blob.size < 600) { recReset(); if (opts.onError) opts.onError('too_short'); return; }
          if (opts.onState) { try { opts.onState('recognizing'); } catch (e) { } }
          var fr = new FileReader();
          fr.onerror = function () { recReset(); if (opts.onError) opts.onError('read_failed'); };
          fr.onload = function () {
            var dataUrl = String(fr.result || '');
            var b64 = dataUrl.slice(dataUrl.indexOf(',') + 1);
            var fmt = fmtOfMime(type);
            R.wd = setTimeout(function () {
              if (token !== R.token) return;
              token = ++R.token; recReset();
              if (opts.onError) opts.onError('timeout');
            }, 30000);
            window.DB.aiInvoke('asr', { audio: b64, format: fmt, sample_rate: '16000' }, newRid()).then(function (r) {
              if (token !== R.token) return;
              recReset();
              var body = (r && r.body) || {};
              if (r.status === 200 && body.ok === true && body.data) {
                var text = String(body.data.text || '').trim();
                var cost = (body.usage && body.usage.cost_cny) || 0;
                A.stats.asrMs = R.stopAt ? (Date.now() - R.stopAt) : 0;
                A.stats.asrSeconds = body.data.seconds || 0;
                A.stats.asrCost += Number(cost || 0);
                A.stats.asrText = text;
                if (opts.onText) opts.onText(text, { seconds: body.data.seconds || 0, cost_cny: cost });
              } else {
                if (opts.onError) opts.onError(body.code || ('asr_' + r.status), body.message || '', r.status);
              }
            }).catch(function (e) {
              if (token !== R.token) return;
              recReset();
              if (opts.onError) opts.onError('network', String((e && e.message) || e));
            });
          };
          fr.readAsDataURL(blob);
        };
        try { rec.start(200); } catch (e) { dropStream(); recReset(); if (opts.onError) opts.onError('start_failed'); return; }
        if (opts.onState) { try { opts.onState('recording'); } catch (e) { } }
        if (opts.autoStop !== false) startVad(stream, token, rec, opts);
        R.timer = setTimeout(function () { if (token !== R.token) return; try { if (rec.state !== 'inactive') rec.stop(); } catch (e) { } }, maxMs);
      })
      .catch(function (err) {
        if (token !== R.token) return;
        recReset();
        var name = String((err && err.name) || '');
        if (opts.onError) opts.onError(name === 'NotAllowedError' || name === 'SecurityError' ? 'not-allowed' : (name === 'NotFoundError' ? 'no_mic' : 'mic_failed'));
      });
    return handle;
  }

  window.Voice = {
    ttsSupported: HAS_TTS,
    asrSupported: !!SR,
    speak: speak,
    stop: stop,
    speaking: speaking,
    listen: listen,
    serverTTSReady: serverTTSReady,
    serverASRReady: serverASRReady,
    initServerAccess: initServerAccess,
    serverAccess: function () { return ACCESS.on; },
    serverSpeak: serverSpeak,
    streamSpeak: streamSpeak,
    primeAudio: primeAudio,
    serverRecord: serverRecord,
    serverSpeaking: serverSpeaking,
    stats: function () { return A.stats; },
    stopServerAudio: stopServerAudio,
    asrConsent: asrConsent,
    voices: voicesNow,
    warm: warm,
    _segments: segments
  };
})();