/* ============================================================
 * assets/core/config.js —— 全站唯一配置入口
 * 你只需要改这一个文件。改完刷新页面即可。
 * 注意：这里只能放 anon public key（公开的只读钥匙）。
 *       service_role key 绝对不能写在这里，它只放在 Cloudflare Worker。
 * ============================================================ */
window.APP_CONFIG = {
  // ① Supabase 项目地址（Project URL）。
  //    留空 = 离线体验模式（数据存本机浏览器，不联网、不花钱）。
  SUPABASE_URL: 'https://ajyvmcqrttcalhliagnr.supabase.co',
  // ② anon public key（Settings → API Keys → Legacy → anon public）。
  //    这是公开钥匙，可以放在前端；它没有权限读写别人的数据（靠 RLS 保护）。
  SUPABASE_ANON_KEY: 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6ImFqeXZtY3FydHRjYWxobGlhZ25yIiwicm9sZSI6ImFub24iLCJpYXQiOjE3OTUwNjIyMzYsImV4cCI6MjExMDYzODIzNn0.cHnK5lI7iy7YGaG66cbiG6whmxwP_mmM42XWoQ4SJeM',

  // A3 实时语音中继（本项目自建的 Supabase Edge Function，仅白名单账号可用）。
  REALTIME_VOICE_URL: 'wss://ajyvmcqrttcalhliagnr.supabase.co/functions/v1/a3-realtime',

  // ③ 预算（单位：元）。服务端以 profiles 表为准，这里只作未登录/离线兜底显示。
  MONTHLY_BUDGET_CNY: 30.0,
  DAILY_BUDGET_CNY: 5.0,

  // ④ 功能开关：与线上实际能力保持一致（2026-11-27 核对）。
  FEATURES: {
    AI_GENERATE: true,
    AI_CHAT: true,     // 第 14 步 P1：AI 英语老师（聊天）
    SPEECH_TTS: true,      // 本机朗读默认可用；服务端付费 TTS 另受 VOICE_SERVER + 白名单控制
    VOICE_REALTIME: true,
    VOICE_SERVER: true,    // 服务端真实语音（付费）：仅 voice_allowlist 内的账号可用，其余自动回退本机语音
    SPEECH_ASR: true,      // 本机语音识别可用（需用户同意麦克风）；服务端付费 ASR 同样受白名单控制
    WEEKLY_TEST: true,
    NEWS_MATERIAL: false,
    // 邀请制：关闭公开注册后前端隐藏「注册一个」入口（Supabase Auth 也需 disable_signup=true）
    ALLOW_REGISTER: false
  },

  // 每日学习量由词书中心的用户偏好及服务端任务规则决定，不设固定时长。
  APP_VERSION: 'v52.65'
};
