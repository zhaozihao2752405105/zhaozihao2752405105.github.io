/* Lumi Words · 统一学习上下文 + AI 学习建议（客户端）
 * 说明：
 *   1) learning_context() 是只读 RPC，零 AI 调用；这里只在本地缓存 30 分钟，避免每次进首页都打库。
 *   2) 学习建议走网关 plan 动作，服务端同一天同上下文只生成一次；客户端再缓存当天结果。
 *   3) focus_words 由本地规则挑选（60% 未掌握 + 40% 近期学过），不额外调用模型。
 */
(function () {
  'use strict';

  var KEY_CTX = 'lumi.ctx.v1';
  var KEY_SUG = 'lumi.plan.sug.v1';
  var KEY_LAST = 'lumi.plan.focuslast.v1';
  var KEY_SKIP = 'lumi.plan.skip.v1';
  var CTX_TTL = 30 * 60 * 1000;

  var mem = null;

  function today() {
    var d = new Date();
    var p = function (n) { return (n < 10 ? '0' : '') + n; };
    return d.getFullYear() + '-' + p(d.getMonth() + 1) + '-' + p(d.getDate());
  }

  function readJson(key, def) {
    try {
      var raw = localStorage.getItem(key);
      return raw ? (JSON.parse(raw) || def) : def;
    } catch (e) { return def; }
  }

  function writeJson(key, val) {
    try { localStorage.setItem(key, JSON.stringify(val)); } catch (e) { /* 忽略 */ }
  }

  function cachedCtx() {
    var c = readJson(KEY_CTX, null);
    if (!c || !c.at || !c.ctx) return null;
    if (Date.now() - c.at > CTX_TTL) return null;
    return c.ctx;
  }

  function loadContext(force) {
    if (!force) {
      if (mem) return Promise.resolve(mem);
      var c = cachedCtx();
      if (c) { mem = c; return Promise.resolve(c); }
    }
    return window.DB.rpc('learning_context').then(function (ctx) {
      if (ctx && ctx.ok) {
        mem = ctx;
        writeJson(KEY_CTX, { at: Date.now(), ctx: ctx });
      }
      return mem;
    }).catch(function () { return mem; });
  }

  function clearContext() {
    mem = null;
    try { localStorage.removeItem(KEY_CTX); } catch (e) { /* 忽略 */ }
  }

  // 60% 未掌握 + 40% 近期学过，按难度过滤长度，避免低级别塞长词。
  function focusWords(module, level, count) {
    var ctx = mem || cachedCtx();
    if (!ctx) return [];
    var lv = Number(level) || 4;
    var maxLen = lv <= 3 ? 9 : (lv <= 6 ? 12 : 20);
    var weak = (ctx.weak_words || []).map(function (x) { return String((x && x.word) || '').toLowerCase(); });
    var recent = (ctx.recent_words || []).map(function (x) { return String((x && x.word) || '').toLowerCase(); });
    var last = readJson(KEY_LAST, []);
    var banned = {};
    (Array.isArray(last) ? last : []).forEach(function (w) { banned[w] = true; });

    function pick(list, n) {
      var out = [];
      for (var i = 0; i < list.length && out.length < n; i++) {
        var w = list[i];
        if (!w || w.length < 2 || w.length > maxLen) continue;
        if (banned[w] || out.indexOf(w) >= 0) continue;
        if (!/^[a-z][a-z'-]*$/.test(w)) continue;
        out.push(w);
      }
      return out;
    }

    var want = Number(count) || (module === 'reading' ? 6 : 4);
    var nWeak = Math.max(1, Math.round(want * 0.6));
    var picked = pick(weak, nWeak).concat(pick(recent, want - nWeak));
    // 不够就互相补
    if (picked.length < 3) picked = picked.concat(pick(weak, 3 - picked.length));
    if (picked.length < 3) picked = picked.concat(pick(recent, 3 - picked.length));
    picked = picked.slice(0, Math.max(3, Math.min(8, want)));
    if (picked.length) {
      writeJson(KEY_LAST, picked.slice().concat(Array.isArray(last) ? last : []).slice(0, 24));
    }
    return picked;
  }

  function skippedToday() {
    var s = readJson(KEY_SKIP, null);
    return !!(s && s.day === today());
  }

  function skipToday() {
    writeJson(KEY_SKIP, { day: today() });
    try { localStorage.removeItem(KEY_SUG); } catch (e) { /* 忽略 */ }
  }

  function cachedSug() {
    var s = readJson(KEY_SUG, null);
    if (!s || s.day !== today() || !s.data) return null;
    return s.data;
  }

  // 拉建议：force=true 时带 refresh 让服务端重算（仍受预算限制）
  function suggestions(force) {
    if (!force) {
      var c = cachedSug();
      if (c) return Promise.resolve({ data: c, cached: true });
    }
    return loadContext(force).then(function (ctx) {
      if (!ctx) return { data: null, cached: false };
      return window.AI.invoke('plan', { context: ctx, refresh: !!force }, {}).then(function (res) {
        var data = res && (res.data || (res.body && res.body.data)) ? (res.data || res.body.data) : null;
        if (!data || !Array.isArray(data.suggestions) || !data.suggestions.length) {
          return { data: null, cached: false, message: (res && (res.message || (res.body && res.body.message))) || '' };
        }
        writeJson(KEY_SUG, { day: today(), data: data });
        return { data: data, cached: false };
      });
    }).catch(function () { return { data: null, cached: false }; });
  }

  function markStart() {
    try { localStorage.removeItem(KEY_SUG); } catch (e) { /* 忽略 */ }
  }

  window.LumiPlan = {
    loadContext: loadContext,
    clearContext: clearContext,
    focusWords: focusWords,
    suggestions: suggestions,
    skippedToday: skippedToday,
    skipToday: skipToday,
    markStart: markStart,
    today: today
  };
})();