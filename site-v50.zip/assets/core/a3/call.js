(function (root) {
  'use strict';
  root.LumiA3 ||= {};
  const { createRealtimeUpload, createSpeechOnset } = root.LumiA3;

const FRAME_BYTES = 640;
const PREROLL_FRAMES = 18;
const MAX_HANDOFF_FRAMES = 170;
const HANDOFF_MS = 3200;
const MAX_SOCKET_BUFFER = 6400;
const REFUSALS = new Set(['voice_forbidden', 'daily_limit', 'site_limit', 'month_limit',
  'session_busy', 'budget_denied', 'invalid_continuation', 'settlement_unconfirmed', 'session_unavailable']);
const SOFT_STOPS = new Set(['handshake_timeout', 'input_limit', 'response_limit', 'frame_invalid',
  'provider_disconnected', 'provider_socket_closed', 'connection_lost']);
const TRANSITIONS = Object.freeze({
  idle: ['admitting'],
  admitting: ['live', 'ended'],
  live: ['cancelling', 'settling', 'ended'],
  cancelling: ['settling', 'ended'],
  settling: ['reconnecting', 'ended'],
  reconnecting: ['admitting', 'ended'],
  ended: ['admitting']
});

function tokenSubject(token) {
  try {
    const part = token.split('.')[1].replace(/-/g, '+').replace(/_/g, '/');
    const subject = JSON.parse(atob(part)).sub;
    return typeof subject === 'string' && subject ? subject : null;
  } catch {
    return null;
  }
}

root.LumiA3.createRealtimeCall = function createRealtimeCall({
  context, endpoint, workletUrl, capture, onState, onChange, onAudioFrame, onPhase, timing, getAccessToken,
  makeSocket = url => new WebSocket(url),
  makeUpload = createRealtimeUpload, makeRequestId = () => crypto.randomUUID()
}) {
  const url = new URL(endpoint);
  const isLoopback = url.hostname === 'localhost' || url.hostname === '127.0.0.1';
  if ((url.protocol !== 'wss:' && !(isLoopback && url.protocol === 'ws:')) ||
      url.username || url.password || url.search || url.hash) {
    throw new Error('Invalid realtime endpoint');
  }

  let active;
  let handoff;
  let owner;
  let state = { phase: 'idle', generation: 0 };

  function transition(phase, generation = state.generation) {
    if (!TRANSITIONS[state.phase].includes(phase) || generation < state.generation) return false;
    state = { phase, generation };
    onPhase?.({ ...state });
    return true;
  }
  const playback = globalThis.LumiPcmPlayback({
    context, sampleRate: 24000,
    onScheduled: mark => timing?.audioScheduled(mark),
    onDrained(responseId) {
      if (active) {
        turns.push({ type: 'playback-drained', responseId, generation: active.generation });
        rotateIfIdle(active);
      }
    }
  });
  const turns = globalThis.LumiRealtimeTurns({
    playback: {
      enqueue(id, samples) {
        playback.enqueue(id, samples);
        onAudioFrame?.('assistant', samples.buffer);
      },
      clear: playback.clear,
      finish: playback.finish
    },
    onChange,
    cancelUpstream(request) { active?.protocol.cancel(request); }
  });

  function closeSocket(socket) {
    if (socket?.readyState <= 1) socket.close();
  }

  function stop(reason = 'ended') {
    const call = active;
    const transfer = handoff;
    if (!call && !transfer) return;
    active = null;
    handoff = null;
    transition('ended');
    clearTimeout(transfer?.deadline);
    clearInterval(transfer?.pump);
    transfer?.upload?.close();
    if (transfer) transfer.queue.length = 0;
    if (call?.upload && call.upload !== transfer?.upload) call.upload.close();
    clearTimeout(call?.timeout);
    turns.end();
    closeSocket(transfer?.oldSocket);
    if (reason === 'interrupted_context' && call?.cancelSent && call.socket.readyState === 1) {
      const cleanup = setTimeout(() => closeSocket(call.socket), 900);
      call.socket.addEventListener('close', () => clearTimeout(cleanup), { once: true });
    } else {
      closeSocket(call?.socket);
    }
    onState(reason);
  }

  function sendPcm(socket, frame) {
    if (socket.readyState !== 1 || socket.bufferedAmount + frame.byteLength > MAX_SOCKET_BUFFER) return false;
    socket.send(frame);
    return true;
  }

  function sendCancel(call) {
    if (call.cancelSent || call.socket.readyState !== 1) return;
    try {
      call.socket.send(JSON.stringify({ type: 'cancel', close: true }));
      call.cancelSent = true;
    } catch {}
  }

  function routeFrame(upload, frame) {
    if (!(frame instanceof ArrayBuffer) || frame.byteLength !== FRAME_BYTES) return false;
    onAudioFrame?.('user', frame);
    if (handoff?.upload === upload) {
      if (handoff.queue.length >= MAX_HANDOFF_FRAMES) {
        stop('reconnect_audio_limit');
        return true;
      }
      handoff.queue.push(frame.slice(0));
      return true;
    }
    const call = active;
    if (!call || call.upload !== upload) return false;
    call.preroll.push(frame.slice(0));
    if (call.preroll.length > PREROLL_FRAMES) call.preroll.shift();
    if (call.detectOnset?.(frame)) turns.interruptPlayback();
    // The detection frame is already in the pre-roll if this call was interrupted.
    return handoff || active !== call ? true : sendPcm(call.socket, frame);
  }

  function rotateIfIdle(call) {
    if (!call?.rotateDue || active !== call || state.phase !== 'live' ||
        call.waitingForResponse || turns.snapshot().response || turns.snapshot().turn?.speaking) return;
    resumeAfterCancellation(call, 'time_limit');
  }

  function resumeAfterCancellation(call, reason) {
    const rotating = reason === 'time_limit';
    const newRoute = reason === 'audio_route_changed';
    if (!owner || !getAccessToken || !call.upload || handoff || call.socket.readyState !== 1 ||
        ((rotating || newRoute) && !call.chain)) {
      stop(reason);
      return;
    }

    const transfer = {
      oldSocket: call.socket, upload: newRoute ? null : call.upload, queue: rotating || newRoute ? [] : call.preroll,
      generation: call.generation, receipt: undefined
    };
    handoff = transfer;
    if (newRoute) call.upload.close();
    active = null;
    if (!rotating) transition('cancelling', call.generation);
    transition('settling', call.generation);
    clearTimeout(call.timeout);
    turns.end();
    if (handoff !== transfer) return;

    transfer.deadline = setTimeout(() => {
      if (handoff === transfer) stop('reconnect_timeout');
    }, HANDOFF_MS);
    call.socket.addEventListener('message', ({ data }) => {
      if (!call.chain || handoff !== transfer || transfer.receipt !== undefined ||
          typeof data !== 'string' || data.length > 1024) return;
      try {
        const message = JSON.parse(data);
        if (message.type === 'settled' && (message.continuation === null ||
            (typeof message.continuation === 'string' && message.continuation.length <= 424))) {
          transfer.receipt = message.continuation;
        }
      } catch {}
    });
    call.socket.addEventListener('close', async ({ code, reason: closeReason }) => {
      if (handoff !== transfer || state.phase !== 'settling' || state.generation !== transfer.generation) return;
      if (code === 1008 && REFUSALS.has(closeReason)) {
        stop(closeReason);
        return;
      }
      if (code !== 1000 || closeReason !== (rotating ? 'rotated' : 'cancelled') ||
          (call.chain && transfer.receipt === undefined)) {
        stop('reconnect_unconfirmed');
        return;
      }
      if (call.chain && transfer.receipt === null) {
        stop('chain_limit');
        return;
      }
      transition('reconnecting', call.generation);
      let token;
      try { token = await getAccessToken(); }
      catch {
        if (handoff === transfer) stop('not_authenticated');
        return;
      }
      if (handoff !== transfer) return;
      if (tokenSubject(token) !== owner) {
        turns.clearHistory();
        stop('not_authenticated');
        return;
      }
      connect(token, { ...call.options, openingTopic: false }, transfer);
    }, { once: true });
    try {
      if (rotating) call.socket.send(JSON.stringify({ type: 'rotate' }));
      else {
        sendCancel(call);
        if (!call.cancelSent) throw new Error('Cancellation send failed');
      }
    } catch {
      stop('reconnect_unconfirmed');
      return;
    }
    onState('reconnecting');
  }

  function drain(call, transfer) {
    function pump() {
      if (active !== call || handoff !== transfer) return;
      try {
        const next = transfer.queue[0];
        if (next && sendPcm(call.socket, next)) transfer.queue.shift();
      } catch {
        stop('audio_upload_unavailable');
        return;
      }
      if (transfer.queue.length) return;
      clearTimeout(transfer.deadline);
      clearInterval(transfer.pump);
      handoff = null;
      transition('live', call.generation);
      onState('listening');
      rotateIfIdle(call);
    }
    transfer.pump = setInterval(pump, 10);
    pump();
  }

  function connect(accessToken, options, transfer) {
    const { language, profile, openingTopic, localBargeIn } = options;
    let socket;
    try { socket = makeSocket(url.href); }
    catch {
      if (transfer) stop('socket_error');
      else {
        transition('admitting');
        transition('ended');
        onState('socket_error');
      }
      return;
    }

    const call = {
      socket, options, ready: false, generation: turns.start(),
      preroll: [], detectOnset: localBargeIn ? createSpeechOnset() : null
    };
    active = call;
    transition('admitting', call.generation);
    const current = () => active === call;
    call.protocol = globalThis.LumiQwenEvents({
      generation: call.generation, turns,
      send(event) { if (event.type === 'response.cancel') sendCancel(call); },
      requireNewSession(reason) {
        if (!current()) return;
        if (reason === 'interrupted_context') resumeAfterCancellation(call, reason);
        else stop(reason);
      }
    });
    call.timeout = setTimeout(() => { if (current()) stop('connection_timeout'); }, 25000);
    socket.addEventListener('open', () => {
      if (!current()) return;
      try {
        const history = turns.snapshot().completed.slice(-6)
          .map(({ role, text }) => ({ role, text: text.slice(0, 160) }));
        const request = { type: 'start', accessToken, requestId: makeRequestId(), language, profile };
        if (history.length) request.history = history;
        if (transfer?.receipt) request.continuation = transfer.receipt;
        let body = JSON.stringify(request);
        const encoder = new TextEncoder();
        while (encoder.encode(body).byteLength > 8192 && history.length) {
          history.shift();
          body = JSON.stringify(request);
        }
        if (encoder.encode(body).byteLength > 8192) throw new Error('Start request exceeds limit');
        socket.send(body);
      } catch { stop('socket_error'); }
      accessToken = undefined;
    });
    socket.addEventListener('message', async ({ data }) => {
      if (!current()) return;
      try {
        if (typeof data !== 'string' || data.length > 262144) throw new Error('Invalid broker message');
        const message = JSON.parse(data);
        if (message.type === 'ready' && !call.ready) {
          call.ready = true;
          call.chain = message.chain === true;
          clearTimeout(call.timeout);
          if (transfer?.upload) {
            call.upload = transfer.upload;
            drain(call, transfer);
            return;
          }
          const canHandoff = Boolean(getAccessToken && owner);
          const upload = makeUpload({
            context, socket, workletUrl, capture,
            sendFrame: canHandoff ? frame => routeFrame(upload, frame) : undefined,
            onFrame: canHandoff ? undefined : pcm => {
              if (!current()) return;
              onAudioFrame?.('user', pcm);
              if (call.detectOnset?.(pcm)) turns.interruptPlayback();
            },
            onFailure: reason => {
              if (active?.upload === upload || handoff?.upload === upload) stop(reason);
            }
          });
          call.upload = upload;
          await upload.start();
          if (current() && transfer) drain(call, transfer);
          else if (current()) {
            transition('live', call.generation);
            onState('listening');
            if (current() && openingTopic && !turns.snapshot().completed.length && call.protocol.requestOpening()) {
              call.waitingForResponse = true;
              socket.send(JSON.stringify({ type: 'opening_topic' }));
            }
          }
        } else if (message.type === 'opening_skipped' && call.ready) {
          call.protocol.skipOpening();
          call.waitingForResponse = false;
          rotateIfIdle(call);
        } else if (message.type === 'rotate_due' && call.chain) {
          call.rotateDue = true;
          rotateIfIdle(call);
        } else if (message.type === 'provider' && call.ready) {
          const accepted = call.protocol.receive(message.event);
          if (!current()) return;
          if (accepted && message.event.type === 'input_audio_buffer.speech_started') call.waitingForResponse = true;
          if (message.event.type === 'input_audio_buffer.speech_stopped') timing?.speechStopped();
          if (accepted && message.event.type === 'response.created') call.waitingForResponse = false;
          rotateIfIdle(call);
        }
      } catch {
        if (current()) stop('event_error');
      }
    });
    socket.addEventListener('error', () => { if (current()) stop('socket_error'); });
    socket.addEventListener('close', ({ code, reason }) => {
      if (!current()) return;
      stop(REFUSALS.has(reason) ? reason : (SOFT_STOPS.has(reason) ? reason : 'connection_lost'));
    });
    if (!transfer) onState('connecting');
  }

  return {
    start(token, { language, profile, openingTopic = false, localBargeIn = false } = {}) {
      if (active || handoff) return;
      const subject = tokenSubject(token);
      if (owner && subject !== owner) turns.clearHistory();
      owner = subject;
      connect(token, { language, profile, openingTopic, localBargeIn });
    },
    end: () => stop(),
    pause: () => stop('paused'),
    offline: () => stop('offline'),
    routeChanged() {
      if (!active || state.phase !== 'live') return;
      resumeAfterCancellation(active, 'audio_route_changed');
    },
    snapshotState: () => ({ ...state }),
    clearHistory: turns.clearHistory
  };
};
})(globalThis);
