﻿(function (root) {
  'use strict';
  function relayUrl() {
    var cfg = root.APP_CONFIG;
    if (cfg?.FEATURES?.VOICE_REALTIME !== true || !cfg.REALTIME_VOICE_URL) return null;
    try {
      var endpoint = new URL(cfg.REALTIME_VOICE_URL);
      var project = new URL(cfg.SUPABASE_URL);
      if (project.protocol !== 'https:' || endpoint.protocol !== 'wss:' || endpoint.host !== project.host ||
          endpoint.pathname !== '/functions/v1/a3-realtime' || endpoint.username || endpoint.password ||
          endpoint.search || endpoint.hash) return null;
      return endpoint.href;
    } catch {
      return null;
    }
  }
  root.LumiA3 ||= {};
  root.LumiA3.relayUrl = relayUrl;
  var entry = document.getElementById('a3VoiceEntry');
  if (entry && relayUrl()) {
    entry.hidden = false;
    entry.classList.remove('hide');
  }
})(window);
