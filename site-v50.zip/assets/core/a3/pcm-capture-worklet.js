/* Mono PCM16 little-endian at 16 kHz. The worklet emits 20 ms frames. */
class LumiPcmCaptureProcessor extends AudioWorkletProcessor {
  constructor() {
    super();
    this.step = sampleRate / 16000;
    this.enabled = false;
    this.epoch = 0;
    this.reset();
    this.port.onmessage = ({ data }) => {
      this.enabled = data.enabled;
      this.epoch = data.epoch;
      this.reset();
    };
  }

  reset() {
    this.frame = new DataView(new ArrayBuffer(640));
    this.frameOffset = 0;
    this.remaining = this.step;
    this.sum = 0;
  }

  process(inputs) {
    const channel = inputs[0]?.[0];
    if (!this.enabled || !channel) return true;
    for (const sample of channel) {
      let available = 1;
      while (available > 0.000001) {
        const weight = Math.min(available, this.remaining);
        this.sum += sample * weight;
        this.remaining -= weight;
        available -= weight;
        if (this.remaining > 0.000001) continue;

        const value = Math.max(-1, Math.min(1, this.sum / this.step));
        this.frame.setInt16(this.frameOffset, Math.round(value * (value < 0 ? 32768 : 32767)), true);
        this.frameOffset += 2;
        this.sum = 0;
        this.remaining = this.step;
        if (this.frameOffset === this.frame.byteLength) {
          const { buffer } = this.frame;
          this.port.postMessage({ buffer, epoch: this.epoch }, [buffer]);
          this.frame = new DataView(new ArrayBuffer(640));
          this.frameOffset = 0;
        }
      }
    }
    return true;
  }
}

registerProcessor('lumi-pcm-capture', LumiPcmCaptureProcessor);
