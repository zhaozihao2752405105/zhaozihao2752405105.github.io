(function (root) {
  'use strict';
  root.LumiA3 ||= {};

root.LumiA3.createRealtimeUpload = function createRealtimeUpload({ context, socket, workletUrl, capture, onFailure, onFrame, sendFrame, maxBufferedBytes = 6400 }) {
  let source;
  let processor;
  let media;
  let starting;
  let closed = false;
  let paused = false;
  let epoch = 0;

  function close() {
    if (closed) return;
    closed = true;
    if (processor) {
      processor.port.onmessage = null;
      processor.port.close();
      processor.disconnect();
    }
    source?.disconnect();
    media?.getTracks().forEach(track => track.stop());
  }

  function fail(reason) {
    if (closed) return;
    close();
    onFailure(reason);
  }

  async function initialize() {
    await context.audioWorklet.addModule(workletUrl);
    if (closed) return;
    const stream = await capture();
    if (closed) {
      stream.getTracks().forEach(track => track.stop());
      return;
    }
    media = stream;
    source = context.createMediaStreamSource(media);
    processor = new AudioWorkletNode(context, 'lumi-pcm-capture', {
      channelCount: 1,
      channelCountMode: 'explicit',
      numberOfInputs: 1,
      numberOfOutputs: 1,
      outputChannelCount: [1]
    });
    processor.port.onmessage = ({ data }) => {
      if (closed || paused || data.epoch !== epoch) return;
      if (!sendFrame && (socket.readyState !== 1 || socket.bufferedAmount + data.buffer.byteLength > maxBufferedBytes)) {
        fail('audio_upload_unavailable');
        return;
      }
      try {
        onFrame?.(data.buffer);
        if (!closed && sendFrame) {
          if (!sendFrame(data.buffer)) fail('audio_upload_unavailable');
        } else if (!closed) socket.send(data.buffer);
      }
      catch { fail('audio_upload_unavailable'); }
    };
    setPaused(paused);
    // No microphone sound reaches the speakers. The worklet writes no output samples.
    source.connect(processor).connect(context.destination);
  }

  function setPaused(pause) {
    if (closed) return;
    paused = Boolean(pause);
    media?.getAudioTracks().forEach(track => { track.enabled = !paused; });
    processor?.port.postMessage({ enabled: !paused, epoch: ++epoch });
  }

  return {
    start() {
      if (!closed && !starting) starting = initialize().catch(() => fail('audio_capture_failed'));
      return starting;
    },
    setPaused,
    close
  };
};
})(globalThis);
