(function (root) {
  'use strict';
  root.LumiA3 ||= {};

  function usesAppleMobileAudio(navigator) {
    return /iPad|iPhone|iPod/.test(navigator.userAgent || '') ||
      navigator.platform === 'MacIntel' && navigator.maxTouchPoints > 1;
  }

  function silentMediaSource() {
    const samples = 800;
    const bytes = new Uint8Array(44 + samples * 2);
    const view = new DataView(bytes.buffer);
    for (const [offset, label] of [[0, 'RIFF'], [8, 'WAVEfmt '], [36, 'data']]) {
      for (let index = 0; index < label.length; index++) bytes[offset + index] = label.charCodeAt(index);
    }
    view.setUint32(4, bytes.length - 8, true);
    view.setUint32(16, 16, true);
    view.setUint16(20, 1, true);
    view.setUint16(22, 1, true);
    view.setUint32(24, 8000, true);
    view.setUint32(28, 16000, true);
    view.setUint16(32, 2, true);
    view.setUint16(34, 16, true);
    view.setUint32(40, samples * 2, true);
    return 'data:audio/wav;base64,' + btoa(String.fromCharCode(...bytes));
  }

  function audioHint({ contextState, mediaBlocked, silentMs }) {
    if (contextState !== 'running') return 'audio_tap_required';
    if (mediaBlocked) return 'audio_media_blocked';
    return silentMs >= 1500 ? 'audio_silent_frames' : null;
  }
  Object.assign(root.LumiA3, { usesAppleMobileAudio, silentMediaSource, audioHint });

  root.LumiA3.createAudioLifecycle = function createAudioLifecycle({
    context, navigator, document, onInterrupted, onRouteChange, onAudioHint = () => {}, resumeTimeoutMs = 1200
  }) {
    const session = navigator.audioSession;
    const devices = navigator.mediaDevices;
    let media, mediaBlocked = false, silentMs = 0, previousHint;
    let listening = false, unlocking = false, route, revision = 0, disposed = false;

    function setSession(type) {
      if (!session) return;
      try { session.type = type; } catch {}
    }

    function publishHint() {
      const next = listening ? audioHint({ contextState: context.state, mediaBlocked, silentMs }) : null;
      if (next !== previousHint) {
        previousHint = next;
        onAudioHint(next);
      }
    }

    function startMedia() {
      if (!usesAppleMobileAudio(navigator) || !document.createElement) return;
      if (!media) {
        media = document.createElement('audio');
        media.loop = true;
        media.playsInline = true;
        media.hidden = true;
        media.src = silentMediaSource();
        document.body?.appendChild(media);
      }
      // Intentionally use a file with zero samples. A muted element may use a different audio path.
      const job = media.play();
      job?.then(() => { mediaBlocked = false; publishHint(); }).catch(() => {
        if (listening && !disposed) { mediaBlocked = true; publishHint(); }
      });
    }

    async function unlockFromGesture(duplex = false) {
      if (disposed || document.hidden || session?.state === 'interrupted') return false;
      let deadline;
      unlocking = true;
      try {
        setSession(duplex ? 'play-and-record' : 'playback');
        mediaBlocked = false;
        try { startMedia(); } catch { mediaBlocked = true; }
        const resumed = context.resume();
        await Promise.race([resumed, new Promise(resolve => { deadline = setTimeout(resolve, resumeTimeoutMs); })]);
        return !disposed && !document.hidden && context.state === 'running' && session?.state !== 'interrupted';
      } catch {
        return false;
      } finally {
        clearTimeout(deadline);
        unlocking = false;
        publishHint();
      }
    }

    async function refreshRoute(notify) {
      const job = ++revision;
      try {
        const list = await devices?.enumerateDevices?.();
        if (job !== revision || disposed || !list) return;
        const next = list.filter(device => device.kind === 'audioinput' || device.kind === 'audiooutput')
          .map(device => [device.kind, device.deviceId, device.groupId].join('/')).join('|');
        const changed = route !== undefined && next !== route;
        route = next;
        if (notify && changed && listening && !document.hidden) onRouteChange();
      } catch {}
    }

    function stateChanged() {
      if (listening && !unlocking && (context.state === 'interrupted' || context.state === 'suspended' ||
          context.state === 'closed' || session?.state === 'interrupted')) onInterrupted();
    }
    function deviceChanged() { void refreshRoute(true); }
    function trackEnded() { if (listening && !document.hidden) onRouteChange(); }

    context.addEventListener('statechange', stateChanged);
    session?.addEventListener?.('statechange', stateChanged);
    devices?.addEventListener?.('devicechange', deviceChanged);

    return {
      unlockFromGesture,
      async capture(constraints) {
        setSession('play-and-record');
        const stream = await devices.getUserMedia(constraints);
        for (const track of stream.getAudioTracks()) track.addEventListener('ended', trackEnded, { once: true });
        void refreshRoute(false);
        return stream;
      },
      observePlayback(pcm) {
        if (!listening || !(pcm instanceof ArrayBuffer)) return;
        const samples = new DataView(pcm);
        let audible = false;
        for (let offset = 0; offset + 1 < samples.byteLength; offset += 2) {
          if (Math.abs(samples.getInt16(offset, true)) > 16) { audible = true; break; }
        }
        silentMs = audible ? 0 : silentMs + samples.byteLength / 48;
        publishHint();
      },
      resetPlaybackHint() {
        silentMs = 0;
        publishHint();
      },
      setListening(value) {
        listening = value;
        if (!value) {
          media?.pause();
          mediaBlocked = false;
          silentMs = 0;
          if (!unlocking) setSession('auto');
        }
        publishHint();
      },
      dispose() {
        disposed = true;
        listening = false;
        revision++;
        media?.pause();
        media?.remove();
        media = undefined;
        context.removeEventListener('statechange', stateChanged);
        session?.removeEventListener?.('statechange', stateChanged);
        devices?.removeEventListener?.('devicechange', deviceChanged);
        setSession('auto');
      }
    };
  };
})(globalThis);
