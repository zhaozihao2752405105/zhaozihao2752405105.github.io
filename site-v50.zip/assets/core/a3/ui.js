(function (root) {
  'use strict';

  const $ = id => document.getElementById(id);
  const start = $('a3Start'), pause = $('a3Pause'), end = $('a3End'), clear = $('a3Clear');
  const status = $('a3Status'), draft = $('a3Draft'), history = $('a3History'), language = $('a3Language');
  const fallback = $('a3Fallback'), fallbackMessages = [...fallback.querySelectorAll('[data-a3-fallback]')];
  const audioHelp = $('a3AudioHelp'), audioHint = $('a3AudioHint'), audioRetry = $('a3AudioRetry');
  const wave = $('a3Wave'), bars = Array.from(wave.children);
  const labels = {
    idle: '等待开始',
    connecting: '正在连接…',
    listening: '正在聆听',
    listening_repeat: '实时语音已接上，请重说刚才那句话。',
    audio_tap_required: '声音已暂停。请点一下开始，重新启用声音。',
    audio_media_blocked: '浏览器拦截了音频。请点「重新启用声音」。',
    audio_silent_frames: '收到的回复音频没有声音。请重试，或返回普通聊天。',
    reconnecting: '正在接续，继续说即可',
    reconnecting_wait: '仍在接续，请等连接恢复后再说。',
    closing: '正在结束这段对话…',
    paused: '已暂停',
    ended: '已结束',
    offline: '网络已断开。联网后可继续。',
    connection_timeout: '连接超时，可以重试或返回普通语音聊天。',
    connection_lost: '实时连接已关闭，可以重试。',
    frame_invalid: '语音数据有问题，已经停下。点「继续」重新开始这一段。',
    provider_disconnected: '语音服务刚才断了一下。点「继续」接着聊。',
    reconnect_timeout: '接续超时。请点继续并重说刚才那句话。',
    reconnect_unconfirmed: '未能接续。请点继续并重说刚才那句话。',
    reconnect_audio_limit: '接续耗时过长。请点继续并重说刚才那句话。',
    voice_forbidden: '当前账号未开通实时语音。',
    daily_limit: '今日语音配额已用完。',
    month_limit: '本月 AI 预算已用完。',
    site_limit: '当前语音额度已用完。',
    budget_denied: '本次实时语音额度未能确认。可先用普通语音聊天。',
    session_unavailable: '实时语音服务暂时无法连接。请稍后重试，或返回普通语音聊天。',
    session_busy: '还有一段语音会话正在结束，请稍后重试。',
    invalid_continuation: '上一段对话无法接续。可以点「继续」开始新一段。',
    not_authenticated: '登录状态已失效，请重新登录后再试。',
    audio_capture_failed: '无法使用麦克风，请检查浏览器权限。',
    audio_upload_unavailable: '音频无法上传，请检查网络。',
    time_limit: '这一段对话到时了。点「继续」接着聊。',
    chain_limit: '连续对话已达到上限，可以重新开始一段。',
    input_limit: '这一段说话的时长用完了，已经自动停下。点「继续」接着聊。',
    response_limit: '这一段回答到上限了，已经自动停下。点「继续」接着聊。',
    handshake_timeout: '连接没有建立起来，请重试。',
    handshake_failed: '连接没有建立起来，请重试。',
    socket_connect_failed: '实时语音连接未建立。请重试，或返回普通语音聊天。',
    socket_error: '实时语音连接意外关闭。可以点「继续」重试。',
    settlement_unconfirmed: '上一段结算没有确认，请稍后重试。',
    output_backpressure: '网络太慢，实时语音已经停下，请重试。',
    unavailable: '实时语音暂未开放，可以返回普通语音聊天。'
  };
  const running = new Set(['connecting', 'listening', 'listening_repeat', 'reconnecting', 'reconnecting_wait']);
  const budgetStops = new Set(['daily_limit', 'month_limit', 'site_limit', 'budget_denied']);
  const connectionStops = new Set(['socket_connect_failed', 'connection_timeout', 'connection_lost', 'input_limit', 'time_limit', 'chain_limit',
    'response_limit', 'frame_invalid', 'provider_disconnected', 'reconnect_timeout',
    'reconnect_unconfirmed', 'audio_upload_unavailable', 'socket_error', 'settlement_unconfirmed',
    'session_busy', 'handshake_timeout', 'invalid_continuation', 'output_backpressure']);
  const endpoint = root.LumiA3.relayUrl();
  const Audio = root.AudioContext || root.webkitAudioContext;
  let phase = 'unavailable', user, context, audio, call, operation = 0, role = 'idle', waitTimer = 0;
  let displayed = [];
  let speakingLevel, speakingUnit, resumedHistorySize = 0;
  let profileRequest;

  async function optional(request) {
    let timeout;
    try {
      return await Promise.race([
        Promise.resolve(request).catch(() => null),
        new Promise(resolve => { timeout = setTimeout(() => resolve(null), 1000); })
      ]);
    } finally { clearTimeout(timeout); }
  }

  function state(next) {
    phase = next;
    const base = labels[next] || '实时连接已停止，可以返回普通语音聊天。';
    status.textContent = base;
    clearInterval(waitTimer);
    waitTimer = 0;
    if (next === 'connecting' || next === 'reconnecting') {
      const since = Date.now();
      waitTimer = setInterval(() => {
        if (phase !== next) { clearInterval(waitTimer); waitTimer = 0; return; }
        const seconds = Math.floor((Date.now() - since) / 1000);
        if (seconds >= 3) status.textContent = base.replace(/…$/, '') + `（已等待 ${seconds} 秒）`;
      }, 1000);
    }
    const active = running.has(next);
    const busy = active || next === 'closing';
    audioHelp.hidden = !active && next !== 'audio_tap_required';
    audioRetry.disabled = !active;
    const fallbackType = next === 'session_unavailable' ? 'service' : budgetStops.has(next) ? 'limit' :
      next === 'offline' ? 'network' : connectionStops.has(next) ? 'connection' :
      next === 'voice_forbidden' ? 'access' : next === 'not_authenticated' ? 'login' : null;
    fallback.hidden = !fallbackType;
    for (const message of fallbackMessages) message.hidden = message.dataset.a3Fallback !== fallbackType;
    start.disabled = busy || !user || !navigator.onLine || next === 'unavailable' || next === 'not_authenticated' || next === 'voice_forbidden' || budgetStops.has(next);
    pause.disabled = !active;
    end.disabled = !active && next !== 'paused';
    language.disabled = busy;
    start.textContent = connectionStops.has(next) || ['paused', 'offline', 'audio_route_changed'].includes(next) ? '继续' : '开始';
    audio?.setListening(active);
    if (!active) {
      setRole('idle');
      if (context?.state === 'running') context.suspend().catch(() => {});
    }
    if (next === 'chain_limit') offerSpeakingFeedback();
  }

  function setRole(value) {
    if (role === value) return;
    if (role === 'assistant') audio?.resetPlaybackHint();
    role = value;
    wave.dataset.speaker = role;
    bars.forEach(bar => bar.style.removeProperty('--level'));
  }

  function render(snapshot) {
    const speaker = snapshot.response ? 'assistant' : snapshot.turn?.speaking ? 'user' : 'idle';
    setRole(speaker);
    draft.textContent = snapshot.response?.text || (!snapshot.turn?.final && snapshot.turn?.text) || '';
    const next = snapshot.completed;
    if (next.length !== displayed.length || next.some((message, i) => message !== displayed[i])) {
      history.replaceChildren(...next.map(message => {
        const line = document.createElement('li');
        line.textContent = (message.role === 'user' ? '你：' : '老师：') + message.text;
        return line;
      }));
      displayed = next;
    }
    clear.disabled = !draft.textContent && !displayed.length;
    if (phase === 'listening') {
      status.textContent = snapshot.response ? '老师正在回答' : snapshot.turn?.speaking ? '正在听你说' :
        snapshot.turn && !snapshot.turn.responded ? '老师正在准备回答' : labels.listening;
    }
  }

  function draw(speaker, pcm) {
    if (speaker === 'assistant') audio?.observePlayback(pcm);
    if (speaker !== role) return;
    const data = new DataView(pcm);
    const width = Math.floor(data.byteLength / (2 * bars.length));
    if (!width) return;
    bars.forEach((bar, index) => {
      let total = 0;
      for (let i = 0; i < width; i++) {
        const value = data.getInt16(2 * (index * width + i), true) / 32768;
        total += value * value;
      }
      bar.style.setProperty('--level', String(Math.min(1, .13 + 7 * Math.sqrt(total / width))));
    });
  }

  function halt(reason) {
    operation++;
    if (reason === 'paused' || reason === 'ended') {
      if ((reason === 'paused' ? call?.pause() : call?.end()) === true) return;
    }
    else if (reason === 'offline') call?.offline();
    else call?.dispose();
    state(reason);
  }

  start.addEventListener('click', async () => {
    if (start.disabled) return;
    const job = ++operation;
    state('connecting');
    try {
      context ||= new Audio();
      audio ||= root.LumiA3.createAudioLifecycle({
        context, navigator, document,
        onInterrupted: () => { if (running.has(phase)) halt('audio_tap_required'); },
        onAudioHint: reason => { audioHint.textContent = reason ? labels[reason] : ''; },
        onRouteChange: () => { if (phase === 'listening' || phase === 'listening_repeat') call?.routeChanged(); }
      });
      const resumed = audio.unlockFromGesture();
      const [token, profile, unlocked, difficulty] = await Promise.all([
        root.DB.auth.getAccessToken(),
        optional(profileRequest),
        resumed,
        optional(root.Difficulty?.read())
      ]);
      if (job !== operation) return;
      if (!unlocked) {
        halt('audio_tap_required');
        return;
      }
      if (!token || !user || user.id !== await root.DB.auth.getUserId()) {
        halt('not_authenticated');
        return;
      }
      if (job !== operation || document.hidden || !navigator.onLine) {
        if (job === operation) halt(navigator.onLine ? 'paused' : 'offline');
        return;
      }

      audio.setListening(true);
      const selected = language.value;
      try { localStorage.setItem('lumi.a3-language.' + user.id, selected); } catch {}
      call ||= root.LumiA3.createRealtimeCall({
        context, endpoint, onState: state, onChange: render, onAudioFrame: draw,
        workletUrl: 'assets/core/a3/pcm-capture-worklet.js?v=20261127-a3r1',
        getAccessToken: () => root.DB.auth.getAccessToken(),
        capture: () => audio.capture({
          audio: { channelCount: 1, echoCancellation: true, noiseSuppression: true, autoGainControl: true }
        })
      });
      speakingLevel = difficulty?.ok ? difficulty.speaking : null;
      speakingUnit = speakingLevel ? 'a3:' + root.crypto.randomUUID() : null;
      resumedHistorySize = displayed.length;
      $('a3DifficultyFeedback').replaceChildren();
      const sessionProfile = speakingLevel ? { ...profile, lumi_speaking_level: speakingLevel } : profile;
      call.start(token, { profile: sessionProfile, language: selected, openingTopic: true, localBargeIn: true });
    } catch {
      if (job === operation) halt('audio_capture_failed');
    }
  });

  audioRetry.addEventListener('click', async () => {
    if (audioRetry.disabled || !audio) return;
    const job = operation;
    if (!await audio.unlockFromGesture(true) && job === operation) halt('audio_tap_required');
  });

  pause.addEventListener('click', () => halt('paused'));
  end.addEventListener('click', () => {
    halt('ended');
    offerSpeakingFeedback();
  });

  function offerSpeakingFeedback() {
    const completed = displayed.slice(resumedHistorySize).filter(line => line.role === 'user').length;
    if (!speakingUnit || !completed) return;
    const unitKey = speakingUnit;
    speakingUnit = null;
    void root.Difficulty?.report({ module: 'speaking', level: speakingLevel, unitKey, stats: {},
      summary: '完成 ' + completed + ' 轮表达', mount: $('a3DifficultyFeedback') });
  }
  clear.addEventListener('click', () => {
    if (displayed.length || draft.textContent) {
      if (running.has(phase)) halt('paused');
      call?.clearHistory();
    }
  });
  root.addEventListener('offline', () => { if (user) halt('offline'); });
  root.addEventListener('online', () => { if (phase === 'offline') state('paused'); });
  document.addEventListener('visibilitychange', () => {
    if (document.hidden && running.has(phase)) halt('audio_tap_required');
  });
  root.addEventListener('pagehide', () => {
    operation++;
    call?.dispose();
    audio?.dispose();
    audio = null;
    context?.close().catch(() => {});
    context = null;
    call = null;
  });

  if (!endpoint || !Audio || !navigator.mediaDevices?.getUserMedia || root.DB.mode !== 'cloud') {
    state('unavailable');
    return;
  }
  root.AppAuth.requireLogin().then(account => {
    if (!account) return;
    user = account;
    profileRequest = root.DB.learnerProfile().catch(() => null);
    try {
      const saved = localStorage.getItem('lumi.a3-language.' + user.id);
      if (['auto', 'english', 'chinese'].includes(saved)) language.value = saved;
    } catch {}
    root.DB.auth.onChange(session => {
      if (session?.user?.id === user?.id) return;
      user = null;
      profileRequest = null;
      halt('not_authenticated');
      call?.clearHistory();
    });
    state(navigator.onLine ? 'idle' : 'offline');
    void root.Difficulty?.mount($('a3Difficulty'), ['speaking']);
  }).catch(() => state('unavailable'));
})(window);
