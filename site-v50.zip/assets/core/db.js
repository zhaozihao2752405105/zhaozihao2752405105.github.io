/* ============================================================
 * assets/core/db.js —— 数据库访问唯一入口
 * 规则（v2.2 7.9）：业务代码里不出现数据库地址、不写 SQL、不出现 supabase 字样。
 * 对外只有 7 个东西：
 *   DB.auth.signIn / signUp / signOut / getUser / onChange
 *   DB.select(table, query) / DB.insert / DB.update / DB.upsert / DB.remove / DB.rpc
 * query 写法：{ id: 'xxx' } 等值；{ 'client_ver.lt': 3 } 比较运算符（eq/lt/lte/gt/gte/neq）；
 *              { order: 'created_at.desc', limit: 10 } 可选；update(..., {select:true}) 返回被更新行。
 * 地址与密钥留空时自动进入「离线体验模式」：用 localStorage 假装数据库，
 * 方便你在没建库、没网时先把界面点一遍。
 * ============================================================ */
window.DB = (function () {
  var cfg = window.APP_CONFIG || {};
  var isMock = !cfg.SUPABASE_URL || !cfg.SUPABASE_ANON_KEY;
  var client = null;

  function getClient() {
    if (isMock) return null;
    if (client) return client;
    if (!window.supabase || !window.supabase.createClient) {
      throw new Error('登录组件没加载成功，请检查网络后刷新');
    }
    client = window.supabase.createClient(cfg.SUPABASE_URL, cfg.SUPABASE_ANON_KEY, {
      auth: { persistSession: true, autoRefreshToken: true, detectSessionInUrl: true }
    });
    return client;
  }

  var MOCK_KEY = 'mockdb.v1';
  function mockAll() {
    try { return JSON.parse(localStorage.getItem(MOCK_KEY) || '{}'); } catch (e) { return {}; }
  }
  function mockSave(all) { localStorage.setItem(MOCK_KEY, JSON.stringify(all)); }
  function mockTable(name) {
    var all = mockAll();
    if (!all[name]) all[name] = [];
    return all[name];
  }
  function mockMatch(row, query) {
    var keys = Object.keys(query || {});
    for (var i = 0; i < keys.length; i++) {
      var k = keys[i];
      if (k === 'limit' || k === 'order') continue;
      if (!mockMatchOp(row, k, query[k])) return false;
    }
    return true;
  }
  function mockApply(rows, query) {
    var out = rows.filter(function (r) { return mockMatch(r, query); });
    if (query && query.order) {
      var parts = String(query.order).split('.');
      var col = parts[0], desc = parts[1] === 'desc';
      out.sort(function (a, b) {
        var x = a[col], y = b[col];
        if (x === y) return 0;
        return (x < y ? -1 : 1) * (desc ? -1 : 1);
      });
    }
    if (query && query.limit) out = out.slice(0, query.limit);
    return out;
  }
  function uid() { return 'm' + Date.now().toString(36) + Math.random().toString(36).slice(2, 8); }

  // 过滤条件支持等值与比较运算符：{ id:'x' } 等值；{ 'client_ver.lt': 3 } 走 lt 比较
  // 支持 eq / lt / lte / gt / gte / neq，默认 eq。这样「只允许较新版本覆盖」可以交给数据库判断。
  var FILTER_OPS = { eq: 1, lt: 1, lte: 1, gt: 1, gte: 1, neq: 1 };
  function splitFilterKey(k) {
    var i = String(k).lastIndexOf('.');
    if (i > 0) {
      var op = String(k).slice(i + 1);
      if (FILTER_OPS[op]) return { col: String(k).slice(0, i), op: op };
    }
    return { col: String(k), op: 'eq' };
  }
  function cmpVal(a, b) {
    if (a == null && b == null) return 0;
    if (a == null) return -1;
    if (b == null) return 1;
    var na = Number(a), nb = Number(b);
    if (!isNaN(na) && !isNaN(nb) && String(a).trim() !== '' && String(b).trim() !== '') return na === nb ? 0 : (na < nb ? -1 : 1);
    var sa = String(a), sb = String(b);
    return sa === sb ? 0 : (sa < sb ? -1 : 1);
  }
  function mockMatchOp(row, k, v) {
    var f = splitFilterKey(k), x = row[f.col], c = cmpVal(x, v);
    if (f.op === 'eq') return c === 0;
    if (f.op === 'neq') return c !== 0;
    if (f.op === 'lt') return c < 0;
    if (f.op === 'lte') return c <= 0;
    if (f.op === 'gt') return c > 0;
    if (f.op === 'gte') return c >= 0;
    return false;
  }
  function applyFilter(q, k, v) {
    var f = splitFilterKey(k);
    return q[f.op](f.col, v);
  }

  function wrapError(err, fallback) {
    var msg = (err && (err.message || err.error_description || err.hint)) || '';
    var map = [
      ['Invalid login credentials', '邮箱或密码不对，请再试一次'],
      ['Email not confirmed', '邮箱还没验证：去邮箱点确认链接（或在 Supabase 后台关掉邮箱验证）'],
      ['User already registered', '这个邮箱已经注册过了，直接点「登录」'],
      ['Password should be at least', '密码太短，至少 6 位'],
      ['permission denied', '没有权限做这个操作（账号或权限设置有误）'],
      ['Failed to fetch', '连不上服务器，检查网络或 Supabase 是否暂停'],
      ['JWT expired', '登录过期了，请重新登录']
    ];
    for (var i = 0; i < map.length; i++) {
      if (msg.indexOf(map[i][0]) !== -1) return new Error(map[i][1]);
    }
    return new Error(msg || fallback || '操作失败，请稍后再试');
  }

  var mockSessionKey = 'mocksession.v1';
  function mockSession() {
    try { return JSON.parse(localStorage.getItem(mockSessionKey) || 'null'); } catch (e) { return null; }
  }

  // Routing only: use the SDK session, not a network /user call on every page.
  // API requests still use the SDK JWT and server RLS. Do not use this for authorization.
  function authFailureIsFinal(e) {
    if (!e) return false;
    return e.name === 'AuthSessionMissingError' ||
      ['session_not_found', 'session_expired', 'refresh_token_not_found',
       'refresh_token_already_used', 'user_not_found', 'user_banned', 'bad_jwt'].indexOf(e.code) !== -1;
  }
  function persistedUser() {
    if (isMock) { var s = mockSession(); return s && s.user || null; }
    // Supabase JS default storage key (project host prefix). No tokens leave this function.
    var project = new URL(cfg.SUPABASE_URL).hostname.split('.')[0];
    var raw = localStorage.getItem('sb-' + project + '-auth-token');
    var session = raw ? JSON.parse(raw) : null;
    return session && session.access_token && session.user && session.user.id ?
      { id: session.user.id, email: session.user.email } : null;
  }

  var auth = {
    peekUser: persistedUser,
    getSessionUser: async function () {
      if (isMock) return persistedUser();
      var res = await getClient().auth.getSession();
      if (res.error) {
        if (authFailureIsFinal(res.error)) return null;
        throw res.error;
      }
      return res.data && res.data.session && res.data.session.user || null;
    },
    signIn: async function (email, password) {
      if (isMock) {
        if (!email) throw new Error('请填邮箱');
        if (!password || password.length < 6) throw new Error('密码至少 6 位');
        var s = { user: { id: 'mock-' + email, email: email }, expires_at: Date.now() + 30 * 86400000 };
        localStorage.setItem(mockSessionKey, JSON.stringify(s));
        return s;
      }
      var c = getClient();
      var res = await c.auth.signInWithPassword({ email: email, password: password });
      if (res.error) throw wrapError(res.error, '登录失败');
      return res.data.session;
    },
    signUp: async function (email, password) {
      if (isMock) return auth.signIn(email, password);
      var c = getClient();
      var res = await c.auth.signUp({ email: email, password: password });
      if (res.error) throw wrapError(res.error, '注册失败');
      return res.data.session;
    },
    signOut: async function () {
      if (isMock) { localStorage.removeItem(mockSessionKey); return; }
      var res = await getClient().auth.signOut({ scope: 'local' });
      if (res.error) throw wrapError(res.error, '退出失败');
    },
    getUser: async function () {
      if (isMock) { var s = mockSession(); return s ? s.user : null; }
      var res = await getClient().auth.getUser();
      return (res.data && res.data.user) || null;
    },
    // 只读本地已保存的会话（不发起网络请求）：离线提交队列每条发送前用它核对账号归属
    getUserId: async function () {
      if (isMock) { var s = mockSession(); return (s && s.user && s.user.id) || null; }
      var res = await getClient().auth.getSession();
      var ses = res && res.data && res.data.session;
      return (ses && ses.user && ses.user.id) || null;
    },
    // 只读本地令牌（不联网）：AI 网关调用需要带用户 JWT
    getAccessToken: async function () {
      if (isMock) return null;
      var res = await getClient().auth.getSession();
      var ses = res && res.data && res.data.session;
      return (ses && ses.access_token) || null;
    },
    onChange: function (cb) {
      if (isMock) return;
      getClient().auth.onAuthStateChange(function (event, session) { cb(session); });
    }
  };

  async function select(table, query) {
    if (isMock) return mockApply(mockTable(table), query);
    var q = getClient().from(table).select('*');
    Object.keys(query || {}).forEach(function (k) {
      if (k === 'limit') return;
      if (k === 'order') { var p = String(query.order).split('.'); q = q.order(p[0], { ascending: p[1] !== 'desc' }); return; }
      q = applyFilter(q, k, query[k]);
    });
    if (query && query.limit) q = q.limit(query.limit);
    var res = await q;
    if (res.error) throw wrapError(res.error, '读取失败');
    return res.data || [];
  }

  async function insert(table, rows) {
    var list = Array.isArray(rows) ? rows : [rows];
    if (isMock) {
      var all = mockAll(), t = mockTable(table);
      list.forEach(function (r) {
        t.push(Object.assign({ id: uid(), created_at: new Date().toISOString() }, r));
      });
      all[table] = t; mockSave(all);
      return list;
    }
    var res = await getClient().from(table).insert(list).select();
    if (res.error) throw wrapError(res.error, '保存失败');
    return res.data || [];
  }

  async function update(table, patch, query, opts) {
    if (isMock) {
      var all = mockAll(), t = mockTable(table), hit = [];
      t.forEach(function (r) { if (mockMatch(r, query)) { Object.assign(r, patch); hit.push(r); } });
      all[table] = t; mockSave(all);
      return (opts && opts.select) ? hit : true;
    }
    var q = getClient().from(table).update(patch);
    Object.keys(query || {}).forEach(function (k) {
      if (k === 'limit' || k === 'order') return;
      q = applyFilter(q, k, query[k]);
    });
    if (opts && opts.select) {
      var sel = await q.select();
      if (sel.error) throw wrapError(sel.error, '更新失败');
      return sel.data || [];
    }
    var res = await q;
    if (res.error) throw wrapError(res.error, '更新失败');
    return true;
  }

  async function upsert(table, rows, opts) {
    var list = Array.isArray(rows) ? rows : [rows];
    if (!list.length) return [];        // 空写入没有意义，直接返回，避免把空数组发给数据库
    if (isMock) {
      for (var i = 0; i < list.length; i++) {
        var all = mockAll(), t = mockTable(table), idx = -1;
        for (var j = 0; j < t.length; j++) if (t[j].id && t[j].id === list[i].id) idx = j;
        if (idx >= 0) Object.assign(t[idx], list[i]);
        else t.push(Object.assign({ id: uid() }, list[i]));
        all[table] = t; mockSave(all);
      }
      return list;
    }
    var uq = getClient().from(table);
    var uopt = (opts && opts.onConflict) ? { onConflict: opts.onConflict } : undefined;
    var res = await (uopt ? uq.upsert(list, uopt) : uq.upsert(list)).select();
    if (res.error) throw wrapError(res.error, '保存失败');
    return res.data || [];
  }

  async function remove(table, query) {
    if (isMock) {
      var all = mockAll();
      all[table] = mockTable(table).filter(function (r) { return !mockMatch(r, query); });
      mockSave(all);
      return true;
    }
    var q = getClient().from(table).delete();
    Object.keys(query || {}).forEach(function (k) {
      if (k === 'limit' || k === 'order') return;
      q = applyFilter(q, k, query[k]);
    });
    var res = await q;
    if (res.error) throw wrapError(res.error, '删除失败');
    return true;
  }

  async function rpc(fnName, args) {
    if (isMock) throw new Error('离线体验模式没有 AI 与预算功能');
    var res = await getClient().rpc(fnName, args || {});
    if (res.error) throw wrapError(res.error, '调用失败');
    return res.data;
  }

  // AI 网关唯一出口：业务代码不写地址、不带密钥，只给 kind + payload + request_id。
  // 不用 supabase-js 的 functions.invoke（它把非 2xx 变成异常，丢掉状态码），这里直接 fetch 拿原始状态码，
  // 让上层按「网络 / 5xx / 429 / 402 / 4xx / 401」分类重试。失败不抛异常，统一返回 {status, body}。
  async function aiInvoke(kind, payload, requestId) {
    if (isMock) return { status: 0, body: { ok: false, code: 'mock_mode', message: '离线体验模式没有 AI 功能' } };
    var token = null;
    try { token = await auth.getAccessToken(); } catch (e) { token = null; }
    if (!token) return { status: 401, body: { ok: false, code: 'not_authenticated', message: '登录已过期，请重新登录' } };
    var url = String(cfg.SUPABASE_URL).replace(/\/+$/, '') + '/functions/v1/ai-gateway';
    var res, text;
    try {
      res = await fetch(url, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'apikey': cfg.SUPABASE_ANON_KEY,
          'Authorization': 'Bearer ' + token
        },
        body: JSON.stringify({ request_id: requestId, kind: kind, payload: payload || {} })
      });
      text = await res.text();
    } catch (e) {
      return { status: 0, body: { ok: false, code: 'network', message: '连不上 AI 服务，请检查网络' } };
    }
    var data = null;
    try { data = text ? JSON.parse(text) : null; } catch (e) {
      data = { ok: false, code: 'bad_response', message: 'AI 返回内容无法解析' };
    }
    return { status: res.status, body: data };
  }


  // B1：老师可用的学习档案（只读本人数据，失败一律返回 null，不影响聊天）。
  // 只取聚合与少量短文本，避免把整份记录塞进提示词；网关还会再次截断。
  function localDateOf(d) {
    var p = function (n) { return (n < 10 ? '0' : '') + n; };
    return d.getFullYear() + '-' + p(d.getMonth() + 1) + '-' + p(d.getDate());
  }
  function shiftDate(s, days) {
    var p = s.split('-');
    var d = new Date(Number(p[0]), Number(p[1]) - 1, Number(p[2]));
    d.setDate(d.getDate() + days);
    return localDateOf(d);
  }
  // B1+B2/B3：给 AI 老师的学习档案。
  // 【严格】没有登录、关闭了教学记忆、任何一张表读失败 → 返回 null，让调用方按「没有档案」处理；
  // 绝不把查询失败当成 0 个到期词、0 个错题（那会让 AI 编造“你最近没学习”）。
  async function learnerProfile() {
    if (isMock) return null;
    var uid = null;
    try { uid = await auth.getUserId(); } catch (e) { uid = null; }
    if (!uid) return null;
    var profRows;
    try { profRows = await select('profiles', { id: uid, limit: 1 }); } catch (e) { return null; }
    if (!Array.isArray(profRows) || !profRows.length) return null;
    // 总开关：关闭后不读学习记录、不带记忆；网关也会按 enabled=false 兜底。
    if (profRows[0].memory_enabled === false) return { enabled: false };

    if (!window.Adaptive || !window.Adaptive.get) return null;
    var a = null;
    try { a = await window.Adaptive.get(uid); } catch (e) { a = null; }
    if (!a || a.enabled === false) return null;

    // 长期记忆只取 active，且推断类必须已确认（表约束 + 这里再筛一次）。
    var mem = [];
    try {
      var rows = await select('learner_memory', { user_id: uid, status: 'active', order: 'updated_at.desc', limit: 12 });
      if (!Array.isArray(rows)) return null;
      mem = rows.filter(function (m) {
        return m && (m.source === 'user' || !!m.confirmed_at);
      }).slice(0, 6).map(function (m) {
        return { kind: String(m.kind || 'note').slice(0, 20), content: String(m.content || '').slice(0, 160) };
      });
    } catch (e) { return null; }

    return {
      enabled: true,
      due_words: a.due_words,
      studied_days_7: a.studied_days_7,
      streak_days: a.streak_days,
      unresolved_mistakes: a.unresolved_mistakes,
      recent_mistakes: a.recent_mistakes,
      weak_words: (a.weak_words || []).map(function (w) { return { word: w.word, lapses: w.lapses }; }),
      level: a.level,
      sample: a.sample,
      module_accuracy: a.module_accuracy,
      mastered_words: a.mastered_words,
      mastered_points: a.mastered_points,
      weak_points: a.weak_points,
      focus: a.focus,
      advice: a.advice,
      memories: mem
    };
  }

  // 流式聊天唯一出口（第 14 步 P1）：SSE 逐段回调，不缓存、不抛异常。
  // 【必须同步返回】返回 { aborted, promise, abort() }。
  // 早期版本是 async function，await 后才返回 → 生成期间调用方拿不到 abort 句柄，
  // 「停止」按钮点下去只是改了提示文字，请求仍在跑（P1-10 实测缺陷，2026-11-20）。
  function chatStream(opts) {
    opts = opts || {};
    var out = { aborted: false, promise: null, _ctrl: null, abort: function () {
      out.aborted = true;
      if (out._ctrl) { try { out._ctrl.abort(); } catch (e) {} }
    } };
    out.promise = (async function run() {
    if (isMock) { if (opts.onError) opts.onError('mock_mode', '离线体验模式没有 AI 功能'); return out; }
    var token = null;
    try { token = await auth.getAccessToken(); } catch (e) { token = null; }
    if (!token) { if (opts.onError) opts.onError('not_authenticated', '登录已过期，请重新登录'); return out; }
    var url = String(cfg.SUPABASE_URL).replace(/\/+$/, '') + '/functions/v1/ai-gateway';
    var ctrl = (typeof AbortController !== 'undefined') ? new AbortController() : null;
    out._ctrl = ctrl;
    var res;
    try {
      res = await fetch(url, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'apikey': cfg.SUPABASE_ANON_KEY,
          'Authorization': 'Bearer ' + token,
          'Accept': 'text/event-stream'
        },
        body: JSON.stringify({
          request_id: opts.requestId,
          kind: 'chat_text',
          payload: {
            stream: true,
            session_id: opts.sessionId,
            mode: opts.mode || 'tutor',
            level: opts.level || 1,
            messages: opts.messages || [],
            profile: opts.profile || undefined,
            // 阶段 1 题目追问：可选白名单上下文，网关会校验 kind/长度并拼成 system 提示
            ask: opts.ask || undefined
          }
        }),
        signal: ctrl ? ctrl.signal : undefined
      });
    } catch (e) {
      if (out.aborted) return out;
      if (opts.onError) opts.onError('network', '连不上 AI 服务，请检查网络后重试');
      return out;
    }
    var ct = (res.headers && res.headers.get && res.headers.get('content-type')) || '';
    if (!res.ok || ct.indexOf('text/event-stream') < 0) {
      var body = null;
      try { body = await res.json(); } catch (e) { body = null; }
      if (opts.onError) opts.onError((body && body.code) || ('http_' + res.status), (body && body.message) || ('AI 服务返回 ' + res.status));
      return out;
    }
    var reader = res.body.getReader();
    var dec = new TextDecoder();
    var buf = '';
    var finished = false;
    try {
      while (!finished) {
        var rd = await reader.read();
        if (rd.done) break;
        buf += dec.decode(rd.value, { stream: true });
        var idx = buf.indexOf('\n');
        while (idx >= 0) {
          var line = buf.slice(0, idx).replace(/\r$/, '');
          buf = buf.slice(idx + 1);
          idx = buf.indexOf('\n');
          if (line.indexOf('data:') !== 0) continue;
          var raw = line.slice(5).trim();
          if (raw === '[DONE]') { finished = true; break; }
          var msg = null;
          try { msg = JSON.parse(raw); } catch (e) { continue; }
          if (!msg || !msg.t) continue;
          if (msg.t === 'meta') { if (opts.onMeta) opts.onMeta(msg); }
          else if (msg.t === 'delta') { if (msg.d && opts.onDelta) opts.onDelta(msg.d); }
          else if (msg.t === 'done') { if (opts.onDone) opts.onDone(msg); }
          else if (msg.t === 'error') {
            if (opts.onError) opts.onError(msg.code || 'stream_error', msg.message || 'AI 生成失败');
          }
        }
      }
    } catch (e) {
      if (!out.aborted && opts.onError) opts.onError('stream_broken', '网络中断，已生成的内容可能不完整，请重试');
    }
    try { reader.releaseLock(); } catch (e) {}
    return out;
    })();
    return out;
  }

  // A3 流式语音：网关边收服务商 PCM 边转发，浏览器逐块拿到 16-bit 单声道 24kHz 采样。
  // 和 chatStream 一样必须同步返回句柄，生成期间才能 abort。失败不抛异常，一律走 onError。
  function ttsStream(opts) {
    opts = opts || {};
    var out = { aborted: false, promise: null, _ctrl: null, abort: function () {
      out.aborted = true;
      if (out._ctrl) { try { out._ctrl.abort(); } catch (e) {} }
    } };
    out.promise = (async function run() {
      if (isMock) { if (opts.onError) opts.onError('mock_mode', '离线体验模式没有 AI 功能'); return out; }
      var token = null;
      try { token = await auth.getAccessToken(); } catch (e) { token = null; }
      if (!token) { if (opts.onError) opts.onError('not_authenticated', '登录已过期，请重新登录'); return out; }
      var url = String(cfg.SUPABASE_URL).replace(/\/+$/, '') + '/functions/v1/ai-gateway';
      var ctrl = (typeof AbortController !== 'undefined') ? new AbortController() : null;
      out._ctrl = ctrl;
      var res;
      try {
        res = await fetch(url, {
          method: 'POST',
          headers: {
            'Content-Type': 'application/json',
            'apikey': cfg.SUPABASE_ANON_KEY,
            'Authorization': 'Bearer ' + token,
            'Accept': 'application/octet-stream'
          },
          body: JSON.stringify({
            request_id: opts.requestId,
            kind: 'tts',
            payload: {
              text: opts.text,
              voice: opts.voice || 'loongbella_v3.1',
              format: 'pcm',
              stream_audio: true
            }
          }),
          signal: ctrl ? ctrl.signal : undefined
        });
      } catch (e) {
        if (out.aborted) return out;
        if (opts.onError) opts.onError('network', '连不上语音服务，请检查网络后重试');
        return out;
      }
      var ct = (res.headers && res.headers.get && res.headers.get('content-type')) || '';
      if (!res.ok || ct.indexOf('application/octet-stream') < 0) {
        var body = null;
        try { body = await res.json(); } catch (e) { body = null; }
        if (opts.onError) opts.onError((body && body.code) || ('http_' + res.status), (body && body.message) || ('语音服务返回 ' + res.status));
        return out;
      }
      var sr = Number(res.headers.get('x-lumi-sample-rate')) || 24000;
      if (opts.onMeta) opts.onMeta({ sampleRate: sr, channels: 1 });
      var reader = res.body.getReader();
      var bytes = 0;
      try {
        for (;;) {
          var rd = await reader.read();
          if (rd.done) break;
          if (rd.value && rd.value.length) {
            bytes += rd.value.length;
            if (opts.onAudio) opts.onAudio(rd.value, bytes);
          }
        }
        if (!bytes) { if (opts.onError) opts.onError('tts_empty', '语音服务没有返回音频'); return out; }
        if (opts.onDone) opts.onDone({ bytes: bytes });
      } catch (e) {
        if (!out.aborted && opts.onError) opts.onError('stream_broken', '语音流中断，请重试');
      }
      try { reader.releaseLock(); } catch (e) {}
      return out;
    })();
    return out;
  }
  // 预热网关：Chat 页打开时发一次空请求，把 Edge Function 实例拉热。
  // 不读库、不调模型、不占预算；失败静默，绝不影响页面。
  function warm() {
    (async function () {
      try {
        var token = await auth.getAccessToken();
        if (!token) return;
        var url = String(cfg.SUPABASE_URL).replace(/\/+$/, '') + '/functions/v1/ai-gateway';
        var rid = 'warm-' + Date.now() + '-' + Math.random().toString(36).slice(2, 8);
        await fetch(url, {
          method: 'POST',
          headers: { 'Content-Type': 'application/json', 'apikey': cfg.SUPABASE_ANON_KEY, 'Authorization': 'Bearer ' + token },
          body: JSON.stringify({ request_id: rid, kind: 'warm', payload: {} })
        });
      } catch (e) { /* 预热失败不影响功能 */ }
    })();
  }
  return {
    mode: isMock ? 'mock' : 'cloud',
    auth: auth,
    select: select, insert: insert, update: update, upsert: upsert, remove: remove, rpc: rpc, aiInvoke: aiInvoke, chatStream: chatStream, ttsStream: ttsStream, warm: warm, learnerProfile: learnerProfile
  };
})();