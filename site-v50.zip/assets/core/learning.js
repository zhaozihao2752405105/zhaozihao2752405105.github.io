/* ============================================================
 * assets/core/learning.js —— 学习数据访问层（v3）
 * 职责：把学习动作翻译成 010 SQL 里的 RPC，断网时交给离线队列。
 * v3 相对 v2 的硬改动（第二轮审查 6 项）：
 *   1) 最终答案永久锁定：submitFinal 先在 finals 里锁答案，锁定后才入队。
 *      同答案重复提交返回 sent/duplicate；不同答案直接 rejected，刷新后依然有效（审查 1）。
 *   2) 队列主键带账号前缀，跨账号同条目 ID 不再撞键；发送前仍逐条核对 user_id（审查 2）。
 *   3) 服务端 ok:false 也要完整分类：业务码→dead；not_authenticated/jwt→auth 停止本轮；
 *      其它（限流/5xx/未知）→保留记录并停止本轮。不能只对 Promise reject 分类（审查 3）。
 *   4) start 失败即视为会话无效：清空 Session.id，心跳不会再拿旧会话发（审查 4）。
 *   5) start 互斥 + 会话代次 generation：旧请求返回时只更新它自己的代次，end()/新会话后
 *      旧心跳结果一律丢弃（审查 5）。
 *   6) clearDead 只清当前账号的 dead 记录（审查 6）。
 * 其余沿用：普通作答只走 log_study_event；最终作答只走 complete_task_item；两者不共用 ID；
 * 心跳 30 秒、闲置 2 分钟不发；回前台先 start 再 flush；start 失败 5 秒重试一次。
 * 对外：window.Learn
 *   ready() / loadTask() / submitAttempt(...) / submitFinal(itemId, result)
 *   skipItem(itemId) / flush() / clearDead() / pendingCount()
 *   Session: start() / heartbeat() / end() / bindEvents() / id / pausedSec / generation / onState / onTick
 * ============================================================ */
window.Learn = (function () {
  var HEARTBEAT_MS = 30000;
  var IDLE_MS = 120000;
  var RETRY_START_MS = 5000;

  // 服务端明确拒绝的业务码：重试也不会成功，标记 dead
  var BUSINESS = {};
  ['item_not_found', 'item_already_completed', 'item_skipped', 'item_not_owned',
   'event_id_conflict', 'word_not_found', 'word_mismatch', 'type_mismatch',
   'session_not_owned', 'session_not_found', 'progress_missing', 'final_event_missing',
   'bad_event_type', 'bad_result', 'bad_client_event_id', 'invalid_result',
   'write_denied', 'write_rejected',
   'task_not_found', 'no_more_items'
  ].forEach(function (c) { BUSINESS[c] = true; });

  // 登录态失效：停止本轮并提示重新登录，队列不动
  var AUTH_CODES = { not_authenticated: 1, jwt_expired: 1, auth_required: 1, invalid_jwt: 1, unauthorized: 1 };

  var CODE_ZH = {
    item_not_found: '这个学习条目不存在了',
    item_already_completed: '这个条目已经完成过了',
    item_skipped: '这个条目已经跳过',
    item_not_owned: '这个条目不属于当前账号',
    event_id_conflict: '提交编号冲突（同编号不同内容）',
    word_not_found: '单词不存在',
    word_mismatch: '单词与条目不匹配',
    type_mismatch: '作答类型与条目类型不匹配',
    session_not_owned: '学习会话不属于当前账号',
    session_not_found: '学习会话不存在',
    progress_missing: '学习进度记录缺失',
    final_event_missing: '最终作答记录缺失',
    task_not_found: '今天的学习任务不存在',
    no_more_items: '今天没有更多条目了',
    not_authenticated: '登录已过期，请重新登录',
    jwt_expired: '登录已过期，请重新登录',
    write_denied: '没有权限保存这条记录（账号或权限设置有误）',
    write_rejected: '服务端拒绝了这条记录'
  };

  var AUTH_RE = /登录过期|重新登录|not_authenticated|jwt|unauthorized|请先登录/i;
  var NET_RE = /连不上服务器|failed to fetch|networkerror|network error|fetch failed|load failed|net::|econn|timeout|timed out|502|503|504|429/i;

  var taskCache = null;
  var bootUser = null;

  function errText(code) { return CODE_ZH[code] || String(code || '提交失败'); }

  // 三类分类：business / auth / temp
  function classifyCode(code) {
    var c = String(code || 'unknown');
    if (BUSINESS[c]) return { type: 'business', message: errText(c), code: c };
    if (AUTH_CODES[c] || AUTH_RE.test(c)) return { type: 'auth', message: errText(c) || '登录已过期，请重新登录', code: c };
    return { type: 'temp', message: c, code: c };
  }
  function classifyThrown(e) {
    var m = (e && e.message) || String(e) || '提交失败';
    if (AUTH_RE.test(m)) return { type: 'auth', message: m, code: 'auth' };
    if (NET_RE.test(m)) return { type: 'temp', message: m, code: 'net' };
    return { type: 'temp', message: m, code: 'unknown' };
  }

  function currentUserId() {
    try { return window.DB.auth.getUserId().catch(function () { return null; }); }
    catch (e) { return Promise.resolve(null); }
  }

  var authBound = false;
  function bindAuthChange() {
    if (authBound || !window.DB || !window.DB.auth || !window.DB.auth.onChange) return;
    authBound = true;
    window.DB.auth.onChange(function (session) {
      var id = (session && session.user && session.user.id) || null;
      bootUser = id;
      if (window.StudyQueue) window.StudyQueue.init(id);
    });
  }

  function ready() {
    if (bootUser) return Promise.resolve({ user_id: bootUser });
    return currentUserId().then(function (id) {
      bootUser = id;
      if (!id) return { user_id: null };
      if (!window.StudyQueue) return { user_id: id, queue: false };
      return window.StudyQueue.init(id).then(function () {
        bindAuthChange();
        return { user_id: id, queue: true };
      });
    });
  }

  function loadTask() {
    return window.DB.rpc('get_or_create_daily_task', {}).then(function (res) {
      if (!res || res.ok === false) throw new Error((res && res.message) || '今日任务加载失败');
      taskCache = res;
      return res;
    });
  }

  // ---------------- 提交 ----------------

  function flushAndLocate(clientId) {
    return flush().then(function (r) {
      var sent = null, dead = null, i;
      for (i = 0; i < r.sent.length; i++) if (r.sent[i].client_event_id === clientId) sent = r.sent[i];
      for (i = 0; i < r.dead.length; i++) if (r.dead[i].client_event_id === clientId) dead = r.dead[i];
      if (sent) return { status: 'sent', client_event_id: clientId, result: sent.res };
      if (dead) return { status: 'dead', client_event_id: clientId, message: errText(dead.code), code: dead.code };
      return { status: 'queued', client_event_id: clientId, message: '已在本机排队，联网后自动补交' };
    });
  }

  function enqueueAndTry(kind, payload, clientId) {
    var owner = null;
    return ready().then(function (r) {
      if (!r.user_id) throw new Error('请先登录');
      if (!window.StudyQueue) throw new Error('浏览器不支持离线队列');
      owner = r.user_id;                       // 一次提交全程使用同一 ownerId
      return window.StudyQueue.enqueue(kind, payload, clientId, owner);
    }).then(function (enq) {
      if (enq.dead) {
        return { status: 'dead', client_event_id: enq.client_event_id, message: '这条记录已被服务端拒绝，不再重试' };
      }
      return flushAndLocate(enq.client_event_id);
    });
  }

  function submitAttempt(wordId, itemId, eventType, result, durationSec, attemptNo, meta) {
    var m = meta || {};
    var payload = {
      p_word_id: wordId || null,
      p_task_item_id: itemId || null,
      p_session_id: Session.id || null,
      p_event_type: eventType || 'learn',
      p_result: result || null,
      p_attempt_no: attemptNo || 1,
      p_duration_sec: Math.max(0, Math.round(durationSec || 0)),
      p_mode: m.mode ? String(m.mode).slice(0, 20) : null,
      p_hint_used: !!m.hint
    };
    return enqueueAndTry('attempt', payload, null);
  }

  // 最终作答：先锁答案（永久），再入队发送；不同答案第二次提交直接拒绝
  function submitFinal(itemId, finalResult) {
    if (!itemId) return Promise.reject(new Error('缺少条目 ID'));
    return ready().then(function (r) {
      if (!r.user_id) throw new Error('请先登录');
      if (!window.StudyQueue) throw new Error('浏览器不支持离线队列');
      var uid = r.user_id;                     // 本次提交唯一 owner，中途不再读全局账号
      var clientId = window.StudyQueue.finalEventId(itemId);
      return window.StudyQueue.lockFinal(itemId, finalResult, uid).then(function (lock) {
        if (!lock.same) {
          return {
            status: 'rejected',
            client_event_id: clientId,
            message: '这个条目第一次提交的答案已锁定，不能再改'
          };
        }
        var st = lock.existing && lock.existing.state;
        if (!lock.created && st === 'sent') {
          return { status: 'sent', client_event_id: clientId, duplicate: true, message: '这个条目已经提交过了' };
        }
        if (!lock.created && st === 'dead') {
          return { status: 'dead', client_event_id: clientId, message: '这条最终作答已被服务端拒绝，不再重试' };
        }
        return window.StudyQueue.enqueue('complete', { p_item_id: itemId, p_final_result: finalResult }, clientId, uid)
          .then(function (enq) {
            if (enq.dead) {
              return window.StudyQueue.setFinalState(itemId, 'dead', uid).then(function () {
                return { status: 'dead', client_event_id: clientId, message: '这条最终作答已被服务端拒绝，不再重试' };
              });
            }
            return flushAndLocate(clientId).then(function (res) {
              if (res.status === 'sent') {
                return window.StudyQueue.setFinalState(itemId, 'sent', uid).then(function () { return res; });
              }
              if (res.status === 'dead') {
                return window.StudyQueue.setFinalState(itemId, 'dead', uid).then(function () { return res; });
              }
              return res;
            });
          });
      });
    });
  }

  function skipItem(itemId) {
    if (!itemId) return Promise.reject(new Error('缺少条目 ID'));
    // skip_task_item 服务端按条目状态幂等（已跳过 ok:true duplicate；已完成 item_already_completed），
    // 本地键 'skp-'+itemId 只用于本地去重，不发给服务端。
    return enqueueAndTry('skip', { p_item_id: itemId }, 'skp-' + itemId);
  }

  // ---------------- 出队发送 ----------------

  function send(rec) {
    var p = rec.payload || {};
    if (rec.kind === 'lesson_result' || rec.kind === 'mistake' || rec.kind === 'weekly_test') {
      return runOp(rec.kind, p, rec.user_id).then(function () { return { ok: true }; }).catch(function (err) {
        var m = (err && err.message) || String(err);
        if (DENY_RE.test(m)) return { ok: false, message: 'write_denied' };   // 永久拒绝 → dead
        throw err;                                                            // 网络/未知 → temp，保留记录
      });
    }
    if (rec.kind === 'complete') {
      return window.DB.rpc('complete_task_item', {
        p_item_id: p.p_item_id, p_client_event_id: rec.client_event_id, p_final_result: p.p_final_result
      });
    }
    if (rec.kind === 'skip') {
      return window.DB.rpc('skip_task_item', { p_item_id: p.p_item_id });
    }
    return window.DB.rpc('log_study_event', {
      p_word_id: p.p_word_id,
      p_task_item_id: p.p_task_item_id,
      p_session_id: p.p_session_id,
      p_event_type: p.p_event_type,
      p_result: p.p_result,
      p_attempt_no: p.p_attempt_no,
      p_duration_sec: p.p_duration_sec,
      p_mode: p.p_mode || null,
      p_hint_used: !!p.p_hint_used,
      p_client_event_id: rec.client_event_id
    });
  }

  function handleBusinessDead(rec, code) {
    // 删除/更新一律绑定记录自身的 user_id（第三轮审查 2）
    return window.StudyQueue.markDead(rec.client_event_id, code, rec.user_id).then(function () {
      var p = rec.payload || {};
      if (rec.kind !== 'complete') return { client_event_id: rec.client_event_id, code: code };
      return window.StudyQueue.setFinalState(p.p_item_id, 'dead', rec.user_id).then(function () {
        return { client_event_id: rec.client_event_id, code: code };
      });
    });
  }

  // 修复：finals 里 queued 但 outbox 里没有对应 complete 记录的“孤儿锁”（例如发送成功后标签页被关）
  function reconcileFinals(uid) {
    if (!window.StudyQueue.listFinals) return Promise.resolve(0);
    return window.StudyQueue.listFinals(uid).then(function (fs) {
      var queued = (fs || []).filter(function (f) { return f.state === 'queued'; });
      if (!queued.length) return 0;
      return window.StudyQueue.listMine().then(function (rows) {
        var have = {};
        (rows || []).forEach(function (r) { have[r.client_event_id] = 1; });
        var todo = queued.filter(function (f) {
          return !have[window.StudyQueue.finalEventId(f.item_id)];
        });
        var n = 0;
        return todo.reduce(function (p, f) {
          return p.then(function () {
            var result = null;
            try { result = JSON.parse(f.result_raw); } catch (e) { return null; }
            return window.StudyQueue.enqueue('complete', { p_item_id: f.item_id, p_final_result: result },
              window.StudyQueue.finalEventId(f.item_id), uid).then(function () { n += 1; });
          });
        }, Promise.resolve()).then(function () { return n; });
      });
    });
  }

  // ---------------- 离线写操作（模块进度 / 错题 / 周测成绩） ----------------
  // 这些是表写入而不是 RPC，重放必须幂等：
  //   lesson_result: 按主键 id update，重复执行结果一致
  //   mistake: 客户端生成确定性 id 后 upsert（同一题永远落到同一行）
  //   weekly_test: 先查 user_id+week_start，有则 update 无则 insert

  function fnv1a(s) {
    var h = 0x811c9dc5;
    for (var i = 0; i < s.length; i++) {
      h ^= s.charCodeAt(i);
      h = (h + ((h << 1) + (h << 4) + (h << 7) + (h << 8) + (h << 24))) >>> 0;
    }
    return ('00000000' + h.toString(16)).slice(-8);
  }

  function hashUuid(s) {
    var str = String(s || '');
    var a = fnv1a(str), b = fnv1a(str + '|b'), c = fnv1a(str + '|c'), d = fnv1a(str + '|d');
    var v4 = (parseInt(c.charAt(0), 16) & 0x3 | 0x8).toString(16);
    return a + '-' + b.slice(0, 4) + '-4' + b.slice(4, 7) + '-' + v4 + c.slice(1, 4) + '-' + c.slice(4) + d;
  }

  // 确定性错题 ID：同一账号的同一道题永远落到同一行，离线重放也不会插出多行。
  // **必须带 owner**：id 是全局主键，若只按 (kind, ref_id, question) 生成，两个不同账号
  // 记录同一道题会算出同一个主键，后写的一方会撞上别人的行（被 RLS 拒绝 → 保存失败）。
  // 历史数据保持旧算法算出的 id（不重算、不迁移），只对之后新产生的错题使用带 owner 的算法。
  function mistakeId(owner, kind, refId, question) {
    return hashUuid([owner || '', kind || '', refId || '', question || ''].join('|'));
  }

  // 写入被服务端明确拒绝时不该无限重试。
  // 判据优先看数据库错误文本里的「权限/约束/类型」字样：这类错误重试一万次也不会成功；
  // 网络、超时、5xx、429 不在其中，会被当成临时错误保留记录。
  var DENY_RE = /没有权限|permission denied|row-level security|not authorized|invalid input|违反|violates|duplicate key|does not exist|不存在|invalid text representation|42501|23502|23503|23514|22P02/i;

  // 三处写入都必须「离线重放一次和十次结果一样」，并且不能覆盖别人的账号：
  //   lesson_result：条件更新（client_ver < 本次版本），旧版本不生效 → 多标签页/补交不会让进度倒退
  //   mistake：强制以队列记录自身的 user_id 覆盖行内 user_id，再按确定性 id upsert
  //   weekly_test：(user_id, week_start) 已有唯一约束，直接用原子 upsert，避免「先查后插」的并发重复
  // ---------------- 进度版本分配（跨标签页严格递增） ----------------
  // Date.now() 不够用：同一毫秒两个标签页会拿到相同版本（其中一个合法提交被吞），
  // 设备时钟还可能不准。这里用独立的小 IndexedDB 给「每个账号 + 每条 lesson_content」
  // 分配单调递增版本：在同一个 readwrite 事务里「读 → max(旧值+1, 当前毫秒) → 写」，
  // IndexedDB 会串行化写事务，所以多标签页共享同一个计数器；版本在「第一次产生写入」时
  // 定下来，离线补交时原样复用，不会重新生成。
  var VDB_NAME = 'study_version.v1', VDB_STORE = 'v', vdbP = null;
  function openVerDb() {
    if (!window.indexedDB) return Promise.reject(new Error('no_indexeddb'));
    if (vdbP) return vdbP;
    vdbP = new Promise(function (resolve, reject) {
      var req = window.indexedDB.open(VDB_NAME, 1);
      req.onupgradeneeded = function () {
        var db = req.result;
        if (!db.objectStoreNames.contains(VDB_STORE)) db.createObjectStore(VDB_STORE, { keyPath: 'key' });
      };
      req.onsuccess = function () { resolve(req.result); };
      req.onerror = function () { vdbP = null; reject(req.error || new Error('版本库打不开')); };
    });
    // 打开失败（含 indexedDB.open 同步抛错）必须清掉缓存，否则 vdbP 会永久停在 rejected 状态，
    // 之后即使本地存储恢复也永远分配不到版本。
    var p = vdbP;
    vdbP = p.then(null, function (err) { vdbP = null; throw err; });
    return vdbP;
  }
  function allocVersion(key) {
    return openVerDb().then(function (db) {
      return new Promise(function (resolve, reject) {
        var tx = db.transaction(VDB_STORE, 'readwrite');
        var st = tx.objectStore(VDB_STORE);
        var next = 0;
        var got = st.get(key);
        got.onsuccess = function () {
          var cur = Number((got.result && got.result.v) || 0);
          next = Math.max(cur + 1, Date.now());
          st.put({ key: key, v: next });
        };
        got.onerror = function () { try { tx.abort(); } catch (e) {} };
        tx.oncomplete = function () { resolve(next); };
        tx.onerror = function () { vdbP = null; reject(tx.error || new Error('版本分配失败')); };
        tx.onabort = function () { reject(tx.error || new Error('版本分配失败')); };
      });
    }).catch(function (err) {
      // 版本分配失败必须「失败关闭」：不能退回 Date.now()，否则会重新引入同毫秒重复、
      // 新版本比旧版本小、有效进度被条件更新拒绝等问题。明确报错让用户重试。
      var m = (err && err.message) || '本地存储不可用';
      var e2 = new Error('学习进度版本分配失败，请重试：' + m);
      e2.permanent = true;
      throw e2;
    });
  }

  function permError(msg) {
    var e = new Error(msg);
    e.permanent = true;           // 永久错误：不进离线队列，直接把原因交回页面
    return e;
  }

  function runOp(kind, p, owner) {
    if (kind === 'lesson_result') {
      var ver = Math.floor(Number((p && p.ver) || 0));
      if (!(ver > 0)) throw permError('这条旧的学习记录没有版本号，已停止写入（避免覆盖更新的进度）');
      var patch = { result: (p && p.result) || {}, client_ver: ver };
      return window.DB.update('lesson_content', patch,
        { id: p.id, user_id: owner, 'client_ver.lt': ver }, { select: true }).then(function (rows) {
        if (rows && rows.length) return rows;          // 条件命中：正常写入
        // 空数组有两种可能，不能混为一谈：
        //   a) 云端版本不比这条旧 → 旧进度不覆盖新进度，可以安全结束这条队列记录
        //   b) 云端根本没有这条 lesson_content → 学习进度没有保存成功，必须报错而不是伪装成功
        return window.DB.select('lesson_content', { id: p.id, user_id: owner, limit: 1 }).then(function (ex) {
          if (!ex || !ex.length) throw permError('云端没有这条课程记录（lesson_content 不存在），进度未保存');
          return [];                                  // a) 版本冲突 → 跳过
        });
      });
    }
    if (kind === 'mistake') {
      var row = Object.assign({}, (p && p.row) || {});
      row.user_id = owner;                   // 账号归属永远以队列记录为准，忽略 payload 里可能残留的旧账号
      return window.DB.upsert('mistakes', [row]).then(null, function (e) {
        // 迁移 015 还没应用时云端没有 context 列：不能让一条错题因为有快照而整条写不进去。
        // 去掉 context 再写一次（题面/答案/解析仍然保存，只是这道题暂时不能追问）。
        if (row.context && /context/i.test(String((e && e.message) || ''))) {
          var r2 = Object.assign({}, row);
          delete r2.context;
          return window.DB.upsert('mistakes', [r2]);
        }
        throw e;
      });
    }
    if (kind === 'weekly_test') {
      return window.DB.upsert('weekly_tests', [{
        user_id: owner, week_start: p.week_start, score: p.score, detail: p.detail || {}
      }], { onConflict: 'user_id,week_start' });
    }
    return Promise.reject(new Error('unknown_op'));
  }

  function opClientId() {
    return 'op-' + Date.now().toString(36) + Math.random().toString(36).slice(2, 8);
  }

  // 入队；coalesce=true 时同一个 cid 用新参数覆盖旧记录（进度类只用最新值，避免队列被中间态塞满）
  function enqueueOp(kind, p, cid, owner, coalesce) {
    function put() {
      return window.StudyQueue.enqueue(kind, p, cid, owner).then(function (enq) {
        if (enq.dead) return { status: 'dead', client_event_id: cid, message: '这条记录已被服务端拒绝，不再重试' };
        return flushAndLocate(cid);
      });
    }
    return put().catch(function (err) {
      var m = (err && err.message) || '';
      if (!coalesce || m.indexOf('不同参数') === -1) throw err;
      return window.StudyQueue.remove(cid, owner).then(put);
    });
  }

  // 先直接写一次；网络类失败才入离线队列；权限类失败直接返回 failed（不排队）
  function submitOp(kind, payload, clientId, coalesce) {
    return ready().then(function (r) {
      if (!r.user_id) throw new Error('请先登录');
      var owner = r.user_id;                 // 一次提交全程用同一 ownerId
      var p = payload || {};
      p.user_id = owner;
      return runOp(kind, p, owner).then(function () {
        return { status: 'sent', client_event_id: clientId || null };
      }).catch(function (err) {
        var m = (err && err.message) || String(err);
        if (err && err.permanent) return { status: 'failed', message: m };
        if (DENY_RE.test(m)) return { status: 'failed', message: '没有权限保存这条记录（账号或权限设置有误）' };
        if (!window.StudyQueue) return { status: 'failed', message: m };
        var cid = clientId || opClientId();
        return enqueueOp(kind, p, cid, owner, coalesce === true);
      });
    });
  }

  var DATE_RE = /^\d{4}-\d{2}-\d{2}$/;

  function saveLessonResult(rowId, merged) {
    if (!rowId) return Promise.reject(new Error('缺少课程内容 ID'));
    if (!merged || typeof merged !== 'object') return Promise.reject(new Error('缺少模块进度内容'));
    // ver 在「用户点完成」这一刻由 IndexedDB 计数器定下，补交时原样复用，不会重新生成
    return ready().then(function (r) {
      if (!r.user_id) throw new Error('请先登录');
      return allocVersion(r.user_id + '|' + rowId);
    }).then(function (ver) {
      return submitOp('lesson_result', { id: rowId, result: merged, ver: ver }, 'lr-' + rowId, true);
    });
  }

  function normMistake(kind, refId, question) {
    return String(question == null ? '' : question).slice(0, 500);
  }

  // 阶段 2：错题原题上下文快照（可空）。只保留白名单字段并限长，
  // 避免把整页对象或超长原文塞进数据库/提示词；网关侧还有 ASK_CONTEXT_MAX 二次截断。
  function normMistakeContext(raw) {
    if (!raw || typeof raw !== 'object') return null;
    var text = String(raw.text == null ? '' : raw.text).trim().slice(0, 1500);
    if (!text) return null;
    return {
      text: text,
      title: String(raw.title == null ? '' : raw.title).slice(0, 80),
      kind: String(raw.kind == null ? '' : raw.kind).slice(0, 16),
      ref: String(raw.ref == null ? '' : raw.ref).slice(0, 120)
    };
  }

  function saveMistakeRow(row) {
    if (!row || typeof row !== 'object') return Promise.reject(new Error('缺少错题内容'));
    var kind = row.kind || 'word';
    var question = normMistake(kind, row.ref_id, row.question);
    if (!question) return Promise.reject(new Error('缺少错题题目'));
    return ready().then(function (r) {
      if (!r.user_id) throw new Error('请先登录');
      // id 带上账号：不同账号记录同一道题不会撞同一个全局主键；调用方没给 id 时在这里补
      var id = row.id || mistakeId(r.user_id, kind, row.ref_id, question);
      var out = {
        id: id,
        kind: kind,
        ref_id: row.ref_id || null,
        question: question,
        user_answer: row.user_answer == null ? null : String(row.user_answer).slice(0, 500),
        correct_answer: row.correct_answer == null ? null : String(row.correct_answer).slice(0, 500),
        explain_zh: row.explain_zh == null ? null : String(row.explain_zh).slice(0, 1000),
        context: normMistakeContext(row.context),
        resolved: row.resolved === true
      };
      return submitOp('mistake', { row: out }, 'mk-' + id, false);
    });
  }

  function saveWeeklyTest(payload) {
    var src = payload || {};
    var ws = String(src.week_start || '').slice(0, 10);
    if (!DATE_RE.test(ws)) return Promise.reject(new Error('周测缺少合法的 week_start（YYYY-MM-DD）'));
    var score = Math.round(Number(src.score));
    if (!isFinite(score) || score < 0 || score > 100) return Promise.reject(new Error('周测分数必须在 0~100 之间'));
    var detail = (src.detail && typeof src.detail === 'object') ? src.detail : {};
    var p = { week_start: ws, score: score, detail: detail };
    // 同一周固定 cid：周测允许重测覆盖，但数据库那一层是原子 upsert，重放不会插出第二行
    return submitOp('weekly_test', p, 'wt-' + ws, true);
  }

  function sendAll() {
    var out = { sent: [], dead: [], queued: [], stopped: null };
    return currentUserId().then(function (uid) {
      if (!uid) { out.stopped = 'auth'; return out; }
      if (bootUser !== uid) { bootUser = uid; window.StudyQueue.init(uid); }
      return reconcileFinals(uid).then(function () {
        return window.StudyQueue.listMine().then(function (rows) {
        out.queued = rows.map(function (r) { return r.client_event_id; });
        var i = 0;
        function step() {
          if (i >= rows.length) return Promise.resolve(out);
          var rec = rows[i++];
          // 每条发送前重新核对账号归属
          return currentUserId().then(function (now) {
            if (now !== rec.user_id) { out.stopped = 'user_changed'; return out; }
            return send(rec).then(function (res) {
              if (res && res.ok === true) {
                return window.StudyQueue.remove(rec.client_event_id, rec.user_id).then(function () {
                  out.sent.push({ client_event_id: rec.client_event_id, kind: rec.kind, res: res });
                  out.queued = out.queued.filter(function (k) { return k !== rec.client_event_id; });
                  if (rec.kind === 'complete') {
                    // 最终答案记录补交成功后必须把 finals 锁置为 sent，否则会永久留在待补交计数里
                    var pp = rec.payload || {};
                    return window.StudyQueue.setFinalState(pp.p_item_id, 'sent', rec.user_id).then(step);
                  }
                  return step();
                });
              }
              // 服务端返回 ok:false 也要完整分类（审查 3）
              var c = classifyCode((res && res.message) || 'unknown');
              if (c.type === 'business') {
                return handleBusinessDead(rec, c.code).then(function (d) {
                  out.dead.push(d);
                  out.queued = out.queued.filter(function (k) { return k !== rec.client_event_id; });
                  return step();
                });
              }
              if (c.type === 'auth') {
                return window.StudyQueue.markError(rec.client_event_id, c.message, rec.user_id).then(function () {
                  out.stopped = 'auth';
                  out.auth_message = c.message;
                  return out;
                });
              }
              return window.StudyQueue.markError(rec.client_event_id, c.message, rec.user_id).then(function () {
                out.stopped = 'temp';
                return out;
              });
            }).catch(function (e) {
              var c = classifyThrown(e);
              return window.StudyQueue.markError(rec.client_event_id, c.message, rec.user_id).then(function () {
                out.stopped = (c.type === 'auth') ? 'auth' : 'temp';
                if (c.type === 'auth') out.auth_message = c.message;
                return out;
              });
            });
          });
        }
        return step();
      });
      });
    }).catch(function (e) {
      out.stopped = 'error';
      out.error = e && e.message;
      return out;
    });
  }

  var flushBusy = false;
  var flushAgain = false;
  var waiters = [];
  function settle(err, res) {
    var ws = waiters; waiters = [];
    ws.forEach(function (w) { if (err) w.reject(err); else w.resolve(res); });
  }
  function runFlush() {
    flushBusy = true;
    flushAgain = false;
    var acc = { sent: [], dead: [], queued: [], stopped: null };
    (function round() {
      sendAll().then(function (r) {
        acc.sent = acc.sent.concat(r.sent);
        acc.dead = acc.dead.concat(r.dead);
        acc.queued = r.queued;
        acc.stopped = r.stopped;
        if (r.auth_message) acc.auth_message = r.auth_message;
        if (!acc.stopped && flushAgain) { flushAgain = false; round(); return; }
        flushBusy = false;
        settle(null, acc);
      }).catch(function () {
        flushBusy = false;
        settle(null, acc);
      });
    })();
  }
  function flush() {
    return new Promise(function (resolve, reject) {
      waiters.push({ resolve: resolve, reject: reject });
      if (flushBusy) { flushAgain = true; return; }
      runFlush();
    });
  }

  // 只清当前账号的 dead 记录（审查 6）
  function clearDead() {
    return currentUserId().then(function (uid) {
      if (!uid) return 0;
      return window.StudyQueue.listAll().then(function (rows) {
        var dead = rows.filter(function (r) { return r.dead === true && r.user_id === uid; });
        return Promise.all(dead.map(function (r) { return window.StudyQueue.remove(r.client_event_id, r.user_id); })).then(function () {
          return dead.length;
        });
      });
    });
  }

  function pendingCount() { return window.StudyQueue.count(); }

  // ---------------- 学习会话 ----------------

  var Session = {
    id: null,
    generation: 0,      // 会话代次：旧请求返回时据此丢弃结果
    started_at: null,
    pausedSec: 0,
    idle: false,
    hbInFlight: false,
    hbGen: 0,          // 心跳锁所属代次：旧请求返回时只释放自己的锁
    startInFlight: null,
    lastActivity: Date.now(),
    timer: null,
    onState: null,
    onTick: null,
    // 是否允许「回到前台」自动创建/恢复会话。默认 false：只有页面明确进入真实学习状态时才置 true。
    // 这样打开页面、逛首页、学完/退出后切前后台，都不会再凭空建出 0.2 秒的空会话。
    autoStart: false
  };
  var handlersBound = false;

  function notify(state, detail) {
    if (typeof Session.onState === 'function') {
      try { Session.onState(state, detail); } catch (e) { /* 页面回调出错不影响主流程 */ }
    }
  }
  function invalidateSession() {
    Session.generation += 1;
    Session.id = null;
    Session.started_at = null;
    Session.hbInFlight = false;
    Session.hbGen = 0;
  }

  // 只有锁的所属代次匹配才释放；旧请求不得误释放新请求的锁（第三轮审查 3）
  function releaseHb(gen) {
    if (Session.hbGen === gen) { Session.hbInFlight = false; Session.hbGen = 0; }
  }

  function tick() {
    var idleNow = (Date.now() - Session.lastActivity) > IDLE_MS;
    if (idleNow !== Session.idle) {
      Session.idle = idleNow;
      notify(idleNow ? 'idle' : 'active');
    }
    if (typeof Session.onTick === 'function' && Session.started_at) {
      try { Session.onTick(Math.round((Date.now() - Session.started_at) / 1000), Session.pausedSec); } catch (e) { /* 忽略 */ }
    }
    heartbeat();
  }
  function startTimer() { if (!Session.timer) Session.timer = setInterval(tick, HEARTBEAT_MS); }
  function stopTimer() { if (Session.timer) { clearInterval(Session.timer); Session.timer = null; } }

  // start 互斥（审查 5）：并发调用复用同一个在途请求
  function start() {
    if (Session.startInFlight) return Session.startInFlight;
    var gen = Session.generation;      // 启动请求代次：end()/新会话会让它在途结果失效
    Session.startInFlight = window.DB.rpc('start_study_session', {}).then(function (res) {
      Session.startInFlight = null;
      // 用户已经 end() 或已切换到新代次：本次启动结果直接丢弃，不能把会话又激活回来（第四轮审查 3）
      if (gen !== Session.generation) return null;
      if (!res || res.ok !== true) {
        // 会话状态不明：旧会话不能再用于心跳或新事件（审查 4）
        invalidateSession();
        notify('error', (res && res.message) || '会话创建失败');
        return null;
      }
      var prev = Session.id;
      var sameSession = (res.resumed === true && prev === res.session_id);
      Session.id = res.session_id;
      Session.started_at = Date.now();
      Session.generation += 1;
      Session.hbInFlight = false;
      Session.hbGen = 0;
      if (!sameSession) Session.pausedSec = 0;
      Session.idle = false;
      Session.lastActivity = Date.now();
      notify(res.resumed === true ? 'resumed' : 'started');
      startTimer();
      return res;
    }).catch(function (e) {
      Session.startInFlight = null;
      if (gen !== Session.generation) return null;
      invalidateSession();
      notify('error', e && e.message);
      return null;
    });
    return Session.startInFlight;
  }

  function heartbeat() {
    if (!Session.id) return Promise.resolve({ ok: false, message: 'no_session' });
    if (typeof document !== 'undefined' && document.hidden) return Promise.resolve({ ok: false, message: 'not_active' });
    if (Session.idle) return Promise.resolve({ ok: false, message: 'not_active' });
    if (Session.hbInFlight) return Promise.resolve({ ok: false, message: 'busy' });
    Session.hbInFlight = true;
    var sid = Session.id;
    var gen = Session.generation;
    Session.hbGen = gen;
    return window.DB.rpc('heartbeat_study_session', {
      p_session_id: sid, p_paused_sec: Session.pausedSec
    }).then(function (res) {
      releaseHb(gen);
      if (gen !== Session.generation) return { ok: false, message: 'stale' };  // 旧会话结果，丢弃
      if (res && res.ok === false && res.message === 'session_expired') {
        invalidateSession();
        notify('session_expired');
        return start().then(function (r) { return { ok: !!r, message: r ? 'restarted' : 'restart_failed' }; });
      }
      if (res && res.ok === false) {
        var c = classifyCode(res.message);
        notify(c.type === 'auth' ? 'auth' : 'error', c.message);
        return { ok: false, message: c.message };
      }
      return { ok: true, res: res };
    }).catch(function (e) {
      releaseHb(gen);
      if (gen !== Session.generation) return { ok: false, message: 'stale' };
      var c = classifyThrown(e);
      notify(c.type === 'auth' ? 'auth' : 'error', c.message);
      return { ok: false, message: c.type };
    });
  }

  function end() {
    stopTimer();
    var sid = Session.id;
    invalidateSession();
    Session.idle = false;
    if (!sid) return Promise.resolve(null);
    return window.DB.rpc('end_study_session', { p_session_id: sid }).catch(function () { return null; });
  }

  function bindEvents() {
    if (handlersBound) return;
    handlersBound = true;
    function markActivity() { Session.lastActivity = Date.now(); }
    ['pointerdown', 'keydown', 'touchstart', 'scroll'].forEach(function (ev) {
      window.addEventListener(ev, markActivity, { passive: true });
    });
    document.addEventListener('visibilitychange', function () {
      if (document.hidden) { notify('hidden'); return; }
      // 页面不在真实学习状态：回前台只补交离线队列，绝不自动建会话（空会话修复）
      if (!Session.autoStart) { flush().catch(function () {}); return; }
      // 离线回前台：同样只补交，不反复创建会话、不做无意义重试（空会话修复）
      if (typeof navigator !== 'undefined' && navigator.onLine === false) { flush().catch(function () {}); return; }
      start().then(function (res) {
        if (res && res.ok === true) { flush().catch(function () {}); return; }
        notify('start_retry');
        setTimeout(function () {
          // 重试前再核对一次：用户可能已经学完/退出，或网络又断了
          if (!Session.autoStart) return;
          if (typeof navigator !== 'undefined' && navigator.onLine === false) return;
          start().then(function (r) { if (r && r.ok === true) flush().catch(function () {}); });
        }, RETRY_START_MS);
      });
    });
  }

  // 方法必须挂到 Session 对象上：上面把它们声明为局部函数，页面通过 Learn.Session.start() 调用
  Session.start = start;
  Session.heartbeat = heartbeat;
  Session.end = end;
  // 网络恢复时自动补交（失败静默，下次切前台/打开页面还会再试）
  try {
    window.addEventListener('online', function () { flush().catch(function () {}); });
  } catch (e) {}

  Session.bindEvents = bindEvents;


  
  return {
    ready: ready,
    loadTask: loadTask,
    submitAttempt: submitAttempt,
    submitFinal: submitFinal,
    skipItem: skipItem,
    saveLessonResult: saveLessonResult,
    saveMistakeRow: saveMistakeRow,
    saveWeeklyTest: saveWeeklyTest,
    mistakeId: mistakeId,
    hashUuid: hashUuid,
    flush: flush,
    clearDead: clearDead,
    pendingCount: pendingCount,
    Session: Session,
    bindEvents: bindEvents
  };
})();
