/* 错题独立复习（阶段3）— 只封装 RPC，不缓存调度状态
 * 服务端：supabase/migrations/016_mistake_review.sql
 *   get_due_mistake_reviews(p_limit)           纯只读，返回 {ok,day,total_due,max_per_day,items}
 *   complete_mistake_review(id,result,event)   幂等提交，返回 reps/interval_days/due_date/graduated 等
 *   set_mistake_mastered(id,mastered)          true=出库并清理调度；false=重新开始复习（轮次+1）
 * 迁移未执行时（PGRST202 / 函数不存在）返回 {ok:false,code:'unsupported'}，页面静默降级，不报错、不写数据。
 */
window.MistakeReview = (function () {
  var MAX_PER_DAY = 2;
  var support = null; // null=未探测 'yes' | 'no'

  function msgOf(e) { return String((e && e.message) || e || ''); }

  function looksUnsupported(text) {
    var s = String(text || '');
    if (s.indexOf('PGRST202') !== -1) return true;
    if (s.indexOf('Could not find the function') !== -1) return true;
    if (s.indexOf('schema cache') !== -1) return true;
    if (s.indexOf('does not exist') !== -1 && s.indexOf('function') !== -1) return true;
    return false;
  }

  function looksNetwork(text) {
    var s = String(text || '');
    return s.indexOf('连不上服务器') !== -1 || s.indexOf('Failed to fetch') !== -1 ||
           s.indexOf('NetworkError') !== -1 || s.indexOf('Load failed') !== -1;
  }

  function markUnsupported() { support = 'no'; }

  function newEventId() {
    var id = '';
    try {
      if (window.crypto && typeof window.crypto.randomUUID === 'function') id = window.crypto.randomUUID();
    } catch (e) { id = ''; }
    if (!id) id = 'mre-' + Date.now().toString(36) + '-' + Math.random().toString(36).slice(2, 10);
    return id;
  }

  function hasDb() { return !!(window.DB && typeof window.DB.rpc === 'function'); }

  function fail(code, message, extra) {
    var out = { ok: false, code: code, message: message || '操作失败，请稍后再试' };
    if (extra) { for (var k in extra) if (Object.prototype.hasOwnProperty.call(extra, k)) out[k] = extra[k]; }
    return out;
  }

  function good(v) { return v === true || v === 'true'; }

  function num(v, d) { var n = Number(v); return isFinite(n) ? n : d; }

  // 到期错题（只读）。limit 上限 30，服务端再夹。
  async function due(limit) {
    if (support === 'no') return fail('unsupported', '复习调度暂不可用');
    if (!hasDb()) return fail('no_db', '数据层还没准备好');
    var data;
    try {
      data = await window.DB.rpc('get_due_mistake_reviews', { p_limit: Math.max(1, Math.min(30, limit || 10)) });
    } catch (e) {
      if (looksUnsupported(msgOf(e))) { markUnsupported(); return fail('unsupported', '复习调度暂不可用（服务端还没更新）'); }
      return fail(looksNetwork(msgOf(e)) ? 'network' : 'error', msgOf(e) || '读取到期错题失败');
    }
    if (!data || data.ok === false) {
      var c = (data && data.message) || 'error';
      if (c === 'not_authenticated') return fail('auth', '登录已过期，请重新登录');
      return fail('error', (data && data.message) || '读取到期错题失败');
    }
    support = 'yes';
    var list = Array.isArray(data.items) ? data.items : [];
    var items = [];
    for (var i = 0; i < list.length; i++) {
      var it = list[i];
      if (!it || !it.mistake_id) continue;
      items.push({
        mistakeId: String(it.mistake_id),
        kind: it.kind || '',
        question: it.question || '',
        userAnswer: it.user_answer || '',
        correctAnswer: it.correct_answer || '',
        explainZh: it.explain_zh || '',
        context: it.context || null,
        createdAt: it.created_at || null,
        dueDate: it.eff_due || null,
        consecutiveWrong: num(it.cw, 0),
        reps: num(it.reps, 0),
        attempts: num(it.attempts, 0),
        lapses: num(it.lapses, 0),
        intervalDays: num(it.interval_days, 0),
        lastResult: it.last_result || null
      });
    }
    return { ok: true, day: data.day || null, total: num(data.total_due, items.length),
             maxPerDay: num(data.max_per_day, MAX_PER_DAY), items: items };
  }

  // 提交一次复习结果。clientEventId 由调用方生成并在网络失败后复用，保证同一次作答不会重复计。
  async function complete(mistakeId, result, clientEventId) {
    if (!mistakeId) return fail('bad_args', '缺少错题 ID');
    if (result !== 'correct' && result !== 'wrong') return fail('bad_args', '结果只能是 correct 或 wrong');
    var eid = clientEventId || newEventId();
    if (support === 'no') return fail('unsupported', '复习调度暂不可用', { clientEventId: eid });
    if (!hasDb()) return fail('no_db', '数据层还没准备好', { clientEventId: eid });
    // 服务端契约只接受 correct / incorrect（与 study_event.result 一致）；
    // 页面内部沿用 correct / wrong，在这里做一次边界转换，避免两套词汇互相污染。
    var apiResult = result === 'wrong' ? 'incorrect' : 'correct';
    var data;
    try {
      data = await window.DB.rpc('complete_mistake_review',
        { p_mistake_id: mistakeId, p_result: apiResult, p_client_event_id: eid });
    } catch (e) {
      var net = looksNetwork(msgOf(e));
      if (looksUnsupported(msgOf(e))) markUnsupported();
      return fail(net ? 'network' : 'error', msgOf(e) || '这次结果没保存成功',
        { clientEventId: eid, retryable: net });
    }
    if (!data || data.ok === false) {
      var code = (data && data.message) || 'error';
      if (code === 'event_id_conflict') return fail('conflict', '这次作答已提交过，但内容对不上，请刷新后重试', { clientEventId: eid });
      if (code === 'mistake_not_found') return fail('not_found', '这道错题已经被删除了', { clientEventId: eid });
      if (code === 'not_authenticated') return fail('auth', '登录已过期，请重新登录', { clientEventId: eid });
      if (code === 'bad_result' || code === 'bad_client_event_id' || code === 'bad_mistake_id') return fail('bad_args', '提交内容不完整，请刷新后重试', { clientEventId: eid });
      // 服务端写入侧硬限制：不可重试、不要排队，避免用户反复点
      if (code === 'daily_limit_reached') return fail('daily_limit', '这道题今天已经复习 2 次了，明天再来', { clientEventId: eid, retryable: false, terminal: true, attemptInDay: num(data.attempt_in_day, 2), maxPerDay: num(data.max_per_day, MAX_PER_DAY) });
      if (code === 'not_due') return fail('not_due', '这道题还没到期，到期后会出现在复习计划里', { clientEventId: eid, retryable: false, terminal: true, dueDate: data.due_date || null });
      return fail('error', (data && data.message) || '这次结果没保存成功', { clientEventId: eid, retryable: true });
    }
    support = 'yes';
    var graduated = good(data.graduated);
    var resolved = good(data.resolved) || graduated;
    return {
      ok: true,
      clientEventId: eid,
      duplicate: good(data.duplicate),
      alreadyResolved: good(data.already_resolved),
      graduated: graduated,
      resolved: resolved,
      result: data.result || result,
      reps: num(data.reps, 0),
      lapses: num(data.lapses, 0),
      consecutiveWrong: num(data.consecutive_wrong, 0),
      attempts: num(data.attempts, 0),
      intervalDays: data.interval_days == null ? null : num(data.interval_days, 0),
      dueDate: data.due_date || null,
      roundNo: data.round_no == null ? null : num(data.round_no, 0),
      attemptInDay: num(data.attempt_in_day, 1)
    };
  }

  // 标记已掌握 / 重新开始复习。服务端保证「已掌握必须清掉到期状态」和「重新开始轮次+1、历史事件保留」。
  async function setMastered(mistakeId, mastered) {
    if (!mistakeId) return fail('bad_args', '缺少错题 ID');
    if (support === 'no') return fail('unsupported', '复习调度暂不可用');
    if (!hasDb()) return fail('no_db', '数据层还没准备好');
    var data;
    try {
      data = await window.DB.rpc('set_mistake_mastered',
        { p_mistake_id: mistakeId, p_mastered: !!mastered });
    } catch (e) {
      if (looksUnsupported(msgOf(e))) { markUnsupported(); return fail('unsupported', '复习调度暂不可用（服务端还没更新）'); }
      return fail(looksNetwork(msgOf(e)) ? 'network' : 'error', msgOf(e) || '操作失败，请稍后再试');
    }
    if (!data || data.ok === false) {
      var c = (data && data.message) || 'error';
      if (c === 'mistake_not_found') return fail('not_found', '这道错题已经被删除了');
      if (c === 'bad_mistake_id' || c === 'bad_mastered') return fail('bad_args', '操作参数不完整，请刷新页面后重试');
      if (c === 'not_authenticated') return fail('auth', '登录已过期，请重新登录');
      return fail('error', (data && data.message) || '操作失败，请稍后再试');
    }
    support = 'yes';
    return { ok: true, resolved: good(data.resolved), roundNo: data.round_no == null ? null : num(data.round_no, 0),
             dueDate: data.due_date || null,
             attempts: data.attempts == null ? null : num(data.attempts, 0),
             idempotent: good(data.idempotent) };
  }

  function isSupported() { return support !== 'no'; }
  function supportState() { return support; }

  return {
    MAX_PER_DAY: MAX_PER_DAY,
    newEventId: newEventId,
    due: due,
    complete: complete,
    setMastered: setMastered,
    isSupported: isSupported,
    supportState: supportState,
    looksUnsupported: looksUnsupported
  };
})();
