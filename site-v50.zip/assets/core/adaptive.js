/* ============================================================
 * assets/core/adaptive.js —— B2 自适应教学的数据层（只读）
 *
 * 原则：
 *   1) 只用本人真实学习记录；任何一张表读失败就整体返回 null，
 *      调用方按「没有档案」处理，绝不拿 0 值冒充数据（B1 要求）。
 *   2) 不做 AI 调用、不花钱；结果按 uid 缓存 5 分钟。
 *   3) 难度调整保守：样本 ≥12 且至少 2 个学习日才动，最多 ±1 级。
 *   4) 少量错题只描述「这几题」，不推断「整体能力差」。
 * ============================================================ */
(function () {
  'use strict';
  var TTL = 300000;
  var cache = { uid: null, at: 0, data: null };

  function two(n) { return (n < 10 ? '0' : '') + n; }
  function localDateOf(d) {
    if (!(d instanceof Date) || isNaN(d.getTime())) return '';
    return d.getFullYear() + '-' + two(d.getMonth() + 1) + '-' + two(d.getDate());
  }
  function shiftDate(s, n) {
    var p = String(s || '').split('-').map(Number);
    var d = new Date(p[0], (p[1] || 1) - 1, p[2] || 1);
    d.setDate(d.getDate() + n);
    return localDateOf(d);
  }
  function daysBetween(a, b) {
    var pa = String(a || '').split('-').map(Number);
    var pb = String(b || '').split('-').map(Number);
    var da = new Date(pa[0], (pa[1] || 1) - 1, pa[2] || 1);
    var db = new Date(pb[0], (pb[1] || 1) - 1, pb[2] || 1);
    return Math.round((db - da) / 86400000);
  }
  function clamp(n, lo, hi) { return Math.max(lo, Math.min(hi, n)); }
  function rateText(r) { return Math.round(r * 100) + '%'; }
  function purity(rows, keys) {
    if (!Array.isArray(rows)) return false;
    return rows.every(function (r) { return r && typeof r === 'object' && keys.every(function (k) { return k in r; }); });
  }

  /* 把一条学习结果折算成「1 个观测」的单位：
   *   · 单词：每题 1 个观测（rate 0/1）
   *   · 课程小测：整次课 1 个观测（rate=得分率），避免一次 20 题压过所有单词
   * 权重只按日期远近：0-2 天 3 倍，3-6 天 2 倍，7-13 天 1 倍。 */
  function weightOf(day, today) {
    var age = daysBetween(day, today);
    if (age < 0 || age > 13) return 0;
    if (age <= 2) return 3;
    if (age <= 6) return 2;
    return 1;
  }

  function analyze(raw, base, today) {
    raw = raw || {};
    var words = Array.isArray(raw.words) ? raw.words : [];
    var events = Array.isArray(raw.events) ? raw.events : [];
    var mistakes = Array.isArray(raw.mistakes) ? raw.mistakes : [];
    var lessons = Array.isArray(raw.lessons) ? raw.lessons : [];
    base = clamp(Number(base) || 1, 1, 3);

    var units = [];              // {day, rate, weight, module}
    var activity = {};           // day -> 1
    var module = { word: { c: 0, t: 0 }, grammar: { c: 0, t: 0 }, listening: { c: 0, t: 0 }, reading: { c: 0, t: 0 }, speaking: { c: 0, t: 0 } };
    var grammar = {};            // title -> {rates:[], days:[], last}
    var i, r, day, w;

    events.forEach(function (e) {
      if (!e || e.is_final !== true) return;
      if (e.result !== 'correct' && e.result !== 'incorrect') return;
      day = localDateOf(new Date(e.created_at));
      w = weightOf(day, today);
      if (!w) return;
      var ok = e.result === 'correct' ? 1 : 0;
      activity[day] = 1;
      units.push({ day: day, rate: ok, weight: w, module: 'word' });
      module.word.t++; if (ok) module.word.c++;
    });

    lessons.forEach(function (l) {
      if (!l || !l.result || l.result.done === false) return;
      var sc = Number(l.result.score), tt = Number(l.result.total);
      if (!(tt > 0) || !(sc >= 0) || sc > tt) return;
      var mod = String(l.module || '');
      if (!module[mod] || mod === 'word' || mod === 'speaking') return;
      day = String(l.lesson_date || '').slice(0, 10);
      w = weightOf(day, today);
      if (!w) return;
      var rate = sc / tt;
      activity[day] = 1;
      units.push({ day: day, rate: rate, weight: w, module: mod });
      module[mod].t += tt; module[mod].c += sc;
      if (mod === 'grammar') {
        var title = String((l.content && (l.content.point || l.content.title)) || '').replace(/\s+/g, ' ').trim().slice(0, 60);
        if (title) {
          if (!grammar[title]) grammar[title] = { rates: [], days: [], last: '', lastRate: 0 };
          grammar[title].rates.push(rate);
          grammar[title].days.push(day);
          if (day >= grammar[title].last) { grammar[title].last = day; grammar[title].lastRate = rate; }
        }
      }
    });

    var sumW = 0, sumR = 0, recentW = 0, recentR = 0;
    units.forEach(function (u) {
      sumW += u.weight; sumR += u.weight * u.rate;
      if (u.day >= shiftDate(today, -2)) { recentW += u.weight; recentR += u.weight * u.rate; }
    });
    var accuracy = sumW ? sumR / sumW : null;
    var recentAcc = recentW ? recentR / recentW : null;
    var activeDays = Object.keys(activity).length;

    var dueWords = 0, masteredWords = 0, weakAll = [];
    words.forEach(function (x) {
      if (!x) return;
      if (x.due_date && String(x.due_date).slice(0, 10) <= today) dueWords++;
      var reps = Number(x.reps) || 0, iv = Number(x.interval_days) || 0, lapses = Number(x.lapses) || 0;
      if (reps >= 3 && iv >= 6 && lapses <= 1) masteredWords++;
      if (lapses >= 2) weakAll.push({ word_id: x.word_id, lapses: lapses, ease: Number(x.ease) || 2.5, reps: reps });
    });
    weakAll.sort(function (a, b) { return b.lapses - a.lapses || a.ease - b.ease || a.reps - b.reps; });
    var weakTop = weakAll.slice(0, 6);

    var dates = Object.keys(activity).sort();
    var streak = 0;
    var cur = dates.indexOf(today) >= 0 ? today : shiftDate(today, -1);
    while (activity[cur]) { streak++; cur = shiftDate(cur, -1); }
    var studied7 = 0;
    for (i = 0; i < 7; i++) if (activity[shiftDate(today, -i)]) studied7++;

    var unresolved = mistakes.filter(function (m) { return m && m.resolved !== true; }).length;
    var recentMistakes = mistakes.filter(function (m) { return m && m.resolved !== true; }).slice(0, 6).map(function (m) {
      return {
        kind: String(m.kind || '').slice(0, 12),
        question: String(m.question || '').replace(/\s+/g, ' ').trim().slice(0, 70)
      };
    });

    var moduleOut = {};
    Object.keys(module).forEach(function (k) {
      var m = module[k];
      moduleOut[k] = { total: m.t, correct: m.c, rate: m.t ? m.c / m.t : null };
    });

    var points = [];
    Object.keys(grammar).forEach(function (title) {
      var g = grammar[title];
      var sum = 0;
      g.rates.forEach(function (x) { sum += x; });
      points.push({
        title: title,
        attempts: g.rates.length,
        last_rate: g.lastRate,
        avg_rate: sum / g.rates.length,
        last_day: g.last
      });
    });
    var masteredPoints = points.filter(function (p) { return p.attempts >= 2 && p.last_rate >= 0.8; })
      .sort(function (a, b) { return b.last_rate - a.last_rate || b.attempts - a.attempts; }).slice(0, 5);
    var weakPoints = points.filter(function (p) { return p.attempts >= 2 && p.avg_rate < 0.6; })
      .sort(function (a, b) { return a.avg_rate - b.avg_rate || b.attempts - a.attempts; }).slice(0, 3);

    /* 难度：先看样本量，再看加权正确率与最近 3 天表现；最多 ±1 级。 */
    var level = base, levelReason = '';
    if (units.length < 12 || activeDays < 2) {
      levelReason = '样本还不够（' + units.length + ' 题 / ' + activeDays + ' 天），先按第 ' + base + ' 阶段。';
    } else if (accuracy >= 0.82 && recentAcc >= 0.75 && units.length >= 16) {
      level = Math.min(3, base + 1);
      levelReason = '近 14 天 ' + rateText(accuracy) + '，最近 3 天 ' + rateText(recentAcc) + '，可以试难一点。';
    } else if (accuracy <= 0.5 && recentAcc <= 0.55) {
      level = Math.max(1, base - 1);
      levelReason = '近 14 天 ' + rateText(accuracy) + '，最近 3 天 ' + rateText(recentAcc) + '，先把基础打稳。';
    } else {
      levelReason = '近 14 天 ' + rateText(accuracy) + '，保持当前难度。';
    }

    var focus = [];
    if (dueWords >= 5) focus.push({ key: 'due', label: '复习 ' + dueWords + ' 个到期词', href: 'review.html' });
    if (unresolved >= 2) focus.push({ key: 'mistakes', label: '错题复练', href: 'mistakes.html?due=1' });
    if (weakAll.length) focus.push({ key: 'weak', label: '弱词专项', href: 'mistakes.html' });
    if (weakPoints.length) focus.push({ key: 'grammar', label: '语法：' + weakPoints[0].title, href: 'lesson.html?module=grammar' });
    if (focus.length < 2) {
      var low = null;
      ['listening', 'reading', 'grammar'].forEach(function (k) {
        var m = moduleOut[k];
        if (m.total >= 4 && m.rate != null && m.rate < 0.6 && (!low || m.rate < low.rate)) low = { key: k, label: ({ listening: '听力', reading: '阅读', grammar: '语法' })[k] + '专项', href: 'lesson.html?module=' + k, rate: m.rate };
      });
      if (low) focus.push(low);
    }
    if (!focus.length) focus.push({ key: 'lesson', label: '继续今日课程', href: 'lesson.html' });

    var advice;
    if (!units.length) {
      advice = '先完成一次学习，我会按你的真实答题调整难度。';
    } else if (dueWords >= 5) {
      advice = '今天有 ' + dueWords + ' 个到期词，可以先复习，再学新词。';
    } else if (weakAll.length) {
      advice = '你在 ' + weakTop.slice(0, 2).map(function (x) { return '「' + (x.word || '旧词') + '」'; }).join('、') + ' 上反复忘记，建议先做一组错题复练。';
    } else if (weakPoints.length) {
      advice = '语法「' + weakPoints[0].title + '」最近两次正确率偏低，今天从它开始。';
    } else if (moduleOut.listening.total >= 4 && moduleOut.listening.rate < 0.6) {
      advice = '听力最近正确率 ' + rateText(moduleOut.listening.rate) + '，今天先做听力，把关键词听出来。';
    } else if (streak >= 3) {
      advice = '已连续学习 ' + streak + ' 天，今天也可以按自己的节奏学习。';
    } else {
      advice = '最近正确率 ' + rateText(accuracy || 0) + '，今天按五个模块完成，稳定后再加难度。';
    }

    return {
      enabled: true,
      sample: { units: units.length, active_days: activeDays, accuracy: accuracy, recent_accuracy: recentAcc },
      due_words: dueWords,
      studied_days_7: studied7,
      streak_days: streak,
      unresolved_mistakes: unresolved,
      recent_mistakes: recentMistakes,
      weak_words: weakTop,
      mastered_words: masteredWords,
      module_accuracy: moduleOut,
      mastered_points: masteredPoints,
      weak_points: weakPoints,
      level: { base: base, suggested: level, reason: levelReason },
      focus: focus.slice(0, 3),
      advice: advice
    };
  }

  async function get(uid) {
    if (!uid || !window.DB || !window.DB.select) return null;
    var now = Date.now();
    if (cache.uid === uid && cache.data && now - cache.at < TTL) return cache.data;
    try {
      // v52 compat: prefer the 027 view, fall back to the live table so the site works
      // before migration 027 is applied in production.
      var wpRows = window.DB.select('active_word_progress', { user_id: uid, limit: 2000 })
        .catch(function () { return window.DB.select('word_progress', { user_id: uid, limit: 2000 }); });
      var r = await Promise.all([
        wpRows,
        window.DB.select('study_event', { user_id: uid, order: 'created_at.desc', limit: 800 }),
        window.DB.select('mistakes', { user_id: uid, order: 'created_at.desc', limit: 80 }),
        window.DB.select('lesson_content', { user_id: uid, order: 'lesson_date.desc', limit: 60 })
      ]);
      if (!Array.isArray(r[0]) || !Array.isArray(r[1]) || !Array.isArray(r[2]) || !Array.isArray(r[3])) return null;
      var base = 1;
      try {
        var first = await window.DB.select('daily_task', { user_id: uid, order: 'study_date.asc', limit: 1 });
        if (first && first.length && first[0].study_date) {
          var idx = Math.max(0, daysBetween(String(first[0].study_date).slice(0, 10), localDateOf(new Date())));
          base = idx < 7 ? 1 : idx < 14 ? 2 : 3;
        }
      } catch (e) { return null; }
      var data = analyze({ words: r[0], events: r[1], mistakes: r[2], lessons: r[3] }, base, localDateOf(new Date()));
      // 弱词显示名：最多 6 次单条查询，并发；查不到就不显示词名，不编造。
      var labels = await Promise.all(data.weak_words.map(function (x) {
        return window.DB.select('words', { id: x.word_id, limit: 1 }).then(function (rows) {
          return (rows && rows[0] && rows[0].word) ? String(rows[0].word).slice(0, 40) : '';
        }).catch(function () { return ''; });
      }));
      data.weak_words = data.weak_words.map(function (x, i) { x.word = labels[i]; return x; }).filter(function (x) { return !!x.word; });
      cache = { uid: uid, at: now, data: data };
      return data;
    } catch (e) {
      return null;
    }
  }

  function invalidate(uid) {
    if (!uid || cache.uid === uid) cache = { uid: null, at: 0, data: null };
  }
  if (typeof window !== 'undefined') {
    window.addEventListener('app:session-changed', function () { cache = { uid: null, at: 0, data: null }; });
    window.Adaptive = { get: get, invalidate: invalidate, analyze: analyze, _reset: function () { cache = { uid: null, at: 0, data: null }; } };
  }
})();
