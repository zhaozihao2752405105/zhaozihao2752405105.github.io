(function () {
  'use strict';
  const items = [
    ['Choose the correct word: I ___ a book.', ['has', 'have', 'having'], 1],
    ['We missed the bus, ___ we walked home.', ['although', 'so', 'until'], 1],
    ['I wish I ___ my umbrella yesterday.', ['had brought', 'bring', 'have brought'], 0],
    ['The library extended its hours. Even so, some students asked for weekend access. What does “even so” show?', ['A cause', 'A contrast', 'A deadline'], 1],
    ['The survey was limited to volunteers. What can we infer?', ['Its sample may not represent everyone.', 'Volunteering produced the results.', 'Nobody was allowed to decline.'], 0],
    ['“It is not that the policy was ineffective; it is that its effects were uneven.” What is the writer’s point?', ['People disagreed about the policy.', 'The policy had different effects on different groups.', 'The policy had no measurable effects.'], 1],
    ['The editor described the proposal as “ambitious” while carefully avoiding any commitment to it. What best describes the tone?', ['Unqualified approval', 'Open hostility', 'Cautious acknowledgment'], 2],
    ['“Every new shortcut took us further from our destination.” What is the main rhetorical effect?', ['Paradox highlights unintended consequences.', 'Hyperbole proves the journey was short.', 'Repetition specifies a route.'], 0],
    ['A city’s traffic fell after it opened a subway line, while many offices also adopted remote work. Which claim is most defensible?', ['The subway alone caused the decline.', 'Both changes may have contributed; this observation cannot isolate their effects.', 'Remote work had no measurable effect.'], 1]
  ];

  function element(tag, text) {
    const node = document.createElement(tag);
    if (text) node.textContent = text;
    return node;
  }
  function button(text, action) {
    const node = element('button', text);
    node.type = 'button';
    node.className = 'btn ghost';
    node.addEventListener('click', action);
    return node;
  }
  function recommendation(answers) {
    const correct = answers.filter((answer, index) => items[index]?.[2] === answer).length;
    return Math.max(1, Math.min(9, correct));
  }

  async function mount(target) {
    if (!target || !window.Difficulty) return;
    const difficulty = window.Difficulty;
    const app = window.LumiDifficulty;
    const status = element('p');
    status.setAttribute('role', 'status');
    const test = element('div');
    const goals = element('label', '考试目标');
    goals.className = 'lumi-difficulty-field';
    const goal = element('select');
    for (const [value, text] of Object.entries(app.examTargets)) {
      const option = element('option', text);
      option.value = value;
      goal.append(option);
    }
    goal.disabled = true;
    goals.append(goal);
    const state = await difficulty.read();
    if (!state.ok || !target.isConnected) return;
    const heading = element('h2', '水平测试与考试目标');
    const note = element('p', '测试可跳过。结果只用于 Lumi 的初始难度建议。');
    target.classList.add('card', 'lumi-difficulty');
    target.replaceChildren(heading, note, goals, status, test);
    goal.value = state.prefs.exam_target || 'none';
    goal.disabled = false;
    goal.addEventListener('change', async () => {
      const value = goal.value;
      goal.disabled = true;
      try {
        const current = difficulty.current();
        const result = await difficulty.saveExamTarget(value, current.revision);
        goal.value = result.prefs.exam_target || 'none';
        status.textContent = result.ok ? '考试目标已保存。' : '另一处已更新，请重选。';
      } catch {
        goal.value = difficulty.current()?.exam_target || 'none';
        status.textContent = '考试目标未保存。';
      } finally { goal.disabled = false; }
    });

    function launch() {
      const answers = [];
      function next() {
        test.replaceChildren();
        const index = answers.length;
        if (index < items.length) {
          const [prompt, options] = items[index];
          const field = element('fieldset');
          field.append(element('legend', prompt));
          options.forEach((value, option) => {
            field.append(button(value, () => { if (answers.length === index) { answers.push(option); next(); } }));
          });
          test.append(element('p', (index + 1) + ' / ' + items.length), field, button('退出测试', reset));
          return;
        }
        const level = recommendation(answers);
        const use = button('采用为全局难度', async () => {
          if (use.disabled) return;
          use.disabled = true;
          try {
            const current = difficulty.current();
            const answer = await difficulty.setGlobal(level, current.revision);
            status.textContent = answer.ok ? '全局难度已更新。' : '设置已变化，请重试。';
            if (answer.ok) {
              void difficulty.mount(document.getElementById('difficultySettings'), ['global', ...Object.keys(app.modules)]);
              reset();
            }
          } catch { status.textContent = '全局难度未保存。'; }
          finally { use.disabled = false; }
        });
        test.append(element('p', '测试建议 ' + difficulty.label(level) + '。模块单独设置会保留。'),
          use, button('保留现有设置', reset));
      }
      next();
    }
    function reset() { test.replaceChildren(button('做一次水平测试', launch)); }
    reset();
  }

  window.LumiDifficultyPlacement = Object.freeze({ recommendation });
  document.addEventListener('DOMContentLoaded', () => void mount(document.getElementById('difficultyPlacement')));
})();
