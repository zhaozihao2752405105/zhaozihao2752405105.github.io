/* ============================================================
 * assets/core/content-repair.js —— AI 生成内容的本地修补（纯函数，无依赖）
 * 背景：模型偶尔会把同一选项写两遍（如 A/B 都是 "The dog barks..."），
 *       这会让「正确答案」产生歧义，学习者选哪一个都可能被判错。
 * 做法：去重选项并把 answer_index 重映射到保留下来的那一项；
 *       去重后不足 2 项、或 answer_index 不合法、或题干为空的题，整题丢弃。
 * 不调用网络、不写数据库，只做内存里的修补。
 * ============================================================ */
(function () {
  'use strict';

  function norm(s) {
    return String(s == null ? '' : s).trim().toLowerCase().replace(/\s+/g, ' ');
  }

  // 修一道单选题；修不了返回 null
  function repairOption(q) {
    if (!q || typeof q !== 'object') return null;
    if (!q.question || !String(q.question).trim()) return null;
    if (!Array.isArray(q.options)) return null;
    var out = [], map = [];
    for (var i = 0; i < q.options.length; i++) {
      var text = String(q.options[i] == null ? '' : q.options[i]).trim();
      if (!text) { map[i] = -1; continue; }
      var key = norm(text), hit = -1;
      for (var j = 0; j < out.length; j++) { if (norm(out[j]) === key) { hit = j; break; } }
      if (hit >= 0) { map[i] = hit; }
      else { map[i] = out.length; out.push(text); }
    }
    if (out.length < 2) return null;
    var ai = q.answer_index;
    if (typeof ai !== 'number' || !isFinite(ai) || ai % 1 !== 0) return null;
    if (ai < 0 || ai >= q.options.length) return null;
    var correct = map[ai];
    if (correct === undefined || correct < 0 || correct >= out.length) return null;
    return {
      question: String(q.question).trim(),
      options: out,
      answer_index: correct,
      explain_zh: q.explain_zh ? String(q.explain_zh) : ''
    };
  }

  function repairList(list, maxKeep) {
    var out = [];
    if (!Array.isArray(list)) return out;
    for (var i = 0; i < list.length; i++) {
      var q = repairOption(list[i]);
      if (q) out.push(q);
      if (maxKeep && out.length >= maxKeep) break;
    }
    return out;
  }

  // 按模块修补整份内容，返回新对象（不改原对象）
  function repair(module, content) {
    if (!content || typeof content !== 'object') return content;
    var copy = {};
    for (var k in content) { if (Object.prototype.hasOwnProperty.call(content, k)) copy[k] = content[k]; }
    if (module === 'grammar') copy.exercises = repairList(content.exercises, 8);
    if (module === 'listening' || module === 'reading' || module === 'test') {
      copy.questions = repairList(content.questions, 10);
    }
    return copy;
  }

  function questionCount(module, content) {
    if (!content || typeof content !== 'object') return 0;
    if (module === 'grammar') return Array.isArray(content.exercises) ? content.exercises.length : 0;
    if (module === 'test') return Array.isArray(content.items) ? content.items.length : 0;
    return Array.isArray(content.questions) ? content.questions.length : 0;
  }

  window.ContentRepair = {
    repair: repair,
    repairOption: repairOption,
    repairList: repairList,
    questionCount: questionCount
  };
})();
