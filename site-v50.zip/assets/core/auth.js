/* ============================================================
 * assets/core/auth.js —— 登录状态与页面守卫
 * 用法：在需要登录的页面先引 db.js，再引本文件，然后 await AppAuth.requireLogin()
 *   未登录 → 自动跳 login.html，并把当前页面记在 ?next= 里
 * ============================================================ */
window.AppAuth = (function () {
  var USER_KEY = 'app.user.cache.v1';

  function cachedUser() {
    try { return JSON.parse(localStorage.getItem(USER_KEY) || 'null'); } catch (e) { return null; }
  }
  function setCache(u) {
    var prev = cachedUser();
    if (u) localStorage.setItem(USER_KEY, JSON.stringify({ id: u.id, email: u.email }));
    else localStorage.removeItem(USER_KEY);
    // 账号变化时通知各页清掉「按用户缓存」的数据（学习档案、会话、待确认记忆等）。
    // 同一账号重复写入不广播，避免每次进入页面都白清一次缓存。
    var nextId = u ? u.id : null;
    var prevId = prev ? prev.id : null;
    if (nextId !== prevId) {
      try {
        window.dispatchEvent(new CustomEvent('app:session-changed', { detail: { userId: nextId } }));
      } catch (e) { /* 老浏览器没有 CustomEvent 构造器时忽略 */ }
    }
  }

  function loginUrl() {
    var here = location.pathname.split('/').pop() || 'index.html';
    return 'login.html?next=' + encodeURIComponent(here + location.hash);
  }

  async function requireLogin() {
    // 断网时完全不碰网络：直接用上次缓存的登录信息，
    // 否则 supabase 会尝试刷新令牌、失败后把本地会话清掉，导致离线打开就变成未登录。
    var preCached = cachedUser();
    if (typeof navigator !== 'undefined' && navigator.onLine === false && preCached && preCached.id) {
      return preCached;
    }
    var user = null;
    var netErr = null;
    try { user = await window.DB.auth.getUser(); } catch (e) { netErr = e; }
    if (!user) {
      // 断网时 getUser 需要联网校验：请求会抛错，或被 supabase 吞成 error 后返回 null。
      // 两种都按「离线」处理——用上次缓存的用户继续，让已排队的记录能显示、能补交；
      // 真正退出登录会走 logout() 清掉缓存，所以这里不会让已退出的账号复活太久。
      var offline = netErr || (typeof navigator !== 'undefined' && navigator.onLine === false);
      var cached = cachedUser();
      if (offline && cached && cached.id) return cached;
    }
    if (!user) {
      // 离线体验模式下 getUser 会读本地假会话；真没登录才跳转
      location.replace(loginUrl());
      return null;
    }
    setCache(user);
    return user;
  }

  async function logout() {
    // 顶栏只有一个 ⎋ 图标，容易被当成「返回」误点；退出是破坏性操作，先确认。
    // 注意：这个方法只由用户点击触发（没有自动登出调用点），加确认是安全的。
    var ok = true;
    try {
      ok = window.confirm('确定退出登录吗？\n\n退出后需要重新输入邮箱和密码；学习记录不会丢失，下次登录会继续。');
    } catch (e) { ok = true; }
    if (!ok) return;
    try { await window.DB.auth.signOut(); } catch (e) { /* 忽略 */ }
    setCache(null);
    location.replace('login.html');
  }

  function displayName(user) {
    if (!user) return '';
    var email = user.email || '';
    return email.split('@')[0] || '同学';
  }

  return {
    requireLogin: requireLogin,
    logout: logout,
    cachedUser: cachedUser,
    displayName: displayName,
    loginUrl: loginUrl
  };
})();
