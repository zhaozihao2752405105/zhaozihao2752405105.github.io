/* ============================================================
 * assets/core/auth.js —— 登录状态与页面守卫
 * 用法：在需要登录的页面先引 db.js，再引本文件，然后 await AppAuth.requireLogin()
 *   未登录 → 自动跳 login.html，并把当前页面记在 ?next= 里
 * ============================================================ */
window.AppAuth = (function () {
  var USER_KEY = 'app.user.cache.v1';

  function cachedUser() {
    try { return JSON.parse(localStorage.getItem(USER_KEY) || 'null'); } catch (e) { return null; }
  }
  function setCache(u) {
    var prev = cachedUser();
    try {
      if (u) localStorage.setItem(USER_KEY, JSON.stringify({ id: u.id, email: u.email }));
      else localStorage.removeItem(USER_KEY);
    } catch (e) { /* Storage may be unavailable in private mode. */ }
    // 账号变化时通知各页清掉「按用户缓存」的数据（学习档案、会话、待确认记忆等）。
    // 同一账号重复写入不广播，避免每次进入页面都白清一次缓存。
    var nextId = u ? u.id : null;
    var prevId = prev ? prev.id : null;
    if (nextId !== prevId) {
      try {
        window.dispatchEvent(new CustomEvent('app:session-changed', { detail: { userId: nextId } }));
      } catch (e) { /* 老浏览器没有 CustomEvent 构造器时忽略 */ }
    }
  }

  function loginUrl() {
    var here = location.pathname.split('/').pop() || 'index.html';
    return 'login.html?next=' + encodeURIComponent(here + location.search + location.hash);
  }

  var inFlight = null;
  var authEpoch = 0;
  function retryNotice() {
    if (document.getElementById('auth-retry')) return;
    var box = document.createElement('div');
    box.id = 'auth-retry';
    box.className = 'card';
    box.setAttribute('role', 'alert');
    var msg = document.createElement('p');
    msg.textContent = '暂时无法读取登录状态，请检查网络后重试。不会自动退出登录。';
    var retry = document.createElement('button');
    retry.type = 'button'; retry.className = 'btn'; retry.textContent = '重新连接';
    retry.addEventListener('click', function () { location.reload(); });
    box.appendChild(msg); box.appendChild(retry);
    (document.getElementById('view') || document.body).prepend(box);
  }
  function requireLogin() {
    if (inFlight) return inFlight;
    var epoch = authEpoch;
    var run = (async function () {
      var local = null;
      try { local = window.DB.auth.peekUser(); } catch (e) { /* SDK may still have a session */ }
      var user;
      try {
        // Do not refresh tokens offline. The stored session only identifies the local view.
        if (navigator.onLine === false && local && local.id) user = local;
        else user = await window.DB.auth.getSessionUser();
      } catch (e) {
        if (epoch !== authEpoch) return null;
        // Retryable errors (including auth rate limiting and network errors) must not log out.
        // Re-read storage, since another tab could have signed out or changed users.
        var now = null;
        try { now = window.DB.auth.peekUser(); } catch (_) {}
        if (local && now && local.id === now.id) user = now;
        else { retryNotice(); return null; }
      }
      if (epoch !== authEpoch) return null;
      if (!user) {
        setCache(null);
        location.replace(loginUrl());
        return null;
      }
      setCache(user);
      return user;
    })();
    inFlight = run;
    run.then(function () { if (inFlight === run) inFlight = null; }, function () { if (inFlight === run) inFlight = null; });
    return run;
  }

  async function logout() {
    // 顶栏只有一个 ⎋ 图标，容易被当成「返回」误点；退出是破坏性操作，先确认。
    // 注意：这个方法只由用户点击触发（没有自动登出调用点），加确认是安全的。
    var ok = true;
    try {
      ok = window.confirm('确定退出登录吗？\n\n退出后需要重新输入邮箱和密码；学习记录不会丢失，下次登录会继续。');
    } catch (e) { ok = true; }
    if (!ok) return;
    authEpoch++;
    try { await window.DB.auth.signOut(); } catch (e) {
      window.alert('暂时无法退出登录，请检查网络后重试。'); return;
    }
    setCache(null);
    location.replace('login.html');
  }

  function displayName(user) {
    if (!user) return '';
    var email = user.email || '';
    return email.split('@')[0] || '同学';
  }

  return {
    requireLogin: requireLogin,
    logout: logout,
    cachedUser: cachedUser,
    displayName: displayName,
    loginUrl: loginUrl
  };
})();
