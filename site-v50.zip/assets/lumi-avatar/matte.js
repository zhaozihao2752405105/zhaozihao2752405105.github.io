(function () {
  'use strict';

  function create(canvas) {
    var gl = canvas.getContext('webgl', {
      alpha: true, antialias: false, depth: false, stencil: false, premultipliedAlpha: false
    });
    if (!gl) return null;

    function shader(kind, source) {
      var part = gl.createShader(kind);
      gl.shaderSource(part, source);
      gl.compileShader(part);
      if (!gl.getShaderParameter(part, gl.COMPILE_STATUS)) throw new Error('Lumi portrait shader');
      return part;
    }

    var program = gl.createProgram();
    var vertex = shader(gl.VERTEX_SHADER,
      'attribute vec2 point; varying vec2 uv; void main(){gl_Position=vec4(point,0.,1.);uv=vec2(.5+.5*point.x,.5-.5*point.y);}'
    );
    var fragment = shader(gl.FRAGMENT_SHADER, [
      '#ifdef GL_FRAGMENT_PRECISION_HIGH',
      'precision highp float;',
      '#else',
      'precision mediump float;',
      '#endif',
      'varying vec2 uv; uniform sampler2D frame; uniform float halfTexel; uniform float split;',
      'void main(){',
      '  vec3 color=texture2D(frame,vec2(uv.x,mix(halfTexel,split-halfTexel,uv.y))).rgb;',
      '  float matte=texture2D(frame,vec2(uv.x,mix(split+halfTexel,1.-halfTexel,uv.y))).r;',
      '  float blackLine=mix(split,1.,.04);',
      '  float dark=min(texture2D(frame,vec2(.016,blackLine)).r,texture2D(frame,vec2(.984,blackLine)).r);',
      '  float whiteLine=mix(split,1.,.742);',
      '  float light=texture2D(frame,vec2(.50,whiteLine)).r;',
      '  float span=split<.6 ? (1.-2.*dark-.018) : (light-dark-.020);',
      '  float opacity=clamp((matte-dark-.010)/max(span,.80),0.,1.);',
      '  gl_FragColor=vec4(color,opacity);',
      '}'
    ].join('\n'));
    gl.attachShader(program, vertex);
    gl.attachShader(program, fragment);
    gl.linkProgram(program);
    gl.deleteShader(vertex);
    gl.deleteShader(fragment);
    if (!gl.getProgramParameter(program, gl.LINK_STATUS)) throw new Error('Lumi portrait renderer');

    gl.useProgram(program);
    gl.uniform1i(gl.getUniformLocation(program, 'frame'), 0);
    var points = gl.createBuffer();
    var point = gl.getAttribLocation(program, 'point');
    gl.bindBuffer(gl.ARRAY_BUFFER, points);
    gl.bufferData(gl.ARRAY_BUFFER, new Float32Array([-1,-1,1,-1,-1,1,1,1]), gl.STATIC_DRAW);
    gl.enableVertexAttribArray(point);
    gl.vertexAttribPointer(point, 2, gl.FLOAT, false, 0, 0);
    var texture = gl.createTexture();
    gl.bindTexture(gl.TEXTURE_2D, texture);
    gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_WRAP_S, gl.CLAMP_TO_EDGE);
    gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_WRAP_T, gl.CLAMP_TO_EDGE);
    gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_MIN_FILTER, gl.LINEAR);
    gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_MAG_FILTER, gl.LINEAR);
    var pad = gl.getUniformLocation(program, 'halfTexel');
    var boundary = gl.getUniformLocation(program, 'split');
    var importedWidth = 0;
    var importedHeight = 0;
    gl.viewport(0, 0, canvas.width, canvas.height);

    return {
      draw: function (video) {
        var width = video.videoWidth;
        var height = video.videoHeight;
        var ratio = width / height;
        var fullAlpha = Math.abs(ratio - .375) < .016;
        if (gl.isContextLost() || !height || (!fullAlpha && Math.abs(ratio - .5) > .016)) return false;
        try {
          // Some WebKit ports report the display-scaled dimensions for video textures.
          if (width !== importedWidth || height !== importedHeight) {
            gl.texImage2D(gl.TEXTURE_2D, 0, gl.RGBA, gl.RGBA, gl.UNSIGNED_BYTE, video);
            if (gl.getError() !== gl.NO_ERROR) return false;
            gl.uniform1f(pad, .5 / height);
            gl.uniform1f(boundary, fullAlpha ? .5 : 2 / 3);
            importedWidth = width;
            importedHeight = height;
          } else {
            gl.texSubImage2D(gl.TEXTURE_2D, 0, 0, 0, gl.RGBA, gl.UNSIGNED_BYTE, video);
          }
          gl.drawArrays(gl.TRIANGLE_STRIP, 0, 4);
          return true;
        } catch (error) {
          return false;
        }
      },
      clear: function () {
        gl.clearColor(0, 0, 0, 0);
        gl.clear(gl.COLOR_BUFFER_BIT);
      }
    };
  }

  window.LumiAvatarMatte = { create: create };
}());
