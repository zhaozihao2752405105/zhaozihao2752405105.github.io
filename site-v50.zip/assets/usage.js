/* ============================================================
 * assets/usage.js —— AI 用量与预算面板（第 3 步）
 * 只读三张表：budget_monthly（月度预算账本）、daily_ai_usage（每日汇总）、
 *             ai_usage_reservations（请求级明细，含预留/结算状态）
 * RLS 已限定「只能读自己的行」，这里仍显式带 user_id，多一层保险。
 * ============================================================ */
(function () {
  var KIND_LABEL = {
    word: '单词', grammar: '语法', listening: '听力', reading: '阅读',
    speaking: '口语', material: '素材', chat_text: '对话文本',
    chat_asr: '语音识别', chat_tts: '语音合成', test: '周测'
  };
  var STATUS_LABEL = { reserved: '预留中', settled: '已结算', released: '已释放', uncertain: '结果未知' };

  var user = null;
  var view, toastTimer = null;

  function $(id) { return document.getElementById(id); }
  function esc(s) {
    return String(s == null ? '' : s).replace(/[&<>"']/g, function (c) {
      return { '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c];
    });
  }
  function money(n) {
    var v = Number(n || 0);
    if (!v) return '0';
    return v < 1 ? v.toFixed(4) : v.toFixed(2);
  }
  function int(n) { return Number(n || 0).toLocaleString('en-US'); }
  function pad(n) { return n < 10 ? '0' + n : '' + n; }
  function ymd(d) { return d.getFullYear() + '-' + pad(d.getMonth() + 1) + '-' + pad(d.getDate()); }
  function monthKey(d) { return d.getFullYear() + '-' + pad(d.getMonth() + 1); }
  function shortTime(iso) {
    if (!iso) return '';
    var d = new Date(iso);
    if (isNaN(d.getTime())) return '';
    return pad(d.getMonth() + 1) + '-' + pad(d.getDate()) + ' ' + pad(d.getHours()) + ':' + pad(d.getMinutes());
  }
  function toast(msg) {
    var el = $('toast');
    if (!el) return;
    el.textContent = msg;
    el.classList.add('on');
    clearTimeout(toastTimer);
    toastTimer = setTimeout(function () { el.classList.remove('on'); }, 2600);
  }

  function meter(pct, tone) {
    var p = Math.max(0, Math.min(100, Math.round(pct)));
    return '<div class="meter' + (tone ? ' ' + tone : '') + '"><span style="width:' + p + '%"></span></div>';
  }

  function topBack() {
    return '<div class="rowline"><button class="btn ghost" data-act="reload">↻ 刷新</button>' +
      '<a class="btn ghost" href="today.html">去学习</a></div>';
  }

  function budgetCard(b) {
    if (!b) {
      return '<section class="card"><h2>本月 AI 预算</h2><p class="muted">还没有消耗记录。开始学习后这里会显示本月已用金额。</p></section>';
    }
    var limit = Number(b.limit_cny || 0);
    var spent = Number(b.spent_cny || 0);
    var reserved = Number(b.reserved_cny || 0);
    var used = spent + reserved;
    var pct = limit > 0 ? (used / limit) * 100 : 0;
    var tone = pct >= 100 ? 'danger' : (pct >= 80 ? 'warn' : '');
    var left = Math.max(0, limit - used);
    var note = '';
    if (limit > 0 && used >= limit) note = '<p class="warn-text">已达本月上限，AI 内容暂停，下月 1 日自动恢复；单词/语法/听力/阅读的内置内容照常可用。</p>';
    else if (pct >= 80) note = '<p class="warn-text">已用超过 80%，系统会自动压缩 AI 用量（减少生成、多用内置内容）。</p>';
    return '<section class="card">' +
      '<h2>本月 AI 预算 <span class="muted small">' + esc(b.month_key || '') + '</span></h2>' +
      '<p class="big">' + money(used) + ' <span class="muted small">/ ' + money(limit) + ' 元</span></p>' +
      meter(pct, tone) +
      '<p class="muted small">已结算 ' + money(spent) + ' 元' + (reserved > 0 ? ' · 进行中预留 ' + money(reserved) + ' 元' : '') + ' · 剩余 ' + money(left) + ' 元</p>' +
      note + '</section>';
  }

  function todayCard(rows, todayStr, requests) {
    var row = null;
    for (var i = 0; i < rows.length; i++) if (rows[i].usage_date === todayStr) row = rows[i];
    var callCount = 0;
    (requests || []).forEach(function (r) { if (r.usage_date === todayStr) callCount++; });
    var cost = row ? Number(row.total_cost_cny || 0) : 0;
    var tin = row ? Number(row.model_input_tokens || 0) : 0;
    var tout = row ? Number(row.model_output_tokens || 0) : 0;
    return '<section class="card">' +
      '<h2>今天 <span class="muted small">' + esc(todayStr) + '</span></h2>' +
      '<p class="big">' + money(cost) + ' <span class="muted small">元</span></p>' +
      '<div class="kv">' +
      '<div><span>AI 请求</span><b>' + int(callCount) + ' 次</b></div>' +
      '<div><span>输入 Tokens</span><b>' + int(tin) + '</b></div>' +
      '<div><span>输出 Tokens</span><b>' + int(tout) + '</b></div>' +
      '</div></section>';
  }

  function daysTable(rows) {
    if (!rows.length) return '<section class="card"><h2>近 30 天</h2><p class="muted">暂无记录。</p></section>';
    var total = 0;
    var body = rows.map(function (r) {
      var c = Number(r.total_cost_cny || 0);
      total += c;
      return '<tr><td>' + esc(r.usage_date) + '</td><td class="num">' + money(c) + '</td><td class="num">' +
        int(r.model_input_tokens) + '</td><td class="num">' + int(r.model_output_tokens) + '</td></tr>';
    }).join('');
    return '<section class="card"><h2>近 30 天 <span class="muted small">合计 ' + money(total) + ' 元</span></h2>' +
      '<div class="table-wrap usage-days-table"><table><thead><tr><th>日期</th><th class="num">费用(元)</th><th class="num">输入</th><th class="num">输出</th></tr></thead><tbody>' +
      body + '</tbody></table></div></section>';
  }

  function reqTable(rows) {
    if (!rows.length) return '<section class="card"><h2>最近请求</h2><p class="muted">还没有 AI 请求记录。</p></section>';
    var body = rows.map(function (r) {
      var st = STATUS_LABEL[r.status] || r.status || '';
      var cost = r.actual_cost == null ? '—' : money(r.actual_cost);
      return '<tr><td data-label="时间">' + esc(shortTime(r.created_at)) + '</td><td data-label="类型">' + esc(KIND_LABEL[r.kind] || r.kind) +
        '</td><td data-label="状态">' + esc(st) + '</td><td data-label="实付" class="num">' + cost + '</td><td data-label="预估" class="num muted">' + money(r.estimated_cost) + '</td></tr>';
    }).join('');
    return '<details class="card v2-fold"><summary><h3>最近请求</h3><span class="muted small">' + rows.length + ' / 最多 20 条</span></summary><div class="v2-fold-body">' +
      '<div class="table-wrap usage-req-table"><table><thead><tr><th>时间</th><th>类型</th><th>状态</th><th class="num">实付</th><th class="num">预估</th></tr></thead><tbody>' +
      body + '</tbody></table></div></div></details>';
  }

  function explainCard() {
    return '<section class="card muted small"><h2>说明</h2>' +
      '<p>1. 金额来自 AI 服务商实际返回的用量，保留 6 位小数；「实付」为空表示该请求还没结算（预留中或结果未知）。</p>' +
      '<p>2. 请求先「预留」再「结算」：预留金额会在预算里占位，所以「已用」= 已结算 + 进行中预留。</p>' +
      '<p>3. 网络失败会自动重试，同一请求重试不重复计费。</p>' +
      '<p>4. 每月上限 30 元，达到后 AI 内容暂停，但内置内容与学习记录照常，下月 1 日自动恢复。</p></section>';
  }

  async function load() {
    view.innerHTML = '<div class="card center"><p class="muted">正在读取用量…</p></div>';
    var now = new Date();
    var todayStr = ymd(now);
    var mk = monthKey(now);
    var uid = user.id;
    var budget = null, days = [], reqs = [];
    try {
      var res = await Promise.all([
        window.DB.select('budget_monthly', { user_id: uid, month_key: mk, limit: 1 }).catch(function () { return []; }),
        window.DB.select('daily_ai_usage', { user_id: uid, order: 'usage_date.desc', limit: 30 }).catch(function () { return []; }),
        window.DB.select('ai_usage_reservations', { user_id: uid, order: 'created_at.desc', limit: 20 }).catch(function () { return []; })
      ]);
      budget = (res[0] && res[0][0]) || null;
      days = res[1] || [];
      reqs = res[2] || [];
    } catch (e) {
      view.innerHTML = '<section class="card"><h2>读取失败</h2><p class="muted">' + esc(e && e.message || '未知错误') + '</p>' + topBack() + '</section>';
      return;
    }
    var html = '';
    html += '<div class="v2-pagehead"><p class="v2-eyebrow">AI usage</p><h1 class="v2-h1">AI 用量</h1><p>本月预算、每天消耗和最近请求，每一笔都能对上。</p></div>';
    html += topBack();
    html += budgetCard(budget);
    html += todayCard(days, todayStr, reqs);
    html += daysTable(days);
    html += reqTable(reqs);
    html += explainCard();
    view.innerHTML = html;
  }

  function bind() {
    view.addEventListener('click', function (ev) {
      var btn = ev.target.closest('[data-act]');
      if (!btn) return;
      var act = btn.getAttribute('data-act');
      if (act === 'reload') load();
    });
  }

  async function boot() {
    view = $('view');
    user = await window.AppAuth.requireLogin();
    if (!user) return;
    $('userName').textContent = window.AppAuth.displayName(user) + ' · 已登录';
    $('btnLogout').addEventListener('click', function () { window.AppAuth.logout(); });
    bind();
    await load();
  }

  document.addEventListener('DOMContentLoaded', function () {
    boot().catch(function (e) {
      var v = $('view');
      if (v) v.innerHTML = '<section class="card"><h2>出错了</h2><p class="muted">' + esc(e && e.message || e) + '</p></section>';
    });
  });
})();
