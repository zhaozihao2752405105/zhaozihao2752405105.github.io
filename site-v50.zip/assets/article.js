/* ============================================================
 * article.js — 读文章：逐句跟写 / 听写 / 点词查义 / 生词收藏
 * 语料来自 public.articles（Simple English Wikipedia，CC BY-SA 4.0），
 * 句子为原文原句，未做 AI 改写；点词查义只查本地词库，不耗 AI。
 * 阅读不动复习安排：只有「收进阅读生词」会写个人词书。
 * ============================================================ */
(function () {
  'use strict';

  var S = {
    list: [],
    level: 0,
    slug: '',
    art: null,
    prog: {},
    open: -1,
    panel: '',        // follow | dictate
    typed: '',
    hint: false,
    fb: null,         // {ok, acc, target}
    busy: false,
    bookId: '',
    popWord: '',
    cat: '',          // '' | daily | story | science | mine
    tri: {},          // { '<sentence>': {zh} | {structure_zh, chunks, tip_zh} }
    mine: [],
    importing: false,
    run: null          // 整篇听写：{idx, ok:[], typed, fb, done}
  };

  var LS_PROG = 'lumi.article.v1';
  var LS_BOOK = 'lumi.readbook.v1';
  var LS_AI = 'lumi.articlex.v1';
  var LS_TRI = 'lumi.art.tri.v1';
  var LS_OFF = 'lumi.art.offline.v1';
  var CAT_ZH = { daily: '日常', story: '故事', science: '科普', news: '新闻', mine: '我的' };
  var LEVEL_ZH = { 1: 'L1 入门', 2: 'L2 基础', 3: 'L3 进阶', 4: 'L4 挑战', 5: 'L5 高阶', 6: 'L6 高阶', 7: 'L7 高阶', 8: 'L8 高阶', 9: 'L9 高阶' };

  function el(id) { return document.getElementById(id); }
  function esc(s) {
    return String(s == null ? '' : s).replace(/[&<>"']/g, function (c) {
      return ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' })[c];
    });
  }
  function loadProg() {
    try { return JSON.parse(localStorage.getItem(LS_PROG) || '{}') || {}; } catch (e) { return {}; }
  }
  function saveProg() {
    try { localStorage.setItem(LS_PROG, JSON.stringify(S.prog)); } catch (e) { /* 忽略 */ }
  }
  function doneOf(slug) {
    var p = S.prog[slug];
    return (p && Array.isArray(p.done)) ? p.done : [];
  }
  function markDone(slug, i) {
    var p = S.prog[slug] || { done: [] };
    if (p.done.indexOf(i) < 0) p.done.push(i);
    S.prog[slug] = p;
    saveProg();
  }
  var readTimer = null;
  function logRead(force) {
    if (!S.art || !window.DB || !window.DB.rpc) return;
    clearTimeout(readTimer);
    var send = function () {
      var done = doneOf(S.art.slug).length;
      var total = S.art.sentences.length;
      try {
        window.DB.rpc('log_article_read', {
          p_slug: S.art.slug, p_level: S.art.level || 3, p_done: done, p_total: total
        });
      } catch (e) { /* 忽略：记录失败不影响阅读 */ }
    };
    if (force) send(); else readTimer = setTimeout(send, 1500);
  }

  function say(text, rate) {
    if (!window.Speech || !window.Speech.say) return;
    try { window.Speech.say(text, { lang: 'en-US', rate: rate || 0.92, force: true }); } catch (e) { /* 忽略 */ }
  }

  /* ---------- 列表 ---------- */
  function cardsHtml() {
    var rows = S.list.filter(function (a) {
      if (S.level && a.level !== S.level) return false;
      if (S.cat === 'mine') return a.category === 'mine';
      if (S.cat) return a.category === S.cat;
      return true;
    });
    if (!rows.length) return '<p class="muted mt8">这个分类下还没有文章。</p>';
    var h = '';
    rows.forEach(function (a) {
      var done = doneOf(a.slug).length;
      var pct = Math.round(done / Math.max(1, a.sentences) * 100);
      var lvTxt = a.category === 'mine' ? '我的文本' : (LEVEL_ZH[a.level] || ('L' + a.level));
      h += '<button type="button" class="art-card" data-act="open" data-slug="' + esc(a.slug) + '">' +
        '<div class="art-card-top"><b>' + esc(a.title) + '</b><span class="art-lv">' + esc(lvTxt) + '</span></div>' +
        '<div class="art-card-meta">' + (a.words || a.word_count || 0) + ' 词 · ' + a.sentences + ' 句 · 已完成 ' + done + '/' + a.sentences + '</div>' +
        '<div class="art-bar"><i style="width:' + pct + '%"></i></div>' +
        '</button>';
    });
    return h;
  }

  function importHtml() {
    if (!S.importing) {
      return '<div class="art-imp"><button type="button" class="btn ghost sm" data-act="importToggle">导入我自己的英文文本</button></div>';
    }
    return '<div class="art-imp is-open">' +
      '<div class="art-imp-head"><b>导入我自己的英文文本</b><span class="small muted">粘贴纯文本即可，按句号/问号/感叹号切句；只存在你自己的账号里。</span></div>' +
      '<input id="artImpTitle" class="art-imp-title" type="text" maxlength="80" placeholder="标题（可留空）">' +
      '<textarea id="artImpText" class="art-imp-text" rows="6" placeholder="Paste your English text here…"></textarea>' +
      '<div class="art-imp-acts">' +
      '<button type="button" class="btn sm" data-act="importSave">保存并开始读</button>' +
      '<button type="button" class="btn ghost sm" data-act="importToggle">取消</button>' +
      '</div></div>';
  }

  function renderList() {
    var seen = {};
    S.list.forEach(function (a) { if (a.level >= 1) seen[a.level] = 1; });
    var lv = [0].concat(Object.keys(seen).map(Number).sort(function (a, b) { return a - b; }));
    var h = '<section class="v2-welcome"><div class="v2-welcome-date">读文章</div><h1>读一篇，写一遍。</h1><p>逐句跟写和听写，遇到生词点一下就能查，收进「阅读生词」再练。</p></section>';
    h += '<div class="card v2-levels"><div class="v2-levels-tip">语料：Simple English Wikipedia（CC BY-SA 4.0）。句子是原文原句，没有 AI 改写。</div>';
    h += '<div class="v2-seg art-seg">';
    lv.forEach(function (n) {
      var on = S.level === n ? ' aria-pressed="true"' : ' aria-pressed="false"';
      h += '<button type="button" class="v2-seg-btn" data-act="level" data-lv="' + n + '"' + on + '>' + (n ? ('L' + n) : '全部') + '</button>';
    });
    h += '</div>';
    h += '<div class="v2-seg art-cat-seg">';
    [['', '全部'], ['daily', '日常'], ['story', '故事'], ['science', '科普'], ['mine', '我的']].forEach(function (c) {
      var on2 = S.cat === c[0] ? ' aria-pressed="true"' : ' aria-pressed="false"';
      h += '<button type="button" class="v2-seg-btn" data-act="cat" data-cat="' + c[0] + '"' + on2 + '>' + c[1] + '</button>';
    });
    h += '</div></div>';
    var resume = null;
    S.list.forEach(function (a) {
      if (resume) return;
      var d = doneOf(a.slug).length;
      if (d > 0 && d < Number(a.sentences || 0)) resume = { a: a, d: d };
    });
    h += resume
      ? '<button type="button" class="art-resume" data-act="open" data-slug="' + esc(resume.a.slug) + '">' +
        '<span class="art-resume-k">上次读到</span><b>' + esc(resume.a.title) + '</b>' +
        '<span class="art-resume-meta">已读 ' + resume.d + '/' + resume.a.sentences + ' 句 · 继续 ›</span></button>'
      : '';
    h += '<section class="card">' + importHtml() + '<div class="art-list">' + cardsHtml() + '</div>' +
      '<div class="art-foot"><a class="v2-coach-link" href="practice.html?src=personal">去练「阅读生词」›</a></div></section>';
    el('view').innerHTML = h;
  }

  /* ---------- 阅读器 ---------- */
  function wordsHtml(sentence) {
    return String(sentence).replace(/[A-Za-z][A-Za-z'\-]*/g, function (w) {
      return '<button type="button" class="art-w" data-act="word" data-w="' + esc(w.toLowerCase()) + '">' + esc(w) + '</button>';
    });
  }

  function sameCh(a, b) {
    if (a === b) return true;
    return String(a).toLowerCase() === String(b).toLowerCase();
  }

  function previewHtml(target, typed) {
    var out = '';
    for (var i = 0; i < target.length; i++) {
      var cls = '';
      if (i < typed.length) cls = sameCh(target.charAt(i), typed.charAt(i)) ? 'ok' : 'bad';
      else if (i === typed.length) cls = 'cur';
      out += '<span class="aw' + (cls ? ' ' + cls : '') + '">' + (target.charAt(i) === ' ' ? '&nbsp;' : esc(target.charAt(i))) + '</span>';
    }
    return out;
  }

  function accuracy(target, typed) {
    if (!target) return 0;
    var n = 0;
    var len = Math.min(target.length, typed.length);
    for (var i = 0; i < len; i++) if (sameCh(target.charAt(i), typed.charAt(i))) n++;
    return n / target.length;
  }

  function panelHtml(i, sentence, mode) {
    var isDict = mode === 'dictate';
    var h = '<div class="art-panel" data-i="' + i + '">';
    if (S.fb) {
      h += '<div class="art-fb ' + (S.fb.ok ? 'ok' : 'bad') + '">' +
        (S.fb.ok ? '写对了，准确率 ' + Math.round(S.fb.acc * 100) + '%。' : '还差一点，准确率 ' + Math.round(S.fb.acc * 100) + '%。') +
        '</div>';
      h += '<div class="art-answer">' + esc(sentence) + '</div>';
      h += '<div class="art-panel-acts"><button type="button" class="btn sm" data-act="again">再写一次</button>' +
        '<button type="button" class="btn ghost sm" data-act="close">收起</button></div>';
    } else {
      if (isDict) h += '<div class="art-hintline">听发音，把整句写出来' + (S.hint ? '（已给首字母）' : '') + '</div>';
      else h += '<div class="art-hintline">照着句子敲一遍，敲错的字母会标红</div>';
      var ph = isDict ? '' : '照着敲…';
      h += '<input id="artInput" class="art-input" type="text" autocomplete="off" autocorrect="off" autocapitalize="none" spellcheck="false" placeholder="' + ph + '" value="' + esc(S.typed) + '">';
      h += '<div class="art-preview" id="artPreview">' + (isDict && !S.hint ? '<span class="muted small">（听写模式：提交后显示原文）</span>' : previewHtml(sentence, S.typed)) + '</div>';
      h += '<div class="art-panel-acts">' +
        '<button type="button" class="btn sm" data-act="submit">提交</button>' +
        '<button type="button" class="btn ghost sm" data-act="say">听一遍</button>' +
        '<button type="button" class="btn ghost sm" data-act="hint">提示</button>' +
        '<button type="button" class="btn ghost sm" data-act="close">收起</button>' +
        '</div>';
    }
    h += '</div>';
    return h;
  }

  function triCache() {
    try { return JSON.parse(localStorage.getItem(LS_TRI) || '{}') || {}; } catch (e) { return {}; }
  }

  function triSave(key, kind, data) {
    S.tri[key] = S.tri[key] || {};
    S.tri[key][kind] = data;
    var all = triCache();
    all[key] = S.tri[key];
    try { localStorage.setItem(LS_TRI, JSON.stringify(all)); } catch (e) { /* 忽略 */ }
  }

  function triHtml(i, sentence) {
    var c = (S.tri[sentence] || triCache()[sentence] || {});
    var h = '';
    if (c.zh) h += '<div class="art-tri-zh">' + esc(c.zh) + '</div>';
    if (c.structure_zh) {
      h += '<div class="art-tri-an"><b>' + esc(c.structure_zh) + '</b>';
      if (Array.isArray(c.chunks) && c.chunks.length) {
        h += '<div class="art-tri-chunks">' + c.chunks.map(function (k) {
          return '<span class="art-tri-ch"><i>' + esc(k.en) + '</i>' + esc(k.zh) + '</span>';
        }).join('') + '</div>';
      }
      if (c.tip_zh) h += '<div class="art-tri-tip">' + esc(c.tip_zh) + '</div>';
      h += '</div>';
    }
    if (c.busy) h += '<div class="art-tri-busy">正在处理…</div>';
    if (c.err) h += '<div class="art-tri-busy">' + esc(c.err) + '</div>';
    if (!h) return '';
    return '<div class="art-tri" data-tri="' + i + '">' + h + '</div>';
  }

  function rowsHtml() {
    var a = S.art;
    var h = '';
    a.sentences.forEach(function (s, i) {
      var done = doneOf(a.slug).indexOf(i) >= 0;
      var open = S.open === i;
      var blurred = open && S.panel === 'dictate' && !S.hint && !S.fb;
      h += '<div class="art-row' + (done ? ' is-done' : '') + (open ? ' is-open' : '') + '" data-i="' + i + '">' +
        '<div class="art-en' + (blurred ? ' is-blur' : '') + '">' + wordsHtml(s) + '</div>' +
        '<div class="art-tools">' +
        '<span class="art-no">' + (i + 1) + '</span>' +
        '<button type="button" class="art-tool" data-act="sayline" data-i="' + i + '">听</button>' +
        '<button type="button" class="art-tool" data-act="follow" data-i="' + i + '">跟写</button>' +
        '<button type="button" class="art-tool" data-act="dictate" data-i="' + i + '">听写</button>' +
        '<button type="button" class="art-tool" data-act="tri" data-i="' + i + '">译</button>' +
        '<button type="button" class="art-tool" data-act="ana" data-i="' + i + '">析</button>' +
        (done ? '<span class="art-done">已写</span>' : '') +
        '</div>' +
        triHtml(i, s) +
        (open ? panelHtml(i, s, S.panel) : '') +
        '</div>';
    });
    return h;
  }

  function aiCache() {
    try { return JSON.parse(localStorage.getItem(LS_AI) || '{}') || {}; } catch (e) { return {}; }
  }

  function aiSave(slug, data) {
    var all = aiCache();
    all[slug] = { at: Date.now(), data: data };
    try { localStorage.setItem(LS_AI, JSON.stringify(all)); } catch (e) { /* 忽略 */ }
  }

  function aiHtml(d) {
    var h = '';
    if (d.summary_zh) h += '<p class="art-ai-sum">' + esc(d.summary_zh) + '</p>';
    if (Array.isArray(d.key_points) && d.key_points.length) {
      h += '<ul class="art-ai-points">' + d.key_points.map(function (x) { return '<li>' + esc(x) + '</li>'; }).join('') + '</ul>';
    }
    if (Array.isArray(d.expressions) && d.expressions.length) {
      h += '<div class="art-ai-expr">' + d.expressions.map(function (e) {
        return '<span class="art-ai-ph"><b>' + esc(e.en) + '</b> ' + esc(e.zh) + '</span>';
      }).join('') + '</div>';
    }
    if (Array.isArray(d.grammar) && d.grammar.length) {
      h += '<div class="art-ai-gr">' + d.grammar.map(function (g) {
        return '<div class="art-ai-gr-row"><code>' + esc(g.fragment) + '</code><span>' + esc(g.note_zh) + '</span></div>';
      }).join('') + '</div>';
    }
    if (d.discuss) {
      h += '<div class="art-ai-talk"><b>口语练习：</b>' + esc(d.discuss) +
        ' <a class="art-ai-go" href="a4-voice.html">去实时对话里聊聊 ›</a></div>';
    }
    return h || '<p class="small muted">这次没拿到讲解，可以再点一次。</p>';
  }

  async function explain() {
    var a = S.art;
    if (!a) return;
    var box = el('artAiBox');
    var btn = document.querySelector('[data-act="explain"]');
    var cache = aiCache()[a.slug];
    if (cache && cache.data) { if (box) box.innerHTML = aiHtml(cache.data); return; }
    if (btn) { btn.disabled = true; btn.textContent = '正在读这篇…'; }
    var r = null;
    try {
      r = await window.AI.invoke('article', {
        title: a.title,
        passage: (a.sentences || []).join(' '),
        level: a.level || 3
      }, {});
    } catch (e) { r = null; }
    if (btn) { btn.disabled = false; btn.textContent = '重新讲一次'; }
    var d = r && r.data ? r.data : (r && r.body && r.body.data ? r.body.data : null);
    if (!d || !d.summary_zh) {
      if (box) box.innerHTML = '<p class="small muted">' + esc((r && (r.message || (r.body && r.body.message))) || '讲解暂时不可用，稍后再试。') + '</p>';
      return;
    }
    aiSave(a.slug, d);
    if (box) box.innerHTML = aiHtml(d);
  }

  function renderArticle() {
    var a = S.art;
    var done = doneOf(a.slug).length;
    var pct = Math.round(done / Math.max(1, a.sentences.length) * 100);
    var focus = S.open;
    var h = '<section class="card art-head">' +
      '<button type="button" class="art-back" data-act="back">‹ 返回文章列表</button>' +
      '<h1 class="art-title">' + esc(a.title) + '</h1>' +
      '<div class="art-sub">' + esc(LEVEL_ZH[a.level] || ('L' + a.level)) + ' · ' + a.word_count + ' 词 · 已完成 ' + done + '/' + a.sentences.length + '</div>' +
      '<div class="art-bar"><i style="width:' + pct + '%"></i></div>' +
      '<div class="art-src">语料：<a href="' + esc(a.source_url || '#') + '" target="_blank" rel="noopener">' + esc(a.source) + '</a> · ' + esc(a.license) + '</div>' +
      '</section>';
    if (S.run) {
      el('view').innerHTML = h + runHtml();
      var ri = el('adInput');
      if (ri) { try { ri.focus(); } catch (e) { /* 忽略 */ } }
      return;
    }
    h += '<section class="card art-ai">' +
      '<div class="art-ai-head"><b>AI 讲解</b><span class="small muted">中文讲清这篇在说什么，再挑几个文中短语</span></div>' +
      '<button type="button" class="btn sm art-ai-btn" data-act="explain">让 Lumi 讲讲这篇</button>' +
      '<button type="button" class="btn ghost sm art-ai-btn" data-act="transall">全文翻译</button>' +
      '<button type="button" class="btn ghost sm art-ai-btn" data-act="rundict">整篇听写</button>' +
      '<button type="button" class="btn ghost sm art-ai-btn" data-act="runfollow">整篇跟写</button>' +
      '<div id="artAiBox" class="art-ai-box"></div>' +
      '</section>';
    if (S.allZh && S.allZh.slug === a.slug) {
      if (S.allZh.busy) h += '<section class="card art-allzh"><div class="small muted">正在翻译全文…</div></section>';
      else if (S.allZh.err) h += '<section class="card art-allzh"><div class="small muted">' + esc(S.allZh.err) + '</div></section>';
      else h += '<section class="card art-allzh"><div class="w-rewrite-k">全文翻译</div>' +
        S.allZh.zh.map(function (z, i) { return '<div class="art-zh-line"><span class="art-zh-n">' + (i + 1) + '</span>' + esc(z) + '</div>'; }).join('') + '</section>';
    }
    h += '<section class="card art-body">' + rowsHtml() + '</section>';
    h += '<p class="small muted art-tip">点单词查词义；「收进阅读生词」会建一本个人词书，只用于自由练习，不进正式复习安排。</p>';
    el('view').innerHTML = h;
    if (focus >= 0) {
      var inp = el('artInput');
      if (inp) { try { inp.focus(); } catch (e) { /* 忽略 */ } }
    }
  }

  /* ---------- 动作 ---------- */
  function runHtml() {
    var a = S.run, art = S.art, n = art.sentences.length, k = a.idx;
    var isFollow = a.mode === 'follow';
    var h = '<section class="card art-run">';
    h += '<div class="art-run-head"><b>' + (isFollow ? '整篇跟写' : '整篇听写') + '</b><span class="small muted">第 ' + Math.min(k + 1, n) + ' / ' + n + ' 句</span></div>';
    h += '<div class="art-bar"><i style="width:' + Math.round(Math.min(k, n) / n * 100) + '%"></i></div>';
    if (a.done) {
      var okN = a.ok.filter(Boolean).length;
      var pct = Math.round(okN / Math.max(1, a.ok.length) * 100);
      h += '<div class="art-run-sum"><b>共 ' + a.ok.length + ' 句，第一遍写对 ' + okN + ' 句</b>' +
        '<span class="small muted">准确率 ' + pct + '%</span></div>';
      h += '<div class="art-panel-acts"><button type="button" class="btn sm" data-act="rundict">再来一遍</button>' +
        '<button type="button" class="btn ghost sm" data-act="runend">收起</button></div>';
    } else if (a.fb) {
      h += '<div class="art-fb ' + (a.fb.ok ? 'ok' : 'bad') + '">' +
        (a.fb.ok ? '这句写对了。' : '还差一点，准确率 ' + Math.round(a.fb.acc * 100) + '%。') + '</div>';
      h += '<div class="art-answer">' + esc(a.fb.target) + '</div>';
      if (!a.fb.ok) h += '<div class="art-note small muted">你写的是「' + esc(a.fb.typed || '') + '」</div>';
      h += '<div class="art-panel-acts"><button type="button" class="btn sm" data-act="runnext">下一句</button>' +
        '<button type="button" class="btn ghost sm" data-act="runsay">再听一遍</button></div>';
    } else {
      if (isFollow) {
        h += '<div class="art-follow-target">' + esc(art.sentences[Math.min(k, n - 1)]) + '</div>';
        h += '<div class="art-hintline">照着上面的句子敲一遍，敲错的字母会标红</div>';
      } else {
        h += '<div class="art-hintline">听发音，把整句写出来（提交后才显示原文）</div>';
      }
      h += '<input id="adInput" class="art-input" type="text" autocomplete="off" autocorrect="off" autocapitalize="none" spellcheck="false" placeholder="' + (isFollow ? '照着敲…' : '听到什么写什么…') + '" value="' + esc(a.typed || '') + '">';
      if (isFollow) h += '<div class="art-preview" id="adPreview">' + previewHtml(art.sentences[Math.min(k, n - 1)], a.typed || '') + '</div>';
      h += '<div class="art-panel-acts"><button type="button" class="btn sm" data-act="runsubmit">提交</button>' +
        '<button type="button" class="btn ghost sm" data-act="runsay">再听一遍</button>' +
        '<button type="button" class="btn ghost sm" data-act="runskip">跳过</button>' +
        '<button type="button" class="btn ghost sm" data-act="runend">结束</button></div>';
    }
    h += '</section>';
    return h;
  }

  // 听力有效记录：整篇听写/整句听写完成后落库（不计 AI、不改单词 SM-2）。
  function logListen(a) {
    try {
      if (!a || a.logged) return;
      if (a.mode !== 'dictate' && a.mode !== 'follow') return;
      var sent = Array.isArray(a.sent) ? a.sent : [];
      if (!sent.length) return;
      a.logged = true;
      var items = sent.length;
      var correct = sent.filter(function (x) { return Number(x.acc) >= 0.92; }).length;
      var seconds = Math.max(0, Math.round((Date.now() - (a.at || Date.now())) / 1000));
      window.DB.rpc('log_listening_practice', {
        p_kind: a.mode === 'dictate' ? 'article_dictation' : 'article_follow',
        p_slug: (S.art && S.art.slug) || '',
        p_level: (S.art && Number(S.art.level)) || 3,
        p_items: items, p_correct: correct, p_seconds: seconds
      }).catch(function () { a.logged = false; });
    } catch (e) { if (a) a.logged = false; }
  }

  function runSubmit() {
    if (!S.run || !S.art) return;
    var a = S.run;
    var target = S.art.sentences[a.idx];
    if (!target) return;
    var acc = accuracy(target, a.typed || '');
    var ok = acc >= 0.92;
    a.ok.push(ok);
    a.sent.push({ i: a.idx, acc: acc });
    a.fb = { ok: ok, acc: acc, target: target, typed: a.typed || '' };
    if (ok) markDone(S.art.slug, a.idx);
    renderArticle();
  }

  function runNext() {
    var a = S.run;
    if (!a) return;
    a.idx += 1;
    a.typed = '';
    a.fb = null;
    if (a.idx >= S.art.sentences.length) { a.done = true; logRead(true); logListen(a); renderArticle(); return; }
    renderArticle();
    say(S.art.sentences[a.idx]);
  }

  function openPanel(i, mode) {
    if (!S.art) return;
    if (S.open === i && S.panel === mode) { S.open = -1; S.panel = ''; S.typed = ''; S.fb = null; renderArticle(); return; }
    S.open = i; S.panel = mode; S.typed = ''; S.fb = null; S.hint = false;
    renderArticle();
    var sentence = S.art.sentences[i];
    if (mode === 'dictate') say(sentence);
  }

  function closePanel() {
    S.open = -1; S.panel = ''; S.typed = ''; S.fb = null; S.hint = false;
    renderArticle();
  }

  function submit() {
    if (!S.art || S.open < 0) return;
    var sentence = S.art.sentences[S.open];
    var typed = S.typed;
    var acc = accuracy(sentence, typed);
    var ok = acc >= 0.92;
    S.fb = { ok: ok, acc: acc, target: sentence };
    if (ok) { markDone(S.art.slug, S.open); logRead(false); }
    renderArticle();
    if (!ok) {
      var inp = el('artInput');
      if (inp) inp.blur();
    }
  }

  async function lookup(word, anchor) {
    var pop = el('artPop');
    if (!pop) return;
    S.popWord = word;
    pop.hidden = false;
    pop.innerHTML = '<div class="art-pop-head"><b>' + esc(word) + '</b><span class="muted small">查词中…</span></div>';
    placePop(pop, anchor);
    var r = null;
    try { r = await window.DB.rpc('word_lookup', { p_word: word }); } catch (e) { r = null; }
    if (!pop.isConnected || S.popWord !== word) return;
    if (!r || r.ok === false) {
      pop.innerHTML = '<div class="art-pop-head"><b>' + esc(word) + '</b></div><div class="art-pop-body muted">词库暂时查不到。</div>';
      return;
    }
    var body = '';
    if (r.ipa) body += '<div class="art-pop-ipa">' + esc(r.ipa) + '</div>';
    body += '<div class="art-pop-mean">' + (r.meaning ? esc(r.meaning) : '<span class="muted">词库里没有这个词的释义</span>') + '</div>';
    if (r.phrases && r.phrases.length) {
      body += '<div class="art-pop-phr">' + r.phrases.slice(0, 4).map(function (p) {
        return '<div class="art-pop-phr-line"><b>' + esc(p.phrase) + '</b> ' + esc(p.meaning) + '</div>';
      }).join('') + '</div>';
    }
    var acts = '<button type="button" class="art-pop-btn" data-act="popsay">听发音</button>';
    if (r.word_id) acts += '<button type="button" class="art-pop-btn" data-act="popfav">收藏</button>';
    acts += '<button type="button" class="art-pop-btn" data-act="popbook">收进阅读生词</button>';
    pop.innerHTML = '<div class="art-pop-head"><b>' + esc(r.word || word) + '</b></div><div class="art-pop-body">' + body + '</div><div class="art-pop-acts">' + acts + '</div>';
    placePop(pop, anchor);
  }

  function placePop(pop, anchor) {
    var r = anchor && anchor.getBoundingClientRect ? anchor.getBoundingClientRect() : null;
    var top = r ? (window.scrollY + r.bottom + 8) : 120;
    var left = r ? Math.min(window.innerWidth - 280, Math.max(12, r.left - 40)) : 12;
    pop.style.top = Math.round(top) + 'px';
    pop.style.left = Math.round(left) + 'px';
  }

  function hidePop() {
    var pop = el('artPop');
    if (pop) { pop.hidden = true; pop.innerHTML = ''; }
    S.popWord = '';
  }

  function offCache() {
    try { return JSON.parse(localStorage.getItem(LS_OFF) || '{}') || {}; } catch (e) { return {}; }
  }

  function offSave(a) {
    var all = offCache();
    all[a.slug] = { at: Date.now(), art: a };
    var keys = Object.keys(all);
    if (keys.length > 12) {
      keys.sort(function (x, y) { return (all[x].at || 0) - (all[y].at || 0); });
      while (keys.length > 12) { delete all[keys.shift()]; }
    }
    try { localStorage.setItem(LS_OFF, JSON.stringify(all)); } catch (e) { /* 忽略 */ }
  }

  async function loadMine() {
    var mine = null;
    try { mine = await window.DB.rpc('list_personal_articles', {}); } catch (e) { mine = null; }
    S.mine = Array.isArray(mine) ? mine : [];
    if (!S.mine.length) return;
    S.mine.forEach(function (m) {
      var slug = 'mine:' + m.id;
      var exists = S.list.some(function (a) { return a.slug === slug; });
      if (exists) return;
      S.list.push({ slug: slug, title: m.title, level: 0, words: m.word_count, sentences: m.sentences, category: 'mine' });
    });
  }

  async function ensureBook() {
    if (S.bookId) return S.bookId;
    try { S.bookId = localStorage.getItem(LS_BOOK) || ''; } catch (e) { S.bookId = ''; }
    if (S.bookId) return S.bookId;
    var r = null;
    try { r = await window.DB.rpc('create_personal_wordbook', { p_title: '阅读生词' }); } catch (e) { r = null; }
    if (r && r.ok && r.id) {
      S.bookId = r.id;
      try { localStorage.setItem(LS_BOOK, r.id); } catch (e) { /* 忽略 */ }
    }
    return S.bookId;
  }

  async function translateAll() {
    var a = S.art;
    if (!a || !a.sentences || !a.sentences.length) return;
    if (S.allZh && S.allZh.slug === a.slug && !S.allZh.busy) { S.allZh = null; renderArticle(); return; }
    if (S.allZh && S.allZh.busy) return;
    S.allZh = { slug: a.slug, busy: true, zh: [], err: '' };
    renderArticle();
    var r = null;
    try { r = await window.AI.invoke('article', { mode: 'translate_all', sentences: a.sentences }, {}); } catch (e) { r = null; }
    var d = r && r.data ? r.data : (r && r.body && r.body.data ? r.body.data : null);
    if (!d || !Array.isArray(d.zh) || !d.zh.length) {
      S.allZh = { slug: a.slug, busy: false, zh: [], err: (r && (r.message || (r.body && r.body.message))) || '全文翻译暂时不可用，稍后再试。' };
      renderArticle(); return;
    }
    S.allZh = { slug: a.slug, busy: false, zh: d.zh, err: '' };
    var all = triCache();
    a.sentences.forEach(function (sen, i) { if (d.zh[i]) { all[sen] = all[sen] || {}; all[sen].zh = d.zh[i]; } });
    try { localStorage.setItem(LS_TRI, JSON.stringify(all)); } catch (e) { /* 忽略 */ }
    renderArticle();
  }

  async function explainSentence(i, mode) {
    var a = S.art;
    var sentence = a.sentences[i];
    var c = S.tri[sentence] || triCache()[sentence] || {};
    if (c.busy) return;
    if (mode === 'translate' && c.zh) {
      delete S.tri[sentence];
      var all0 = triCache(); if (all0[sentence]) { delete all0[sentence].zh; try { localStorage.setItem(LS_TRI, JSON.stringify(all0)); } catch (e) {} }
      renderArticle(); return;
    }
    if (mode === 'analyze' && c.structure_zh) { renderArticle(); return; }
    c.busy = true; c.err = '';
    S.tri[sentence] = c;
    renderArticle();
    var r = null;
    try {
      r = await window.AI.invoke('article', { mode: mode, sentence: sentence, level: a.level || 3 }, {});
    } catch (e) { r = null; }
    var d = r && r.data ? r.data : (r && r.body && r.body.data ? r.body.data : null);
    var c2 = S.tri[sentence] || {};
    c2.busy = false;
    if (!d || (mode === 'translate' && !d.zh) || (mode === 'analyze' && !d.structure_zh)) {
      c2.err = (r && (r.message || (r.body && r.body.message))) || '暂时不可用，稍后再试。';
      S.tri[sentence] = c2;
      renderArticle(); return;
    }
    triSave(sentence, mode === 'translate' ? 'zh' : 'an', d);
    S.tri[sentence] = Object.assign({}, S.tri[sentence], mode === 'translate' ? { zh: d.zh } : { structure_zh: d.structure_zh, chunks: d.chunks, tip_zh: d.tip_zh });
    delete S.tri[sentence].busy;
    delete S.tri[sentence].err;
    renderArticle();
  }

  /* ---------- 事件 ---------- */
  document.addEventListener('click', async function (ev) {
    var t = ev.target && ev.target.closest ? ev.target.closest('[data-act]') : null;
    var act = t && t.getAttribute('data-act');
    if (!act) {
      if (ev.target && ev.target.closest && !ev.target.closest('#artPop')) hidePop();
      return;
    }
    if (act === 'transall') { translateAll(); return; }
    if (act === 'explain') {
      ev.preventDefault();
      await explain();
      return;
    }
    if (act === 'level') {
      S.level = Number(t.getAttribute('data-lv')) || 0;
      renderList();
      return;
    }
    if (act === 'cat') {
      S.cat = t.getAttribute('data-cat') || '';
      renderList();
      return;
    }
    if (act === 'importToggle') {
      S.importing = !S.importing;
      renderList();
      if (S.importing) { var ta = el('artImpText'); if (ta) { try { ta.focus(); } catch (e) { /* 忽略 */ } } }
      return;
    }
    if (act === 'importSave') {
      var titleEl = el('artImpTitle');
      var textEl = el('artImpText');
      var txt = textEl ? textEl.value : '';
      if (!txt || txt.trim().length < 40) { alert('至少粘贴 40 个字符的英文文本。'); return; }
      t.disabled = true; t.textContent = '保存中…';
      var r3 = null;
      try {
        r3 = await window.DB.rpc('personal_article_save', { p_title: titleEl ? titleEl.value : '', p_text: txt });
      } catch (e) { r3 = null; }
      t.disabled = false; t.textContent = '保存并开始读';
      if (!r3 || !r3.ok) { alert('保存失败：' + ((r3 && r3.reason) || '请稍后再试')); return; }
      S.importing = false;
      await loadMine();
      var a2 = null;
      try { a2 = await window.DB.rpc('personal_article_get', { p_id: r3.id }); } catch (e) { a2 = null; }
      if (a2 && a2.ok !== false) { S.art = a2; S.slug = a2.slug; S.open = -1; S.panel = ''; S.typed = ''; S.fb = null; renderArticle(); }
      return;
    }
    if (act === 'tri' || act === 'ana') {
      var i3 = Number(t.getAttribute('data-i'));
      if (!S.art || !S.art.sentences[i3]) return;
      await explainSentence(i3, act === 'ana' ? 'analyze' : 'translate');
      return;
    }
    if (act === 'open') {
      ev.preventDefault();
      var slug = t.getAttribute('data-slug');
      var a = null;
      if (slug.indexOf('mine:') === 0) {
        try { a = await window.DB.rpc('personal_article_get', { p_id: slug.slice(5) }); } catch (e) { a = null; }
      } else {
        try { a = await window.DB.rpc('article_get', { p_slug: slug }); } catch (e) { a = null; }
      }
      if ((!a || a.ok === false) && offCache()[slug]) a = offCache()[slug].art;
      if (!a || a.ok === false) { alert('这篇文章暂时打不开，且本地没有缓存。'); return; }
      S.art = a; S.slug = slug; S.open = -1; S.panel = ''; S.typed = ''; S.fb = null;
      offSave(a);
      renderArticle();
      return;
    }
    if (act === 'back') {
      S.art = null; S.slug = ''; S.open = -1;
      renderList();
      return;
    }
    if (act === 'sayline') {
      var i0 = Number(t.getAttribute('data-i'));
      if (S.art && S.art.sentences[i0]) say(S.art.sentences[i0]);
      return;
    }
    if (act === 'rundict') {
      if (!S.art) return;
      S.run = { idx: 0, ok: [], sent: [], typed: '', fb: null, done: false, mode: 'dictate', at: Date.now() };
      renderArticle();
      say(S.art.sentences[0]);
      return;
    }
    if (act === 'runfollow') {
      if (!S.art) return;
      S.run = { idx: 0, ok: [], sent: [], typed: '', fb: null, done: false, mode: 'follow', at: Date.now() };
      renderArticle();
      return;
    }
    if (act === 'runsubmit') { runSubmit(); return; }
    if (act === 'runnext') { runNext(); return; }
    if (act === 'runsay') {
      if (S.run && S.art) say(S.art.sentences[Math.min(S.run.idx, S.art.sentences.length - 1)]);
      return;
    }
    if (act === 'runskip') {
      if (!S.run) return;
      S.run.ok.push(false);
      S.run.sent.push({ i: S.run.idx, acc: 0 });
      runNext();
      return;
    }
    if (act === 'runend') { if (S.run) logListen(S.run); S.run = null; logRead(true); renderArticle(); return; }
    if (act === 'follow' || act === 'dictate') {
      openPanel(Number(t.getAttribute('data-i')), act);
      return;
    }
    if (act === 'close') { closePanel(); return; }
    if (act === 'again') {
      S.fb = null; S.typed = ''; S.hint = false;
      renderArticle();
      var in2 = el('artInput');
      if (in2) { try { in2.focus(); } catch (e) { /* 忽略 */ } }
      return;
    }
    if (act === 'hint') {
      S.hint = true;
      if (!S.typed && S.art && S.open >= 0) {
        var s = S.art.sentences[S.open];
        S.typed = s.charAt(0);
      }
      renderArticle();
      var inp3 = el('artInput');
      if (inp3) { try { inp3.focus(); } catch (e) { /* 忽略 */ } }
      return;
    }
    if (act === 'submit') { submit(); return; }
    if (act === 'say') {
      if (S.art && S.open >= 0) say(S.art.sentences[S.open]);
      return;
    }
    if (act === 'word') {
      ev.preventDefault();
      await lookup(t.getAttribute('data-w'), t);
      return;
    }
    if (act === 'popsay') { say(S.popWord); return; }
    if (act === 'popfav') {
      t.disabled = true;
      var lk = null;
      try { lk = await window.DB.rpc('word_lookup', { p_word: S.popWord }); } catch (e) { lk = null; }
      if (!lk || !lk.word_id) { t.disabled = false; t.textContent = '词库没有这个词'; return; }
      var res = null;
      try { res = await window.DB.rpc('toggle_word_favorite', { p_word_id: lk.word_id }); } catch (e) { res = null; }
      t.disabled = false;
      t.textContent = res && res.ok ? (res.favorited ? '已收藏' : '已取消') : '收藏失败';
      return;
    }
    if (act === 'popbook') {
      t.disabled = true;
      t.textContent = '收集中…';
      var id = await ensureBook();
      var r2 = null;
      if (id) {
        try { r2 = await window.DB.rpc('add_personal_book_words', { p_book_id: id, p_words: [S.popWord] }); } catch (e) { r2 = null; }
      }
      t.disabled = false;
      if (r2 && r2.ok) t.textContent = r2.added ? '已收进阅读生词' : '词库没有这个词';
      else t.textContent = '暂时收不了';
      return;
    }
  });

  document.addEventListener('input', function (ev) {
    if (!ev.target) return;
    if (ev.target.id === 'adInput') {
      if (S.run) {
        S.run.typed = ev.target.value || '';
        if (S.run.mode === 'follow' && S.art) {
          var pv2 = el('adPreview');
          if (pv2) pv2.innerHTML = previewHtml(S.art.sentences[Math.min(S.run.idx, S.art.sentences.length - 1)], S.run.typed);
        }
      }
      return;
    }
    if (ev.target.id !== 'artInput') return;
    S.typed = ev.target.value || '';
    if (S.panel !== 'follow') return;
    var pv = el('artPreview');
    if (pv && S.art && S.open >= 0) pv.innerHTML = previewHtml(S.art.sentences[S.open], S.typed);
  });

  document.addEventListener('keydown', function (ev) {
    if (ev.key !== 'Enter') return;
    if (!ev.target) return;
    if (ev.target.id === 'adInput') { ev.preventDefault(); runSubmit(); return; }
    if (ev.target.id !== 'artInput') return;
    ev.preventDefault();
    submit();
  });

  window.addEventListener('scroll', function () { hidePop(); }, { passive: true });
  window.addEventListener('pagehide', function () { logRead(true); });

  /* ---------- 启动 ---------- */
  (async function boot() {
    el('view').innerHTML = '<div class="card"><p class="muted">正在准备…</p></div>';
    var user = null;
    try { user = await window.AppAuth.requireLogin(); } catch (e) { user = null; }
    if (!user) return;
    var name = '';
    try { name = window.AppAuth.displayName(user) || ''; } catch (e) { name = ''; }
    var u = el('userName');
    if (u) u.textContent = (name ? name + ' · ' : '') + '已登录';
    S.prog = loadProg();
    try { S.bookId = localStorage.getItem(LS_BOOK) || ''; } catch (e) { S.bookId = ''; }
    try { S.tri = triCache(); } catch (e) { S.tri = {}; }
    var list = null;
    try { list = await window.DB.rpc('list_articles', {}); } catch (e) { list = null; }
    if (!Array.isArray(list)) {
      var off = offCache();
      list = Object.keys(off).map(function (k) { return off[k].art; }).filter(function (a) {
        return a && a.sentences && a.sentences.length;
      }).map(function (a) {
        return { slug: a.slug, title: a.title, level: a.level || 3, words: a.word_count || 0, sentences: a.sentences.length, category: a.category || 'science' };
      });
      if (!list.length) {
        el('view').innerHTML = '<div class="card"><p class="muted">文章库暂时连不上，本地也还没有缓存。联网后再试一次。</p></div>';
        return;
      }
      S.list = list;
      await loadMine();
      renderList();
      return;
    }
    if (!list.length) {
      el('view').innerHTML = '<div class="card"><p class="muted">文章库还没准备好，稍后再来。</p></div>';
      return;
    }
    S.list = list;
    await loadMine();
    renderList();
  })();
})();