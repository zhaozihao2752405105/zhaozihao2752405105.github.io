/* ============================================================
 * article.js — 读文章：逐句跟写 / 听写 / 点词查义 / 生词收藏
 * 语料来自 public.articles（Simple English Wikipedia，CC BY-SA 4.0），
 * 句子为原文原句，未做 AI 改写；点词查义只查本地词库，不耗 AI。
 * 阅读不动复习安排：只有「收进阅读生词」会写个人词书。
 * ============================================================ */
(function () {
  'use strict';

  var S = {
    list: [],
    level: 0,
    slug: '',
    art: null,
    prog: {},
    open: -1,
    panel: '',        // follow | dictate
    typed: '',
    hint: false,
    fb: null,         // {ok, acc, target}
    busy: false,
    bookId: '',
    popWord: ''
  };

  var LS_PROG = 'lumi.article.v1';
  var LS_BOOK = 'lumi.readbook.v1';
  var LEVEL_ZH = { 1: 'L1 入门', 2: 'L2 基础', 3: 'L3 进阶', 4: 'L4 挑战', 5: 'L5 高阶', 6: 'L6 高阶', 7: 'L7 高阶', 8: 'L8 高阶', 9: 'L9 高阶' };

  function el(id) { return document.getElementById(id); }
  function esc(s) {
    return String(s == null ? '' : s).replace(/[&<>"']/g, function (c) {
      return ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' })[c];
    });
  }
  function loadProg() {
    try { return JSON.parse(localStorage.getItem(LS_PROG) || '{}') || {}; } catch (e) { return {}; }
  }
  function saveProg() {
    try { localStorage.setItem(LS_PROG, JSON.stringify(S.prog)); } catch (e) { /* 忽略 */ }
  }
  function doneOf(slug) {
    var p = S.prog[slug];
    return (p && Array.isArray(p.done)) ? p.done : [];
  }
  function markDone(slug, i) {
    var p = S.prog[slug] || { done: [] };
    if (p.done.indexOf(i) < 0) p.done.push(i);
    S.prog[slug] = p;
    saveProg();
  }
  function say(text, rate) {
    if (!window.Speech || !window.Speech.say) return;
    try { window.Speech.say(text, { lang: 'en-US', rate: rate || 0.92, force: true }); } catch (e) { /* 忽略 */ }
  }

  /* ---------- 列表 ---------- */
  function cardsHtml() {
    var rows = S.list.filter(function (a) { return !S.level || a.level === S.level; });
    if (!rows.length) return '<p class="muted mt8">这个难度还没有文章。</p>';
    var h = '';
    rows.forEach(function (a) {
      var done = doneOf(a.slug).length;
      var pct = Math.round(done / Math.max(1, a.sentences) * 100);
      h += '<button type="button" class="art-card" data-act="open" data-slug="' + esc(a.slug) + '">' +
        '<div class="art-card-top"><b>' + esc(a.title) + '</b><span class="art-lv">' + esc(LEVEL_ZH[a.level] || ('L' + a.level)) + '</span></div>' +
        '<div class="art-card-meta">' + a.words + ' 词 · ' + a.sentences + ' 句 · 已完成 ' + done + '/' + a.sentences + '</div>' +
        '<div class="art-bar"><i style="width:' + pct + '%"></i></div>' +
        '</button>';
    });
    return h;
  }

  function renderList() {
    var lv = [0, 1, 2, 3, 4];
    var h = '<section class="v2-welcome"><div class="v2-welcome-date">读文章</div><h1>读一篇，写一遍。</h1><p>逐句跟写和听写，遇到生词点一下就能查，收进「阅读生词」再练。</p></section>';
    h += '<div class="card v2-levels"><div class="v2-levels-tip">语料：Simple English Wikipedia（CC BY-SA 4.0）。句子是原文原句，没有 AI 改写。</div>';
    h += '<div class="v2-seg art-seg">';
    lv.forEach(function (n) {
      var on = S.level === n ? ' aria-pressed="true"' : ' aria-pressed="false"';
      h += '<button type="button" class="v2-seg-btn" data-act="level" data-lv="' + n + '"' + on + '>' + (n ? ('L' + n) : '全部') + '</button>';
    });
    h += '</div></div>';
    h += '<section class="card"><div class="art-list">' + cardsHtml() + '</div>' +
      '<div class="art-foot"><a class="v2-coach-link" href="practice.html?src=personal">去练「阅读生词」›</a></div></section>';
    el('view').innerHTML = h;
  }

  /* ---------- 阅读器 ---------- */
  function wordsHtml(sentence) {
    return String(sentence).replace(/[A-Za-z][A-Za-z'\-]*/g, function (w) {
      return '<button type="button" class="art-w" data-act="word" data-w="' + esc(w.toLowerCase()) + '">' + esc(w) + '</button>';
    });
  }

  function sameCh(a, b) {
    if (a === b) return true;
    return String(a).toLowerCase() === String(b).toLowerCase();
  }

  function previewHtml(target, typed) {
    var out = '';
    for (var i = 0; i < target.length; i++) {
      var cls = '';
      if (i < typed.length) cls = sameCh(target.charAt(i), typed.charAt(i)) ? 'ok' : 'bad';
      else if (i === typed.length) cls = 'cur';
      out += '<span class="aw' + (cls ? ' ' + cls : '') + '">' + (target.charAt(i) === ' ' ? '&nbsp;' : esc(target.charAt(i))) + '</span>';
    }
    return out;
  }

  function accuracy(target, typed) {
    if (!target) return 0;
    var n = 0;
    var len = Math.min(target.length, typed.length);
    for (var i = 0; i < len; i++) if (sameCh(target.charAt(i), typed.charAt(i))) n++;
    return n / target.length;
  }

  function panelHtml(i, sentence, mode) {
    var isDict = mode === 'dictate';
    var h = '<div class="art-panel" data-i="' + i + '">';
    if (S.fb) {
      h += '<div class="art-fb ' + (S.fb.ok ? 'ok' : 'bad') + '">' +
        (S.fb.ok ? '写对了，准确率 ' + Math.round(S.fb.acc * 100) + '%。' : '还差一点，准确率 ' + Math.round(S.fb.acc * 100) + '%。') +
        '</div>';
      h += '<div class="art-answer">' + esc(sentence) + '</div>';
      h += '<div class="art-panel-acts"><button type="button" class="btn sm" data-act="again">再写一次</button>' +
        '<button type="button" class="btn ghost sm" data-act="close">收起</button></div>';
    } else {
      if (isDict) h += '<div class="art-hintline">听发音，把整句写出来' + (S.hint ? '（已给首字母）' : '') + '</div>';
      else h += '<div class="art-hintline">照着句子敲一遍，敲错的字母会标红</div>';
      var ph = isDict ? '' : '照着敲…';
      h += '<input id="artInput" class="art-input" type="text" autocomplete="off" autocorrect="off" autocapitalize="none" spellcheck="false" placeholder="' + ph + '" value="' + esc(S.typed) + '">';
      h += '<div class="art-preview" id="artPreview">' + (isDict && !S.hint ? '<span class="muted small">（听写模式：提交后显示原文）</span>' : previewHtml(sentence, S.typed)) + '</div>';
      h += '<div class="art-panel-acts">' +
        '<button type="button" class="btn sm" data-act="submit">提交</button>' +
        '<button type="button" class="btn ghost sm" data-act="say">听一遍</button>' +
        '<button type="button" class="btn ghost sm" data-act="hint">提示</button>' +
        '<button type="button" class="btn ghost sm" data-act="close">收起</button>' +
        '</div>';
    }
    h += '</div>';
    return h;
  }

  function rowsHtml() {
    var a = S.art;
    var h = '';
    a.sentences.forEach(function (s, i) {
      var done = doneOf(a.slug).indexOf(i) >= 0;
      var open = S.open === i;
      var blurred = open && S.panel === 'dictate' && !S.hint && !S.fb;
      h += '<div class="art-row' + (done ? ' is-done' : '') + (open ? ' is-open' : '') + '" data-i="' + i + '">' +
        '<div class="art-en' + (blurred ? ' is-blur' : '') + '">' + wordsHtml(s) + '</div>' +
        '<div class="art-tools">' +
        '<span class="art-no">' + (i + 1) + '</span>' +
        '<button type="button" class="art-tool" data-act="sayline" data-i="' + i + '">听</button>' +
        '<button type="button" class="art-tool" data-act="follow" data-i="' + i + '">跟写</button>' +
        '<button type="button" class="art-tool" data-act="dictate" data-i="' + i + '">听写</button>' +
        (done ? '<span class="art-done">已写</span>' : '') +
        '</div>' +
        (open ? panelHtml(i, s, S.panel) : '') +
        '</div>';
    });
    return h;
  }

  function renderArticle() {
    var a = S.art;
    var done = doneOf(a.slug).length;
    var pct = Math.round(done / Math.max(1, a.sentences.length) * 100);
    var focus = S.open;
    var h = '<section class="card art-head">' +
      '<button type="button" class="art-back" data-act="back">‹ 返回文章列表</button>' +
      '<h1 class="art-title">' + esc(a.title) + '</h1>' +
      '<div class="art-sub">' + esc(LEVEL_ZH[a.level] || ('L' + a.level)) + ' · ' + a.word_count + ' 词 · 已完成 ' + done + '/' + a.sentences.length + '</div>' +
      '<div class="art-bar"><i style="width:' + pct + '%"></i></div>' +
      '<div class="art-src">语料：<a href="' + esc(a.source_url || '#') + '" target="_blank" rel="noopener">' + esc(a.source) + '</a> · ' + esc(a.license) + '</div>' +
      '</section>';
    h += '<section class="card art-body">' + rowsHtml() + '</section>';
    h += '<p class="small muted art-tip">点单词查词义；「收进阅读生词」会建一本个人词书，只用于自由练习，不进正式复习安排。</p>';
    el('view').innerHTML = h;
    if (focus >= 0) {
      var inp = el('artInput');
      if (inp) { try { inp.focus(); } catch (e) { /* 忽略 */ } }
    }
  }

  /* ---------- 动作 ---------- */
  function openPanel(i, mode) {
    if (!S.art) return;
    if (S.open === i && S.panel === mode) { S.open = -1; S.panel = ''; S.typed = ''; S.fb = null; renderArticle(); return; }
    S.open = i; S.panel = mode; S.typed = ''; S.fb = null; S.hint = false;
    renderArticle();
    var sentence = S.art.sentences[i];
    if (mode === 'dictate') say(sentence);
  }

  function closePanel() {
    S.open = -1; S.panel = ''; S.typed = ''; S.fb = null; S.hint = false;
    renderArticle();
  }

  function submit() {
    if (!S.art || S.open < 0) return;
    var sentence = S.art.sentences[S.open];
    var typed = S.typed;
    var acc = accuracy(sentence, typed);
    var ok = acc >= 0.92;
    S.fb = { ok: ok, acc: acc, target: sentence };
    if (ok) markDone(S.art.slug, S.open);
    renderArticle();
    if (!ok) {
      var inp = el('artInput');
      if (inp) inp.blur();
    }
  }

  async function lookup(word, anchor) {
    var pop = el('artPop');
    if (!pop) return;
    S.popWord = word;
    pop.hidden = false;
    pop.innerHTML = '<div class="art-pop-head"><b>' + esc(word) + '</b><span class="muted small">查词中…</span></div>';
    placePop(pop, anchor);
    var r = null;
    try { r = await window.DB.rpc('word_lookup', { p_word: word }); } catch (e) { r = null; }
    if (!pop.isConnected || S.popWord !== word) return;
    if (!r || r.ok === false) {
      pop.innerHTML = '<div class="art-pop-head"><b>' + esc(word) + '</b></div><div class="art-pop-body muted">词库暂时查不到。</div>';
      return;
    }
    var body = '';
    if (r.ipa) body += '<div class="art-pop-ipa">' + esc(r.ipa) + '</div>';
    body += '<div class="art-pop-mean">' + (r.meaning ? esc(r.meaning) : '<span class="muted">词库里没有这个词的释义</span>') + '</div>';
    if (r.phrases && r.phrases.length) {
      body += '<div class="art-pop-phr">' + r.phrases.slice(0, 4).map(function (p) {
        return '<div class="art-pop-phr-line"><b>' + esc(p.phrase) + '</b> ' + esc(p.meaning) + '</div>';
      }).join('') + '</div>';
    }
    var acts = '<button type="button" class="art-pop-btn" data-act="popsay">听发音</button>';
    if (r.word_id) acts += '<button type="button" class="art-pop-btn" data-act="popfav">收藏</button>';
    acts += '<button type="button" class="art-pop-btn" data-act="popbook">收进阅读生词</button>';
    pop.innerHTML = '<div class="art-pop-head"><b>' + esc(r.word || word) + '</b></div><div class="art-pop-body">' + body + '</div><div class="art-pop-acts">' + acts + '</div>';
    placePop(pop, anchor);
  }

  function placePop(pop, anchor) {
    var r = anchor && anchor.getBoundingClientRect ? anchor.getBoundingClientRect() : null;
    var top = r ? (window.scrollY + r.bottom + 8) : 120;
    var left = r ? Math.min(window.innerWidth - 280, Math.max(12, r.left - 40)) : 12;
    pop.style.top = Math.round(top) + 'px';
    pop.style.left = Math.round(left) + 'px';
  }

  function hidePop() {
    var pop = el('artPop');
    if (pop) { pop.hidden = true; pop.innerHTML = ''; }
    S.popWord = '';
  }

  async function ensureBook() {
    if (S.bookId) return S.bookId;
    try { S.bookId = localStorage.getItem(LS_BOOK) || ''; } catch (e) { S.bookId = ''; }
    if (S.bookId) return S.bookId;
    var r = null;
    try { r = await window.DB.rpc('create_personal_wordbook', { p_title: '阅读生词' }); } catch (e) { r = null; }
    if (r && r.ok && r.id) {
      S.bookId = r.id;
      try { localStorage.setItem(LS_BOOK, r.id); } catch (e) { /* 忽略 */ }
    }
    return S.bookId;
  }

  /* ---------- 事件 ---------- */
  document.addEventListener('click', async function (ev) {
    var t = ev.target && ev.target.closest ? ev.target.closest('[data-act]') : null;
    var act = t && t.getAttribute('data-act');
    if (!act) {
      if (ev.target && ev.target.closest && !ev.target.closest('#artPop')) hidePop();
      return;
    }
    if (act === 'level') {
      S.level = Number(t.getAttribute('data-lv')) || 0;
      renderList();
      return;
    }
    if (act === 'open') {
      ev.preventDefault();
      var slug = t.getAttribute('data-slug');
      var a = null;
      try { a = await window.DB.rpc('article_get', { p_slug: slug }); } catch (e) { a = null; }
      if (!a || a.ok === false) { alert('这篇文章暂时打不开。'); return; }
      S.art = a; S.slug = slug; S.open = -1; S.panel = ''; S.typed = ''; S.fb = null;
      renderArticle();
      return;
    }
    if (act === 'back') {
      S.art = null; S.slug = ''; S.open = -1;
      renderList();
      return;
    }
    if (act === 'sayline') {
      var i0 = Number(t.getAttribute('data-i'));
      if (S.art && S.art.sentences[i0]) say(S.art.sentences[i0]);
      return;
    }
    if (act === 'follow' || act === 'dictate') {
      openPanel(Number(t.getAttribute('data-i')), act);
      return;
    }
    if (act === 'close') { closePanel(); return; }
    if (act === 'again') {
      S.fb = null; S.typed = ''; S.hint = false;
      renderArticle();
      var in2 = el('artInput');
      if (in2) { try { in2.focus(); } catch (e) { /* 忽略 */ } }
      return;
    }
    if (act === 'hint') {
      S.hint = true;
      if (!S.typed && S.art && S.open >= 0) {
        var s = S.art.sentences[S.open];
        S.typed = s.charAt(0);
      }
      renderArticle();
      var inp3 = el('artInput');
      if (inp3) { try { inp3.focus(); } catch (e) { /* 忽略 */ } }
      return;
    }
    if (act === 'submit') { submit(); return; }
    if (act === 'say') {
      if (S.art && S.open >= 0) say(S.art.sentences[S.open]);
      return;
    }
    if (act === 'word') {
      ev.preventDefault();
      await lookup(t.getAttribute('data-w'), t);
      return;
    }
    if (act === 'popsay') { say(S.popWord); return; }
    if (act === 'popfav') {
      t.disabled = true;
      var lk = null;
      try { lk = await window.DB.rpc('word_lookup', { p_word: S.popWord }); } catch (e) { lk = null; }
      if (!lk || !lk.word_id) { t.disabled = false; t.textContent = '词库没有这个词'; return; }
      var res = null;
      try { res = await window.DB.rpc('toggle_word_favorite', { p_word_id: lk.word_id }); } catch (e) { res = null; }
      t.disabled = false;
      t.textContent = res && res.ok ? (res.favorited ? '已收藏' : '已取消') : '收藏失败';
      return;
    }
    if (act === 'popbook') {
      t.disabled = true;
      t.textContent = '收集中…';
      var id = await ensureBook();
      var r2 = null;
      if (id) {
        try { r2 = await window.DB.rpc('add_personal_book_words', { p_book_id: id, p_words: [S.popWord] }); } catch (e) { r2 = null; }
      }
      t.disabled = false;
      if (r2 && r2.ok) t.textContent = r2.added ? '已收进阅读生词' : '词库没有这个词';
      else t.textContent = '暂时收不了';
      return;
    }
  });

  document.addEventListener('input', function (ev) {
    if (!ev.target || ev.target.id !== 'artInput') return;
    S.typed = ev.target.value || '';
    if (S.panel !== 'follow') return;
    var pv = el('artPreview');
    if (pv && S.art && S.open >= 0) pv.innerHTML = previewHtml(S.art.sentences[S.open], S.typed);
  });

  document.addEventListener('keydown', function (ev) {
    if (ev.key !== 'Enter') return;
    if (!ev.target || ev.target.id !== 'artInput') return;
    ev.preventDefault();
    submit();
  });

  window.addEventListener('scroll', function () { hidePop(); }, { passive: true });

  /* ---------- 启动 ---------- */
  (async function boot() {
    el('view').innerHTML = '<div class="card"><p class="muted">正在准备…</p></div>';
    var user = null;
    try { user = await window.AppAuth.requireLogin(); } catch (e) { user = null; }
    if (!user) return;
    var name = '';
    try { name = window.AppAuth.displayName(user) || ''; } catch (e) { name = ''; }
    var u = el('userName');
    if (u) u.textContent = (name ? name + ' · ' : '') + '已登录';
    S.prog = loadProg();
    try { S.bookId = localStorage.getItem(LS_BOOK) || ''; } catch (e) { S.bookId = ''; }
    var list = null;
    try { list = await window.DB.rpc('list_articles', {}); } catch (e) { list = null; }
    if (!Array.isArray(list) || !list.length) {
      el('view').innerHTML = '<div class="card"><p class="muted">文章库还没准备好，稍后再来。</p></div>';
      return;
    }
    S.list = list;
    renderList();
  })();
})();