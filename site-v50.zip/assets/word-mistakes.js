/* ============================================================
 * word-mistakes.js — 错词本 / 收藏（单词维度）
 * 数据：RPC list_word_mistakes / list_word_favorites / set_word_mistake_mastered
 *       / toggle_word_favorite / list_wordbooks
 * 纯本地排序与筛选，不消耗 AI 额度。
 * ============================================================ */
(function () {
  'use strict';

  var S = {
    tab: 'mistakes',   // mistakes | favs
    items: [],
    favs: [],
    books: [],
    bookId: '',
    includeMastered: false,
    q: '',
    busy: false,
    loaded: { mistakes: false, favs: false },
    coach: null,        // AI 错词分析结果（缓存）
    coachKey: '',
    coachBusy: false
  };

  function el(id) { return document.getElementById(id); }

  function esc(s) {
    return String(s == null ? '' : s).replace(/[&<>"']/g, function (c) {
      return ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' })[c];
    });
  }

  function toast(msg, ms) {
    var t = el('toast');
    if (!t) return;
    t.textContent = msg;
    t.classList.add('show');
    clearTimeout(toast._t);
    toast._t = setTimeout(function () { t.classList.remove('show'); }, ms || 2200);
  }

  function rpc(name, args) {
    if (!window.DB || typeof window.DB.rpc !== 'function') return Promise.reject(new Error('数据库未就绪'));
    return window.DB.rpc(name, args || {});
  }

  function when(ts) {
    if (!ts) return '';
    var d = new Date(ts);
    if (isNaN(d.getTime())) return '';
    var diff = (Date.now() - d.getTime()) / 1000;
    if (diff < 60) return '刚刚';
    if (diff < 3600) return Math.floor(diff / 60) + ' 分钟前';
    if (diff < 86400) return Math.floor(diff / 3600) + ' 小时前';
    if (diff < 86400 * 30) return Math.floor(diff / 86400) + ' 天前';
    return d.getFullYear() + '-' + ('0' + (d.getMonth() + 1)).slice(-2) + '-' + ('0' + d.getDate()).slice(-2);
  }

  function modeName(m) {
    return ({ choice: '选择题', spell: '拼写', follow: '跟写', dictate: '听写', recall: '默写', read: '认知' })[m] || (m || '练习');
  }

  /* ---------------- 发音 ---------------- */
  function say(word, lang, btn) {
    if (!window.Speech || typeof window.Speech.say !== 'function') { toast('这个浏览器不支持朗读'); return; }
    try { window.Speech.say(word, { lang: lang || 'en-US', force: true }); } catch (e) { /* 忽略 */ }
    if (btn) {
      btn.classList.add('on');
      setTimeout(function () { btn.classList.remove('on'); }, 700);
    }
  }

  /* ---------------- 渲染 ---------------- */
  function tabsHtml() {
    var m = (el('wmCountM') && el('wmCountM').textContent) || '';
    return '<div class="wm-tabs">' +
      '<button type="button" class="wm-tab' + (S.tab === 'mistakes' ? ' on' : '') + '" data-act="tab:mistakes">错词本</button>' +
      '<button type="button" class="wm-tab' + (S.tab === 'favs' ? ' on' : '') + '" data-act="tab:favs">收藏</button>' +
      '</div>';
  }

  function bookOptionsHtml() {
    var h = ['<option value="">全部词书</option>'];
    S.books.forEach(function (b) {
      var n = b.word_count || b.total || 0;
      h.push('<option value="' + esc(b.id) + '"' + (S.bookId === b.id ? ' selected' : '') + '>' +
        esc(b.title || b.code) + (n ? '（' + n + '）' : '') + '</option>');
    });
    return h.join('');
  }

  function toolsHtml() {
    if (S.tab !== 'mistakes') {
      return '<div class="wm-tools">' +
        '<input id="wmSearch" class="wm-search" type="search" placeholder="搜单词或释义" value="' + esc(S.q) + '">' +
        '</div>';
    }
    return '<div class="wm-tools">' +
      '<select id="wmBook" class="wm-book">' + bookOptionsHtml() + '</select>' +
      '<label class="wm-check"><input type="checkbox" id="wmMastered"' + (S.includeMastered ? ' checked' : '') + '> 含已掌握</label>' +
      '<input id="wmSearch" class="wm-search" type="search" placeholder="搜单词或释义" value="' + esc(S.q) + '">' +
      '<a class="wm-btn text" href="practice.html">自由练习</a>' +
      '</div>';
  }

  function emptyHtml() {
    if (S.tab === 'favs') {
      return '<div class="card wm-empty"><p class="muted">还没有收藏的词。</p>' +
        '<p class="muted small">在背单词卡片里点「收藏这个词」，或展开详情后收藏。</p>' +
        '<a class="btn ghost block" href="study.html">去背单词</a></div>';
    }
    return '<div class="card wm-empty"><p class="muted">错词本是空的——说明目前没写错过。</p>' +
      '<p class="muted small">答错的单词会自动进来，记下你实际写错的样子，方便集中重练。</p>' +
      '<a class="btn ghost block" href="study.html">去背单词</a></div>';
  }

  function booksChips(list) {
    if (!list || !list.length) return '';
    var names = { daily: '日常', cet4: '四级', cet6: '六级', ielts: '雅思', toefl: '托福', gre: 'GRE', gk: '高考', zk: '中考', kaoyan: '考研', kaoyan_hi: '考研高频', kaoyan_adv: '考研难词' };
    return list.slice(0, 4).map(function (c) {
      return '<span class="wm-chip">' + esc(names[c] || c) + '</span>';
    }).join('');
  }

  function mistakeRow(it) {
    var h = ['<li class="wm-row" data-word="' + esc(it.word_id) + '">'];
    h.push('<div class="wm-main">');
    h.push('<div class="wm-w"><b>' + esc(it.word) + '</b>');
    if (it.ipa) h.push(' <span class="wm-ipa">' + esc(it.ipa) + '</span>');
    h.push('</div>');
    h.push('<div class="wm-mean">' + esc(it.meaning) + '</div>');
    var meta = [];
    meta.push('错 ' + (it.misses || 1) + ' 次');
    if (it.last_mode) meta.push('上次' + modeName(it.last_mode));
    if (it.last_miss_at) meta.push(when(it.last_miss_at));
    if (it.mastered) meta.push('已掌握');
    h.push('<div class="wm-meta">' + esc(meta.join(' · ')) + '</div>');
    if (it.last_typed) h.push('<div class="wm-typed">你写的是：<code>' + esc(it.last_typed) + '</code></div>');
    var chip = booksChips(it.books);
    if (chip) h.push('<div class="wm-books">' + chip + '</div>');
    h.push('</div>');
    h.push('<div class="wm-acts">');
    h.push('<button type="button" class="wm-btn" data-act="say" data-w="' + esc(it.word) + '" data-lang="en-US" title="美音">🔊</button>');
    h.push('<button type="button" class="wm-btn" data-act="say" data-w="' + esc(it.word) + '" data-lang="en-GB" title="英音">🎧</button>');
    if (!it.mastered) h.push('<button type="button" class="wm-btn text" data-act="master:' + esc(it.word_id) + '">已掌握</button>');
    h.push('</div></li>');
    return h.join('');
  }

  function favRow(it) {
    return '<li class="wm-row">' +
      '<div class="wm-main"><div class="wm-w"><b>' + esc(it.word) + '</b>' +
      (it.ipa ? ' <span class="wm-ipa">' + esc(it.ipa) + '</span>' : '') + '</div>' +
      '<div class="wm-mean">' + esc(it.meaning) + '</div>' +
      (it.created_at ? '<div class="wm-meta">收藏于 ' + esc(when(it.created_at)) + '</div>' : '') +
      '</div>' +
      '<div class="wm-acts">' +
      '<button type="button" class="wm-btn" data-act="say" data-w="' + esc(it.word) + '" data-lang="en-US" title="美音">🔊</button>' +
      '<button type="button" class="wm-btn text" data-act="unfav:' + esc(it.word_id) + '">取消</button>' +
      '</div></li>';
  }

  function filterItems(list) {
    var q = String(S.q || '').trim().toLowerCase();
    if (!q) return list;
    return list.filter(function (it) {
      return String(it.word || '').toLowerCase().indexOf(q) !== -1 ||
        String(it.meaning || '').toLowerCase().indexOf(q) !== -1;
    });
  }

  function render() {
    var list = filterItems(S.tab === 'mistakes' ? S.items : S.favs);
    var h = [];
    h.push(tabsHtml());
    h.push(toolsHtml());
    if (S.tab === 'mistakes') { h.push(coachHostHtml()); if (S.coach) h.push(coachCardHtml()); }
    h.push('<p class="wm-tip">' + (S.tab === 'mistakes'
      ? '答错的词自动收进来，按错得多少排。点「已掌握」就不再出现在这里。'
      : '收藏的词都在这里，随时回来看一眼或听发音。') + '</p>');
    if (!list.length) {
      h.push(emptyHtml());
    } else {
      h.push('<ul class="wm-list">');
      list.forEach(function (it) {
        h.push(S.tab === 'mistakes' ? mistakeRow(it) : favRow(it));
      });
      h.push('</ul>');
    }
    el('view').innerHTML = '<div class="card wm-card">' + h.join('') + '</div>';
    bindTools();
    if (el('wmCount')) {
      el('wmCount').textContent = S.tab === 'mistakes' ? (S.items.length + ' 个错词') : (S.favs.length + ' 个收藏');
    }
  }

  function bindTools() {
    var sel = el('wmBook');
    if (sel) sel.addEventListener('change', function () { S.bookId = sel.value || ''; load(true); });
    var cb = el('wmMastered');
    if (cb) cb.addEventListener('change', function () { S.includeMastered = !!cb.checked; load(true); });
    var q = el('wmSearch');
    if (q) {
      q.addEventListener('input', function () {
        S.q = q.value || '';
        var list = filterItems(S.tab === 'mistakes' ? S.items : S.favs);
        // 只重画列表，保持输入焦点
        var host = document.querySelector('#view .wm-list');
        var box = document.querySelector('#view .wm-empty');
        if (host) {
          host.innerHTML = list.map(function (it) { return S.tab === 'mistakes' ? mistakeRow(it) : favRow(it); }).join('');
          host.style.display = list.length ? '' : 'none';
        }
        if (box) box.style.display = list.length ? 'none' : '';
      });
    }
  }

  /* ---------------- 数据 ---------------- */
  async function loadBooks() {
    try {
      var res = await rpc('list_wordbooks', {});
      S.books = (res && (res.wordbooks || res.books)) || [];
    } catch (e) { S.books = []; }
  }

  async function load(showLoading) {
    if (S.busy) return;
    S.busy = true;
    if (showLoading) el('view').innerHTML = '<div class="card"><p class="muted">正在读取…</p></div>';
    try {
      if (S.tab === 'mistakes') {
        var args = { p_limit: 200, p_include_mastered: !!S.includeMastered };
        if (S.bookId) args.p_book_id = S.bookId;
        var r = await rpc('list_word_mistakes', args);
        S.items = (r && r.items) || [];
      } else {
        var f = await rpc('list_word_favorites', { p_limit: 200 });
        S.favs = (f && f.items) || [];
      }
      S.busy = false;
      render();
    } catch (e) {
      S.busy = false;
      el('view').innerHTML = '<div class="card"><p class="warn-text">读取失败：' + esc((e && e.message) || e) + '</p>' +
        '<div class="row mt8"><button class="btn ghost block" data-act="reload">重试</button></div></div>';
    }
  }

  async function setMastered(wordId, on) {
    try {
      var r = await rpc('set_word_mistake_mastered', { p_word_id: wordId, p_mastered: !!on });
      if (!r || r.ok === false) { toast('没有保存成功，稍后再试'); return false; }
      return true;
    } catch (e) { toast('没有保存成功，稍后再试'); return false; }
  }

  async function unfav(wordId) {
    try {
      var r = await rpc('toggle_word_favorite', { p_word_id: wordId });
      if (!r || r.ok === false) { toast('没有保存成功，稍后再试'); return false; }
      return true;
    } catch (e) { toast('没有保存成功，稍后再试'); return false; }
  }

  /* ---------------- AI 错词分析（可选，只在用户主动点击时调用一次） ---------------- */
  var COACH_KEY = 'lumi.coach.v1';
  var COACH_TTL = 12 * 3600 * 1000;

  function coachSig(list) {
    return list.slice(0, 20).map(function (i) { return i.word + ':' + (i.misses || 1); }).join('|');
  }

  function readCoachCache(key) {
    try {
      var raw = window.localStorage.getItem(COACH_KEY);
      if (!raw) return null;
      var obj = JSON.parse(raw);
      if (!obj || obj.key !== key) return null;
      if (Date.now() - (obj.at || 0) > COACH_TTL) return null;
      return obj.data || null;
    } catch (e) { return null; }
  }

  function writeCoachCache(key, data) {
    try {
      window.localStorage.setItem(COACH_KEY, JSON.stringify({ key: key, at: Date.now(), data: data }));
    } catch (e) { /* 配额满就跳过 */ }
  }

  async function currentLevel() {
    try {
      if (window.Difficulty && typeof window.Difficulty.read === 'function') {
        var r = await window.Difficulty.read();
        var lv = r && (r.words || (r.ok && r.words));
        if (lv) return Math.max(1, Math.min(9, Number(lv) || 4));
      }
    } catch (e) { /* 忽略 */ }
    return 4;
  }

  function coachHostHtml() {
    if (S.tab !== 'mistakes') return '';
    var n = S.items.length;
    if (n < 3) {
      return '<div class="wm-coach">' +
        '<p class="wm-coach-tip">错词满 3 个后，可以让 Lumi 分析你反复写错的字母规律。平时背词不上传、不耗 AI。</p>' +
        '</div>';
    }
    var busy = S.coachBusy ? ' disabled' : '';
    return '<div class="wm-coach">' +
      '<button type="button" class="wm-coach-btn"' + busy + ' data-act="coach">' +
      (S.coachBusy ? '正在分析你的错词…' : '让 Lumi 分析这 ' + Math.min(20, n) + ' 个错词') + '</button>' +
      '<p class="wm-coach-tip">只在你点的时候调用一次 AI（约 ¥0.02），结果会在本机缓存半天。</p>' +
      '</div>';
  }

  function coachCardHtml() {
    var d = S.coach;
    if (!d) return '';
    var h = ['<div class="wm-coach-card">'];
    if (d.summary_zh) h.push('<p class="wm-coach-sum">' + esc(d.summary_zh) + '</p>');
    if (d.weak_areas && d.weak_areas.length) {
      h.push('<div class="wm-weak">' + d.weak_areas.slice(0, 4).map(function (w) {
        return '<span class="wm-chip">' + esc(w) + '</span>';
      }).join('') + '</div>');
    }
    (d.patterns || []).slice(0, 5).forEach(function (p) {
      h.push('<div class="wm-pattern">');
      h.push('<div class="wm-pattern-w"><b>' + esc(p.word || '') + '</b>' +
        (p.typed ? ' <span class="wm-typed-inline">写成 <code>' + esc(p.typed) + '</code></span>' : '') + '</div>');
      if (p.why_zh) h.push('<p class="wm-pattern-p">' + esc(p.why_zh) + '</p>');
      if (p.memory_tip_zh) h.push('<p class="wm-pattern-tip">记法：' + esc(p.memory_tip_zh) + '</p>');
      h.push('</div>');
    });
    (d.confusables || []).slice(0, 3).forEach(function (c) {
      h.push('<p class="wm-confuse">易混：<b>' + esc(c.a || '') + '</b> / <b>' + esc(c.b || '') + '</b> —— ' + esc(c.why_zh || '') + '</p>');
    });
    if (d.next_steps && d.next_steps.length) {
      h.push('<div class="wm-next"><div class="wm-next-h">接下来这样练</div><ol>' +
        d.next_steps.slice(0, 4).map(function (t) { return '<li>' + esc(t) + '</li>'; }).join('') + '</ol></div>');
    }
    if (d.book_hint && d.book_hint.code) {
      h.push('<p class="wm-book-hint">推荐词书：<b>' + esc(d.book_hint.code) + '</b> —— ' + esc(d.book_hint.why_zh || '') + '</p>');
    }
    h.push('</div>');
    return h.join('');
  }

  async function runCoach() {
    if (S.coachBusy) return;
    if (!window.AI || typeof window.AI.invoke !== 'function') { toast('AI 暂时不可用'); return; }
    var list = S.items.slice().sort(function (a, b) { return (b.misses || 1) - (a.misses || 1); }).slice(0, 20);
    if (list.length < 3) { toast('错词太少，攒到 3 个再分析'); return; }
    var key = coachSig(list);
    var cached = readCoachCache(key);
    if (cached) { S.coach = cached; render(); return; }
    S.coachBusy = true;
    render();
    var level = await currentLevel();
    var books = (S.books || []).slice(0, 40).map(function (b) { return { code: b.code, title: b.title || b.code }; });
    var r = await window.AI.invoke('coach', {
      level: level,
      books: books,
      words: list.map(function (i) {
        return { word: i.word, typed: i.last_typed || '', meaning: i.meaning || '', misses: i.misses || 1 };
      })
    });
    S.coachBusy = false;
    if (!r || !r.ok) {
      render();
      toast(r && r.message ? r.message : '分析没成功，稍后再试');
      return;
    }
    S.coach = r.data || null;
    if (S.coach) writeCoachCache(key, S.coach);
    render();
  }

  /* ---------------- 事件 ---------------- */
  document.addEventListener('click', function (ev) {
    var t = ev.target.closest('[data-act]');
    if (!t) return;
    var act = t.getAttribute('data-act');
    if (act === 'reload') return load(true);
    if (act.indexOf('tab:') === 0) {
      var tab = act.slice(4);
      if (tab === S.tab) return;
      S.tab = tab;
      S.q = '';
      if (tab === 'favs' && !S.loaded.favs) { S.loaded.favs = true; }
      return load(true);
    }
    if (act === 'coach') return runCoach();
    if (act === 'say') return say(t.getAttribute('data-w'), t.getAttribute('data-lang'), t);
    if (act.indexOf('master:') === 0) {
      var id = act.slice(7);
      t.disabled = true;
      setMastered(id, true).then(function (ok) {
        t.disabled = false;
        if (!ok) return;
        S.items = S.items.filter(function (i) { return i.word_id !== id; });
        toast('已标记掌握，不再进错词本');
        render();
      });
      return;
    }
    if (act.indexOf('unfav:') === 0) {
      var fid = act.slice(6);
      t.disabled = true;
      unfav(fid).then(function (ok) {
        t.disabled = false;
        if (!ok) return;
        S.favs = S.favs.filter(function (i) { return i.word_id !== fid; });
        toast('已取消收藏');
        render();
      });
      return;
    }
  });

  /* ---------------- 启动 ---------------- */
  (async function boot() {
    el('view').innerHTML = '<div class="card"><p class="muted">正在读取…</p></div>';
    var user = null;
    try { user = await window.AppAuth.requireLogin(); } catch (e) { user = null; }
    if (!user) return;
    var name = '';
    try { name = window.AppAuth.displayName(user) || ''; } catch (e) { name = ''; }
    var u = el('userName');
    if (u) u.textContent = (name ? name + ' · ' : '') + '已登录';
    await loadBooks();
    await load(true);
  })();
})();