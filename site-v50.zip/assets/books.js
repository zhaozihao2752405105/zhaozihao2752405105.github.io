/* ============================================================
 * assets/books.js —— 词书中心
 * 功能：查看所有词书 / 选一本作为当前书 / 加入或暂停或移出计划 / 多书合并模式 /
 *       自定义每日新词数与复习上限 / 显示每本的总量·已学·掌握·剩余 / 显示来源与许可
 * 约束：
 *   1) 写操作全部走 RPC（user_wordbooks 客户端只读），不直接写表。
 *   2) 切换词书只改变「后续新词来源」，不删除 word_progress / 错题 / 统计 / 到期复习。
 *   3) 与单词无关的记录一律不动；本页不提供任何删除学习记录的入口。
 * 数据来源：RPC list_wordbooks（含每本 learned/mastered 与用户 study_prefs）
 * ============================================================ */
(function () {
  'use strict';
  var user = null;
  var S = { list: [], prefs: {}, busy: false, q: '', tab: 'all', peek: {} };

  /* 词书分组：优先用数据库里的 category（以后加的教材书会带），否则按 code 归类 */
  var GROUP_OF = {
    daily: 'core', ndl: 'core', lspeak: 'core', lwrite: 'core',
    oxa1: 'core', oxa2: 'core', oxb1: 'core', coca1k: 'core',
    cet4: 'exam', cet6: 'exam', kaoyan: 'exam', kaoyan_hi: 'exam', kaoyan_adv: 'exam', zk: 'exam', gk: 'exam',
    ielts: 'exam', toefl: 'exam', gre: 'exam',
    oxb2: 'exam', oxc1: 'exam', coca3k: 'exam', coca5k: 'exam',
    nawl: 'prof', tsl: 'prof', bsl: 'prof', fel: 'prof'
  };
  var GROUP_LABEL = { core: '高频', exam: '考试', prof: '行业', book: '教材', life: '生活', other: '其他' };

  function groupOf(b) {
    if (b && b.category) return String(b.category);
    return GROUP_OF[b && b.code] || 'other';
  }
  function groupLabel(b) { return GROUP_LABEL[groupOf(b)] || '其他'; }
  function mineOf(b) { return !!(b && (b.is_current || b.mine_status)); }
  function matchQ(b, q) {
    if (!q) return true;
    var hay = [b.title, b.subtitle, b.code, b.description, b.source_name].join(' ').toLowerCase();
    return hay.indexOf(q) >= 0;
  }
  function matchTab(b, tab) {
    if (tab === 'all') return true;
    if (tab === 'mine') return mineOf(b);
    return groupOf(b) === tab;
  }

  function el(id) { return document.getElementById(id); }
  function esc(s) {
    return String(s == null ? '' : s).replace(/[&<>"]/g, function (c) {
      return { '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;' }[c];
    });
  }
  function toast(msg) {
    var t = el('toast'); if (!t) return alert(msg);
    t.textContent = msg; t.classList.add('on');
    clearTimeout(toast._t);
    toast._t = setTimeout(function () { t.classList.remove('on'); }, 2800);
  }
  function pct(a, b) { return b > 0 ? Math.round(a * 100 / b) : 0; }

  function rpc(name, args) {
    return window.DB.rpc(name, args || {}).then(function (res) {
      if (!res || res.ok === false) {
        var msg = (res && (res.message || res.code)) || '操作失败';
        throw new Error(msg);
      }
      return res;
    });
  }

  function load() {
    return rpc('list_wordbooks', {}).then(function (res) {
      // 旧种子词书不再推荐给新用户；但已经加入/正在用的存量账号必须能在词书中心
      // 看到并管理它（否则“当前学习词书”会显示成「还没选」，也没法换掉它）。
      S.list = (res.wordbooks || res.books || []).filter(function (b) {
        return b && (b.code !== 'seed' || b.is_current ||
          b.mine_status === 'active' || b.mine_status === 'paused');
      });
      S.prefs = res.study_prefs || {};
      render();
    });
  }

  /* ---------------- 顶部：当前书 + 学习量 ---------------- */
  function currentCard() {
    var cur = null;
    for (var i = 0; i < S.list.length; i++) if (S.list[i].is_current) { cur = S.list[i]; break; }
    var mode = S.prefs.wordbook_mode === 'multi' ? 'multi' : 'single';
    var newWords = S.prefs.daily_new_words;
    var revLimit = S.prefs.review_limit;

    var h = '<div class="card">';
    h += '<h2 style="margin:0 0 6px">当前计划</h2>';
    h += '<p class="muted small" style="margin:0 0 12px">正在学的书、取词方式和每天学习量。改完点「保存学习量」。</p>';

    h += '<div class="kv"><span class="muted small">当前学习词书</span><span><b>' +
      (cur ? esc(cur.title) : '还没选') + '</b></span></div>';
    if (cur) {
      h += '<div class="kv"><span class="muted small">这本书进度</span><span>' +
        esc(cur.learned) + ' / ' + esc(cur.word_count) + ' 词（' + pct(cur.learned, cur.word_count) + '%）</span></div>';
    }

    h += '<div class="kv"><span class="muted small">新词来源</span><span>' +
      '<button class="btn ghost sm" data-act="mode" data-mode="single" ' + (mode === 'single' ? 'disabled' : '') + '>只当前书</button> ' +
      '<button class="btn ghost sm" data-act="mode" data-mode="multi" ' + (mode === 'multi' ? 'disabled' : '') + '>多本合并</button>' +
      '</span></div>';
    h += '<p class="muted small" style="margin:6px 0 0">「只当前书」= 每天的新词只从当前这本出（默认，不混书）；「多本合并」= 从所有已加入且未暂停的书里合并取词。</p>';

    h += '<div class="kv"><span class="muted small">每天新词数</span><span>' +
      '<input id="prefNew" type="number" min="1" max="50" inputmode="numeric" style="width:76px" value="' +
      (newWords == null ? '' : esc(newWords)) + '" placeholder="自动"></span></div>';
    h += '<div class="kv"><span class="muted small">每天复习上限</span><span>' +
      '<input id="prefRev" type="number" min="0" max="100" inputmode="numeric" style="width:76px" value="' +
      (revLimit == null ? '' : esc(revLimit)) + '" placeholder="自动"></span></div>';
    h += '<p class="muted small" style="margin:6px 0 0">按自己的节奏设置学习量。留空则使用系统自动安排；保存后从明天起应用，不改变已生成的任务。</p>';
    h += '<div class="row mt12"><button class="btn" data-act="save-prefs">保存学习量</button></div>';

    h += '</div>';
    return h;
  }

  /* ---------------- 书单 ---------------- */
  function bookItem(b) {
    var st = b.mine_status || '';
    var badge = '';
    if (b.is_current) badge = '<span class="tag on">当前</span>';
    else if (st === 'active') badge = '<span class="tag">已加入</span>';
    else if (st === 'paused') badge = '<span class="tag">已暂停</span>';
    else badge = '<span class="tag">未加入</span>';

    var h = '<div class="book-item">';
    h += '<div class="book-head"><div><b>' + esc(b.title) + '</b> ' + badge +
      ' <span class="tag ghost">' + esc(groupLabel(b)) + '</span>' +
      '<div class="muted small">' + esc(b.subtitle || '') + '</div></div></div>';
    h += '<div class="book-meta muted small">共 ' + esc(b.word_count) + ' 词 · 已学 ' + esc(b.learned) +
      ' · 掌握 ' + esc(b.mastered) + ' · 剩余 ' + esc(Math.max(0, b.word_count - b.learned)) + '</div>';
    h += '<div class="progress"><i style="width:' + pct(b.learned, b.word_count) + '%"></i></div>';

    h += '<div class="row mt12">';
    h += '<button class="btn ghost sm" data-act="peek" data-id="' + esc(b.id) + '">先看几个词</button>';
    if (!b.is_current) {
      h += '<button class="btn ghost sm" data-act="cur" data-id="' + esc(b.id) + '">设为当前</button>';
    }
    if (!st) {
      h += '<button class="btn sm" data-act="add" data-id="' + esc(b.id) + '">加入计划</button>';
    } else if (st === 'paused') {
      h += '<button class="btn ghost sm" data-act="resume" data-id="' + esc(b.id) + '">恢复学习</button>';
    } else if (!b.is_current) {
      h += '<button class="btn ghost sm" data-act="pause" data-id="' + esc(b.id) + '">暂停</button>';
    }
    if (st && !b.is_current) {
      h += '<button class="btn ghost sm" data-act="remove" data-id="' + esc(b.id) + '">移出计划</button>';
    }
    h += '</div>';

    h += '<details class="mt8"><summary class="muted small">来源与许可</summary>' +
      '<div class="muted small" style="line-height:1.6;margin-top:6px">' +
      '选词来源：' + esc(b.source_name || '—') +
      (b.source_version ? '<br>版本：' + esc(b.source_version) : '') +
      '<br>许可：' + esc(b.license || '—') +
      (b.attribution ? '<br>署名：' + esc(b.attribution) : '') +
      (b.source_url ? '<br>地址：<a href="' + esc(b.source_url) + '" target="_blank" rel="noopener">' + esc(b.source_url) + '</a>' : '') +
      (b.license_url ? '<br>许可地址：<a href="' + esc(b.license_url) + '" target="_blank" rel="noopener">' + esc(b.license_url) + '</a>' : '') +
      '</div></details>';

    h += '<div class="bk-peek" id="peek-' + esc(b.id) + '" hidden></div>';
    h += '</div>';
    return h;
  }

  function listCard() {
    var h = '<div class="card"><h3 style="margin:0 0 10px">全部词书（<span id="bkCount">' + S.list.length + '</span> 本）</h3>';
    h += '<div class="bk-tools">' +
      '<input id="bkSearch" class="bk-search" type="search" inputmode="search" placeholder="搜词书：中考 / 四级 / 托福 / GRE…" value="' + esc(S.q) + '">' +
      '<div class="bk-chips">' +
        chip('all', '全部') + chip('mine', '我的') + chip('core', '高频') +
        chip('exam', '考试') + chip('prof', '行业·学术') +
      '</div>' +
      '</div>';
    h += '<div id="bkList">' + bookListHtml() + '</div>';
    h += '</div>';
    return h;
  }

  function chip(tab, label) {
    return '<button class="bk-chip' + (S.tab === tab ? ' on' : '') + '" data-act="tab" data-tab="' + tab + '">' + esc(label) + '</button>';
  }

  function filtered() {
    var q = String(S.q || '').trim().toLowerCase();
    var out = [];
    for (var i = 0; i < S.list.length; i++) {
      var b = S.list[i];
      if (!matchTab(b, S.tab)) continue;
      if (!matchQ(b, q)) continue;
      out.push(b);
    }
    return out;
  }

  function bookListHtml() {
    var arr = filtered();
    if (!arr.length) return '<p class="muted small" style="padding:12px 0">没有匹配的词书。换个关键词，或点「全部」。</p>';
    var h = '';
    for (var i = 0; i < arr.length; i++) h += bookItem(arr[i]);
    return h;
  }

  function renderList() {
    var box = el('bkList'), cnt = el('bkCount');
    if (box) box.innerHTML = bookListHtml();
    if (cnt) cnt.textContent = filtered().length;
  }

  /* ---------------- 说明与许可 ---------------- */
  function noticeCard() {
    var h = '<div class="card">';
    h += '<h3 style="margin:0 0 8px">关于这些词书</h3>';
    h += '<p class="muted small" style="line-height:1.7">' +
      '词条内容来自公开可核查的数据集：<b>ECDICT</b>（MIT，音标/中文释义）、<b>NGSL 1.2</b>（CC BY-SA 4.0，日常高频选词）、' +
      '<b>Tatoeba</b>（CC BY 2.0 FR / CC0，英中例句，逐句保留句子 ID 与作者）。' +
      '词表是按数据集里的考试标签筛出来的，<b>不等于官方完整考试大纲</b>（雅思本身也没有官方词表）。' +
      '缺失的音标/例句留空显示「暂无」，没有用 AI 补齐或编造。' +
      '</p>';
    h += '<p class="muted small" style="line-height:1.7">NGSL 选词部分属 CC BY-SA 4.0 衍生数据，署名：Browne, C., Culligan, B., and Phillips, J. — New General Service List（www.newgeneralservicelist.com）。</p>';
    h += '<p class="muted small" style="line-height:1.7">同一个单词在多本词书里只存一份资料（共用音标、释义、例句），学习记录也跟着这一份走，不会重复扣学习量。</p>';
    h += '</div>';
    return h;
  }

  function render() {
    var h = '<div class="v2-pagehead"><p class="v2-eyebrow">Your wordbooks</p><h1 class="v2-h1">词书中心</h1><p>换书只改变以后的新词从哪本出；已学的词、复习安排和错题都不会重置。</p></div>';
    h += currentCard() + listCard() + noticeCard();
    el('view').innerHTML = h;
  }

  /* ---------------- 动作 ---------------- */
  function reload(msg) {
    return load().then(function () { if (msg) toast(msg); });
  }

  function savePrefs() {
    var nEl = el('prefNew'), rEl = el('prefRev');
    var patch = {};
    var nv = nEl && nEl.value !== '' ? parseInt(nEl.value, 10) : null;
    var rv = rEl && rEl.value !== '' ? parseInt(rEl.value, 10) : null;
    if (nv != null && (isNaN(nv) || nv < 1 || nv > 50)) return toast('每天新词数请填 1–50');
    if (rv != null && (isNaN(rv) || rv < 0 || rv > 100)) return toast('每天复习上限请填 0–100');
    patch.daily_new_words = nv;
    patch.review_limit = rv;
    S.busy = true;
    rpc('set_study_prefs', { p_patch: patch }).then(function () {
      S.busy = false;
      return reload('已保存，明天起按新数量排词');
    }).catch(function (e) { S.busy = false; toast(e.message || '保存失败'); });
  }

  function act(name, ds) {
    if (name === 'tab') { setTab(ds.tab); return; }
    if (name === 'peek') { peek(ds.id); return; }
    if (S.busy) return;
    var id = ds.id;
    var p = null;
    if (name === 'mode') {
      var want = ds.mode === 'multi' ? 'multi' : 'single';
      if ((S.prefs.wordbook_mode || 'single') === want) return;
      p = rpc('set_study_prefs', { p_patch: { wordbook_mode: want } }).then(function () {
        return reload(want === 'multi' ? '已改为多本合并' : '已改为只学当前书');
      });
    } else if (name === 'save-prefs') {
      return savePrefs();
    } else if (name === 'cur') {
      p = rpc('set_current_wordbook', { p_book_id: id }).then(function () { return reload('已切换当前词书'); });
    } else if (name === 'add') {
      p = rpc('add_wordbook', { p_book_id: id }).then(function () { return reload('已加入学习计划'); });
    } else if (name === 'pause') {
      p = rpc('set_wordbook_status', { p_book_id: id, p_status: 'paused' }).then(function () { return reload('已暂停这本书'); });
    } else if (name === 'resume') {
      p = rpc('set_wordbook_status', { p_book_id: id, p_status: 'active' }).then(function () { return reload('已恢复这本书'); });
    } else if (name === 'remove') {
      if (!window.confirm('把这本书移出学习计划吗？\n\n只解除这本书的来源，已经学过的词、复习记录、错题和统计都不会被删除。')) return;
      p = rpc('remove_wordbook', { p_book_id: id }).then(function () { return reload('已移出计划（学习记录保留）'); });
    }
    if (!p) return;
    S.busy = true;
    p.catch(function (e) { toast(e.message || '操作失败'); }).then(function () { S.busy = false; });
  }

  /* ---------------- 预览与筛选 ---------------- */
  function setTab(tab) {
    S.tab = tab || 'all';
    var chips = document.querySelectorAll('.bk-chip');
    for (var i = 0; i < chips.length; i++) {
      chips[i].classList.toggle('on', chips[i].dataset && chips[i].dataset.tab === S.tab);
    }
    renderList();
  }

  function peek(id) {
    var box = el('peek-' + id);
    if (!box) return;
    if (box.getAttribute('data-loaded') === '1') { box.hidden = !box.hidden; return; }
    box.hidden = false;
    box.innerHTML = '<p class="muted small">正在取词…</p>';
    rpc('wordbook_preview', { p_book_id: id, p_limit: 10 }).then(function (res) {
      var ws = res.words || [];
      var h = '<p class="muted small" style="margin:0 0 6px">按词频从高到低的前 ' + ws.length +
        ' 个词（真实词条，没让 AI 补写）：</p><ul class="bk-peek-list">';
      for (var i = 0; i < ws.length; i++) {
        var w = ws[i];
        h += '<li><b>' + esc(w.word) + '</b>' +
          (w.ipa ? ' <span class="muted small">' + esc(w.ipa) + '</span>' : '') +
          '<div class="muted small">' + esc(String(w.meaning || '').split('\n')[0]) + '</div></li>';
      }
      h += '</ul>';
      box.innerHTML = h;
      box.setAttribute('data-loaded', '1');
    }).catch(function (e) {
      box.innerHTML = '<p class="muted small">取词失败：' + esc(e.message || '') + '</p>';
    });
  }

  function boot() {
    var auth = window.AppAuth;
    if (window.DB && auth && auth.requireLogin) {
      auth.requireLogin().then(function (u) {
        user = u;
        var n = el('userName');
        if (n) n.textContent = (auth.displayName ? auth.displayName(u) : (u && u.email ? String(u.email).split('@')[0] : ''));
        return load();
      }).catch(function (e) {
        el('view').innerHTML = '<div class="card"><p>需要登录后才能管理词书。</p><p class="muted small">' +
          esc((e && e.message) || '') + '</p><p><a class="btn" href="login.html">去登录</a></p></div>';
      });
    } else {
      el('view').innerHTML = '<div class="card"><p>页面脚本没加载完整，请刷新。</p></div>';
    }
  }

  document.addEventListener('input', function (ev) {
    var t = ev.target;
    if (t && t.id === 'bkSearch') { S.q = t.value || ''; renderList(); }
  });

  document.addEventListener('click', function (ev) {
    var b = ev.target.closest ? ev.target.closest('[data-act]') : null;
    if (!b) return;
    var ds = b.dataset || {};
    if (ds.act === 'logout' || b.id === 'btnLogout') return;
    act(ds.act, ds);
  });
  var lo = el('btnLogout');
  if (lo) lo.addEventListener('click', function () {
    if (window.AppAuth && window.AppAuth.logout) window.AppAuth.logout();
  });

  boot();
})();
