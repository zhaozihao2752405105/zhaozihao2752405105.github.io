/* Lumi Words — 单词配图
 * 1) 优先用本地图片库 assets/img/w/<word>.webp（维基百科条目主图，可商用，署名在卡片里）
 * 2) 没有图就用一个 emoji 占位，保证每张单词卡都有视觉锚点
 * 3) 索引懒加载一次，浏览器缓存 7 天；离线时用上次的索引
 */
(function () {
  'use strict';
  var IDX_URL = 'assets/img/w/index.json';
  var LS_KEY = 'lumi.wimg.idx.v1';
  var LS_TTL = 7 * 864e5;
  var S = { map: null, loading: null, failed: false };

  // 常见词的 emoji 兜底（没有照片时也能看图记词）
  var EMOJI = {
    time: '⏰', year: '📅', day: '📆', week: '🗓', hour: '🕒', minute: '⏱', month: '📅', season: '🍂',
    life: '🌱', people: '👥', person: '🧑', man: '👨', woman: '👩', child: '🧒', children: '🧒', baby: '👶',
    family: '👨‍👩‍👧', friend: '👫', teacher: '🧑‍🏫', student: '🧑‍🎓', doctor: '🧑‍⚕️', nurse: '👩‍⚕️',
    work: '💼', job: '💼', office: '🏢', company: '🏢', business: '💼', money: '💰', price: '🏷', cost: '💸',
    bank: '🏦', market: '🏪', shop: '🛍', store: '🏬', customer: '🧑‍💼', service: '🤝', meeting: '🗣',
    home: '🏠', house: '🏡', room: '🚪', kitchen: '🍳', bedroom: '🛏', door: '🚪', window: '🪟', wall: '🧱',
    floor: '🪜', roof: '🏠', garden: '🌷', yard: '🌿', street: '🛣', road: '🛣', city: '🏙', town: '🏘',
    village: '🏘', country: '🗺', world: '🌍', map: '🗺', place: '📍', area: '📐', space: '🚀',
    water: '💧', fire: '🔥', air: '💨', earth: '🌍', sun: '☀️', moon: '🌙', star: '⭐', sky: '🌤',
    cloud: '☁️', rain: '🌧', snow: '❄️', wind: '🌬', storm: '⛈', weather: '🌦', light: '💡', dark: '🌑',
    night: '🌙', morning: '🌅', evening: '🌆', noon: '🕛', food: '🍽', meal: '🍽', breakfast: '🥐',
    lunch: '🍱', dinner: '🍽', bread: '🍞', rice: '🍚', meat: '🥩', fish: '🐟', egg: '🥚', milk: '🥛',
    coffee: '☕', tea: '🍵', sugar: '🍬', salt: '🧂', oil: '🫒', fruit: '🍎', apple: '🍎', banana: '🍌',
    orange: '🍊', grape: '🍇', vegetable: '🥦', potato: '🥔', tomato: '🍅', onion: '🧅', soup: '🍲',
    cake: '🍰', candy: '🍬', drink: '🥤', wine: '🍷', beer: '🍺', bottle: '🍾', cup: '🥤', plate: '🍽',
    animal: '🐾', dog: '🐕', cat: '🐈', bird: '🐦', horse: '🐎', cow: '🐄', pig: '🐖', sheep: '🐑',
    chicken: '🐔', mouse: '🐁', rabbit: '🐇', tiger: '🐅', lion: '🦁', bear: '🐻', elephant: '🐘',
    monkey: '🐒', snake: '🐍', insect: '🐜', bee: '🐝', butterfly: '🦋', spider: '🕷',
    tree: '🌳', flower: '🌺', grass: '🌿', leaf: '🍃', forest: '🌲', plant: '🪴', seed: '🌱', root: '🌱',
    mountain: '⛰', hill: '🏔', river: '🏞', lake: '🏞', sea: '🌊', ocean: '🌊', beach: '🏖', island: '🏝',
    desert: '🏜', field: '🌾', farm: '🚜', rock: '🪨', stone: '🪨', sand: '🏖', ice: '🧊', soil: '🌱',
    car: '🚗', bus: '🚌', train: '🚆', plane: '✈️', ship: '🚢', boat: '⛵', bike: '🚲', bicycle: '🚲',
    taxi: '🚕', truck: '🚚', subway: '🚇', airport: '🛫', station: '🚉', ticket: '🎫', travel: '🧳',
    journey: '🧭', trip: '🧳', holiday: '🏖', vacation: '🏖', hotel: '🏨', luggage: '🧳', passport: '🛂',
    book: '📕', page: '📄', paper: '📄', letter: '✉️', word: '🔤', language: '🗣', english: '🇬🇧',
    story: '📖', news: '📰', magazine: '📓', pen: '🖊', pencil: '✏️', email: '📧',
    phone: '📱', computer: '💻', laptop: '💻', screen: '🖥', keyboard: '⌨️', camera: '📷', photo: '🖼',
    picture: '🖼', music: '🎵', song: '🎶', movie: '🎬', film: '🎬', game: '🎮', sport: '⚽', football: '⚽',
    basketball: '🏀', tennis: '🎾', swim: '🏊', run: '🏃', ride: '🚴', dance: '💃', sing: '🎤',
    body: '🧍', head: '🗣', face: '🙂', eye: '👁', ear: '👂', nose: '👃', mouth: '👄', tooth: '🦷',
    hair: '💇', hand: '✋', foot: '🦶', leg: '🦵', arm: '💪', heart: '❤️', blood: '🩸', bone: '🦴',
    skin: '🧴', brain: '🧠', stomach: '🫃', health: '❤️‍🩹', medicine: '💊', hospital: '🏥',
    illness: '🤒', fever: '🤒', pain: '😖', sleep: '😴', dream: '💭', tired: '😪', hungry: '🍽',
    clothes: '👕', shirt: '👔', coat: '🧥', shoe: '👞', hat: '🎩', dress: '👗', trousers: '👖', bag: '👜',
    watch: '⌚', ring: '💍', glass: '🥛', key: '🔑', box: '📦', ball: '⚽', toy: '🧸', gift: '🎁',
    color: '🎨', red: '🔴', blue: '🔵', green: '🟢', yellow: '🟡', black: '⚫', white: '⚪', brown: '🟤',
    number: '🔢', question: '❓', answer: '✅', idea: '💡', problem: '❗', reason: '🤔', truth: '✔️',
    love: '❤️', happy: '😊', sad: '😢', angry: '😠', afraid: '😨', fear: '😨', hope: '🌟', luck: '🍀',
    peace: '🕊', war: '⚔️', law: '⚖️', rule: '📏', right: '➡️', wrong: '❌', school: '🏫', class: '🏫',
    lesson: '📚', exam: '📝', test: '📝', study: '📚', learn: '📖', teach: '🧑‍🏫', practice: '🔁',
    write: '✍️', read: '📖', listen: '👂', speak: '🗣', talk: '💬', call: '📞', message: '💬',
    sign: '🪧', board: '📋', list: '📋', plan: '🗒', start: '🚦', end: '🏁', goal: '🎯',
    win: '🏆', lose: '📉', team: '👥', group: '👥', party: '🎉', birthday: '🎂', wedding: '💒'
  };

  function norm(w) { return String(w || '').toLowerCase().trim(); }

  function readCache() {
    try {
      var raw = localStorage.getItem(LS_KEY);
      if (!raw) return null;
      var o = JSON.parse(raw);
      if (!o || !o.t || Date.now() - o.t > LS_TTL || !o.m) return null;
      return o.m;
    } catch (e) { return null; }
  }

  function writeCache(m) {
    try { localStorage.setItem(LS_KEY, JSON.stringify({ t: Date.now(), m: m })); } catch (e) { /* 配额满就算了 */ }
  }

  function load() {
    if (S.map) return Promise.resolve(S.map);
    if (S.loading) return S.loading;
    var hit = readCache();
    if (hit) { S.map = hit; return Promise.resolve(hit); }
    if (typeof fetch !== 'function') { S.failed = true; return Promise.resolve(null); }
    S.loading = fetch(IDX_URL, { cache: 'force-cache' })
      .then(function (r) { return r && r.ok ? r.json() : null; })
      .then(function (m) {
        S.map = m && typeof m === 'object' ? m : {};
        writeCache(S.map);
        return S.map;
      })
      .catch(function () { S.failed = true; return null; });
    return S.loading;
  }

  function entry(word) {
    var w = norm(word);
    if (!w || !S.map) return null;
    return S.map[w] || null;
  }

  function esc(s) {
    return String(s == null ? '' : s).replace(/[&<>"']/g, function (c) {
      return { '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c];
    });
  }

  // 返回一段 HTML；没有图也没有 emoji 时返回空串
  function html(word, opts) {
    var o = opts || {};
    var w = norm(word);
    var e = entry(w);
    if (e && e.s) {
      var credit = e.c ? '图：' + esc(e.c) + (e.l ? ' · ' + esc(e.l) : '') : '';
      var fig = '<figure class="wimg' + (o.cls ? ' ' + o.cls : '') + '">' +
        '<img src="assets/img/w/' + esc(e.s) + '" alt="' + esc(w) + '" width="240" height="240" loading="lazy" decoding="async">' +
        (credit ? '<figcaption>' + (e.p ? '<a href="' + esc(e.p) + '" target="_blank" rel="noopener">' + credit + '</a>' : credit) + '</figcaption>' : '') +
        '</figure>';
      return fig;
    }
    var em = EMOJI[w];
    if (em) return '<div class="wimg wimg-emoji' + (o.cls ? ' ' + o.cls : '') + '" aria-hidden="true"><span>' + em + '</span></div>';
    return '';
  }

  window.LumiWordImage = {
    load: load,
    html: html,
    has: function (w) { return !!(entry(w) || EMOJI[norm(w)]); },
    entry: entry,
    emoji: function (w) { return EMOJI[norm(w)] || ''; },
    count: function () { return S.map ? Object.keys(S.map).length : 0; }
  };
})();
