(function () {
  'use strict';

  var view = document.getElementById('view');
  var toastEl = document.getElementById('toast');
  var S = { home: null, module: null, row: null, quiz: null, speak: null, startedAt: 0, busy: false };

  function esc(s) {
    return String(s == null ? '' : s).replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;');
  }
  var toastTimer = null;
  function toast(msg) {
    if (!toastEl) return;
    toastEl.textContent = msg;
    toastEl.classList.add('show');
    if (toastTimer) clearTimeout(toastTimer);
    toastTimer = setTimeout(function () { toastEl.classList.remove('show'); }, 2600);
  }
  function minutes(ms) {
    var m = Math.round(ms / 60000);
    return m < 1 ? '不到 1' : String(m);
  }

  // ---------- 课程视觉组件（只生成展示标记） ----------
  function courseIcon(module) {
    var paths = {
      grammar: '<path d="M4 5h16M4 10h12M4 15h7m3 2 2 2 4-5"/>',
      listening: '<path d="M4 14v-2a8 8 0 0 1 16 0v2M4 13h3a2 2 0 0 1 2 2v4H6a2 2 0 0 1-2-2zm16 0h-3a2 2 0 0 0-2 2v4h3a2 2 0 0 0 2-2z"/>',
      reading: '<path d="M12 6C9 3 5 3 3 4v15c3-1 6-1 9 2 3-3 6-3 9-2V4c-2-1-6-1-9 2zm0 0v15"/>',
      writing: '<path d="M5 19l3.5-.8L19 7.7 16.3 5 5.8 15.5 5 19zM14.5 6.8l2.7 2.7M11 19h8"/>',
      speaking: '<rect x="9" y="3" width="6" height="12" rx="3"/><path d="M5 11v1a7 7 0 0 0 14 0v-1M12 19v3m-4 0h8"/>'
    };
    return '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.7" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true">' + (paths[module] || '') + '</svg>';
  }
  function screen(name) { view.setAttribute('data-screen', name); }
  // ---------- 首页 ----------
  async function renderHome() {
    // 离开课程时统一收口：停朗读/停录音/停口语计时并清空本轮口语临时状态（BUG A/B）
    if (window.Speech) window.Speech.stop();
    stopAudio(); stopListening(); stopSpeakTimer(); stopSpeakRec(true); S.speak = null;
    S.module = null; S.row = null; S.quiz = null;
    delete document.body.dataset.lumiAudioFocus;
    S.busy = true;
    try {
      var info = window.Lesson.info();
      var prog = await window.Lesson.progress();
      var names = {
        grammar: ['语法', '知识讲解 · 随堂练习'],
        listening: ['听力', '先听再答 · 原文回顾'],
        reading: ['阅读', '短文理解 · 重点词汇'],
        speaking: ['口语', '话题表达 · 60 秒自查'],
        writing: ['写作', '写作任务 · 自查与反馈']
      };
      var h = '<div class="v2-welcome"><div class="v2-welcome-date">' + esc(window.Lesson.todayStr()) + '</div><h1>今天，继续探索英语。</h1><p>选择你想练习的课程，按自己的节奏学习。</p></div>';
      var offlineNow = (typeof navigator !== 'undefined' && navigator.onLine === false);
      if (offlineNow) {
        h += '<section class="card tight" style="margin-bottom:10px"><b>离线模式</b>' +
          '<p class="muted small" style="margin:6px 0 0">现在没有网络：已缓存的模块可以直接看和练，新内容、AI 生成要等联网。答题记录先存在本机，联网后自动补交。</p></section>';
      }
      var total = window.Lesson.MODULES.length;
      var count = Math.max(0, Math.min(total, Number(prog.done_count) || 0));
      h += '<section class="card v2-course-hero">';
      h += '<div class="v2-course-hero-row"><div class="hero-txt">';
      h += '<div class="v2-hero-kicker"><span></span>今日课程</div>';
      h += '<h2>课程练习</h2><p>已完成 ' + count + ' / ' + total + ' 个模块</p></div>';
      h += '<div class="v2-course-count" aria-label="已完成 ' + count + ' 个模块"><b>' + count + '<small>/' + total + '</small></b><span>课程进度</span></div></div>';
      h += '<div class="v2-course-segments" aria-hidden="true">' + window.Lesson.MODULES.map(function (_, i) { return '<i' + (i < count ? ' class="filled"' : '') + '></i>'; }).join('') + '</div>';
      h += '<div class="row v2-course-meta">';
      h += '<span class="pill">第 ' + (info.dayIndex + 1) + ' 天</span>';
      h += '<span class="pill grey">' + esc(domainLabel(info.domain)) + '</span>';
      h += '<span class="pill grey">' + (window.APP_CONFIG.FEATURES.AI_GENERATE ? 'AI 生成 + 内置备用' : '内置内容库') + '</span>';
      h += '</div></section>';
      if (info.aiBlocked && info.blockMessage) {
        h += '<section class="card tight" style="margin-top:10px"><p class="warn-text">' + esc(info.blockMessage) + '</p><p class="muted small">其它功能照常可用，内置内容不花钱。</p></section>';
      }
      h += '<div class="v2-section-head v2-course-listhead"><h2>选择课程</h2></div><div class="tasklist v2-course-grid">';
      window.Lesson.MODULES.forEach(function (m) {
        var n = names[m];
        var done = !!prog[m];
        h += '<button class="task v2-course-tile v2-module--' + m + (done ? ' done' : '') + '" data-act="start:' + m + '">';
        h += '<span class="task-ico v2-module-icon">' + courseIcon(m) + '</span>';
        h += '<span class="task-main"><span class="task-name">' + n[0] + '</span>';
        h += '<span class="task-meta">' + n[1] + '</span><span class="v2-course-status">' + (done ? '已完成 · 可再练习' : '开始练习') + '</span></span>';
        h += '<span class="task-arrow" aria-hidden="true">' + (done ? '✓' : '›') + '</span></button>';
      });
      h += '</div>';
      h += '<section class="card tight v2-course-note"><p class="muted small">同一天的同档内容跨设备复用。更改难度后，新打开的课程按新等级准备。断网或 AI 不可用时使用内置内容或缓存，学习记录按原机制补交。</p></section>';
      h += '<div class="row v2-course-footer"><a class="btn ghost" href="today.html">返回今日学习</a></div>';
      screen('home');
      view.innerHTML = h;
    } catch (e) {
      renderError(e);
    } finally { S.busy = false; }
  }

  function domainLabel(d) {
    return ({ gen: '日常', work: '工作', mech: '机械', med: '医疗' })[d] || d;
  }
  function renderError(e) {
    screen('status');
    var off = (typeof navigator !== 'undefined' && navigator.onLine === false);
    view.innerHTML = '<section class="card"><p class="warn-text">' + (off ? '现在没有网络' : '加载失败') + '：' + esc((e && e.message) || e) + '</p>' +
      '<p class="muted small">' + (off
        ? '已经练过的模块可以直接打开（内容在本机）；还没缓存过的模块要等联网。学习记录不会丢。'
        : '先检查网络；如果一直失败，回今日页重新登录。') + '</p>' +
      '<div class="row" style="margin-top:10px"><button class="btn" data-act="reload">重试</button><a class="btn ghost" href="today.html">回今日</a></div></section>';
  }

  // ---------- 进入模块 ----------
  async function startModule(module) {
    if (S.busy) return;
    S.busy = true;
    try {
      screen('status');
      view.innerHTML = '<section class="card"><p class="muted">正在准备「' + esc(window.Lesson.MODULE_LABEL[module]) + '」内容…</p><p class="muted small">第一次生成大约需要 3–6 秒；当天再打开会直接读，不用等。</p></section>';
      // 只有真正进入模块才允许回前台自动恢复会话（空会话修复：打开 lesson 首页不算学习）
      try { if (window.Learn && window.Learn.Session) { window.Learn.Session.autoStart = true; window.Learn.Session.start(); } } catch (e) { /* 时长统计失败不影响学习 */ }
      var row = await window.Lesson.get(module);
      S.module = module; S.row = row; S.startedAt = Date.now(); S.quiz = null;
      if (module === 'listening') document.body.dataset.lumiAudioFocus = 'listening';
      else delete document.body.dataset.lumiAudioFocus;
      S.hints = 0;
      S.hinted = new Set();
      S.transcriptSeen = false;
      Listen.i = 0;
      Listen.rate = window.LumiDifficulty.level(window.Lesson.difficultyOf(row, module)).rate;
      if (row.degraded) toast('AI 暂时不可用，已用内置内容继续');
      renderModule();
    } catch (e) {
      // 内容没打开就不该留下学习会话（空会话修复）
      try { window.Learn.Session.autoStart = false; window.Learn.Session.end(); } catch (e2) { }
      renderError(e);
    } finally { S.busy = false; }
  }

  function headerHtml(title, sub) {
    var actualLevel = window.Lesson.difficultyOf(S.row, S.module);
    var src = S.row?.source === 'ai' ? 'AI 模拟练习' : (S.row?.content?.lumi_fallback_band ? '内置备用材料' : '内置内容');
    return '<header class="v2-course-head v2-module--' + S.module + '"><div class="v2-course-head-main">' +
      '<span class="v2-module-icon">' + courseIcon(S.module) + '</span><h1>' + esc(title) + '</h1>' +
      '<button class="btn sm ghost" data-act="back">返回课程</button></div>' +
      '<div class="row v2-course-meta"><span class="pill grey">' + esc(window.Difficulty.label(actualLevel)) + '</span>' +
      '<span class="pill grey">' + src + '</span></div>' +
      (sub ? '<p class="muted small">' + esc(sub) + '</p>' : '') + '</header><section id="lessonDifficulty"></section>';
  }

  function renderModule() {
    screen('study');
    if (S.module === 'grammar') renderGrammar();
    else if (S.module === 'listening') renderListening();
    else if (S.module === 'reading') renderReading();
    else if (S.module === 'writing') renderWriting();
    else renderSpeaking();
    void window.Difficulty.mount(document.getElementById('lessonDifficulty'), [S.module]);
  }

  function renderWriting() {
    const content = S.row.content || {};
    view.innerHTML = headerHtml('写作', '写完后根据任务自行检查，再评价难度。') +
      '<section class="card"><h2>写作任务</h2><p>' + esc(content.prompt || '') + '</p>' +
      '<p class="muted small">建议约 ' + esc(content.target_words) + ' 个英文词</p>' +
      '<label for="lumiWriting">我的练习</label><textarea class="lumi-writing-input" id="lumiWriting" maxlength="4000">' +
      esc(S.row.result?.draft || '') + '</textarea><div class="row end"><button class="btn" data-act="finish">保存并完成</button></div></section>';
  }

  // ---------- 语法 ----------
  function renderGrammar() {
    var c = S.row.content || {};
    if (!S.quiz) S.quiz = { module: 'grammar', questions: c.exercises || [], i: 0, answers: [], done: false };
    var h = headerHtml('语法', '先看讲解，再做题。答错会立刻告诉你正确答案。');
    h += '<section class="card v2-course-material">';
    h += '<div class="pill grey">知识点</div>';
    h += '<h2 style="margin:8px 0 6px;font-size:19px">' + esc(c.point) + '</h2>';
    h += '<p class="v2-course-explain">' + esc(c.explain_zh) + '</p>';
    h += '<div class="muted small" style="margin-top:6px">例句</div>';
    (c.examples || []).forEach(function (ex) {
      h += '<div class="v2-course-example"><div class="v2-course-en">' + esc(ex.en) + '</div><button type="button" class="btn ghost sm mt8" data-act="sayexample" data-en="' + esc(ex.en) + '">听例句</button><div class="muted small">' + esc(ex.zh) + '</div></div>';
    });
    h += '</section>';
    h += '<div id="quiz"></div>';
    view.innerHTML = h;
    renderQuiz();
  }

  // ---------- 听力 ----------
  function renderListening() {
    var c = S.row.content || {};
    if (!S.quiz) S.quiz = { module: 'listening', questions: c.questions || [], i: 0, answers: [], done: false };
    var h = headerHtml('听力', '先听录音再答题。需要帮助时可以提前查看原文。');
    h += '<section class="card v2-course-material v2-course-listening">';
    h += '<div class="pill grey">听力材料</div>';
    h += '<h2 style="margin:8px 0 10px;font-size:19px">' + esc(c.title) + '</h2>';
    h += '<div class="v2-listen-symbol" aria-hidden="true">' + courseIcon('listening') + '</div><div class="row v2-course-controls">';
    h += '<button class="btn" data-act="play">▶ 播放</button>';
    h += '<button class="btn ghost" data-act="stopplay">■ 停止</button>';
    h += '<button class="btn ghost" data-act="repeatSentence">重听本句</button>';
    h += '<button class="btn ghost" data-act="nextSentence">下一句</button>';
    h += '<label class="lumi-listen-rate">语速<select id="lumiListenRate">' +
      Array.from(new Set([0.7, 0.85, 1, 1.15, Listen.rate])).sort().map(rate =>
        '<option value="' + rate + '"' + (rate === Listen.rate ? ' selected' : '') + '>' + rate + '×</option>').join('') +
      '</select></label>';
    h += '</div>';
    h += '<p class="muted small" style="margin:8px 0 0">有预制录音时优先播放录音，没有对应录音时使用系统朗读。实际音色与设备支持情况有关。</p>';
    h += '<div id="listenStatus" class="muted small v2-listen-status" role="status" style="margin:6px 0 0">正在准备语音…</div>';
    if (c.transcript) h += '<details id="lumiTranscriptPreview"><summary>查看原文（提示）</summary><p class="transcript">' + esc(c.transcript) + '</p></details>';
    h += '</section>';
    h += '<div id="quiz"></div>';
    view.innerHTML = h;
    window.Speech?.voiceFor('en-US');
    setListen('点「播放」开始听。');
    renderQuiz();
    const preview = document.getElementById('lumiTranscriptPreview');
    preview?.addEventListener('toggle', () => {
      if (!preview.open || S.quiz.done || S.transcriptSeen) return;
      S.transcriptSeen = true;
      S.hints++;
    });
    document.getElementById('lumiListenRate').addEventListener('change', function (event) {
      Listen.rate = Number(event.target.value);
      if (Playing.audio) Playing.audio.playbackRate = Listen.rate;
    });
  }

  // ---------- 阅读 ----------
  function renderReading() {
    var c = S.row.content || {};
    if (!S.quiz) S.quiz = { module: 'reading', questions: c.questions || [], i: 0, answers: [], done: false };
    var kwMap = {};
    (c.key_words || []).forEach(function (w) { kwMap[String(w.word).toLowerCase()] = w; });
    var h = headerHtml('阅读', '先读短文，点带下划线的词可以看音标和意思；再做题。');
    h += '<section class="card v2-course-material v2-course-reading">';
    h += '<div class="pill grey">短文</div>';
    h += '<h2 style="margin:8px 0 10px;font-size:19px">' + esc(c.title) + '</h2>';
    h += '<p class="passage">' + markWords(c.passage || '', kwMap) + '</p>';
    h += '</section>';
    h += '<div id="quiz"></div>';
    view.innerHTML = h;
    renderQuiz();
  }
  function markWords(text, kwMap) {
    var out = '';
    var parts = String(text).split(/([A-Za-z][A-Za-z'-]*)/);
    parts.forEach(function (p) {
      var k = p.toLowerCase();
      if (kwMap[k]) out += '<button type="button" class="kw" data-kw="' + esc(k) + '" title="查看词义">' + esc(p) + '</button>';
      else out += esc(p);
    });
    return out;
  }

  // ---------- 通用做题 ----------
  function renderQuiz() {
    var box = document.getElementById('quiz');
    if (!box) return;
    var q = S.quiz;
    if (q.done) return renderQuizResult(box);
    var cur = q.questions[q.i];
    if (!cur) return renderQuizResult(box);
    var ans = q.answers[q.i];
    var h = '<section class="card v2-course-quiz">';
    h += '<div class="v2-course-question-head"><span>随堂练习</span><span>第 ' + (q.i + 1) + ' / ' + q.questions.length + ' 题</span></div>';
    h += '<div class="v2-course-qbar" aria-hidden="true"><i style="width:' + Math.round(q.i / q.questions.length * 100) + '%"></i></div>';
    h += '<p class="v2-course-question">' + esc(cur.question) + '</p>';
    (cur.options || []).forEach(function (opt, idx) {
      var cls = 'opt';
      if (ans) {
        if (idx === cur.answer_index) cls += ' right';
        else if (idx === ans.chosen) cls += ' wrong';
      }
      h += '<button class="' + cls + '" data-act="opt:' + idx + '"' + (ans ? ' disabled' : '') + '>';
      h += '<span class="k">' + 'ABCD'[idx] + '</span><span>' + esc(opt) + '</span></button>';
    });
    if (ans) {
      h += '<div class="fb ' + (ans.ok ? 'ok' : 'bad') + '" role="status">';
      h += '<div style="font-weight:700">' + (ans.ok ? '答对了' : '答错了') + '</div>';
      if (!ans.ok) h += '<div class="small" style="margin-top:4px">正确答案：' + esc(cur.options[cur.answer_index]) + '</div>';
      h += '<div class="muted small" style="margin-top:4px">' + esc(cur.explain_zh || '') + '</div></div>';
      h += '<div class="row end" style="margin-top:10px"><button class="btn" data-act="nextq">' + (q.i + 1 >= q.questions.length ? '看结果' : '下一题') + '</button></div>';
    }
    h += '</section>';
    box.innerHTML = h;
    // 阶段 1：题目下方「问问 AI」（语法/阅读/听力；单词题不给入口）
    // 只在作答之后出现：作答前就挂入口，等于把正确答案提前暴露给模型。
    if (ans && window.AskUI && window.AskUI.mount) {
      try { window.AskUI.mount(box, askCtx(q, cur)); } catch (e) {}
    }
  }

  // 只传白名单字段；原文/题干截断在网关侧还有二次限制（ASK_CONTEXT_MAX=1500）
  function askCtx(q, cur) {
    var c = S.row.content || {};
    var parts = ['模块: ' + q.module];
    if (q.module === 'grammar') {
      parts.push('知识点: ' + String(c.point || ''));
      parts.push('讲解: ' + String(c.explain_zh || '').slice(0, 220));
      (c.examples || []).slice(0, 2).forEach(function (ex) { parts.push('例句: ' + String(ex.en || '') + ' / ' + String(ex.zh || '')); });
    } else if (q.module === 'reading' || q.module === 'listening') {
      parts.push('标题: ' + String(c.title || ''));
      parts.push((q.module === 'reading' ? '原文: ' : '听力原文: ') + String(c.passage || c.transcript || '').slice(0, 800));
    }
    parts.push('题干: ' + String(cur.question || ''));
    (cur.options || []).forEach(function (o, i) { parts.push('ABCD'.charAt(i) + '. ' + String(o)); });
    parts.push('正确答案: ' + String((cur.options || [])[cur.answer_index] || ''));
    var ans = (q.answers || [])[q.i];
    if (ans) {
      parts.push('你的答案: ' + String((cur.options || [])[ans.chosen] || '未选'));
      if (cur.explain_zh) parts.push('解答: ' + String(cur.explain_zh).slice(0, 220));
    }
    var text = parts.join('\n').slice(0, 1500);
    return {
      kind: q.module,
      ref: String(S.row.lesson_date || '') + ':' + q.module + ':' + (q.i + 1),
      title: String(c.title || c.point || q.module),
      context: text
    };
  }

  function renderQuizResult(box) {
    var q = S.quiz;
    var c = S.row.content || {};
    var total = q.questions.length;
    var ok = q.answers.filter(function (a) { return a && a.ok; }).length;
    var h = '<section class="card v2-course-result">';
    h += '<div class="pill">本模块结果</div>';
    h += '<h2 style="margin:8px 0 6px;font-size:20px">答对 ' + ok + ' / ' + total + '</h2>';
    h += '<p class="muted small">' + (ok === total ? '全对，保持住。' : '错题已经记进错题本，以后会自动出现。') + '</p>';
    if (q.module === 'listening') {
      h += '<div class="muted small" style="margin-top:10px">听力原文</div>';
      h += '<p class="transcript">' + esc(c.transcript || '') + '</p>';
      if (c.explanation_zh) h += '<p class="muted small">' + esc(c.explanation_zh) + '</p>';
      if (c.dictation_excerpt) h += '<details><summary>听写参考</summary><p>' + esc(c.dictation_excerpt) + '</p></details>';
    }
    var kws = c.key_words || [];
    if (kws.length) {
      h += '<div class="muted small" style="margin-top:10px">重点词汇</div><div class="kwlist">';
      kws.forEach(function (w) {
        h += '<div class="kwrow"><b>' + esc(w.word) + '</b> <span class="muted small">' + esc(w.ipa || '') + '</span> <span>' + esc(w.meaning) + '</span></div>';
      });
      h += '</div>';
    }
    h += '<div class="row end" style="margin-top:12px"><button class="btn" data-act="finish">完成这个模块</button></div>';
    h += '</section>';
    box.innerHTML = h;
  }

  async function answer(qi, chosen) {
    var q = S.quiz;
    if (!q || q.answers[q.i]) return;
    var cur = q.questions[q.i];
    var ok = chosen === cur.answer_index;
    q.answers[q.i] = { chosen: chosen, ok: ok,
      independent: !S.transcriptSeen && !document.getElementById('lumiTranscriptPreview')?.open && !S.hinted.has(q.i) };
    if (!ok) {
      // 阶段 2：错题保存当时那道题的上下文快照，错题本里才能「问问 AI」
      var mctx = askCtx(q, cur);
      window.Lesson.saveMistake(q.module, {
        ref_id: S.row.id,
        question: cur.question,
        user_answer: cur.options[chosen],
        correct_answer: cur.options[cur.answer_index],
        explain_zh: cur.explain_zh || '',
        context: { text: mctx.context, title: mctx.title, kind: mctx.kind, ref: mctx.ref }
      });
    }
    renderQuiz();
  }

  // 没有服务端语音时，用浏览器本机听写（旧路径，原样保留）
  function speakRecLocal() {
    var box = document.getElementById('speakRec');
    if (!(window.Voice && window.Voice.asrSupported)) {
      if (box) box.textContent = '这个浏览器不支持语音输入；直接对着屏幕说 60 秒也一样有效。';
      return;
    }
    if (SpeakRec.active) {
      stopSpeakRec();
      if (box) box.textContent = '已停止。';
      return;
    }
    if (box) box.textContent = '在听…说一句英文，说完会自动变成文字。';
    SpeakRec.active = true;
    SpeakRec.h = window.Voice.listen({
      lang: 'en-US',
      onPartial: function (t) { if (box) box.textContent = '识别中：' + t; },
      onEnd: function (t) {
        SpeakRec.active = false; SpeakRec.h = null;
        if (!box) return;
        box.textContent = t
          ? '识别到：' + t + '（这是浏览器的听写结果，用来确认你说了什么，不是发音评分）'
          : '这次没有识别到内容，可以再说一次。';
      },
      onError: function (code) {
        SpeakRec.active = false; SpeakRec.h = null;
        if (code === 'cancelled') { if (box) box.textContent = '已取消语音输入。'; return; }
        if (box) box.textContent = '语音输入不可用（' + code + '）；直接说 60 秒再按自查勾选。';
      }
    });
    if (!SpeakRec.h) SpeakRec.active = false;
  }

  // ---------- 口语 ----------
  function renderSpeaking() {
    var c = S.row.content || {};
    if (!S.speak) S.speak = { checks: [false, false, false, false, false], left: 60, timer: null, spoken: false, used: 0 };
    var sp = S.speak;
    var h = headerHtml('口语', '不用怕说错。先看表达，再开口说 60 秒，最后按 5 条自查。');
    h += '<section class="card v2-course-material">';
    h += '<div class="pill grey">今天的话题</div>';
    h += '<h2 style="margin:8px 0 10px;font-size:19px">' + esc(c.topic) + '</h2>';
    h += '<div class="muted small">要说清的三点</div><ol class="plainlist">';
    (c.prompts_zh || []).forEach(function (p) { h += '<li>' + esc(p) + '</li>'; });
    h += '</ol>';
    h += '<div class="muted small" style="margin-top:10px">可以套用的句子</div>';
    (c.patterns || []).forEach(function (p) {
      h += '<div class="v2-course-example"><div class="v2-course-en">' + esc(p.en) + '</div><div class="muted small">' + esc(p.zh) + '</div></div>';
    });
    h += '<div class="row" style="margin-top:12px"><button class="btn ghost sm" data-act="speakdemo">🔊 听示范</button><span class="spacer"></span><button class="btn ghost sm" data-act="speakrec">🎤 试着说一遍</button></div>';
    h += '<div id="speakRec" class="muted small" style="margin-top:8px"></div>';
    h += '</section>';
    h += '<section class="card v2-course-timer">';
    h += '<div class="v2-course-timer-label">口语计时 · 自主练习</div><div class="clock" id="speakClock">' + sp.left + ' 秒</div>';
    h += '<div class="row" style="justify-content:center;margin-top:8px">';
    h += '<button class="btn" data-act="speakstart">▶ 开始说</button>';
    h += '<button class="btn ghost" data-act="speakstop">说完了</button>';
    h += '</div>';
    h += '<p class="muted small" style="margin:8px 0 0">倒计时只是提醒，时间到也可以继续说。系统不会给你打分，也不会上传录音。</p>';
    h += '</section>';
    h += '<section class="card v2-course-checklist">';
    h += '<div class="muted small">说完后自查（5 条都勾上才算完成）</div>';
    (c.checklist || []).forEach(function (item, i) {
      h += '<button class="checkrow' + (sp.checks[i] ? ' on' : '') + '" data-act="check:' + i + '" aria-pressed="' + String(sp.checks[i]) + '">';
      h += '<span class="box">' + (sp.checks[i] ? '✓' : '') + '</span><span>' + esc(item) + '</span></button>';
    });
    h += '<div id="sampleBox" style="display:none;margin-top:10px"><div class="muted small">参考答案（说完再看）</div><p class="transcript">' + esc(c.sample_answer || '') + '</p></div>';
    h += '<div class="row" style="margin-top:10px"><button class="btn ghost sm" data-act="togglesample" aria-controls="sampleBox" aria-expanded="false">看参考答案</button><span class="spacer"></span>';
    h += '<button class="btn" data-act="finish" id="speakFinish"' + (canFinishSpeak() ? '' : ' disabled') + '>完成口语</button></div>';
    h += '</section>';
    view.innerHTML = h;
  }
  function canFinishSpeak() {
    var sp = S.speak;
    if (!sp) return false;
    return sp.spoken && sp.checks.every(function (x) { return x; });
  }
  function updateSpeakFinish() {
    var b = document.getElementById('speakFinish');
    if (b) b.disabled = !canFinishSpeak();
  }
  function stopSpeakTimer() {
    if (S.speak && S.speak.timer) { clearInterval(S.speak.timer); S.speak.timer = null; }
  }
  function startSpeakTimer() {
    var sp = S.speak;
    if (!sp || sp.timer) return;
    sp.spoken = true;
    sp.timer = setInterval(function () {
      if (sp.left > 0) { sp.left -= 1; sp.used += 1; }
      var el = document.getElementById('speakClock');
      if (el) el.textContent = sp.left + ' 秒';
      if (sp.left <= 0) stopSpeakTimer();
    }, 1000);
    updateSpeakFinish();
  }

  // ---------- 完成 ----------
  async function finishModule() {
    if (!S.module || !S.row || S.busy) return;
    const module = S.module;
    const row = S.row;
    const extra = {};
    let stats = {};
    if (S.quiz) {
      extra.score = S.quiz.answers.filter(answer => answer?.ok).length;
      extra.total = S.quiz.questions.length;
      const independent = S.quiz.answers.filter(answer => answer?.independent);
      extra.missed_questions = S.quiz.answers.flatMap((answer, index) => answer && !answer.ok ? [index] : []);
      const priorMisses = Array.isArray(row.result?.missed_questions) ? row.result.missed_questions : [];
      if (!row.content?.lumi_fallback_band) stats = {
        independent: independent.length, correct: independent.filter(answer => answer.ok).length,
        hints: S.hints, repeated: extra.missed_questions.filter(index => priorMisses.includes(index)).length
      };
      if (module === 'grammar') extra.next_point = row.content?.point || '';
    }
    if (module === 'speaking' && S.speak) {
      extra.checklist = 5;
      extra.seconds_spoken = S.speak.used;
    }
    if (module === 'writing') {
      extra.draft = document.getElementById('lumiWriting').value.trim();
      if (!/[a-z]/i.test(extra.draft)) { toast('先写一点英文，再完成练习。'); return; }
    }
    extra.duration_min = Math.round((Date.now() - S.startedAt) / 60000);
    extra.difficulty_sample = window.Difficulty.normalizeStats(stats);
    S.busy = true;
    try {
      await window.Lesson.finish(module, extra);
      try {
        window.Learn.Session.autoStart = false;
        await window.Learn.Session.end();
      } catch { /* Course result is already saved. */ }
      stopSpeakTimer(); stopListening(); stopAudio(); stopSpeakRec(true);
      const score = S.quiz ? ('答对 ' + extra.score + ' / ' + extra.total) : '学习记录已保存';
      screen('study');
      view.innerHTML = '<section class="card"><h1>练习完成</h1><p>' + esc(score) +
        '</p><button class="btn ghost" data-act="back">返回课程</button></section><section id="lessonDifficultyFeedback"></section>';
      void window.Difficulty.report({ module, level: window.Lesson.difficultyOf(row, module), unitKey: 'lesson:' + row.id,
        stats, mount: document.getElementById('lessonDifficultyFeedback') });
    } catch (error) {
      toast('保存失败：' + (error.message || error));
    } finally {
      S.busy = false;
    }
  }

  // 听力录音（事前用自然音色生成，避免依赖手机朗读；iPhone 静音拨片打开时也能听）
  var AUDIO_MAP = {
    'A Busy Morning': 'assets/audio/listening-01.mp3',
    'At the Supermarket': 'assets/audio/listening-02.mp3',
    'A Short Team Meeting': 'assets/audio/listening-03.mp3',
    'A Phone Call About a Late Order': 'assets/audio/listening-04.mp3',
    'Starting the Machine Safely': 'assets/audio/listening-05.mp3',
    'Checking a Water Pump': 'assets/audio/listening-06.mp3',
    'At the Clinic': 'assets/audio/listening-07.mp3',
    'A Weekend Trip by Train': 'assets/audio/listening-08.mp3'
  };

  // ---------- 朗读 ----------
  function setListen(msg) {
    var el = document.getElementById('listenStatus');
    if (el) el.textContent = msg;
  }

  var Listen = { sentences: [], i: 0, active: false, started: false, single: false, rate: 0.85, epoch: 0 };
  var SpeakRec = { active: false, h: null };

  function splitSentences(t) {
    var src = String(t || '').replace(/\s+/g, ' ').trim();
    if (!src) return [];
    if (typeof Intl.Segmenter === 'function') {
      const segmenter = new Intl.Segmenter('en', { granularity: 'sentence' });
      return Array.from(segmenter.segment(src), entry => entry.segment.trim()).filter(Boolean);
    }
    var out = [], cur = '';
    var enders = '.!?';
    for (var i = 0; i < src.length; i++) {
      var ch = src.charAt(i);
      cur += ch;
      var next = src.charAt(i + 1);
      if (enders.indexOf(ch) >= 0 && (next === '' || next === ' ' || next === '"' || next === "'")) {
        if (cur.trim()) out.push(cur.trim());
        cur = '';
      }
    }
    if (cur.trim()) out.push(cur.trim());
    return out.length ? out : [src];
  }



  function stopSpeakRec(cancel) {
    if (SpeakRec.h) {
      try {
        if (cancel) (SpeakRec.h.abort || SpeakRec.h.stop).call(SpeakRec.h);
        else (SpeakRec.h.stop || SpeakRec.h.abort).call(SpeakRec.h);
      } catch (e) { }
    }
    SpeakRec.h = null; SpeakRec.active = false;
  }

  // 口语自查：只比较「示范句里哪些词没被识别到」，这是听写差异，不是发音评分
  function speakDiff(target, said) {
    var norm = function (s) {
      return String(s || '').toLowerCase().replace(/[^a-z0-9'\s]/g, ' ').split(/\s+/).filter(Boolean);
    };
    var tw = norm(target), sw = norm(said);
    if (!tw.length || !sw.length) return null;
    var bag = {};
    sw.forEach(function (w) { bag[w] = (bag[w] || 0) + 1; });
    var missing = [];
    tw.forEach(function (w) {
      if (bag[w]) { bag[w]--; return; }
      if (missing.indexOf(w) < 0) missing.push(w);
    });
    return { missing: missing.slice(0, 8), total: tw.length, said: sw.length };
  }

  function stopListening() {
    Listen.epoch++;
    Listen.active = false;
    try { if ('speechSynthesis' in window) window.speechSynthesis.cancel(); } catch (e) { }
  }

  function speakSentence(idx) {
    var ss = window.speechSynthesis;
    if (!Listen.active || S.module !== 'listening') { Listen.active = false; return; }
    if (idx >= Listen.sentences.length) {
      Listen.active = false;
      setListen('朗读结束。没听清可以再点「▶ 播放」听一遍。');
      return;
    }
    Listen.i = idx;
    var last = idx, text = Listen.sentences[idx];
    var boundaries = [0];
    // Let the synthesizer carry intonation through adjacent short sentences.
    while (!Listen.single && last < idx + 2 && last + 1 < Listen.sentences.length &&
           text.length + Listen.sentences[last + 1].length + 1 <= 220) {
      boundaries.push(text.length + 1);
      text += ' ' + Listen.sentences[++last];
    }
    var u = new SpeechSynthesisUtterance(text);
    var v = window.Speech?.voiceFor('en-US', { localOnly: Listen.localOnly });
    u.lang = v?.lang || 'en-US';
    if (v) u.voice = v;
    const epoch = Listen.epoch;
    u.rate = Listen.rate;
    u.onstart = function () {
      if (epoch !== Listen.epoch) return;
      Listen.started = true;
      setListen('正在朗读第 ' + (idx + 1) + (last > idx ? '–' + (last + 1) : '') + ' 句…');
    };
    u.onboundary = function (event) {
      if (epoch !== Listen.epoch || !Number.isFinite(event.charIndex)) return;
      for (let i = boundaries.length - 1; i >= 0; i--) {
        if (event.charIndex >= boundaries[i]) { Listen.i = idx + i; break; }
      }
    };
    u.onend = function () {
      if (!Listen.active || epoch !== Listen.epoch) return;
      Listen.i = last;
      if (Listen.single) { Listen.active = false; setListen('本句已播完。'); }
      else speakSentence(last + 1);
    };
    u.onerror = function (ev) {
      if (epoch !== Listen.epoch || ['canceled', 'interrupted'].includes(ev?.error)) return;
      if (!Listen.localOnly && window.Speech?.isRemote(v)) {
        Listen.localOnly = true;
        speakSentence(Listen.i);
        return;
      }
      Listen.active = false;
      var code = (ev && ev.error) || '未知原因';
      setListen('朗读失败：' + code + '，可以先看原文跟读');
      toast('朗读失败：' + code);
    };
    try {
      ss.speak(u);
    } catch (e) {
      Listen.active = false;
      setListen('朗读失败：' + ((e && e.message) || e));
    }
  }



  function playListeningTTS(sentence) {
    if (S.module !== 'listening') return;   // 已离开听力模块：异步回调不得再启动朗读
    var c = (S.row && S.row.content) || {};
    if (!('speechSynthesis' in window)) { setListen('这个浏览器不支持朗读，可以看原文跟读'); toast('这个浏览器不支持朗读'); return; }
    if (!c.transcript) { setListen('这一篇没有可朗读的原文'); return; }

    Listen.epoch++;
    const epoch = Listen.epoch;
    stopAudio();
    window.Speech?.stop();
    var ss = window.speechSynthesis;
    Listen.sentences = splitSentences(c.transcript);
    if (!Listen.sentences.length) return;
    Listen.localOnly = false;
    Listen.single = Number.isInteger(sentence);
    Listen.i = Listen.single ? Math.min(Math.max(sentence, 0), Listen.sentences.length - 1) : 0;
    const startAt = Listen.i;
    Listen.started = false;
    Listen.active = true;

    // iOS 上 pause()/cancel() 残留会让后续 speak() 静默失败，先彻底复位。
    try { ss.cancel(); } catch (e) { }
    try { if (ss.paused) ss.resume(); } catch (e) { }

    setListen('已开始朗读（共 ' + Listen.sentences.length + ' 句）…');
    speakSentence(startAt);   // —— 必须在点击事件里同步调用，iOS Safari 才认这个手势 ——

    // iOS 第一次偶尔没声音：1.5 秒还没开始就自动重试一次（此时语音已被手势解锁）。
    setTimeout(function () {
      if (epoch !== Listen.epoch || !Listen.active || Listen.started) return;
      Listen.started = true;
      Listen.localOnly = true;
      setListen('第一次没有声音，正在再试一次…（iPhone 请确认左侧静音拨片没有打开）');
      try { ss.cancel(); } catch (e) { }
      try { if (ss.paused) ss.resume(); } catch (e) { }
      speakSentence(startAt);
    }, 1500);
  }

  var Playing = { audio: null, url: '', epoch: 0 };

  function stopAudio() {
    Playing.epoch++;
    if (Playing.audio) {
      try { Playing.audio.pause(); Playing.audio.currentTime = 0; } catch (e) { }
    }
  }

  function playRecording(url) {
    // iOS：把音频会话切成播放类型，媒体元素不会被「静音拨片」掐掉（能切就切，切不了也不影响）
    try {
      if (navigator.audioSession && 'type' in navigator.audioSession) navigator.audioSession.type = 'playback';
    } catch (e) { }

    stopListening();
    window.Speech?.stop();
    stopAudio();
    const epoch = Playing.epoch;
    if (!Playing.audio || Playing.url !== url) {
      Playing.audio = new Audio(url);
      Playing.url = url;
      Playing.audio.preload = 'auto';
    }
    var a = Playing.audio;
    a.playbackRate = Listen.rate;
    a.onplay = function () { if (epoch === Playing.epoch) setListen('正在播放录音…'); };
    a.onended = function () { if (epoch !== Playing.epoch || S.module !== 'listening') return; setListen('录音播放结束。可以再点「播放」重听。'); };
    a.onerror = function () {
      if (epoch !== Playing.epoch || S.module !== 'listening') return;
      setListen('录音文件打不开，改用系统朗读…');
      playListeningTTS();
    };
    try { a.currentTime = 0; } catch (e) { }
    setListen('正在载入录音…');
    var pr = null;
    try { pr = a.play(); } catch (e) { setListen('录音播放失败：' + ((e && e.message) || e)); return; }
    if (pr && pr.catch) {
      pr.catch(function () {
        if (epoch !== Playing.epoch) return;
        setListen('浏览器拦了一次，请再点一下「▶ 播放」');
      });
    }
  }

  function playListening() {
    var c = (S.row && S.row.content) || {};
    var file = Object.hasOwn(AUDIO_MAP, c.title) ? AUDIO_MAP[c.title] : null;
    var builtin = window.BUILTIN_LESSONS?.listening?.find(item => item.title === c.title);
    if (file && builtin?.transcript && builtin.transcript === c.transcript) return playRecording(file);
    return playListeningTTS();
  }

  // ---------- 事件 ----------
  document.addEventListener('click', function (ev) {
    var el = ev.target.closest ? ev.target.closest('[data-act]') : null;
    if (!el) return;
    var act = el.getAttribute('data-act');
    if (act === 'sayexample') {
      if (!window.Speech || !window.Speech.say(el.getAttribute('data-en'), { rate: 0.9 })) toast('发音不可用，请检查设置中的发音开关');
      return;
    }
    if (act === 'reload') return renderHome();
    if (act === 'back') { stopSpeakTimer(); try { window.Learn.Session.autoStart = false; window.Learn.Session.end(); } catch (e) { } return renderHome(); }
    if (act.indexOf('start:') === 0) return startModule(act.slice(6));
    if (act.indexOf('opt:') === 0) return answer(S.quiz ? S.quiz.i : 0, parseInt(act.slice(4), 10));
    if (act === 'nextq') {
      var q = S.quiz;
      if (q.i + 1 >= q.questions.length) { q.done = true; } else { q.i += 1; }
      return renderQuiz();
    }
    if (act === 'finish') return finishModule();
    if (act === 'play') return playListening();
    if (act === 'repeatSentence' || act === 'nextSentence') {
      stopAudio();
      return playListeningTTS(Listen.i + (act === 'nextSentence' ? 1 : 0));
    }
    if (act === 'stopplay') { stopAudio(); stopListening(); setListen('已停止播放。'); return; }
    if (act === 'speakdemo') {
      var c2 = (S.row && S.row.content) || {};
      var useServer2 = !!(window.Voice && window.Voice.serverTTSReady && window.Voice.serverTTSReady());
      if (!(window.Voice && (window.Voice.ttsSupported || useServer2))) { toast('这个浏览器不支持朗读，可以看文字跟读'); return; }
      if (window.Voice.speaking()) { window.Voice.stop(); toast('已停止朗读'); return; }
      if (window.Voice.primeAudio) { try { window.Voice.primeAudio(); } catch (e) { } }
      var parts = [];
      (c2.patterns || []).forEach(function (p) { if (p && p.en) parts.push(String(p.en)); });
      if (c2.sample_answer) parts.push(String(c2.sample_answer));
      if (!parts.length) { toast('这一课没有可朗读的示范句'); return; }
      var demoText = parts.join(' ');
      var okSpeak;
      if (useServer2) {
        okSpeak = !!window.Voice.serverSpeak(demoText, {
          rate: 0.88,
          onState: function (st, p2) {
            if (st !== 'error') return;
            if (p2 && p2.code === 'blocked') { toast('浏览器拦截了自动播放，再点一次「听示范」'); return; }
            if (window.Voice.ttsSupported) window.Voice.speak(demoText, { rate: 0.88 });
          }
        });
        toast(okSpeak ? '正在朗读示范句（在线语音），跟着说一遍' : '朗读没能启动，可以看文字跟读');
      } else {
        okSpeak = window.Voice.speak(demoText, { rate: 0.88 });
        toast(okSpeak ? '正在朗读示范句，跟着说一遍' : '朗读没能启动，可以看文字跟读');
      }
      return;
    }
    if (act === 'speakrec') {
      var box = document.getElementById('speakRec');
      if (!(window.Voice && (window.Voice.serverASRReady && window.Voice.serverASRReady()))) return speakRecLocal();
      if (SpeakRec.active) {
        var wasOpening = !!(SpeakRec.h && SpeakRec.h.active && !SpeakRec.h.active());
        stopSpeakRec();
        if (box) box.textContent = wasOpening ? '已取消（麦克风还没开始录音）。准备好再点一次「试着说一遍」。' : '已停止，正在识别这段语音…';
        return;
      }
      var c3 = (S.row && S.row.content) || {};
      var target = String(c3.sample_answer || ((c3.patterns || [])[0] || {}).en || '');
      if (box) box.textContent = '正在打开麦克风…（最多 15 秒，说完再点一下）';
      SpeakRec.active = true;
      SpeakRec.h = window.Voice.serverRecord({
        maxMs: 15000,
        onState: function (st) {
          if (st === 'recording' && box) box.textContent = '在听…说一句英文，说完再点一下「试着说一遍」。';
          if (st === 'recognizing' && box) box.textContent = '正在识别…';
        },
        onText: function (text, meta) {
          SpeakRec.active = false; SpeakRec.h = null;
          if (!box) return;
          if (!text) { box.textContent = '这次没有识别到内容，可以再说一次。'; return; }
          var line = '识别到：' + text + '（这是听写转写，不是发音评分）';
          var d = speakDiff(target, text);
          if (d && d.missing.length) line += ' 示范句里这些词没被识别到：' + d.missing.join('、') + '。可以放慢一点再说一遍。';
          else if (d) line += ' 示范句里的词都识别到了，可以再练一遍语气和停顿。';
          box.textContent = line;
        },
        onError: function (code, message) {
          SpeakRec.active = false; SpeakRec.h = null;
          if (!box) return;
          if (code === 'cancelled') { box.textContent = '已取消语音输入。'; return; }
          if (code === 'too_short') { box.textContent = '说得太短了，完整说一句再停。'; return; }
          if (code === 'speech_daily_limit') { box.textContent = message || '今天的语音次数用完了，明天再练。'; return; }
          box.textContent = '语音识别不可用（' + code + '）；直接说 60 秒再按自查勾选。';
        }
      });
      if (!SpeakRec.h) SpeakRec.active = false;
      return;
    }
    if (act === 'speakstart') return startSpeakTimer();
    if (act === 'speakstop') { stopSpeakTimer(); if (S.speak) S.speak.spoken = true; updateSpeakFinish(); toast('已记录：你开口说了'); return; }
    if (act.indexOf('check:') === 0) {
      var i = parseInt(act.slice(6), 10);
      if (!S.speak) return;
      S.speak.checks[i] = !S.speak.checks[i];
      el.classList.toggle('on', S.speak.checks[i]);
      el.setAttribute('aria-pressed', String(S.speak.checks[i]));
      var box = el.querySelector('.box');
      if (box) box.textContent = S.speak.checks[i] ? '✓' : '';
      updateSpeakFinish();
      return;
    }
    if (act === 'togglesample') {
      var sb = document.getElementById('sampleBox');
      if (sb) { sb.style.display = sb.style.display === 'none' ? 'block' : 'none'; el.textContent = sb.style.display === 'none' ? '看参考答案' : '收起参考答案'; el.setAttribute('aria-expanded', String(sb.style.display !== 'none')); }
      return;
    }
    if (act.indexOf('kw:') === 0) {
      var w = act.slice(3);
      var kws = (S.row && S.row.content && S.row.content.key_words) || [];
      for (var k = 0; k < kws.length; k++) {
        if (String(kws[k].word).toLowerCase() === w) { toast(kws[k].word + ' ' + (kws[k].ipa || '') + ' ' + kws[k].meaning); return; }
      }
    }
  });

  // 阅读里点单词用的是 title/span，没有 data-act：单独处理
  document.addEventListener('click', function (ev) {
    var t = ev.target.closest ? ev.target.closest('.kw') : null;
    if (!t) return;
    var w = t.getAttribute('data-kw');
    var kws = (S.row && S.row.content && S.row.content.key_words) || [];
    for (var k = 0; k < kws.length; k++) {
      if (String(kws[k].word).toLowerCase() !== w) continue;
      if (S.module === 'reading' && S.quiz && !S.quiz.done && !S.quiz.answers[S.quiz.i]) {
        S.hints++;
        S.hinted.add(S.quiz.i);
      }
      toast(kws[k].word + ' ' + (kws[k].ipa || '') + ' ' + kws[k].meaning);
      return;
    }
  });

  (function bindLogout() {
    var b = document.getElementById('btnLogout');
    if (!b) return;
    b.addEventListener('click', async function () {
      await window.AppAuth.logout();
    });
  })();

  window.addEventListener('error', function (e) { toast('出错：' + (e.message || '未知错误')); });
  window.addEventListener('unhandledrejection', function (e) { toast('出错：' + ((e.reason && e.reason.message) || e.reason || '未知错误')); });

  // 启动
  (async function boot() {
    try {
      var u = await window.AppAuth.requireLogin();
      if (!u) return;
      if (u && document.getElementById('userName')) document.getElementById('userName').textContent = (u.email || '').split('@')[0] + ' · 已登录';
    } catch (e) { return; }
    // 付费语音灰度：确认账号是否在服务端名单内；不在名单时继续用本机音色/听写。
    try { if (window.Voice && Voice.initServerAccess) await Voice.initServerAccess(); } catch (e) { }
    // 离开页面（切后台/关闭）时停止所有朗读与录音，避免后台继续出声或继续采集麦克风。
    function pageCleanup() {
      try { if (window.Speech) window.Speech.stop(); } catch (e) {}
      try { window.Voice && window.Voice.stop(); } catch (e) { }
      try { stopSpeakRec(true); } catch (e) { }
      try { stopListening(); } catch (e) { }
      try { stopSpeakTimer(); } catch (e) { }
      try { stopAudio(); } catch (e) { }
    }
    document.addEventListener('visibilitychange', function () { if (document.hidden) pageCleanup(); });
    window.addEventListener('pagehide', pageCleanup);

    var ready = false;
    try { await window.Lesson.ready(); ready = true; } catch (e) { /* 保留原首页降级，不自动开启模块 */ }
    try { if (window.Learn && window.Learn.Session) { window.Learn.Session.autoStart = false; window.Learn.Session.bindEvents(); } } catch (e) { }
    // 仅接受已存在的四个模块；一次性消费直达参数，避免刷新或返回重复开启会话。
    var requested = null;
    try { requested = new URLSearchParams(location.search).get('module'); } catch (e) { }
    if (ready && window.Lesson.MODULES.indexOf(requested) !== -1) {
      try {
        var url = new URL(location.href);
        url.searchParams.delete('module');
        history.replaceState(history.state, '', url.pathname + url.search + url.hash);
      } catch (e) { }
      return startModule(requested);
    }
    renderHome();
  })();
})();
