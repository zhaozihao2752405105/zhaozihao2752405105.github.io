/* ============================================================
 * assets/study.js —— 今日学习 / 到期复习 共享控制器
 * 依赖：app.css、config.js、supabase CDN、db.js、auth.js、queue.js、learning.js
 * 页面用法：<body data-mode="today"> ... StudyUI.boot()
 * 本阶段零 AI 调用：内容全部来自 get_or_create_daily_task 返回的任务条目。
 * 记录三态：提交成功后显示 sent/dead，离线排队显示 queued（不得显示成已保存）。
 * ============================================================ */
window.StudyUI = (function () {
  'use strict';

  var MODE = 'today';           // 'today' | 'review'
  var S = {
    user: null,
    status: 'loading',          // loading|error|home|study|done
    error: '',
    task: null,
    allItems: [],               // 当前模块（new/review）的全部条目
    queue: [],                  // 待学习条目
    doneInitial: 0,           // 加载时已完成
    skippedInit: 0,           // 加载时已跳过
    idx: 0,
    done: 0,
    skipped: 0,
    phase: 'card',              // card|quiz|quiz_fb|spell|spell_fb|retry|retry_fb|saving|item_done
    firstResult: null,          // 'correct'|'incorrect' 首次作答（决定 SM-2 调度）
    attemptNo: 0,
    itemStart: 0,
    options: [],
    picked: null,
    lastSave: null,             // {status,message}
    busy: false,
    elapsed: 0,
    lastTickSec: 0,
    lastState: '',
    starting: false,
    pending: 0,
    offlineView: false,      // 当前显示的是本机缓存快照（断网）
    cacheDate: '',           // 快照对应的日期
    offlineStudy: false,     // 无网络时继续学：记录先存本机，联网后补交
    localTimer: null
  };

  var view = null;
  var toastTimer = null;

  // ---------- 小工具 ----------
  function esc(s) {
    return String(s == null ? '' : s)
      .replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;')
      .replace(/"/g, '&quot;').replace(/'/g, '&#39;');
  }
  function $(id) { return document.getElementById(id); }
  // 真实学习状态开关：只有进入学习页且会话确实要用时才允许「回前台自动建会话」
  function setAuto(on) {
    try { if (window.Learn && window.Learn.Session) window.Learn.Session.autoStart = !!on; } catch (e) { }
  }
  function toast(msg, ms) {
    var el = $('toast');
    if (!el) return;
    el.textContent = msg;
    el.className = 'toast on';
    if (toastTimer) clearTimeout(toastTimer);
    toastTimer = setTimeout(function () { el.className = 'toast'; }, ms || 2400);
  }
  function fmt(sec) {
    sec = Math.max(0, Math.floor(sec || 0));
    var m = Math.floor(sec / 60), s = sec % 60;
    return (m < 10 ? '0' : '') + m + ':' + (s < 10 ? '0' : '') + s;
  }
  function normSpell(v) {
    return String(v || '').toLowerCase().replace(/[\s\-']/g, '');
  }
  function pct(a, b) { return b > 0 ? Math.round(a * 100 / b) : 0; }
  function todayStr() {
    var d = new Date();
    var m = d.getMonth() + 1, dd = d.getDate();
    return d.getFullYear() + '-' + (m < 10 ? '0' : '') + m + '-' + (dd < 10 ? '0' : '') + dd;
  }
  // 学习日（yyyy-mm-dd）转成中文短日期：11月26日 周四；解析失败时原样返回
  function cnDate(s) {
    var m = /^(\d{4})-(\d{2})-(\d{2})$/.exec(String(s || ''));
    if (!m) return String(s || '');
    var d = new Date(Number(m[1]), Number(m[2]) - 1, Number(m[3]));
    if (isNaN(d.getTime())) return String(s || '');
    var w = ['周日', '周一', '周二', '周三', '周四', '周五', '周六'][d.getDay()];
    return Number(m[2]) + '月' + Number(m[3]) + '日 ' + w;
  }

  // ---------- 选项生成 ----------
  var FALLBACK_MEANINGS = [
    'n. 机器；机械', 'n. 维护；保养', 'n. 测试；试验', 'n. 设备；装置',
    'v. 检查；检验', 'n. 病人；患者', 'n. 零件；部件', 'n. 安全；安全措施'
  ];
  function buildOptions(item) {
    var pool = [], seen = {};
    S.allItems.forEach(function (it) {
      if (!it || !it.meaning) return;
      if (it.word_id === item.word_id) return;
      if (seen[it.meaning]) return;
      seen[it.meaning] = true;
      pool.push(it.meaning);
    });
    for (var i = 0; i < FALLBACK_MEANINGS.length && pool.length < 3; i++) {
      if (!seen[FALLBACK_MEANINGS[i]]) { seen[FALLBACK_MEANINGS[i]] = true; pool.push(FALLBACK_MEANINGS[i]); }
    }
    // 洗牌后取 3 个干扰项，再和正确项混合
    for (var j = pool.length - 1; j > 0; j--) {
      var k = Math.floor(Math.random() * (j + 1)); var t = pool[j]; pool[j] = pool[k]; pool[k] = t;
    }
    var opts = [item.meaning].concat(pool.slice(0, 3));
    for (var m = opts.length - 1; m > 0; m--) {
      var n = Math.floor(Math.random() * (m + 1)); var tmp = opts[m]; opts[m] = opts[n]; opts[n] = tmp;
    }
    return opts;
  }

  // ---------- 页面骨架 ----------
  function renderTopbar() {
    var name = $('userName');
    if (name && S.user) name.textContent = window.AppAuth.displayName(S.user) + ' · 已登录';
  }

  function renderShell(inner, screen, phase, feedback) {
    // 仅展示状态，不参与学习状态机；每次渲染清除旧状态样式。
    view.setAttribute('data-screen', screen || 'status');
    if (phase) view.setAttribute('data-phase', phase); else view.removeAttribute('data-phase');
    if (feedback) view.setAttribute('data-feedback', feedback); else view.removeAttribute('data-feedback');
    view.innerHTML = inner;
  }

  function progress() {
    var total = S.allItems.length;
    var done = S.doneInitial + S.done;
    var skipped = S.skippedInit + S.skipped;
    return { total: total, done: done, skipped: skipped, pct: pct(done, total) };
  }

  function itemLabel(item) { return item.task_type === 'review' ? '复习' : '新词'; }
  function domainLabel(d) {
    var map = { gen: '通用', work: '职场', mech: '机械', med: '医疗', test: '测试' };
    return map[d] || '';
  }

  // ---------- 渲染：加载 / 错误 ----------
  function renderLoading() {
    renderShell('<div class="card center"><p class="muted">正在准备今天的学习内容…</p></div>');
  }
  function renderError() {
    var off = S.offline;
    renderShell(
      '<div class="card">' +
      '<h3>' + (off ? '现在没有网络' : '加载失败') + '</h3>' +
      '<p class="small muted">' + esc(S.error || '未知错误') + '</p>' +
      (off ? '<p class="small muted">今天的学习内容需要联网才能打开。你之前没交上去的学习记录还在本机，联网后会自己补交，不会丢。</p>' +
        '<div class="ex-line"><span>本机待补交</span><span class="zh" id="pendingCount">— 条</span></div>' : '') +
      '<div class="row mt12"><button class="btn" data-act="reload">重试</button>' +
      '<a class="btn ghost" href="books.html">词书中心</a>' +
      '<button class="btn ghost" data-act="logout">重新登录</button></div>' +
      '</div>');
    if (off) refreshPending();
  }

  // ---------- 渲染：首页（Lavender Future 展示层，2026-11-26） ----------
  // 今日页与复习页共享材质、进度和操作组件。
  function renderQuickLinks(aiOn) {
    var h = '<div class="v2-quicklist">';
    if (aiOn) {
      h += '<a class="card aicoach v2-quick v2-coach" href="chat.html?v=20261127p"><span class="v2-coach-orb" aria-hidden="true"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.7" stroke-linecap="round"><path d="M5 10v4m4-7v10m6-12v14m4-9v4"/></svg></span><span class="aicoach-txt"><b>AI 英语老师</b><i>自由提问 · 双语文字交流</i></span><span class="aicoach-go" aria-hidden="true">›</span></a>';
    }
    h += '<a class="card aicoach v2-quick v2-books" href="books.html?v=20261127p"><span class="aicoach-ico" aria-hidden="true"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.7" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true" focusable="false"><path d="M4 19V5a2 2 0 0 1 2-2h14v18H6a2 2 0 0 1 0-4h14"/><path d="m9 12 2.5-6L14 12M10 10h3"/></svg></span><span class="aicoach-txt"><b>词书中心</b><i>选词书 · 调整每日词量</i></span><span class="aicoach-go" aria-hidden="true">›</span></a></div>';
    return h;
  }

  // B2 学习教练卡：首屏先占位，渲染完再异步补真实数据；读不到就明说读不到，不显示假进度。
  function coachLevelLabel(n) { return ['', 'L1 基础', 'L2 进阶', 'L3 挑战'][n] || 'L1 基础'; }
  function coachHref(h) { return /^[a-z0-9][a-z0-9?=&._-]*$/i.test(String(h || '')) ? h : 'memory.html'; }
  function coachCardHtml(p) {
    if (!p) {
      return '<div class="v2-coach-head"><span class="v2-coach-orb" aria-hidden="true">✦</span><div><b>今日建议</b><small>暂时读不到你的学习记录</small></div></div>' +
        '<p class="v2-coach-advice">现在可能是离线，或数据还没同步。先按计划学习，记录会保存在本机；联网后再看建议。</p>' +
        '<a class="v2-coach-link" href="memory.html">查看学习档案 ›</a>';
    }
    if (p.enabled === false) {
      return '<div class="v2-coach-head"><span class="v2-coach-orb" aria-hidden="true">✦</span><div><b>今日建议</b><small>学习档案已关闭</small></div></div>' +
        '<p class="v2-coach-advice">你关闭了「学习档案与教学记忆」，AI 老师和今日建议都不会读取你的学习记录。</p>' +
        '<a class="v2-coach-link" href="memory.html">去重新开启 ›</a>';
    }
    var lv = p.level || {};
    var sm = p.sample || {};
    var sample = sm.units ? '近 14 天 ' + sm.units + ' 题 · 正确率 ' + Math.round((sm.accuracy || 0) * 100) + '%' : '样本还少';
    var h = '<div class="v2-coach-head"><span class="v2-coach-orb" aria-hidden="true">✦</span><div><b>今日建议</b><small>' + esc(coachLevelLabel(lv.suggested || lv.base || 1)) + ' · ' + esc(sample) + '</small></div></div>';
    h += '<p class="v2-coach-advice">' + esc(p.advice || '按计划完成今天的学习。') + '</p>';
    var focus = (p.focus || []).slice(0, 3);
    if (focus.length) {
      h += '<div class="v2-coach-focus">';
      focus.forEach(function (f) {
        h += '<a class="v2-coach-chip" href="' + esc(coachHref(f.href)) + '">' + esc(f.label || '继续') + '<span aria-hidden="true">›</span></a>';
      });
      h += '</div>';
    }
    h += '<a class="v2-coach-link" href="memory.html">学习档案与教学记忆 ›</a>';
    return h;
  }
  async function hydrateCoachCard() {
    var node = document.getElementById('coachCard');
    if (!node || !window.DB || !window.DB.learnerProfile) return;
    var p = null;
    try { p = await window.DB.learnerProfile(); } catch (e) { p = null; }
    if (!node.isConnected) return;
    node.innerHTML = coachCardHtml(p);
    node.hidden = false;
    node.classList.add('is-ready');
  }

  function renderTodayHome() {
    var p = progress();
    var items = (S.task && S.task.items) || [];
    var rev = items.filter(function (i) { return i.task_type === 'review'; });
    var revDone = rev.filter(function (i) { return i.status === 'completed'; }).length;
    var canStart = S.queue.length > 0;
    var aiOn = !!(window.APP_CONFIG && window.APP_CONFIG.FEATURES && window.APP_CONFIG.FEATURES.AI_CHAT);
    var iconPaths = {
      word: '<path d="M4 19V5a2 2 0 0 1 2-2h14v18H6a2 2 0 0 1 0-4h14"/><path d="m9 12 2.5-6L14 12M10 10h3"/>',
      grammar: '<path d="M4 5h16M4 10h10M4 15h7M4 20h6"/><path d="m14 17 3 3 4-6"/>',
      listening: '<path d="M3 13v-2a9 9 0 0 1 18 0v2"/><rect x="3" y="12" width="5" height="8" rx="2"/><rect x="16" y="12" width="5" height="8" rx="2"/>',
      reading: '<path d="M12 6c-3-3-7-3-10-2v15c4-1 7-1 10 2 3-3 6-3 10-2V4c-3-1-7-1-10 2v15"/>',
      speaking: '<rect x="9" y="3" width="6" height="12" rx="3"/><path d="M5 11v1a7 7 0 0 0 14 0v-1M12 19v3m-4 0h8"/>'
    };
    function ico(key) {
      return '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.7" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true" focusable="false">' + iconPaths[key] + '</svg>';
    }
    var h = '<div class="v2-home v2-home-next' + (S.offlineView ? ' v2-home-offline' : '') + '">';
    h += '<section class="v2-welcome"><div class="v2-welcome-date">' + esc(cnDate(S.task && S.task.study_date)) + (S.offlineView ? ' · 缓存任务' : '') + '</div><h1>今天，学点英语。</h1><p>按自己的节奏，让进步一点点发生。</p></section>';
    if (S.offlineView) {
      var stale = S.cacheDate && S.cacheDate !== todayStr();
      h += '<div class="card v2-offline"><b>离线查看</b><p class="small muted mt8">' + (stale ? '显示 ' + esc(S.cacheDate) + ' 的内容，联网后刷新。' : '显示上次同步的内容，联网后刷新。') + ' 学习记录会先存在本机，联网后自动补交。</p></div>';
    }
    h += '<section class="card v2-coach-card" id="coachCard" aria-live="polite" hidden></section>';
    h += '<section class="card v2-hero" id="today-word" aria-labelledby="v2-word-title"><div class="v2-hero-head"><div class="hero-txt"><div class="v2-hero-kicker"><span></span> 单词计划</div><h2 class="hero-title" id="v2-word-title">' + (canStart ? '今日新词' : (p.total === 0 ? '暂无待学新词' : (p.skipped === p.total ? '本轮新词已跳过' : (p.skipped ? '本轮新词学习结束' : '今日新词已完成')))) + '</h2>';
    h += '<div class="hero-sub">已完成 <b>' + p.done + ' / ' + p.total + '</b> 个' + (canStart ? ' · 剩余 ' + S.queue.length + ' 个' : '') + (p.skipped ? ' · 跳过 ' + p.skipped + ' 个' : '') + '</div></div>';
    h += '<div class="v2-progress-orb"><div class="ring" style="--p:' + p.pct + '" role="img" aria-label="新词完成率 ' + p.pct + '%"><span>' + (p.total ? p.pct + '%' : '—') + '</span></div><small>新词进度</small></div></div>';
    h += '<div class="v2-hero-actions">';
    if (canStart) h += '<button type="button" class="btn block" data-act="start">' + (p.done + p.skipped > 0 ? '继续学习' : '开始学习') + '<span aria-hidden="true">›</span></button>';
    else h += '<a class="btn block" href="lesson.html">继续其他课程<span aria-hidden="true">›</span></a><button type="button" class="btn ghost sm v2-refresh" data-act="reload">刷新任务</button>';
    h += '</div></section>';
    h += '<section class="v2-modules" aria-labelledby="v2-mod-title"><div class="v2-section-head"><h2 id="v2-mod-title">学习模块</h2><a href="lesson.html">全部课程 ›</a></div><div class="v2-module-grid">';
    h += (canStart ? '<button type="button" class="v2-module v2-module--word" data-act="start">' : '<a class="v2-module v2-module--word" href="#today-word">') + '<span class="v2-module-icon">' + ico('word') + '</span><b>单词</b><small>词汇</small>' + (canStart ? '</button>' : '</a>');
    [['grammar','语法','规则'],['listening','听力','听懂'],['reading','阅读','理解'],['speaking','口语','表达']].forEach(function (m) {
      h += '<a class="v2-module v2-module--' + m[0] + '" href="lesson.html?module=' + m[0] + '"><span class="v2-module-icon">' + ico(m[0]) + '</span><b>' + m[1] + '</b><small>' + m[2] + '</small></a>';
    });
    h += '</div></section>';
    h += renderQuickLinks(aiOn);
    h += '<section class="card v2-overview" aria-labelledby="v2-overview-title"><div class="v2-section-head"><h2 id="v2-overview-title">今日概览</h2><a href="stats.html">学习统计 ›</a></div><div class="v2-metrics">';
    h += '<div class="v2-metric"><b>' + p.done + ' / ' + p.total + '</b><span>新词</span></div><div class="v2-metric"><b>' + revDone + ' / ' + rev.length + '</b><span>到期复习</span></div><div class="v2-metric"><b id="pendingCount">' + S.pending + ' 条</b><span>待补交</span></div></div>';
    h += '<div class="v2-actions"><button type="button" class="btn ghost sm" data-act="flush">补交本机记录</button><a class="btn ghost sm" href="review.html">去到期复习</a></div></section>';
    h += '</div>';
    renderShell(h, 'home');
    hydrateCoachCard();
  }

  function renderHome() {
    if (MODE === 'today') return renderTodayHome();
    var p = progress();
    var canStart = S.queue.length > 0;
    var aiOn = !!(window.APP_CONFIG && window.APP_CONFIG.FEATURES && window.APP_CONFIG.FEATURES.AI_CHAT);
    var newAll = ((S.task && S.task.items) || []).filter(function (i) { return i.task_type === 'new'; });
    var newDone = newAll.filter(function (i) { return i.status === 'completed'; }).length;
    var html = '<div class="v2-home v2-review-home' + (S.offlineView ? ' v2-review-offline' : '') + '">';
    html += '<section class="v2-welcome"><div class="v2-welcome-date">' + esc(cnDate(S.task && S.task.study_date)) + (S.offlineView ? ' · 缓存任务' : '') + '</div><h1>温故，知新。</h1><p>复习已经学过的单词，让记忆更牢固。</p></section>';
    if (S.offlineView) {
      var staleTip = S.cacheDate && S.cacheDate !== todayStr() ? '显示 ' + esc(S.cacheDate) + ' 的内容，联网后刷新。' : '显示上次同步的内容，联网后刷新。';
      html += '<div class="card v2-offline"><b>离线查看</b><p class="small muted mt8">' + staleTip + ' 学习记录会先存在本机，联网后自动补交。</p></div>';
    }
    html += '<section class="card v2-hero" aria-labelledby="v2-review-title"><div class="v2-hero-head"><div class="hero-txt"><div class="v2-hero-kicker"><span></span> 复习计划</div><h2 class="hero-title" id="v2-review-title">到期单词</h2><div class="hero-sub">已完成 <b>' + p.done + ' / ' + p.total + '</b> 个' + (canStart ? ' · 剩余 ' + S.queue.length + ' 个' : '') + (p.skipped ? ' · 跳过 ' + p.skipped + ' 个' : '') + '</div></div>';
    html += '<div class="v2-progress-orb"><div class="ring" style="--p:' + p.pct + '" role="img" aria-label="复习完成率 ' + p.pct + '%"><span>' + (p.total ? p.pct + '%' : '—') + '</span></div><small>复习进度</small></div></div>';
    html += '<div class="v2-hero-actions"><button class="btn block" data-act="' + (canStart ? 'start' : 'reload') + '">' + (canStart ? (p.done + p.skipped > 0 ? '继续复习' : '开始复习') : '刷新任务') + '</button></div></section>';
    html += '<section class="card v2-overview"><div class="v2-section-head"><h2>今日概览</h2><a href="stats.html">学习统计 ›</a></div><div class="v2-metrics"><div class="v2-metric"><b>' + newDone + ' / ' + newAll.length + '</b><span>新词</span></div><div class="v2-metric"><b>' + p.done + ' / ' + p.total + '</b><span>到期复习</span></div><div class="v2-metric"><b id="pendingCount">' + S.pending + ' 条</b><span>待补交</span></div></div><div class="v2-actions"><button class="btn ghost sm" data-act="flush">补交本机记录</button><a class="btn ghost sm" href="today.html">去今日新词</a></div></section>';
    html += renderQuickLinks(aiOn) + '</div>';
    renderShell(html, 'home');
  }

  // ---------- 渲染：学习流 ----------
  function currentItem() { return S.queue[S.idx] || null; }

  function studyHead(item) {
    var p = progress();
    var html = '<div class="study-head">';
    html += '<div class="row" style="align-items:center">';
    html += '<span class="pill">' + itemLabel(item) + '</span>';
    var posBase = S.done + S.doneInitial + S.skipped + S.skippedInit;
    var posNow = Math.max(1, Math.min(p.total, posBase + (S.phase === 'item_done' ? 0 : 1)));
    html += '<span class="muted small">第 ' + posNow + ' / ' + p.total + ' 个</span>';
    if (S.offlineStudy) html += '<span class="pill">离线</span>';
    html += '<span class="spacer"></span>';
    html += '<span class="badge" id="timer">' + fmt(S.elapsed) + '</span>';
    html += '</div>';
    html += '<div class="bar mt8" role="progressbar" aria-label="已完成比例" aria-valuemin="0" aria-valuemax="100" aria-valuenow="' + p.pct + '"><i style="width:' + p.pct + '%"></i></div>';
    html += '</div>';
    return html;
  }

  // 发音按钮：点击后在同一个手势里朗读（iPhone Safari 要求），播放期间按钮显示「朗读中」
  function sayBtn(word, where) {
    var w = esc(word || '');
    return '<div class="say-row"><button class="say-btn" data-act="say" data-w="' + w + '" data-where="' + esc(where || '') + '" title="朗读这个词（浏览器自带语音）"><svg viewBox="0 0 24 24" width="20" height="20" fill="none" stroke="currentColor" stroke-width="1.7" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M3 9h4l5-4v14l-5-4H3zM16 9a4 4 0 0 1 0 6m3-9a8 8 0 0 1 0 12"/></svg><span class="say-txt">听发音</span></button></div>';
  }

  function wordCard(item, compact) {
    var html = '<div class="wordcard">';
    html += '<div class="hero-date">' + esc(domainLabel(item.domain)) + (item.difficulty ? ' · 难度 ' + esc(item.difficulty) : '') + '</div>';
    html += '<div class="word-en">' + esc(item.word) + '</div>';
    html += '<div class="word-ipa">' + esc(item.ipa || '') + '</div>';
    html += sayBtn(item.word, 'word');
    html += '<div class="word-cn">' + esc(item.meaning || '') + '</div>';
    if (!compact) {
      if (item.example_en) {
        html += '<div class="word-ex"><b>' + esc(item.example_en) + '</b>';
        if (item.example_zh) html += '<div class="mt8">' + esc(item.example_zh) + '</div>';
        html += '</div>';
      }
    }
    html += '</div>';
    return html;
  }

  function optionsHtml(item, picked, reveal) {
    var html = '';
    for (var i = 0; i < S.options.length; i++) {
      var opt = S.options[i];
      var cls = 'opt';
      if (reveal) {
        if (opt === item.meaning) cls += ' right';
        else if (picked != null && i === picked) cls += ' wrong';
      }
      html += '<button class="' + cls + '" data-act="pick" data-i="' + i + '"' + (reveal ? ' disabled' : '') + '>';
      html += '<span class="k">' + String.fromCharCode(65 + i) + '</span><span>' + esc(opt) + '</span></button>';
    }
    return html;
  }

  function renderStudy() {
    var item = currentItem();
    if (!item) { renderDone(); return; }
    var html = studyHead(item);
    var stage = { card:'认识单词', quiz:'词义选择', quiz_fb:'词义反馈', spell:'拼写练习', spell_fb:'拼写反馈', retry:'当轮复现', retry_fb:'复现反馈', saving:'保存记录', item_done:'本词结果' };
    html += '<div class="v2-study-stage">' + stage[S.phase] + '</div>';

    if (S.phase === 'card') {
      html += wordCard(item, false);
      html += '<div class="card tight">';
      html += '<p class="small muted">先读一遍单词和例句，再开始答题。不会就点「跳过」，不算错误、不进复习安排。</p>';
      html += '<div class="row mt8"><button class="btn block" data-act="toquiz"' + (S.busy ? ' disabled' : '') + '>开始答题</button></div>';
      html += '<div class="row mt8"><button class="btn ghost sm" data-act="skip"' + (S.busy ? ' disabled' : '') + '>跳过这个词</button></div>';
      html += '</div>';
    } else if (S.phase === 'quiz' || S.phase === 'retry') {
      html += '<div class="card tight"><h3>' + (S.phase === 'retry' ? '当轮复现：再选一次' : '选出正确的中文意思') + '</h3>';
      html += '<div class="word-en" style="font-size:26px">' + esc(item.word) + '</div>';
      html += '<div class="word-ipa">' + esc(item.ipa || '') + '</div>';
      html += sayBtn(item.word, 'quiz');
      html += optionsHtml(item, null, false);
      html += '</div>';
      html += wordExSmall(item);
    } else if (S.phase === 'quiz_fb') {
      var ok = S.pickedMeaningOk;
      html += '<div class="card tight">';
      html += '<h3>' + (ok ? '答对了' : '答错了') + '</h3>';
      html += '<div class="word-en" style="font-size:26px">' + esc(item.word) + '</div>';
      html += '<div class="word-ipa">' + esc(item.ipa || '') + '</div>';
      html += sayBtn(item.word, 'feedback');
      html += '<div class="word-cn">' + esc(item.meaning || '') + '</div>';
      if (!ok) html += '<div class="note mt12">这个词会在本轮再练一次；最终复习安排只按这次（第一次）的作答计算。</div>';
      html += '<div class="row mt16"><button class="btn block" data-act="tospell">继续：拼写这个词</button></div>';
      html += '</div>';
    } else if (S.phase === 'spell') {
      html += '<div class="card tight"><h3>拼写这个词</h3>';
      html += '<div class="word-cn">' + esc(item.meaning || '') + '</div>';
      html += '<p class="muted small mt8">提示：' + esc(firstLetterHint(item.word)) + '，共 ' + item.word.replace(/[^A-Za-z]/g, '').length + ' 个字母</p>';
      html += '<div class="field mt8"><input id="spellInput" aria-label="输入英文单词" type="text" autocomplete="off" autocapitalize="off" autocorrect="off" spellcheck="false" placeholder="在这里输入英文单词"></div>';
      html += '<div class="row"><button class="btn block" data-act="spell"' + (S.busy ? ' disabled' : '') + '>提交拼写</button></div>';
      html += '</div>';
    } else if (S.phase === 'spell_fb') {
      var sok = S.spellOk;
      html += '<div class="card tight">';
      html += '<h3>' + (sok ? '拼写正确' : '拼写有误') + '</h3>';
      html += '<div class="word-en" style="font-size:26px">' + esc(item.word) + '</div>';
      html += '<div class="word-cn">' + esc(item.meaning || '') + '</div>';
      if (!sok) html += '<div class="note mt12">你输入的是「' + esc(S.spellInput || '（空）') + '」。拼写不计入复习安排，但仍会记入学习记录。</div>';
      html += '<div class="row mt16"><button class="btn block" data-act="' + (S.firstResult === 'incorrect' ? 'toretry' : 'save') + '">';
      html += (S.firstResult === 'incorrect' ? '继续：当轮复现' : '完成这个词') + '</button></div>';
      html += '</div>';
    } else if (S.phase === 'retry_fb') {
      html += '<div class="card tight">';
      html += '<h3>' + (S.retryOk ? '复现答对了' : '复现又答错了') + '</h3>';
      html += '<div class="word-en" style="font-size:26px">' + esc(item.word) + '</div>';
      html += '<div class="word-ipa">' + esc(item.ipa || '') + '</div>';
      html += '<div class="word-cn">' + esc(item.meaning || '') + '</div>';
      html += '<div class="note mt12">本轮复现只用于巩固，不会改变按第一次作答计算的复习间隔。这个词明天会再次出现。</div>';
      html += '<div class="row mt16"><button class="btn block" data-act="save">完成这个词</button></div>';
      html += '</div>';
    } else if (S.phase === 'saving') {
      html += '<div class="card center"><p class="muted">正在保存作答…</p></div>';
    } else if (S.phase === 'item_done') {
      var st = S.lastSave || {};
      var map = {
        sent: '已保存到云端',
        queued: '已在本机排队，联网后自动补交',
        dead: '这条记录被服务端拒绝，不会再重试',
        rejected: '这个条目之前已按另一个答案提交，本次没有覆盖'
      };
      html += '<div class="card tight">';
      html += '<h3>' + (st.status === 'sent' ? '本词记录已提交' : '本词处理结果') + '</h3>';
      html += wordCard(item, true);
      html += '<div class="note mt12">' + esc(map[st.status] || st.message || '已记录') + '</div>';
      if (st.status === 'queued') html += '<p class="small muted mt8">本机还有 ' + S.pending + ' 条待补交记录，回到列表页可点「补交本机记录」。</p>';
      html += '<div class="row mt16"><button class="btn block" data-act="next">' + (S.idx + 1 < S.queue.length ? '下一个词' : '查看今日结果') + '</button></div>';
      html += '</div>';
    }
    var feedback = S.phase === 'quiz_fb' ? (S.pickedMeaningOk ? 'correct' : 'incorrect') :
      S.phase === 'spell_fb' ? (S.spellOk ? 'correct' : 'incorrect') :
      S.phase === 'retry_fb' ? (S.retryOk ? 'correct' : 'incorrect') : '';
    renderShell(html, 'study', S.phase, feedback);
    if (S.phase === 'spell') {
      var inp = $('spellInput');
      if (inp) {
        inp.value = '';
        setTimeout(function () { try { inp.focus(); } catch (e) { /* iOS 需用户手势，忽略 */ } }, 30);
      }
    }
  }

  function wordExSmall(item) {
    if (!item.example_en) return '';
    var html = '<div class="card tight"><p class="small muted">例句（只给英文，答题时参考）</p>';
    html += '<p class="small"><b>' + esc(item.example_en) + '</b></p>';
    html += '</div>';
    return html;
  }

  function firstLetterHint(word) {
    var w = String(word || '');
    if (w.length <= 2) return w.charAt(0) + '…';
    return w.charAt(0) + new Array(Math.max(1, w.length - 2)).join('_') + w.charAt(w.length - 1);
  }

  // ---------- 渲染：完成 ----------
  function renderDone() {
    var p = progress();
    var html = '<div class="card center">';
    var label = MODE === 'review' ? '复习' : '新词学习';
    var heading = !p.total ? (MODE === 'review' ? '暂无到期单词' : '暂无待学新词') :
      p.skipped === p.total ? '本轮' + label + '已跳过' : p.skipped ? '本轮' + label + '结束' :
      p.done === p.total ? '今日' + label + '已完成' : '本轮' + label + '结果';
    html += '<h2>' + heading + '</h2>';
    html += '<p class="muted">本轮共 ' + p.total + ' 个词，已完成 ' + p.done + ' 个，已跳过 ' + p.skipped + ' 个。当前学习用时 ' + fmt(S.elapsed) + '。</p>';
    if (MODE === 'today') {
      html += '<div class="row mt16"><a class="btn block" href="lesson.html">继续其他课程（语法·听力·阅读·口语）</a></div>';
      html += '<div class="row mt8"><a class="btn ghost block" href="review.html">去到期复习</a></div>';
    } else {
      html += '<div class="row mt16"><a class="btn block" href="today.html">去今日新词</a></div>';
      html += '<div class="row mt8"><a class="btn ghost block" href="lesson.html">学习其他课程（语法·听力·阅读·口语）</a></div>';
    }
    html += '<div class="row mt8"><button class="btn ghost block" data-act="home">回到任务列表</button></div>';
    html += '</div>';
    if (S.offlineStudy) {
      html += '<div class="note mt12">这次是离线学习：记录已存在本机，回到联网状态后会自动补交。</div>';
    }
    if (S.pending > 0) {
      html += '<div class="note mt12">本机还有 ' + S.pending + ' 条记录没有提交成功。联网后会自动补交，也可以手动重试。</div>';
      html += '<div class="row mt8"><button class="btn ghost sm" data-act="flush">立即补交</button></div>';
    }
    renderShell(html, 'done');
  }

  // ---------- 数据流程 ----------
  function refreshPending() {
    return window.Learn.pendingCount().then(function (n) {
      S.pending = n || 0;
      var el = $('pendingCount');
      if (el) el.textContent = S.pending + ' 条';
      return S.pending;
    }).catch(function () { return S.pending; });
  }

  function applyTask(task, opt) {
    opt = opt || {};
    S.task = task || {};
    var items = S.task.items || [];
    S.allItems = items.filter(function (it) { return it.task_type === (MODE === 'review' ? 'review' : 'new'); });
    S.queue = S.allItems.filter(function (it) { return it.status === 'pending'; });
    S.doneInitial = S.allItems.filter(function (it) { return it.status === 'completed'; }).length;
    S.skippedInit = S.allItems.filter(function (it) { return it.status === 'skipped'; }).length;
    S.offlineView = opt.offline === true;
    S.cacheDate = opt.cacheDate || '';
    S.idx = 0; S.done = 0; S.skipped = 0; S.phase = 'card'; S.lastSave = null; S.firstResult = null;
    S.offlineStudy = false;
    if (S.localTimer) { clearInterval(S.localTimer); S.localTimer = null; }
    S.status = S.queue.length > 0 ? 'home' : 'done';
    if (S.status === 'done' && MODE !== 'today') { renderDone(); } else { renderHome(); }
    refreshPending();
  }

  // 断网/连不上服务器时：读本机快照渲染，不再只给「加载失败」
  function loadCachedTask(uid, tip) {
    var got = (window.OfflineCache && uid) ? window.OfflineCache.getTask(uid) : null;
    if (!got || !got.task) return false;
    applyTask(got.task, { offline: true, cacheDate: got.date });
    toast(tip || '没有网络：显示上次同步的内容，记录会先存在本机', 3200);
    return true;
  }

  // list_wordbooks 返回所有公共词书；mine_status 才代表个人加入状态。
  // 不允许初始化失败后继续调用会从全库抽词的旧 RPC 路径。
  function enrollmentError(message) {
    var err = new Error(message);
    err.code = 'wordbook_required';
    return err;
  }

  function readEnrollment() {
    return window.DB.rpc('list_wordbooks', {}).then(function (res) {
      if (!res || res.ok !== true || !Array.isArray(res.wordbooks) || !res.wordbooks.length) {
        throw enrollmentError('无法确认词书状态，请重试或前往词书中心。');
      }
      var list = res.wordbooks;
      if (list.some(function (b) {
        return !b || typeof b.id !== 'string' || !b.id || typeof b.code !== 'string' ||
          typeof b.is_current !== 'boolean' ||
          (b.mine_status !== null && b.mine_status !== 'active' && b.mine_status !== 'paused');
      })) throw enrollmentError('词书状态异常，请重试或前往词书中心。');
      var current = list.filter(function (b) { return b.is_current; });
      if (current.length > 1 || (current.length && current[0].mine_status !== 'active')) {
        throw enrollmentError('当前词书状态异常，请前往词书中心重新选择。');
      }
      return { list: list, current: current[0] || null,
        joined: list.filter(function (b) { return b.mine_status !== null; }),
        active: list.filter(function (b) { return b.mine_status === 'active'; }) };
    });
  }

  function ensureEnrollment() {
    if (!window.DB || typeof window.DB.rpc !== 'function') {
      return Promise.reject(enrollmentError('词书服务未就绪，请重试。'));
    }
    if (typeof navigator !== 'undefined' && navigator.onLine === false) {
      return Promise.reject(new Error('当前离线，无法确认词书状态'));
    }
    return readEnrollment().then(function (state) {
      if (state.current) return state.current; // 保留用户选择（包括既有 seed），不改变学习模式
      var rpcName, target;
      if (!state.joined.length) {
        target = state.list.find(function (b) { return b.code === 'cet4'; });
        if (!target) throw enrollmentError('找不到默认四级词书，请前往词书中心。');
        rpcName = 'add_wordbook'; // 首次加入会自动设为当前；不会主动覆盖已存在的 current
      } else if (state.active.length === 1) {
        target = state.active[0];
        rpcName = 'set_current_wordbook';
      } else {
        throw enrollmentError('请前往词书中心选择一本当前词书，再继续学习。');
      }
      return window.DB.rpc(rpcName, { p_book_id: target.id }).then(function (res) {
        if (!res || res.ok !== true) throw enrollmentError('词书设置未成功，请重试或前往词书中心。');
        // 不能只相信写 RPC 返回 ok；再次确认存在有效 current 才能生成任务。
        return readEnrollment().then(function (after) {
          if (!after.current) throw enrollmentError('当前词书尚未生效，请重试或前往词书中心。');
          return after.current;
        });
      });
    });
  }

  var taskLoadInFlight = null;
  function loadTask() {
    if (taskLoadInFlight) return taskLoadInFlight;
    S.status = 'loading';
    setAuto(false);   // 首页/加载/失败/完成都不是真实学习状态
    renderLoading();
    var uid = null;
    taskLoadInFlight = Promise.resolve().then(function () { return window.Learn.ready(); }).then(function (who) {
      if (!who || !who.user_id) throw new Error('没有登录会话');
      uid = who.user_id;
      S.user = S.user || { id: uid };
      // 在线生成任务前必须确认有效词书；旧任务由服务端原样返回。
      return ensureEnrollment().then(function () { return window.Learn.loadTask(); });
    }).then(function (res) {
      if (!res || res.ok !== true) {
        var msg = (res && (res.message || res.code)) || '任务创建失败';
        throw new Error(msg);
      }
      if (window.OfflineCache && uid) window.OfflineCache.putTask(uid, res.task || {});
      applyTask(res.task || {}, {});
    }).catch(function (e) {
      var off = (typeof navigator !== 'undefined' && navigator.onLine === false);
      function fallback(u) {
        var bookError = e && e.code === 'wordbook_required';
        var tip = bookError ? '词书未就绪：显示已同步任务，请前往词书中心' :
          (off ? '现在没有网络：显示上次同步的内容' : '连不上服务器：显示上次同步的内容');
        if (loadCachedTask(u, tip)) return;
        S.status = 'error';
        S.error = (e && e.message) || '加载失败';
        S.offline = off;
        if (off) S.error = '连不上服务器（已离线），本机还没有缓存过今天的内容';
        else if (/登录|auth|jwt|session/i.test(S.error)) S.error += '（点「重新登录」可重新进入）';
        renderError();
      }
      if (uid) { fallback(uid); return; }
      Promise.resolve(window.DB && window.DB.auth ? window.DB.auth.getUserId() : null)
        .then(function (u) { fallback(u); })
        .catch(function () { fallback(null); });
    }).finally(function () { taskLoadInFlight = null; });
    return taskLoadInFlight;
  }

  // 无网络时继续学：会话服务连不上，就用本机队列记录（attempt/final 都以 session_id=null 提交，
  // 服务端 log_study_event 允许 session_id 为空，联网补交时照样入库）
  function startOfflineStudy() {
    setAuto(false);   // 离线没有在线会话，回前台只补交队列，不反复尝试建会话
    S.offlineStudy = true;
    S.offlineView = false;
    S.status = 'study';
    S.phase = 'card';
    S.itemStart = Date.now();
    S.elapsed = 0;
    if (S.localTimer) clearInterval(S.localTimer);
    S.localTimer = setInterval(function () {
      if (S.status !== 'study') return;
      S.elapsed += 1;
      var el = $('timer');
      if (el) el.textContent = fmt(S.elapsed);
    }, 1000);
    renderStudy();
    toast('离线学习：记录先存在本机，联网后自动补交', 3200);
  }

  function startSession() {
    if (S.busy) return;
    S.busy = true;
    S.starting = true;
    setAuto(true);    // 用户点了「开始学习」：此刻起回前台允许恢复/重建会话
    window.Learn.Session.start().then(function (res) {
      S.busy = false;
      S.starting = false;
      if (!res) {
        setAuto(false);
        if (typeof navigator !== 'undefined' && navigator.onLine === false) { startOfflineStudy(); return; }
        toast('学习会话创建失败，请检查网络后重试'); renderHome(); return;
      }
      S.offlineStudy = false;
      if (S.localTimer) { clearInterval(S.localTimer); S.localTimer = null; }
      S.status = 'study';
      S.phase = 'card';
      S.itemStart = Date.now();
      S.elapsed = 0;
      renderStudy();
    }).catch(function (e) {
      S.busy = false;
      S.starting = false;
      setAuto(false);
      toast('启动学习失败：' + ((e && e.message) || e), 5000);
    });
  }

  function attempt(item, result, no) {
    var dur = Math.round((Date.now() - (S.attemptStart || Date.now())) / 1000);
    S.attemptStart = Date.now();
    return window.Learn.submitAttempt(item.word_id, item.item_id, item.task_type, result, dur, no)
      .catch(function (e) {
        toast('作答记录没提交成功：' + ((e && e.message) || '网络问题'));
        return null;
      });
  }

  function cachePatch(itemId, status, result) {
    try {
      if (window.OfflineCache && S.user && S.user.id) {
        window.OfflineCache.patchTaskItem(S.user.id, itemId, status, result || null);
      }
    } catch (e) { /* 缓存写失败不影响学习 */ }
  }

  function saveFinal() {
    var item = currentItem();
    if (!item) return;
    S.phase = 'saving';
    renderStudy();
    window.Learn.submitFinal(item.item_id, S.firstResult === 'correct' ? 'correct' : 'incorrect').then(function (res) {
      S.lastSave = res || { status: 'queued', message: '未知状态' };
      S.done += 1;
      S.phase = 'item_done';
      cachePatch(item.item_id, 'completed', S.firstResult === 'correct' ? 'correct' : 'incorrect');
      refreshPending().then(renderStudy);
      if (S.lastSave.status === 'queued') toast('已排在本机，联网后自动补交');
      if (S.lastSave.status === 'dead') toast('服务端拒绝了这条记录，已停止重试');
    }).catch(function (e) {
      S.lastSave = { status: 'queued', message: (e && e.message) || '提交失败，已保留在本机' };
      S.done += 1;
      S.phase = 'item_done';
      refreshPending().then(renderStudy);
      toast('提交失败，已保留在本机，稍后补交');
    });
  }

  // ---------- 交互动作 ----------
  // 朗读：必须在 click 事件里同步调用（iPhone Safari 不允许延迟播放）
  function speakWord(word, btn) {
    if (!window.Speech || typeof window.Speech.say !== 'function') return;
    if (!window.Speech.supported()) {
      toast('这个浏览器不支持朗读，换用 Safari 或新版 Edge 试试');
      return;
    }
    var ok = window.Speech.say(word);
    if (!ok) {
      toast('已关闭发音，可以在「设置 → 单词发音」里打开');
      return;
    }
    if (!btn) return;
    var txt = btn.querySelector ? btn.querySelector('.say-txt') : null;
    if (!txt) return;
    var old = '听发音';
    txt.textContent = '朗读中…';
    // 不禁用按钮：再点一次就是「重播」（内部会先 cancel 上一个，不会叠音）
    setTimeout(function () { txt.textContent = old; }, 1200);
  }

  var ACT = {
    say: function (el) {
      var w = el.getAttribute('data-w') || '';
      speakWord(w, el);
    },
    reload: function () { loadTask(); },
    logout: function () { window.AppAuth.logout(); },
    start: function () { startSession(); },
    home: function () { loadTask(); },
    flush: function () {
      window.Learn.flush().then(function (r) {
        var sent = (r && r.sent ? r.sent.length : 0);
        var dead = (r && r.dead ? r.dead.length : 0);
        toast(sent > 0 ? '补交成功 ' + sent + ' 条' : (dead > 0 ? '有 ' + dead + ' 条被服务端拒绝' : '没有可补交的记录'));
        return refreshPending();
      }).catch(function (e) { toast('补交失败：' + ((e && e.message) || '网络问题')); });
    },
    toquiz: function () {
      var item = currentItem(); if (!item || S.busy) return;
      // 答题前先听一遍（可在设置里关掉）。这里仍在点击事件内，iOS 允许播放。
      try {
        var sp = window.Speech && window.Speech.prefs ? window.Speech.prefs() : null;
        if (sp && sp.on && sp.auto) speakWord(item.word, null);
      } catch (e) {}
      S.options = buildOptions(item);
      S.picked = null;
      S.phase = 'quiz';
      S.attemptStart = Date.now();
      renderStudy();
    },
    pick: function (el) {
      var item = currentItem(); if (!item || S.busy) return;
      var i = parseInt(el.getAttribute('data-i'), 10);
      S.picked = i;
      var chosen = S.options[i];
      var ok = chosen === item.meaning;
      if (S.phase === 'quiz') {
        S.firstResult = ok ? 'correct' : 'incorrect';
        S.pickedMeaningOk = ok;
        attempt(item, ok ? 'correct' : 'incorrect', 1);
        S.phase = 'quiz_fb';
        renderStudy();
      } else if (S.phase === 'retry') {
        S.retryOk = ok;
        attempt(item, ok ? 'correct' : 'incorrect', 3);
        S.phase = 'retry_fb';
        renderStudy();
      }
    },
    tospell: function () {
      S.phase = 'spell';
      S.attemptStart = Date.now();
      S.spellInput = '';
      renderStudy();
    },
    spell: function () {
      var item = currentItem(); if (!item || S.busy) return;
      var inp = $('spellInput');
      var val = inp ? inp.value : '';
      S.spellInput = val;
      var ok = normSpell(val) === normSpell(item.word);
      S.spellOk = ok;
      attempt(item, ok ? 'correct' : 'incorrect', 2);
      S.phase = 'spell_fb';
      renderStudy();
    },
    toretry: function () {
      var item = currentItem(); if (!item) return;
      S.options = buildOptions(item);
      S.picked = null;
      S.phase = 'retry';
      renderStudy();
    },
    save: function () { saveFinal(); },
    next: function () {
      if (S.idx + 1 < S.queue.length) {
        S.idx += 1;
        S.phase = 'card';
        S.picked = null;
        S.firstResult = null;
        S.lastSave = null;
        S.itemStart = Date.now();
        renderStudy();
        return;
      }
      setAuto(false);
      window.Learn.Session.end();
      if (S.localTimer) { clearInterval(S.localTimer); S.localTimer = null; }
      S.status = 'done';
      renderDone();
      window.Learn.flush().then(refreshPending);
    },
    skip: function () {
      var item = currentItem(); if (!item || S.busy) return;
      S.busy = true;
      window.Learn.skipItem(item.item_id).then(function (res) {
        S.busy = false;
        var st = res && res.status;
        if (st === 'sent' || st === 'queued') {
          S.skipped += 1;
          S.lastSave = { status: st, message: res.message };
          S.phase = 'item_done';
          cachePatch(item.item_id, 'skipped', null);
          renderStudy();
        } else {
          toast('跳过没提交成功：' + ((res && res.message) || '未知错误'));
          renderStudy();
        }
      }).catch(function (e) {
        S.busy = false;
        toast('跳过失败：' + ((e && e.message) || '网络问题'));
        renderStudy();
      });
    }
  };

  function bind() {
    view = $('view');
    window.addEventListener('error', function (ev) {
      toast('页面脚本错误：' + ((ev && ev.message) || '未知'), 6000);
    });
    window.addEventListener('unhandledrejection', function (ev) {
      var reason = ev && ev.reason;
      toast('异步错误：' + ((reason && (reason.message || reason.code)) || reason || '未知'), 6000);
    });
    if (!view) { return; }
    view.addEventListener('click', function (ev) {
      var el = ev.target;
      while (el && el !== view) {
        if (el.getAttribute && el.getAttribute('data-act')) break;
        el = el.parentNode;
      }
      if (!el || el === view) return;
      var act = el.getAttribute('data-act');
      var fn = ACT[act];
      if (fn) { ev.preventDefault(); fn(el); }
    });
    view.addEventListener('keydown', function (ev) {
      if (ev.key === 'Enter' && S.phase === 'spell') {
        ev.preventDefault();
        ACT.spell();
      }
    });
  }

  function boot() {
    var body = document.body;
    MODE = (body && body.getAttribute('data-mode')) === 'review' ? 'review' : 'today';
    var t = document.getElementById('pageTitle');
    if (t) t.textContent = MODE === 'review' ? '到期复习' : '今日学习';
    var back = $('btnLogout');
    if (back) back.addEventListener('click', function () { window.AppAuth.logout(); });
    window.Learn.Session.onTick = function (sec) {
      S.elapsed = sec;
      S.lastTickSec = sec;
      var el = $('timer');
      if (el) el.textContent = fmt(sec);
    };
    window.Learn.Session.onState = function (state, detail) {
      S.lastState = state;
      // 回前台时 data 层会自动 start 会话；只有正在学习时才允许会话存在
      if ((state === 'started' || state === 'resumed') && S.status !== 'study' && !S.starting) {
        setAuto(false);
        window.Learn.Session.end();
        return;
      }
      if (state === 'session_expired') toast('学习会话已重建，记录会继续保存');
      if (state === 'auth') toast('登录已过期，请重新登录');
      if (state === 'error' && detail) toast('会话异常：' + detail);
    };
    window.Learn.Session.bindEvents();

    window.AppAuth.requireLogin().then(function (user) {
      if (!user) return;
      S.user = user;
      renderTopbar();
      loadTask();
    });
  }

  document.addEventListener('DOMContentLoaded', function () { bind(); boot(); });

  return { boot: boot, state: S };
})();
