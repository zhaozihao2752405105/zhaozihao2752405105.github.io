/* ============================================================
 * assets/study.js —— 今日学习 / 到期复习 共享控制器
 * 依赖：app.css、config.js、supabase CDN、db.js、auth.js、queue.js、learning.js
 * 页面用法：<body data-mode="today"> ... StudyUI.boot()
 * 本阶段零 AI 调用：内容全部来自 get_or_create_daily_task 返回的任务条目。
 * 记录三态：提交成功后显示 sent/dead，离线排队显示 queued（不得显示成已保存）。
 * ============================================================ */
window.StudyUI = (function () {
  'use strict';

  var MODE = 'today';           // 'today' | 'review'
  var S = {
    user: null,
    status: 'loading',          // loading|error|home|study|done
    error: '',
    task: null,
    allItems: [],               // 当前模块（new/review）的全部条目
    queue: [],                  // 待学习条目
    doneInitial: 0,           // 加载时已完成
    skippedInit: 0,           // 加载时已跳过
    idx: 0,
    done: 0,
    skipped: 0,
    phase: 'card',              // card|quiz|quiz_fb|spell|spell_fb|retry|retry_fb|saving|item_done
    firstResult: null,          // 'correct'|'incorrect' 首次作答（决定 SM-2 调度）
    zUnit: '',                  // 本会话难度反馈的 unit_key
    zStats: { independent: 0, correct: 0, hints: 0, repeated: 0 }, // 本会话作答统计（只给难度反馈用）
    attemptNo: 0,
    itemStart: 0,
    options: [],
    picked: null,
    lastSave: null,             // {status,message}
    busy: false,
    elapsed: 0,
    lastTickSec: 0,
    lastState: '',
    starting: false,
    pending: 0,
    levels: { adaptive: 1, listening: 1, reading: 1 },
    mode: 'read',               // read 认知 | follow 跟写 | dictate 听写 | recall 默写
    hintUsed: false,            // 默写/听写里是否用过提示（影响调度计分）
    typed: '',                  // 当前输入（跟写实时比对用）
    offlineView: false,      // 当前显示的是本机缓存快照（断网）
    cacheDate: '',           // 快照对应的日期
    offlineStudy: false,     // 无网络时继续学：记录先存本机，联网后补交
    localTimer: null
  };

  var view = null;
  var toastTimer = null;

  // ---------- 小工具 ----------
  function esc(s) {
    return String(s == null ? '' : s)
      .replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;')
      .replace(/"/g, '&quot;').replace(/'/g, '&#39;');
  }
  function $(id) { return document.getElementById(id); }
  // 真实学习状态开关：只有进入学习页且会话确实要用时才允许「回前台自动建会话」
  function setAuto(on) {
    try { if (window.Learn && window.Learn.Session) window.Learn.Session.autoStart = !!on; } catch (e) { }
  }
  function toast(msg, ms) {
    var el = $('toast');
    if (!el) return;
    el.textContent = msg;
    el.className = 'toast on';
    if (toastTimer) clearTimeout(toastTimer);
    toastTimer = setTimeout(function () { el.className = 'toast'; }, ms || 2400);
  }
  function fmt(sec) {
    sec = Math.max(0, Math.floor(sec || 0));
    var m = Math.floor(sec / 60), s = sec % 60;
    return (m < 10 ? '0' : '') + m + ':' + (s < 10 ? '0' : '') + s;
  }
  function normSpell(v) {
    return String(v || '').toLowerCase().replace(/[\s\-']/g, '');
  }
  function pct(a, b) { return b > 0 ? Math.round(a * 100 / b) : 0; }
  function todayStr() {
    var d = new Date();
    var m = d.getMonth() + 1, dd = d.getDate();
    return d.getFullYear() + '-' + (m < 10 ? '0' : '') + m + '-' + (dd < 10 ? '0' : '') + dd;
  }
  // 学习日（yyyy-mm-dd）转成中文短日期：11月26日 周四；解析失败时原样返回
  function cnDate(s) {
    var m = /^(\d{4})-(\d{2})-(\d{2})$/.exec(String(s || ''));
    if (!m) return String(s || '');
    var d = new Date(Number(m[1]), Number(m[2]) - 1, Number(m[3]));
    if (isNaN(d.getTime())) return String(s || '');
    var w = ['周日', '周一', '周二', '周三', '周四', '周五', '周六'][d.getDay()];
    return Number(m[2]) + '月' + Number(m[3]) + '日 ' + w;
  }

  // ---------- 选项生成 ----------
  var FALLBACK_MEANINGS = [
    'n. 时间', 'n. 朋友', 'n. 机会', 'n. 方向',
    'v. 选择', 'v. 理解', 'n. 习惯', 'n. 计划'
  ];
  function buildOptions(item) {
    var pool = [], seen = {};
    S.allItems.forEach(function (it) {
      if (!it || !it.meaning) return;
      if (it.word_id === item.word_id) return;
      if (seen[it.meaning]) return;
      seen[it.meaning] = true;
      pool.push(it.meaning);
    });
    for (var i = 0; i < FALLBACK_MEANINGS.length && pool.length < 3; i++) {
      if (!seen[FALLBACK_MEANINGS[i]]) { seen[FALLBACK_MEANINGS[i]] = true; pool.push(FALLBACK_MEANINGS[i]); }
    }
    // 洗牌后取 3 个干扰项，再和正确项混合
    for (var j = pool.length - 1; j > 0; j--) {
      var k = Math.floor(Math.random() * (j + 1)); var t = pool[j]; pool[j] = pool[k]; pool[k] = t;
    }
    var opts = [item.meaning].concat(pool.slice(0, 3));
    for (var m = opts.length - 1; m > 0; m--) {
      var n = Math.floor(Math.random() * (m + 1)); var tmp = opts[m]; opts[m] = opts[n]; opts[n] = tmp;
    }
    return opts;
  }

  // ---------- 页面骨架 ----------
  function renderTopbar() {
    var name = $('userName');
    if (name && S.user) name.textContent = window.AppAuth.displayName(S.user) + ' · 已登录';
  }

  function renderShell(inner, screen, phase, feedback) {
    // 仅展示状态，不参与学习状态机；每次渲染清除旧状态样式。
    view.setAttribute('data-screen', screen || 'status');
    if (phase) view.setAttribute('data-phase', phase); else view.removeAttribute('data-phase');
    if (feedback) view.setAttribute('data-feedback', feedback); else view.removeAttribute('data-feedback');
    view.innerHTML = inner;
    fillPhrases();
  }

  function progress() {
    var total = S.allItems.length;
    var done = S.doneInitial + S.done;
    var skipped = S.skippedInit + S.skipped;
    return { total: total, done: done, skipped: skipped, pct: pct(done, total) };
  }

  function itemLabel(item) { return item.task_type === 'review' ? '复习' : '新词'; }
  function domainLabel(d) {
    var map = { gen: '通用', work: '职场', mech: '机械', med: '医疗', test: '测试' };
    return map[d] || '';
  }

  // ---------- 渲染：加载 / 错误 ----------
  function renderLoading() {
    renderShell('<div class="card center"><p class="muted">正在准备今天的学习内容…</p></div>');
  }
  function renderError() {
    var off = S.offline;
    renderShell(
      '<div class="card">' +
      '<h3>' + (off ? '现在没有网络' : '加载失败') + '</h3>' +
      '<p class="small muted">' + esc(S.error || '未知错误') + '</p>' +
      (off ? '<p class="small muted">今天的学习内容需要联网才能打开。你之前没交上去的学习记录还在本机，联网后会自己补交，不会丢。</p>' +
        '<div class="ex-line"><span>本机待补交</span><span class="zh" id="pendingCount">— 条</span></div>' : '') +
      '<div class="row mt12"><button class="btn" data-act="reload">重试</button>' +
      '<a class="btn ghost" href="books.html">词书中心</a>' +
      '<button class="btn ghost" data-act="logout">重新登录</button></div>' +
      '</div>');
    if (off) refreshPending();
  }

  // ---------- 渲染：首页（Lavender Future 展示层，2026-11-26） ----------
  // 今日页与复习页共享材质、进度和操作组件。
  function renderQuickLinks(aiOn) {
    var h = '<div class="v2-quicklist">';
    if (aiOn) {
      h += '<a class="card aicoach v2-quick v2-coach" href="chat.html?v=20261127be"><span class="v2-coach-orb" aria-hidden="true"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.7" stroke-linecap="round"><path d="M5 10v4m4-7v10m6-12v14m4-9v4"/></svg></span><span class="aicoach-txt"><b>AI 英语老师</b><i>自由提问 · 双语文字交流</i></span><span class="aicoach-go" aria-hidden="true">›</span></a>';
    }
    h += '<a class="card aicoach v2-quick v2-books" href="books.html?v=20261127be"><span class="aicoach-ico" aria-hidden="true"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.7" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true" focusable="false"><path d="M4 19V5a2 2 0 0 1 2-2h14v18H6a2 2 0 0 1 0-4h14"/><path d="m9 12 2.5-6L14 12M10 10h3"/></svg></span><span class="aicoach-txt"><b>词书中心</b><i>选词书 · 调整每日词量</i></span><span class="aicoach-go" aria-hidden="true">›</span></a>';
    h += '<a class="card aicoach v2-quick v2-mistakes" href="word-mistakes.html?v=20261127be"><span class="aicoach-ico" aria-hidden="true"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.7" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true" focusable="false"><path d="M12 3 2 20h20L12 3Z"/><path d="M12 9v5m0 3v.5"/></svg></span><span class="aicoach-txt"><b>错词本</b><i>写错的词 · 收藏的词</i></span><span class="aicoach-go" aria-hidden="true">›</span></a>';
    h += '<a class="card aicoach v2-quick" href="practice.html?v=20261127be"><span class="aicoach-ico" aria-hidden="true"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.7" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true" focusable="false"><path d="M12 20h9"/><path d="M16.5 3.5a2.1 2.1 0 0 1 3 3L7 19l-4 1 1-4Z"/></svg></span><span class="aicoach-txt"><b>自由练习</b><i>错词 / 收藏 / 当前词书 · 跟写、听写、默写</i></span><span class="aicoach-go" aria-hidden="true">›</span></a>';
    h += '<a class="card aicoach v2-quick" href="article.html?v=20261127be"><span class="aicoach-ico" aria-hidden="true"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.7" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true" focusable="false"><path d="M4 4h7a3 3 0 0 1 3 3v13a3 3 0 0 0-3-3H4Z"/><path d="M20 4h-3a3 3 0 0 0-3 3v13a3 3 0 0 1 3-3h3Z"/></svg></span><span class="aicoach-txt"><b>读文章</b><i>逐句跟写 / 听写 · 点词查义 · 收生词</i></span><span class="aicoach-go" aria-hidden="true">›</span></a>';
    h += '<a class="card aicoach v2-quick" href="write.html?v=20261127be"><span class="aicoach-ico" aria-hidden="true"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.7" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true" focusable="false"><path d="M12 20h9"/><path d="M16.5 3.5a2.1 2.1 0 0 1 3 3L7 19l-4 1 1-4Z"/></svg></span><span class="aicoach-txt"><b>写作训练</b><i>按难度出题 · 批改只标客观错误</i></span><span class="aicoach-go" aria-hidden="true">›</span></a></div>';
    return h;
  }

  // ---------- 学习模式（认知 / 跟写 / 听写 / 默写） ----------
  var MODES = {
    read: { name: '认知', tip: '看一眼单词，选词义，再拼一遍。' },
    follow: { name: '跟写', tip: '照着单词逐字敲，敲错的字母会立刻标红。' },
    dictate: { name: '听写', tip: '只给发音，不看拼写，把听到的词写出来。' },
    recall: { name: '默写', tip: '只给中文意思，凭记忆写出英文。' },
    selftest: { name: '自测', tip: '快速自评：认识、有点印象、不认识。凭第一感觉点，别纠结。' }
  };
  function modeName(m) { return (MODES[m] || MODES.read).name; }

  function loadMode() {
    if (!window.DB || typeof window.DB.rpc !== 'function') return Promise.resolve();
    return window.DB.rpc('list_wordbooks', {}).then(function (res) {
      var p = (res && res.study_prefs) || {};
      var m = String(p.word_mode || '');
      if (MODES[m]) S.mode = m;
    }).catch(function () { /* 读不到就用上次的 */ });
  }

  function saveMode(m) {
    S.mode = MODES[m] ? m : 'read';
    if (!window.DB || typeof window.DB.rpc !== 'function') return Promise.resolve(S.mode);
    return window.DB.rpc('set_study_prefs', { p_patch: { word_mode: S.mode } }).then(function (res) {
      var p = (res && res.study_prefs) || {};
      if (MODES[p.word_mode]) S.mode = p.word_mode;
      return S.mode;
    }).catch(function () { return S.mode; });
  }

  function modeChipsHtml() {
    var h = '<div class="v2-seg v2-modes">';
    var keys = ['read', 'follow', 'dictate', 'recall', 'selftest'];
    for (var i = 0; i < keys.length; i++) {
      var k = keys[i];
      h += '<button class="v2-seg-btn" data-act="mode" data-mode="' + k + '" aria-pressed="' + (S.mode === k ? 'true' : 'false') + '">' + MODES[k].name + '</button>';
    }
    return h + '</div>';
  }

  // 跟写：把已输入的字母和目标词逐字比对
  function followHtml(word) {
    var w = String(word || ''), t = String(S.typed || '');
    var h = '<div class="fw-word" id="fwWord" aria-live="polite">';
    for (var i = 0; i < w.length; i++) {
      var ch = w.charAt(i);
      var cls = 'fw-ch';
      if (i < t.length) cls += (t.charAt(i).toLowerCase() === ch.toLowerCase() ? ' ok' : ' bad');
      else if (i === t.length) cls += ' cur';
      h += '<span class="' + cls + '">' + esc(ch === ' ' ? ' ' : ch) + '</span>';
    }
    return h + '</div>';
  }

  function typeInputHtml(item, placeholder) {
    return '<div class="field mt8"><input id="typeInput" aria-label="输入英文单词" type="text" autocomplete="off" autocapitalize="off" autocorrect="off" spellcheck="false" enterkeyhint="done" placeholder="' + esc(placeholder || '输入英文单词') + '"></div>';
  }

  // ---------- 031 模块难度：听力 / 阅读各自一档，写进 study_prefs，AI 生成按此档位出题
  function levelCardHtml() { return '<section id="lumi-home-difficulty"></section>'; }

  function loadLevels() {
    const node = document.getElementById('lumi-home-difficulty');
    if (node && window.Difficulty) return window.Difficulty.mount(node, ['words', 'listening', 'reading']);
  }

  // B2 学习教练卡：首屏先占位，渲染完再异步补真实数据；读不到就明说读不到，不显示假进度。
  function coachLevelLabel(n) { return ['', 'L1 基础', 'L2 进阶', 'L3 挑战'][n] || 'L1 基础'; }
  function coachHref(h) { return /^[a-z0-9][a-z0-9?=&._-]*$/i.test(String(h || '')) ? h : 'memory.html'; }
  function coachCardHtml(p) {
    if (!p) {
      return '<div class="v2-coach-head"><span class="v2-coach-orb" aria-hidden="true">✦</span><div><b>今日建议</b><small>暂时读不到你的学习记录</small></div></div>' +
        '<p class="v2-coach-advice">现在可能是离线，或数据还没同步。先按计划学习，记录会保存在本机；联网后再看建议。</p>' +
        '<a class="v2-coach-link" href="memory.html">查看学习档案 ›</a>';
    }
    if (p.enabled === false) {
      return '<div class="v2-coach-head"><span class="v2-coach-orb" aria-hidden="true">✦</span><div><b>今日建议</b><small>学习档案已关闭</small></div></div>' +
        '<p class="v2-coach-advice">你关闭了「学习档案与教学记忆」，AI 老师和今日建议都不会读取你的学习记录。</p>' +
        '<a class="v2-coach-link" href="memory.html">去重新开启 ›</a>';
    }
    var lv = p.level || {};
    var sm = p.sample || {};
    var sample = sm.units ? '近 14 天 ' + sm.units + ' 题 · 正确率 ' + Math.round((sm.accuracy || 0) * 100) + '%' : '样本还少';
    var h = '<div class="v2-coach-head"><span class="v2-coach-orb" aria-hidden="true">✦</span><div><b>今日建议</b><small>' + esc(coachLevelLabel(lv.suggested || lv.base || 1)) + ' · ' + esc(sample) + '</small></div></div>';
    h += '<p class="v2-coach-advice">' + esc(p.advice || '按计划完成今天的学习。') + '</p>';
    var focus = (p.focus || []).slice(0, 3);
    if (focus.length) {
      h += '<div class="v2-coach-focus">';
      focus.forEach(function (f) {
        h += '<a class="v2-coach-chip" href="' + esc(coachHref(f.href)) + '">' + esc(f.label || '继续') + '<span aria-hidden="true">›</span></a>';
      });
      h += '</div>';
    }
    h += '<a class="v2-coach-link" href="memory.html">学习档案与教学记忆 ›</a>';
    return h;
  }
  /* ---------- AI 学习建议（learning_context → 网关 plan，服务端按天缓存） ---------- */
  var PLAN_MOD_ZH = { words: '单词', grammar: '语法', listening: '听力', reading: '阅读', speaking: '口语' };
  var PLAN_ICO = { words: 'Aa', grammar: 'G', listening: '♪', reading: 'R', speaking: 'M' };

  function planCardHtml(data) {
    var list = (data && data.suggestions) || [];
    if (!list.length) return '';
    var h = '<div class="v2-plan-head"><div><b>接着学这些</b><span class="small muted">按你的真实记录推荐</span></div>' +
      '<button type="button" class="v2-plan-refresh" data-act="planRefresh">换一批</button></div>';
    h += '<div class="v2-plan-list">';
    list.forEach(function (s) {
      var mod = String(s.module || 'words');
      var words = mod === 'words';
      var open = words ? '<button type="button" class="v2-plan-item" data-act="planStart"'
        : '<a class="v2-plan-item" href="lesson.html?module=' + encodeURIComponent(mod) + '"';
      var close = words ? '</button>' : '</a>';
      h += open + '>' +
        '<span class="v2-plan-ico v2-plan-' + esc(mod) + '" aria-hidden="true">' + (PLAN_ICO[mod] || '·') + '</span>' +
        '<span class="v2-plan-body"><b>' + esc(s.title || '') + '</b>' +
        '<small>' + esc(s.reason || '') + (s.focus_words && s.focus_words.length ? ' · 重点词 ' + esc(s.focus_words.slice(0, 3).join(' / ')) : '') + '</small></span>' +
        '<span class="v2-plan-meta">' + esc(PLAN_MOD_ZH[mod] || mod) + ' · L' + (Number(s.level) || 4) + ' · ' + (Number(s.estimated_minutes) || 10) + '′</span>' +
        close;
    });
    h += '</div><div class="v2-plan-foot"><button type="button" class="link-btn" data-act="planSkip">今天不看了</button>' +
      '<span class="small muted">建议仅供参考，时间不必照做</span></div>';
    return h;
  }

  async function hydratePlan() {
    var node = document.getElementById('planCard');
    if (!node || !window.LumiPlan || !window.AI) return;
    if (window.LumiPlan.skippedToday()) { node.hidden = true; return; }
    var r = null;
    try { r = await window.LumiPlan.suggestions(false); } catch (e) { r = null; }
    var data = r && r.data;
    if (!data) {
      node.hidden = false;
      node.innerHTML = '<div class="v2-plan-head"><div><b>接着学这些</b><span class="small muted">本地建议（AI 暂不可用）</span></div></div>' +
        '<div class="v2-plan-list"><a class="v2-plan-item" href="review.html"><span class="v2-plan-ico v2-plan-words" aria-hidden="true">Aa</span><span class="v2-plan-body"><b>先把到期复习做完</b><small>按你现有的复习安排</small></span><span class="v2-plan-meta">复习</span></a>' +
        '<a class="v2-plan-item" href="lesson.html?module=listening"><span class="v2-plan-ico v2-plan-listening" aria-hidden="true">♪</span><span class="v2-plan-body"><b>听一段短文</b><small>离线也能做</small></span><span class="v2-plan-meta">听力</span></a></div>';
      return;
    }
    var html = planCardHtml(data);
    node.hidden = !html;
    node.innerHTML = html;
  }

  async function hydrateCoachCard() {
    var node = document.getElementById('coachCard');
    if (!node || !window.DB || !window.DB.learnerProfile) return;
    var p = null;
    try { p = await window.DB.learnerProfile(); } catch (e) { p = null; }
    if (!node.isConnected) return;
    node.innerHTML = coachCardHtml(p);
    node.hidden = false;
    node.classList.add('is-ready');
  }

  function renderTodayHome() {
    var p = progress();
    var items = (S.task && S.task.items) || [];
    var rev = items.filter(function (i) { return i.task_type === 'review'; });
    var revDone = rev.filter(function (i) { return i.status === 'completed'; }).length;
    var canStart = S.queue.length > 0;
    var aiOn = !!(window.APP_CONFIG && window.APP_CONFIG.FEATURES && window.APP_CONFIG.FEATURES.AI_CHAT);
    var iconPaths = {
      word: '<path d="M4 19V5a2 2 0 0 1 2-2h14v18H6a2 2 0 0 1 0-4h14"/><path d="m9 12 2.5-6L14 12M10 10h3"/>',
      grammar: '<path d="M4 5h16M4 10h10M4 15h7M4 20h6"/><path d="m14 17 3 3 4-6"/>',
      listening: '<path d="M3 13v-2a9 9 0 0 1 18 0v2"/><rect x="3" y="12" width="5" height="8" rx="2"/><rect x="16" y="12" width="5" height="8" rx="2"/>',
      reading: '<path d="M12 6c-3-3-7-3-10-2v15c4-1 7-1 10 2 3-3 6-3 10-2V4c-3-1-7-1-10 2v15"/>',
      speaking: '<rect x="9" y="3" width="6" height="12" rx="3"/><path d="M5 11v1a7 7 0 0 0 14 0v-1M12 19v3m-4 0h8"/>'
    };
    function ico(key) {
      return '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.7" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true" focusable="false">' + iconPaths[key] + '</svg>';
    }
    var h = '<div class="v2-home v2-home-next' + (S.offlineView ? ' v2-home-offline' : '') + '">';
    h += '<section class="v2-welcome v2-welcome-new"><div class="v2-welcome-copy"><div class="v2-welcome-date">' + esc(cnDate(S.task && S.task.study_date)) + (S.offlineView ? ' · 缓存任务' : '') + '</div><h1>欢迎回来。</h1><p>今天想学什么？按自己的节奏开始。</p>' + (aiOn ? '<a class="v2-welcome-cta" href="chat.html">和 AI 老师聊聊 <span aria-hidden="true">›</span></a>' : '<a class="v2-welcome-cta" href="books.html">选择学习内容 <span aria-hidden="true">›</span></a>') + '</div><div class="v2-welcome-orb" aria-hidden="true"><span>L</span></div></section>';
    if (S.offlineView) {
      var stale = S.cacheDate && S.cacheDate !== todayStr();
      h += '<div class="card v2-offline"><b>离线查看</b><p class="small muted mt8">' + (stale ? '显示 ' + esc(S.cacheDate) + ' 的内容，联网后刷新。' : '显示上次同步的内容，联网后刷新。') + ' 学习记录会先存在本机，联网后自动补交。</p></div>';
    }
    h += '<section class="card v2-plan-card" id="planCard" aria-live="polite" hidden></section>';
    h += '<section class="card v2-coach-card" id="coachCard" aria-live="polite" hidden></section>';
    h += '<section class="card v2-hero" id="today-word" aria-labelledby="v2-word-title"><div class="v2-hero-head"><div class="hero-txt"><div class="v2-hero-kicker"><span></span> 单词计划</div><h2 class="hero-title" id="v2-word-title">' + (canStart ? '今日新词' : (p.total === 0 ? '暂无待学新词' : (p.skipped === p.total ? '本轮新词已跳过' : (p.skipped ? '本轮新词学习结束' : '今日新词已完成')))) + '</h2>';
    h += '<div class="hero-sub">已完成 <b>' + p.done + ' / ' + p.total + '</b> 个' + (canStart ? ' · 剩余 ' + S.queue.length + ' 个' : '') + (p.skipped ? ' · 跳过 ' + p.skipped + ' 个' : '') + '</div></div>';
    h += '<div class="v2-progress-orb"><div class="ring" style="--p:' + p.pct + '" role="img" aria-label="新词完成率 ' + p.pct + '%"><span>' + (p.total ? p.pct + '%' : '—') + '</span></div><small>新词进度</small></div></div>';
    h += '<div class="v2-hero-actions">';
    if (canStart) h += '<button type="button" class="btn block" data-act="start">' + (p.done + p.skipped > 0 ? '继续学习' : '开始学习') + '<span aria-hidden="true">›</span></button>';
    else h += '<a class="btn block" href="lesson.html">继续其他课程<span aria-hidden="true">›</span></a><button type="button" class="btn ghost sm v2-refresh" data-act="reload">刷新任务</button>';
    h += '</div></section>';
    h += '<section class="v2-modules" aria-labelledby="v2-mod-title"><div class="v2-section-head"><h2 id="v2-mod-title">学习模块</h2><a href="lesson.html">全部课程 ›</a></div><div class="v2-module-grid">';
    h += (canStart ? '<button type="button" class="v2-module v2-module--word" data-act="start">' : '<a class="v2-module v2-module--word" href="#today-word">') + '<span class="v2-module-icon">' + ico('word') + '</span><b>单词</b><small>词汇</small>' + (canStart ? '</button>' : '</a>');
    [['grammar','语法','规则'],['listening','听力','听懂'],['reading','阅读','理解'],['speaking','口语','表达']].forEach(function (m) {
      h += '<a class="v2-module v2-module--' + m[0] + '" href="lesson.html?module=' + m[0] + '"><span class="v2-module-icon">' + ico(m[0]) + '</span><b>' + m[1] + '</b><small>' + m[2] + '</small></a>';
    });
    h += '</div></section>';
    h += levelCardHtml();
    h += renderQuickLinks(aiOn);
    h += '<section class="card v2-overview" aria-labelledby="v2-overview-title"><div class="v2-section-head"><h2 id="v2-overview-title">今日概览</h2><a href="stats.html">学习统计 ›</a></div><div class="v2-metrics">';
    h += '<div class="v2-metric"><b>' + p.done + ' / ' + p.total + '</b><span>新词</span></div><div class="v2-metric"><b>' + revDone + ' / ' + rev.length + '</b><span>到期复习</span></div><div class="v2-metric"><b id="pendingCount">' + S.pending + ' 条</b><span>待补交</span></div></div>';
    h += '<div class="v2-actions"><button type="button" class="btn ghost sm" data-act="flush">补交本机记录</button><a class="btn ghost sm" href="review.html">去到期复习</a></div></section>';
    h += '</div>';
    renderShell(h, 'home');
    hydrateCoachCard();
    hydratePlan();
  }

  function renderHome() {
    if (MODE === 'today') return renderTodayHome();
    var p = progress();
    var canStart = S.queue.length > 0;
    var aiOn = !!(window.APP_CONFIG && window.APP_CONFIG.FEATURES && window.APP_CONFIG.FEATURES.AI_CHAT);
    var newAll = ((S.task && S.task.items) || []).filter(function (i) { return i.task_type === 'new'; });
    var newDone = newAll.filter(function (i) { return i.status === 'completed'; }).length;
    var html = '<div class="v2-home v2-review-home' + (S.offlineView ? ' v2-review-offline' : '') + '">';
    html += '<section class="v2-welcome"><div class="v2-welcome-date">' + esc(cnDate(S.task && S.task.study_date)) + (S.offlineView ? ' · 缓存任务' : '') + '</div><h1>温故，知新。</h1><p>复习已经学过的单词，让记忆更牢固。</p></section>';
    if (S.offlineView) {
      var staleTip = S.cacheDate && S.cacheDate !== todayStr() ? '显示 ' + esc(S.cacheDate) + ' 的内容，联网后刷新。' : '显示上次同步的内容，联网后刷新。';
      html += '<div class="card v2-offline"><b>离线查看</b><p class="small muted mt8">' + staleTip + ' 学习记录会先存在本机，联网后自动补交。</p></div>';
    }
    html += '<section class="card v2-hero" aria-labelledby="v2-review-title"><div class="v2-hero-head"><div class="hero-txt"><div class="v2-hero-kicker"><span></span> 复习计划</div><h2 class="hero-title" id="v2-review-title">到期单词</h2><div class="hero-sub">已完成 <b>' + p.done + ' / ' + p.total + '</b> 个' + (canStart ? ' · 剩余 ' + S.queue.length + ' 个' : '') + (p.skipped ? ' · 跳过 ' + p.skipped + ' 个' : '') + '</div></div>';
    html += '<div class="v2-progress-orb"><div class="ring" style="--p:' + p.pct + '" role="img" aria-label="复习完成率 ' + p.pct + '%"><span>' + (p.total ? p.pct + '%' : '—') + '</span></div><small>复习进度</small></div></div>';
    html += '<div class="v2-hero-actions"><button class="btn block" data-act="' + (canStart ? 'start' : 'reload') + '">' + (canStart ? (p.done + p.skipped > 0 ? '继续复习' : '开始复习') : '刷新任务') + '</button></div></section>';
    html += '<section class="card v2-overview"><div class="v2-section-head"><h2>今日概览</h2><a href="stats.html">学习统计 ›</a></div><div class="v2-metrics"><div class="v2-metric"><b>' + newDone + ' / ' + newAll.length + '</b><span>新词</span></div><div class="v2-metric"><b>' + p.done + ' / ' + p.total + '</b><span>到期复习</span></div><div class="v2-metric"><b id="pendingCount">' + S.pending + ' 条</b><span>待补交</span></div></div><div class="v2-actions"><button class="btn ghost sm" data-act="flush">补交本机记录</button><a class="btn ghost sm" href="today.html">去今日新词</a></div></section>';
    html += renderQuickLinks(aiOn) + '</div>';
    renderShell(html, 'home');
  }

  // ---------- 渲染：学习流 ----------
  function currentItem() { return S.queue[S.idx] || null; }

  function studyHead(item) {
    var p = progress();
    var html = '<div class="study-head">';
    html += '<div class="row" style="align-items:center">';
    html += '<span class="pill">' + itemLabel(item) + '</span>';
    var posBase = S.done + S.doneInitial + S.skipped + S.skippedInit;
    var posNow = Math.max(1, Math.min(p.total, posBase + (S.phase === 'item_done' ? 0 : 1)));
    html += '<span class="muted small">第 ' + posNow + ' / ' + p.total + ' 个</span>';
    if (S.offlineStudy) html += '<span class="pill">离线</span>';
    html += '<span class="spacer"></span>';
    html += '<span class="badge" id="timer">' + fmt(S.elapsed) + '</span>';
    html += '</div>';
    html += '<div class="bar mt8" role="progressbar" aria-label="已完成比例" aria-valuemin="0" aria-valuemax="100" aria-valuenow="' + p.pct + '"><i style="width:' + p.pct + '%"></i></div>';
    html += '</div>';
    return html;
  }

  // 发音按钮：英美双音，都在同一个点击手势里朗读（iPhone Safari 要求），播放期间按钮显示「朗读中」
  function sayBtn(word, where) {
    var w = esc(word || '');
    var svg = '<svg viewBox="0 0 24 24" width="18" height="18" fill="none" stroke="currentColor" stroke-width="1.7" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M3 9h4l5-4v14l-5-4H3zM16 9a4 4 0 0 1 0 6m3-9a8 8 0 0 1 0 12"/></svg>';
    if (where === 'example') {
      return '<div class="say-row">' +
        '<button class="say-btn" data-act="say" data-w="' + w + '" data-where="example" data-lang="en-US" title="朗读英文例句">' + svg + '<span class="say-txt">听例句</span></button>' +
        '<button class="say-btn ghost" data-act="say" data-w="' + w + '" data-where="example" data-lang="en-US" data-rate="0.72" title="慢速朗读例句">' + svg + '<span class="say-txt">慢速</span></button>' +
        '</div>';
    }
    return '<div class="say-row">' +
      '<button class="say-btn" data-act="say" data-w="' + w + '" data-where="word" data-lang="en-US" title="美式发音">' + svg + '<span class="say-txt">美音</span></button>' +
      '<button class="say-btn ghost" data-act="say" data-w="' + w + '" data-where="word" data-lang="en-GB" title="英式发音">' + svg + '<span class="say-txt">英音</span></button>' +
      '</div>';
  }

  // 单词详情：只显示数据库里真实存在的字段（词性 / 词形变化 / 常用度 / 柯林斯星级 / 英文释义），缺失就不显示
  // 详情 RPC 结果缓存：卡片上的固定搭配和详情折叠共用一次请求
  var DETAIL_CACHE = {};
  function getDetail(id) {
    if (!id) return Promise.resolve(null);
    if (DETAIL_CACHE[id]) return Promise.resolve(DETAIL_CACHE[id]);
    return window.DB.rpc('word_detail', { p_word_id: id }).then(function (d) {
      if (d && d.ok !== false) DETAIL_CACHE[id] = d;
      return d;
    });
  }

  // 卡片上的固定搭配：只显示数据库里真实存在的短语，最多 3 条
  function phrasesHtml(list) {
    if (!list || !list.length) return '';
    var out = [];
    for (var i = 0; i < list.length && i < 3; i++) {
      var p = list[i] || {};
      if (!p.phrase) continue;
      out.push('<div class="phr"><b>' + esc(p.phrase) + '</b><span>' + esc(p.meaning || '') + '</span></div>');
    }
    return out.length ? '<div class="word-phr-box"><div class="wd-k">固定搭配</div>' + out.join('') + '</div>' : '';
  }

  // 卡片上只露「搭配名」（一行小字），完整释义放详情折叠里，避免卡片太满
  function phrasesTeaser(list) {
    if (!list || !list.length) return '';
    var out = [];
    for (var i = 0; i < list.length && i < 3; i++) {
      var p = list[i] || {};
      if (p.phrase) out.push('<span class="phr-chip">' + esc(p.phrase) + '</span>');
    }
    if (!out.length) return '';
    return '<div class="word-phr-line"><span class="wd-k">搭配</span>' + out.join('') + '</div>';
  }

  function fillPhrases() {
    var nodes = view ? view.querySelectorAll('[data-phr]') : [];
    for (var i = 0; i < nodes.length; i++) {
      (function (node) {
        var id = node.getAttribute('data-phr');
        var teaser = node.classList && node.classList.contains('word-phr');
        getDetail(id).then(function (d) {
          var list = d && d.phrases;
          node.innerHTML = teaser ? phrasesTeaser(list) : phrasesHtml(list);
          if (!node.innerHTML) node.innerHTML = '';
        }).catch(function () { node.innerHTML = ''; });
      })(nodes[i]);
    }
  }

  function wordDetailBtn(item) {
    if (!item || !item.word_id) return '';
    var id = esc(item.word_id);
    return '<div class="wd-wrap"><button class="wd-more" data-act="wd" data-id="' + id + '" aria-expanded="false">词性 · 词形 · 常用度</button>' +
      '<div class="wd-box hide" id="wd-' + id + '"></div></div>';
  }

  function freqLabel(rank) {
    var n = parseInt(rank, 10);
    if (!(n > 0)) return '';
    if (n <= 1000) return '最常用（约前 ' + n + ' 位）';
    if (n <= 3000) return '常用（约前 ' + n + ' 位）';
    if (n <= 8000) return '一般（约前 ' + n + ' 位）';
    return '较少见（约前 ' + n + ' 位）';
  }

  function wordDetailHtml(d, id) {
    if (!d || d.ok === false) return '<p class="small muted">没有更多资料。</p>';
    var rows = [];
    function row(k, v) {
      if (v == null || v === '') return;
      rows.push('<div class="wd-row"><span class="wd-k">' + esc(k) + '</span><span class="wd-v">' + v + '</span></div>');
    }
    row('词性', d.pos ? esc(d.pos) : '');
    row('词形变化', d.forms ? esc(d.forms) : '');
    row('常用度', freqLabel(d.freq_rank));
    if (d.misses > 0) row('写错次数', d.misses + ' 次' + (d.mastered ? '（已标记为掌握）' : ''));
    if (d.favorited || d.mastered) {
      var flags = [];
      if (d.favorited) flags.push('已收藏');
      if (d.mastered) flags.push('已掌握');
      rows.push('<div class="wd-row"><span class="wd-k">状态</span><span class="wd-v">' + esc(flags.join(' · ')) + '</span></div>');
    }
    if (d.phrases && d.phrases.length) {
      var pl = [];
      for (var j = 0; j < d.phrases.length; j++) {
        var ph = d.phrases[j] || {};
        if (!ph.phrase) continue;
        pl.push('<p class="wd-def"><b>' + esc(ph.phrase) + '</b> ' + esc(ph.meaning || '') + '</p>');
      }
      if (pl.length) rows.push('<div class="wd-row col"><span class="wd-k">固定搭配</span><div class="wd-v">' + pl.join('') + '</div></div>');
    }
    row('柯林斯星级', d.collins ? new Array(Math.max(1, Math.min(5, d.collins)) + 1).join('★') : '');
    if (d.definition_en) {
      var def = String(d.definition_en).split(/\n+/).filter(function (x) { return x.trim(); }).slice(0, 4);
      var dl = [];
      for (var i = 0; i < def.length; i++) dl.push('<p class="wd-def">' + esc(def[i].trim()) + '</p>');
      rows.push('<div class="wd-row col"><span class="wd-k">英文释义</span><div class="wd-v">' + dl.join('') + '</div></div>');
    }
    if (id) {
      var favLabel = (d && d.favorited) ? '取消收藏' : '收藏这个词';
      var mstLabel = (d && d.mastered) ? '移出错词本（重新学）' : '标为已掌握';
      rows.push('<div class="wd-acts">' +
        '<button type="button" class="btn ghost sm" data-act="fav" data-id="' + esc(id) + '">' + favLabel + '</button>' +
        '<button type="button" class="btn ghost sm" data-act="master" data-id="' + esc(id) + '" data-on="' + ((d && d.mastered) ? '1' : '0') + '">' + mstLabel + '</button>' +
        '</div>');
    }
    if (!rows.length) return '<p class="small muted">没有更多资料。</p>';
    return rows.join('');
  }

  function wordCard(item, compact) {
    var html = '<div class="wordcard">';
    html += '<div class="hero-date">' + esc(domainLabel(item.domain)) + (item.difficulty ? ' · 难度 ' + esc(item.difficulty) : '') + '</div>';
    html += '<div class="word-en">' + esc(item.word) + '</div>';
    html += '<div class="word-ipa">' + esc(item.ipa || '') + '</div>';
    html += sayBtn(item.word, 'word');
    html += '<div class="word-cn">' + esc(item.meaning || '') + '</div>';
    if (item.word_id) html += '<div class="word-phr" data-phr="' + esc(item.word_id) + '"></div>';
    html += wordDetailBtn(item);
    if (!compact) {
      if (item.example_en) {
        html += '<div class="word-ex"><b>' + esc(item.example_en) + '</b>' + sayBtn(item.example_en, 'example');
        if (item.example_zh) html += '<div class="mt8">' + esc(item.example_zh) + '</div>';
        html += '</div>';
      }
    }
    html += '</div>';
    return html;
  }

  function optionsHtml(item, picked, reveal) {
    var html = '';
    for (var i = 0; i < S.options.length; i++) {
      var opt = S.options[i];
      var cls = 'opt';
      if (reveal) {
        if (opt === item.meaning) cls += ' right';
        else if (picked != null && i === picked) cls += ' wrong';
      }
      html += '<button class="' + cls + '" data-act="pick" data-i="' + i + '"' + (reveal ? ' disabled' : '') + '>';
      html += '<span class="k">' + String.fromCharCode(65 + i) + '</span><span>' + esc(opt) + '</span></button>';
    }
    return html;
  }

  // 跟写：输入时实时刷新逐字比对
  function onTypeInput(ev) {
    S.typed = ev && ev.target ? ev.target.value : '';
    if (S.mode !== 'follow') return;
    var item = currentItem();
    var box = $('fwWord');
    if (!item || !box) return;
    box.innerHTML = followHtml(item.word).replace(/^<div class="fw-word" id="fwWord"[^>]*>/, '').replace(/<\/div>$/, '');
  }

  function renderStudy() {
    var item = currentItem();
    if (!item) { renderDone(); return; }
    var html = studyHead(item);
    var stage = { card:'认识单词', quiz:'词义选择', quiz_fb:'词义反馈', spell:'拼写练习', spell_fb:'拼写反馈', retry:'当轮复现', retry_fb:'复现反馈',
      type: modeName(S.mode), type_fb: '模式反馈', saving:'保存记录', item_done:'本词结果' };
    html += '<div class="v2-study-stage">' + stage[S.phase] + '</div>';

    if (S.phase === 'card') {
      html += wordCard(item, false);
      html += '<div class="card tight">';
      html += '<p class="small muted">学习模式</p>';
      html += modeChipsHtml();
      html += '<p class="small muted mt8">' + esc((MODES[S.mode] || MODES.read).tip) + '</p>';
      var startAct = S.mode === 'read' ? 'toquiz' : 'totype';
      var startLabel = S.mode === 'read' ? '开始答题' : '开始' + modeName(S.mode);
      html += '<div class="row mt8"><button class="btn block" data-act="' + startAct + '"' + (S.busy ? ' disabled' : '') + '>' + startLabel + '</button></div>';
      html += '<div class="row mt8"><button class="btn ghost sm" data-act="skip"' + (S.busy ? ' disabled' : '') + '>跳过这个词</button></div>';
      html += '</div>';
    } else if (S.phase === 'type') {
      html += '<div class="card tight"><h3>' + esc(modeName(S.mode)) + '</h3>';
      if (S.mode === 'selftest') {
        html += '<p class="small muted">先在心里回忆这个中文对应的英文，然后老实自评。</p>';
        html += '<div class="word-cn">' + esc(item.meaning || '') + '</div>';
        html += '<div class="row mt12"><button class="btn block" data-act="selfrate" data-r="known"' + (S.busy ? ' disabled' : '') + '>认识，能直接写出来</button></div>';
        html += '<div class="row mt8"><button class="btn ghost block" data-act="selfrate" data-r="fuzzy"' + (S.busy ? ' disabled' : '') + '>有点印象，但要想想</button></div>';
        html += '<div class="row mt8"><button class="btn ghost block" data-act="selfrate" data-r="unknown"' + (S.busy ? ' disabled' : '') + '>不认识</button></div>';
      } else if (S.mode === 'follow') {
        html += '<p class="small muted">照着敲一遍，敲错的字母会标红。</p>';
        html += followHtml(item.word);
        html += '<div class="mt8">' + sayBtn(item.word, 'word') + '</div>';
        html += typeInputHtml(item, '照着上面的单词输入');
      } else if (S.mode === 'dictate') {
        html += '<p class="small muted">听发音，写出你听到的单词。可以反复重听。</p>';
        html += '<div class="mt8">' + sayBtn(item.word, 'word') + '</div>';
        html += '<p class="small muted mt8">提示默认关闭；实在听不出可点下面的按钮。</p>';
        html += '<div class="mt8"><button type="button" class="btn ghost sm" data-act="typehint" aria-expanded="' + (S.hintUsed ? 'true' : 'false') + '">' + (S.hintUsed ? '已给出首字母和长度' : '给一点提示') + '</button>';
        if (S.hintUsed) html += '<p class="muted small mt8" id="typeHint">首字母 ' + esc(String(item.word).charAt(0)) + '，共 ' + String(item.word).length + ' 个字母</p>';
        html += '</div>';
        html += typeInputHtml(item, '听到什么就写什么');
      } else {
        html += '<div class="word-cn">' + esc(item.meaning || '') + '</div>';
        if (item.pos) html += '<p class="small muted mt8">词性 ' + esc(item.pos) + '</p>';
        html += '<div class="mt8"><button type="button" class="btn ghost sm" data-act="typehint" aria-expanded="' + (S.hintUsed ? 'true' : 'false') + '">' + (S.hintUsed ? '已给出首字母和长度' : '给一点提示') + '</button>';
        if (S.hintUsed) html += '<p class="muted small mt8" id="typeHint">首字母 ' + esc(String(item.word).charAt(0)) + '，共 ' + String(item.word).length + ' 个字母</p>';
        html += '</div>';
        html += typeInputHtml(item, '写出对应的英文单词');
      }
      if (S.mode !== 'selftest') html += '<div class="row mt8"><button class="btn block" data-act="typesubmit"' + (S.busy ? ' disabled' : '') + '>提交</button></div>';
      html += '</div>';
    } else if (S.phase === 'type_fb') {
      var tok = S.typeOk;
      html += '<div class="card tight">';
      html += '<h3>' + (tok ? modeName(S.mode) + '正确' : modeName(S.mode) + '有误') + '</h3>';
      html += '<div class="word-en" style="font-size:26px">' + esc(item.word) + '</div>';
      html += '<div class="word-ipa">' + esc(item.ipa || '') + '</div>';
      html += sayBtn(item.word, 'feedback');
      html += '<div class="word-cn">' + esc(item.meaning || '') + '</div>';
      if (S.mode === 'selftest') {
        html += '<div class="note mt12">' + (tok ? '自评认识：复习间隔会拉长。' : (S.selfFuzzy ? '自评「有点印象」：这个词会更快再出现一次。' : '自评不认识：按未掌握重新安排复习。')) + '</div>';
      } else if (!tok) html += '<div class="note mt12">你写的是「' + esc(S.typed || '（空）') + '」。这个词会按未掌握重新安排复习。</div>';
      if (tok && S.hintUsed) html += '<div class="note mt12">这次用了提示，按「提示后答对」记录，复习间隔会比独立答对短一些。</div>';
      if (tok && !S.hintUsed) html += '<div class="note mt12">独立写对了，复习间隔会拉长。</div>';
      html += '<div class="row mt16"><button class="btn block" data-act="save">完成这个词</button></div>';
      html += '</div>';
    } else if (S.phase === 'quiz' || S.phase === 'retry') {
      html += '<div class="card tight"><h3>' + (S.phase === 'retry' ? '当轮复现：再选一次' : '选出正确的中文意思') + '</h3>';
      html += '<div class="word-en" style="font-size:26px">' + esc(item.word) + '</div>';
      html += '<div class="word-ipa">' + esc(item.ipa || '') + '</div>';
      html += sayBtn(item.word, 'quiz');
      html += optionsHtml(item, null, false);
      html += '</div>';
      html += wordExSmall(item);
    } else if (S.phase === 'quiz_fb') {
      var ok = S.pickedMeaningOk;
      html += '<div class="card tight">';
      html += '<h3>' + (ok ? '答对了' : '答错了') + '</h3>';
      html += '<div class="word-en" style="font-size:26px">' + esc(item.word) + '</div>';
      html += '<div class="word-ipa">' + esc(item.ipa || '') + '</div>';
      html += sayBtn(item.word, 'feedback');
      html += '<div class="word-cn">' + esc(item.meaning || '') + '</div>';
      if (!ok) html += '<div class="note mt12">这个词会在本轮再练一次；最终复习安排只按这次（第一次）的作答计算。</div>';
      html += '<div class="row mt16"><button class="btn block" data-act="tospell">继续：拼写这个词</button></div>';
      html += '</div>';
    } else if (S.phase === 'spell') {
      html += '<div class="card tight"><h3>拼写这个词</h3>';
      html += '<div class="word-cn">' + esc(item.meaning || '') + '</div>';
      html += '<div class="mt8"><button type="button" class="btn ghost sm" data-act="spellhint" aria-expanded="false" aria-controls="spellHint">查看提示</button><p class="muted small mt8" id="spellHint" aria-live="polite" hidden></p></div>';
      html += '<div class="field mt8"><input id="spellInput" aria-label="输入英文单词" type="text" autocomplete="off" autocapitalize="off" autocorrect="off" spellcheck="false" placeholder="在这里输入英文单词"></div>';
      html += '<div class="row"><button class="btn block" data-act="spell"' + (S.busy ? ' disabled' : '') + '>提交拼写</button></div>';
      html += '</div>';
    } else if (S.phase === 'spell_fb') {
      var sok = S.spellOk;
      html += '<div class="card tight">';
      html += '<h3>' + (sok ? '拼写正确' : '拼写有误') + '</h3>';
      html += '<div class="word-en" style="font-size:26px">' + esc(item.word) + '</div>';
      html += '<div class="word-cn">' + esc(item.meaning || '') + '</div>';
      if (!sok) html += '<div class="note mt12">你输入的是「' + esc(S.spellInput || '（空）') + '」。拼写不计入复习安排，但仍会记入学习记录。</div>';
      html += '<div class="row mt16"><button class="btn block" data-act="' + (S.firstResult === 'incorrect' ? 'toretry' : 'save') + '">';
      html += (S.firstResult === 'incorrect' ? '继续：当轮复现' : '完成这个词') + '</button></div>';
      html += '</div>';
    } else if (S.phase === 'retry_fb') {
      html += '<div class="card tight">';
      html += '<h3>' + (S.retryOk ? '复现答对了' : '复现又答错了') + '</h3>';
      html += '<div class="word-en" style="font-size:26px">' + esc(item.word) + '</div>';
      html += '<div class="word-ipa">' + esc(item.ipa || '') + '</div>';
      html += '<div class="word-cn">' + esc(item.meaning || '') + '</div>';
      html += '<div class="note mt12">本轮复现只用于巩固，不会改变按第一次作答计算的复习间隔。这个词明天会再次出现。</div>';
      html += '<div class="row mt16"><button class="btn block" data-act="save">完成这个词</button></div>';
      html += '</div>';
    } else if (S.phase === 'saving') {
      html += '<div class="card center"><p class="muted">正在保存作答…</p></div>';
    } else if (S.phase === 'item_done') {
      var st = S.lastSave || {};
      var map = {
        sent: '已保存到云端',
        queued: '已在本机排队，联网后自动补交',
        dead: '这条记录被服务端拒绝，不会再重试',
        rejected: '这个条目之前已按另一个答案提交，本次没有覆盖'
      };
      html += '<div class="card tight">';
      html += '<h3>' + (st.status === 'sent' ? '本词记录已提交' : '本词处理结果') + '</h3>';
      html += wordCard(item, true);
      html += '<div class="note mt12">' + esc(map[st.status] || st.message || '已记录') + '</div>';
      if (st.status === 'queued') html += '<p class="small muted mt8">本机还有 ' + S.pending + ' 条待补交记录，回到列表页可点「补交本机记录」。</p>';
      html += '<div class="row mt16"><button class="btn block" data-act="next">' + (S.idx + 1 < S.queue.length ? '下一个词' : '查看今日结果') + '</button></div>';
      html += '</div>';
    }
    var feedback = S.phase === 'type_fb' ? (S.typeOk ? 'correct' : 'incorrect') :
      S.phase === 'quiz_fb' ? (S.pickedMeaningOk ? 'correct' : 'incorrect') :
      S.phase === 'spell_fb' ? (S.spellOk ? 'correct' : 'incorrect') :
      S.phase === 'retry_fb' ? (S.retryOk ? 'correct' : 'incorrect') : '';
    renderShell(html, 'study', S.phase, feedback);
    if (S.phase === 'spell') {
      var inp = $('spellInput');
      if (inp) {
        inp.value = '';
        setTimeout(function () { try { inp.focus(); } catch (e) { /* iOS 需用户手势，忽略 */ } }, 30);
      }
    }
    if (S.phase === 'type') {
      var tin = $('typeInput');
      if (tin) {
        tin.value = S.typed || '';
        tin.addEventListener('input', onTypeInput);
        tin.addEventListener('keydown', function (ev) {
          if (ev.key === 'Enter') { ev.preventDefault(); ACT.typesubmit(); }
        });
        setTimeout(function () { try { tin.focus({ preventScroll: true }); } catch (e) { /* iOS 需用户手势 */ } }, 30);
      }
    }
  }

  function wordExSmall(item) {
    if (!item.example_en) return '';
    var html = '<div class="card tight"><p class="small muted">例句（只给英文，答题时参考）</p>';
    html += '<p class="small"><b>' + esc(item.example_en) + '</b></p>' + sayBtn(item.example_en, 'example');
    html += '</div>';
    return html;
  }

  function firstLetterHint(word) {
    var w = String(word || '');
    if (w.length <= 2) return w.charAt(0) + '…';
    return w.charAt(0) + new Array(Math.max(1, w.length - 2)).join('_') + w.charAt(w.length - 1);
  }

  // ---------- 渲染：完成 ----------
  function renderDone() {
    var p = progress();
    var html = '<div class="card center">';
    var label = MODE === 'review' ? '复习' : '新词学习';
    var heading = !p.total ? (MODE === 'review' ? '暂无到期单词' : '暂无待学新词') :
      p.skipped === p.total ? '本轮' + label + '已跳过' : p.skipped ? '本轮' + label + '结束' :
      p.done === p.total ? '今日' + label + '已完成' : '本轮' + label + '结果';
    html += '<h2>' + heading + '</h2>';
    html += '<p class="muted">本轮共 ' + p.total + ' 个词，已完成 ' + p.done + ' 个，已跳过 ' + p.skipped + ' 个。当前学习用时 ' + fmt(S.elapsed) + '。</p>';
    if (MODE === 'today') {
      html += '<div class="row mt16"><a class="btn block" href="lesson.html">继续其他课程（语法·听力·阅读·口语）</a></div>';
      html += '<div class="row mt8"><a class="btn ghost block" href="review.html">去到期复习</a></div>';
    } else {
      html += '<div class="row mt16"><a class="btn block" href="today.html">去今日新词</a></div>';
      html += '<div class="row mt8"><a class="btn ghost block" href="lesson.html">学习其他课程（语法·听力·阅读·口语）</a></div>';
    }
    html += '<div class="row mt8"><button class="btn ghost block" data-act="home">回到任务列表</button></div>';
    html += '</div>';
    html += '<section id="lumi-done-difficulty" class="card" hidden></section>';
    if (S.offlineStudy) {
      html += '<div class="note mt12">这次是离线学习：记录已存在本机，回到联网状态后会自动补交。</div>';
    }
    if (S.pending > 0) {
      html += '<div class="note mt12">本机还有 ' + S.pending + ' 条记录没有提交成功。联网后会自动补交，也可以手动重试。</div>';
      html += '<div class="row mt8"><button class="btn ghost sm" data-act="flush">立即补交</button></div>';
    }
    renderShell(html, 'done');
    reportDifficulty();
  }

  // ---------- 难度反馈（Codex 九级难度：words 模块由本页在会话结束时上报一次） ----------
  function reportDifficulty() {
    var D = window.Difficulty;
    var st = S.zStats;
    if (!D || !D.report || !st || !st.independent) return;
    if (!S.zUnit) {
      var day = (S.task && S.task.study_date) || todayStr();
      S.zUnit = 'words:' + day + ':' + String(S.allItems.length) + ':' + String(Date.now());
    }
    try {
      Promise.resolve(D.read()).then(function (res) {
        var lv = res && res.words ? res.words : null;
        if (!lv) return;
        var mount = document.getElementById('lumi-done-difficulty') || document.getElementById('lumi-home-difficulty');
        if (mount) { mount.hidden = false; }
        return D.report({ module: 'words', level: lv, unitKey: S.zUnit, stats: st, mount: mount || undefined });
      }).catch(function () { /* 反馈失败不影响学习 */ });
    } catch (e) { /* ignore */ }
  }

  // ---------- 数据流程 ----------
  function refreshPending() {
    return window.Learn.pendingCount().then(function (n) {
      S.pending = n || 0;
      var el = $('pendingCount');
      if (el) el.textContent = S.pending + ' 条';
      return S.pending;
    }).catch(function () { return S.pending; });
  }

  function applyTask(task, opt) {
    opt = opt || {};
    S.task = task || {};
    var items = S.task.items || [];
    S.allItems = items.filter(function (it) { return it.task_type === (MODE === 'review' ? 'review' : 'new'); });
    S.queue = S.allItems.filter(function (it) { return it.status === 'pending'; });
    S.doneInitial = S.allItems.filter(function (it) { return it.status === 'completed'; }).length;
    S.skippedInit = S.allItems.filter(function (it) { return it.status === 'skipped'; }).length;
    S.offlineView = opt.offline === true;
    S.cacheDate = opt.cacheDate || '';
    S.idx = 0; S.done = 0; S.skipped = 0; S.phase = 'card'; S.lastSave = null; S.firstResult = null;
    S.zUnit = ''; S.zStats = { independent: 0, correct: 0, hints: 0, repeated: 0 };
    S.offlineStudy = false;
    if (S.localTimer) { clearInterval(S.localTimer); S.localTimer = null; }
    S.status = S.queue.length > 0 ? 'home' : 'done';
    if (S.status === 'done' && MODE !== 'today') { renderDone(); } else { renderHome(); }
    refreshPending();
  }

  // 断网/连不上服务器时：读本机快照渲染，不再只给「加载失败」
  function loadCachedTask(uid, tip) {
    var got = (window.OfflineCache && uid) ? window.OfflineCache.getTask(uid) : null;
    if (!got || !got.task) return false;
    applyTask(got.task, { offline: true, cacheDate: got.date });
    toast(tip || '没有网络：显示上次同步的内容，记录会先存在本机', 3200);
    return true;
  }

  // list_wordbooks 返回所有公共词书；mine_status 才代表个人加入状态。
  // 不允许初始化失败后继续调用会从全库抽词的旧 RPC 路径。
  function enrollmentError(message) {
    var err = new Error(message);
    err.code = 'wordbook_required';
    return err;
  }

  function readEnrollment() {
    return window.DB.rpc('list_wordbooks', {}).then(function (res) {
      if (!res || res.ok !== true || !Array.isArray(res.wordbooks) || !res.wordbooks.length) {
        throw enrollmentError('无法确认词书状态，请重试或前往词书中心。');
      }
      // 旧种子词书（code=seed）在词书中心里对新用户隐藏，但存量账号可能正用它。
      // 迁移 027 未执行前，直接把它判为“正在更新”会让老账号一进首页就加载失败，
      // 所以这里只把未加入的 seed 排除，已加入/暂停的 seed 仍按普通词书处理。
      var list = res.wordbooks.filter(function (b) {
        return !b || b.code !== 'seed' || b.mine_status === 'active' || b.mine_status === 'paused';
      });
      if (list.some(function (b) {
        return !b || typeof b.id !== 'string' || !b.id || typeof b.code !== 'string' ||
          typeof b.is_current !== 'boolean' ||
          (b.mine_status !== null && b.mine_status !== 'active' && b.mine_status !== 'paused');
      })) throw enrollmentError('词书状态异常，请重试或前往词书中心。');
      var current = list.filter(function (b) { return b.is_current; });
      if (current.length > 1 || (current.length && current[0].mine_status !== 'active')) {
        throw enrollmentError('当前词书状态异常，请前往词书中心重新选择。');
      }
      return { list: list, current: current[0] || null,
        joined: list.filter(function (b) { return b.mine_status !== null; }),
        active: list.filter(function (b) { return b.mine_status === 'active'; }) };
    });
  }

  function ensureEnrollment() {
    if (!window.DB || typeof window.DB.rpc !== 'function') {
      return Promise.reject(enrollmentError('词书服务未就绪，请重试。'));
    }
    if (typeof navigator !== 'undefined' && navigator.onLine === false) {
      return Promise.reject(new Error('当前离线，无法确认词书状态'));
    }
    return readEnrollment().then(function (state) {
      if (state.current) return state.current; // 保留用户已选的真实词书，不改变学习模式
      var rpcName, target;
      if (!state.joined.length) {
        target = state.list.find(function (b) { return b.code === 'daily'; });
        if (!target) throw enrollmentError('找不到日常高频词书，请前往词书中心。');
        rpcName = 'add_wordbook'; // 首次加入会自动设为当前；不会主动覆盖已存在的 current
      } else if (state.active.length === 1) {
        target = state.active[0];
        rpcName = 'set_current_wordbook';
      } else {
        throw enrollmentError('请前往词书中心选择一本当前词书，再继续学习。');
      }
      return window.DB.rpc(rpcName, { p_book_id: target.id }).then(function (res) {
        if (!res || res.ok !== true) throw enrollmentError('词书设置未成功，请重试或前往词书中心。');
        // 不能只相信写 RPC 返回 ok；再次确认存在有效 current 才能生成任务。
        return readEnrollment().then(function (after) {
          if (!after.current) throw enrollmentError('当前词书尚未生效，请重试或前往词书中心。');
          return after.current;
        });
      });
    });
  }

  var taskLoadInFlight = null;
  function loadTask() {
    if (taskLoadInFlight) return taskLoadInFlight;
    S.status = 'loading';
    setAuto(false);   // 首页/加载/失败/完成都不是真实学习状态
    renderLoading();
    var uid = null;
    taskLoadInFlight = Promise.resolve().then(function () { return window.Learn.ready(); }).then(function (who) {
      if (!who || !who.user_id) throw new Error('没有登录会话');
      uid = who.user_id;
      S.user = S.user || { id: uid };
      // 在线生成任务前必须确认有效词书；旧任务由服务端原样返回。
      return ensureEnrollment().then(function () { return window.Learn.loadTask(); });
    }).then(function (res) {
      if (!res || res.ok !== true) {
        var msg = (res && (res.message || res.code)) || '任务创建失败';
        throw new Error(msg);
      }
      if (window.OfflineCache && uid) window.OfflineCache.putTask(uid, res.task || {});
      applyTask(res.task || {}, {});
      loadLevels();
    }).catch(function (e) {
      var off = (typeof navigator !== 'undefined' && navigator.onLine === false);
      function fallback(u) {
        var bookError = e && e.code === 'wordbook_required';
        var tip = bookError ? '词书未就绪：显示已同步任务，请前往词书中心' :
          (off ? '现在没有网络：显示上次同步的内容' : '连不上服务器：显示上次同步的内容');
        if (loadCachedTask(u, tip)) return;
        S.status = 'error';
        S.error = (e && e.message) || '加载失败';
        S.offline = off;
        if (off) S.error = '连不上服务器（已离线），本机还没有缓存过今天的内容';
        else if (/登录|auth|jwt|session/i.test(S.error)) S.error += '（点「重新登录」可重新进入）';
        renderError();
      }
      if (uid) { fallback(uid); return; }
      Promise.resolve(window.DB && window.DB.auth ? window.DB.auth.getUserId() : null)
        .then(function (u) { fallback(u); })
        .catch(function () { fallback(null); });
    }).finally(function () { taskLoadInFlight = null; });
    return taskLoadInFlight;
  }

  // 无网络时继续学：会话服务连不上，就用本机队列记录（attempt/final 都以 session_id=null 提交，
  // 服务端 log_study_event 允许 session_id 为空，联网补交时照样入库）
  function startOfflineStudy() {
    setAuto(false);   // 离线没有在线会话，回前台只补交队列，不反复尝试建会话
    S.offlineStudy = true;
    S.offlineView = false;
    S.status = 'study';
    S.phase = 'card';
    S.itemStart = Date.now();
    S.elapsed = 0;
    if (S.localTimer) clearInterval(S.localTimer);
    S.localTimer = setInterval(function () {
      if (S.status !== 'study') return;
      S.elapsed += 1;
      var el = $('timer');
      if (el) el.textContent = fmt(S.elapsed);
    }, 1000);
    renderStudy();
    toast('离线学习：记录先存在本机，联网后自动补交', 3200);
  }

  function startSession() {
    if (S.busy) return;
    S.busy = true;
    S.starting = true;
    setAuto(true);    // 用户点了「开始学习」：此刻起回前台允许恢复/重建会话
    window.Learn.Session.start().then(function (res) {
      S.busy = false;
      S.starting = false;
      if (!res) {
        setAuto(false);
        if (typeof navigator !== 'undefined' && navigator.onLine === false) { startOfflineStudy(); return; }
        toast('学习会话创建失败，请检查网络后重试'); renderHome(); return;
      }
      S.offlineStudy = false;
      if (S.localTimer) { clearInterval(S.localTimer); S.localTimer = null; }
      S.status = 'study';
      S.phase = 'card';
      S.itemStart = Date.now();
      S.elapsed = 0;
      S.typed = '';
      S.hintUsed = false;
      loadMode().then(renderStudy, renderStudy);
    }).catch(function (e) {
      S.busy = false;
      S.starting = false;
      setAuto(false);
      toast('启动学习失败：' + ((e && e.message) || e), 5000);
    });
  }

  function attempt(item, result, no) {
    var dur = Math.round((Date.now() - (S.attemptStart || Date.now())) / 1000);
    S.attemptStart = Date.now();
    if (S.zStats) {
      if (no === 1) { S.zStats.independent += 1; if (result === 'correct') S.zStats.correct += 1; if (S.hintUsed) S.zStats.hints += 1; }
      else S.zStats.repeated += 1;
    }
    return window.Learn.submitAttempt(item.word_id, item.item_id, item.task_type, result, dur, no,
      { mode: S.mode === 'read' ? 'read' : S.mode, hint: !!S.hintUsed })
      .catch(function (e) {
        toast('作答记录没提交成功：' + ((e && e.message) || '网络问题'));
        return null;
      });
  }

  // 写错了就记一笔（错词本）：只写数据库，不走 AI，失败也不打扰学习
  function noteMiss(item, mode, typed) {
    if (!item || !item.word_id || !window.DB || typeof window.DB.rpc !== 'function') return;
    try {
      window.DB.rpc('record_word_miss', {
        p_word_id: item.word_id,
        p_typed: String(typed == null ? '' : typed).slice(0, 60),
        p_mode: String(mode || '').slice(0, 20)
      }).catch(function () { /* 记不上不影响本轮学习 */ });
    } catch (e) { /* 忽略 */ }
    if (DETAIL_CACHE[item.word_id]) { DETAIL_CACHE[item.word_id].misses = (DETAIL_CACHE[item.word_id].misses || 0) + 1; }
  }

  function cachePatch(itemId, status, result) {
    try {
      if (window.OfflineCache && S.user && S.user.id) {
        window.OfflineCache.patchTaskItem(S.user.id, itemId, status, result || null);
      }
    } catch (e) { /* 缓存写失败不影响学习 */ }
  }

  function saveFinal() {
    var item = currentItem();
    if (!item) return;
    S.phase = 'saving';
    renderStudy();
    window.Learn.submitFinal(item.item_id, S.firstResult === 'correct' ? 'correct' : 'incorrect').then(function (res) {
      S.lastSave = res || { status: 'queued', message: '未知状态' };
      S.done += 1;
      S.phase = 'item_done';
      cachePatch(item.item_id, 'completed', S.firstResult === 'correct' ? 'correct' : 'incorrect');
      refreshPending().then(renderStudy);
      if (S.lastSave.status === 'queued') toast('已排在本机，联网后自动补交');
      if (S.lastSave.status === 'dead') toast('服务端拒绝了这条记录，已停止重试');
    }).catch(function (e) {
      S.lastSave = { status: 'queued', message: (e && e.message) || '提交失败，已保留在本机' };
      S.done += 1;
      S.phase = 'item_done';
      refreshPending().then(renderStudy);
      toast('提交失败，已保留在本机，稍后补交');
    });
  }

  // ---------- 交互动作 ----------
  // 朗读：必须在 click 事件里同步调用（iPhone Safari 不允许延迟播放）
  function speakWord(word, btn, lang, rate) {
    if (!window.Speech || typeof window.Speech.say !== 'function') return;
    if (!window.Speech.supported()) {
      toast('这个浏览器不支持朗读，换用 Safari 或新版 Edge 试试');
      return;
    }
    // 显式点按：一定朗读（force），并先 cancel 上一段，保证不叠音
    var ok = window.Speech.say(word, { lang: lang || 'en-US', rate: rate || 0, force: true });
    if (!ok) {
      toast('这个浏览器暂时读不出，可以换 Safari 或新版 Edge');
      return;
    }
    if (!btn) return;
    var txt = btn.querySelector ? btn.querySelector('.say-txt') : null;
    if (!txt) return;
    var old = txt.textContent;
    txt.textContent = '朗读中…';
    // 不禁用按钮：再点一次就是「重播」（内部会先 cancel 上一个，不会叠音）
    setTimeout(function () { txt.textContent = old; }, 1200);
  }

  var ACT = {
    planStart: function () {
      if (window.LumiPlan) window.LumiPlan.markStart();
      ACT.start();
    },
    planSkip: function () {
      if (window.LumiPlan) window.LumiPlan.skipToday();
      var n = document.getElementById('planCard');
      if (n) { n.hidden = true; n.innerHTML = ''; }
    },
    planRefresh: function () {
      var n = document.getElementById('planCard');
      if (n) n.innerHTML = '<div class="v2-plan-head"><div><b>接着学这些</b><span class="small muted">正在重新看你的记录…</span></div></div>';
      if (window.LumiPlan) window.LumiPlan.clearContext();
      hydratePlan();
    },
    wd: function (el) {
      var id = el.getAttribute('data-id');
      var box = id ? document.getElementById('wd-' + id) : null;
      if (!box) return;
      if (!box.classList.contains('hide')) {
        box.classList.add('hide');
        el.setAttribute('aria-expanded', 'false');
        return;
      }
      box.classList.remove('hide');
      el.setAttribute('aria-expanded', 'true');
      if (box.dataset && box.dataset.loaded) return;
      box.innerHTML = '<p class="small muted">正在读取…</p>';
      getDetail(id).then(function (d) {
        if (box.dataset) box.dataset.loaded = '1';
        box.innerHTML = wordDetailHtml(d, id);
      }).catch(function () {
        box.innerHTML = '<p class="small muted">详情暂时读不到，稍后再试。</p>';
      });
    },
    spellhint: function (el) {
      var item = currentItem(), hint = $('spellHint');
      if (S.phase !== 'spell' || !item || !hint) return;
      var reveal = el.getAttribute('aria-expanded') !== 'true';
      hint.textContent = reveal ? '提示：' + firstLetterHint(item.word) + '，共 ' + item.word.replace(/[^A-Za-z]/g, '').length + ' 个字母' : '';
      hint.hidden = !reveal;
      el.setAttribute('aria-expanded', String(reveal));
      el.textContent = reveal ? '收起提示' : '查看提示';
    },
    say: function (el) {
      var w = el.getAttribute('data-w') || '';
      var lang = el.getAttribute('data-lang') || 'en-US';
      var rate = parseFloat(el.getAttribute('data-rate') || '0') || 0;
      speakWord(w, el, lang, rate);
    },
    fav: function (el) {
      var id = el.getAttribute('data-id');
      if (!id || !window.DB) return;
      el.disabled = true;
      window.DB.rpc('toggle_word_favorite', { p_word_id: id }).then(function (r) {
        el.disabled = false;
        if (!r || r.ok === false) { toast('收藏没存上，稍后再试'); return; }
        if (DETAIL_CACHE[id]) DETAIL_CACHE[id].favorited = r.favorited;
        el.textContent = r.favorited ? '取消收藏' : '收藏这个词';
        toast(r.favorited ? '已加入收藏' : '已取消收藏');
      }).catch(function () {
        el.disabled = false;
        toast('收藏没存上，稍后再试');
      });
    },
    master: function (el) {
      var id = el.getAttribute('data-id');
      if (!id || !window.DB) return;
      var on = el.getAttribute('data-on') === '1';
      el.disabled = true;
      window.DB.rpc('set_word_mistake_mastered', { p_word_id: id, p_mastered: !on }).then(function (r) {
        el.disabled = false;
        if (!r || r.ok === false) { toast('没有保存成功，稍后再试'); return; }
        if (DETAIL_CACHE[id]) DETAIL_CACHE[id].mastered = !on;
        el.setAttribute('data-on', on ? '0' : '1');
        el.textContent = on ? '标为已掌握' : '移出错词本（重新学）';
        toast(on ? '已放回错词本，会重新练' : '已标记为掌握，不再进错词本');
      }).catch(function () {
        el.disabled = false;
        toast('没有保存成功，稍后再试');
      });
    },
    reload: function () { loadTask(); },
    logout: function () { window.AppAuth.logout(); },
    start: function () { startSession(); },
    home: function () { loadTask(); },
    flush: function () {
      window.Learn.flush().then(function (r) {
        var sent = (r && r.sent ? r.sent.length : 0);
        var dead = (r && r.dead ? r.dead.length : 0);
        toast(sent > 0 ? '补交成功 ' + sent + ' 条' : (dead > 0 ? '有 ' + dead + ' 条被服务端拒绝' : '没有可补交的记录'));
        return refreshPending();
      }).catch(function (e) { toast('补交失败：' + ((e && e.message) || '网络问题')); });
    },
    toquiz: function () {
      var item = currentItem(); if (!item || S.busy) return;
      // 答题前先听一遍（可在设置里关掉）。这里仍在点击事件内，iOS 允许播放。
      try {
        var sp = window.Speech && window.Speech.prefs ? window.Speech.prefs() : null;
        if (sp && sp.on && sp.auto) speakWord(item.word, null);
      } catch (e) {}
      S.options = buildOptions(item);
      S.picked = null;
      S.phase = 'quiz';
      S.attemptStart = Date.now();
      renderStudy();
    },
    pick: function (el) {
      var item = currentItem(); if (!item || S.busy) return;
      var i = parseInt(el.getAttribute('data-i'), 10);
      S.picked = i;
      var chosen = S.options[i];
      var ok = chosen === item.meaning;
      if (!ok) noteMiss(item, S.mode === 'read' ? 'choice' : S.mode, '');
      if (S.phase === 'quiz') {
        S.firstResult = ok ? 'correct' : 'incorrect';
        S.pickedMeaningOk = ok;
        attempt(item, ok ? 'correct' : 'incorrect', 1);
        S.phase = 'quiz_fb';
        renderStudy();
      } else if (S.phase === 'retry') {
        S.retryOk = ok;
        attempt(item, ok ? 'correct' : 'incorrect', 3);
        S.phase = 'retry_fb';
        renderStudy();
      }
    },
    mode: function (el) {
      if (S.busy) return;
      var m = el.getAttribute('data-mode');
      if (!MODES[m] || m === S.mode) return;
      S.busy = true;
      saveMode(m).then(function () {
        S.busy = false;
        renderStudy();
        toast('学习模式已切到「' + modeName(S.mode) + '」');
      });
    },
    selfrate: function (el) {
      if (S.busy) return;
      var r = el.getAttribute('data-r');
      var item = currentItem();
      if (!item) return;
      S.busy = true;
      var ok = r === 'known';
      S.typeOk = ok;
      S.selfFuzzy = r === 'fuzzy';
      S.typed = '';
      if (!ok && window.DB && r === 'unknown') noteMiss(item, 'selftest', '');
      attempt(item, ok ? 'correct' : 'incorrect', r === 'fuzzy' ? 2 : 1);
      S.busy = false;
      S.phase = 'type_fb';
      renderStudy();
    },
    totype: function () {
      if (S.busy) return;
      S.phase = 'type';
      S.typed = '';
      S.typeOk = null;
      S.hintUsed = false;
      S.attemptStart = Date.now();
      renderStudy();
    },
    typehint: function () {
      if (S.phase !== 'type' || S.hintUsed) return;
      S.hintUsed = true;
      renderStudy();
    },
    typesubmit: function () {
      var item = currentItem();
      if (!item || S.busy) return;
      var inp = $('typeInput');
      var val = inp ? inp.value : S.typed;
      S.typed = String(val || '');
      var ok = normSpell(S.typed) === normSpell(item.word);
      S.typeOk = ok;
      if (!ok) noteMiss(item, S.mode, S.typed);
      // 提示后答对：按未掌握记录，避免"看一眼写出来"就拉长间隔
      var record = ok && !S.hintUsed ? 'correct' : 'incorrect';
      S.firstResult = record;
      attempt(item, record, 1);
      S.phase = 'type_fb';
      renderStudy();
    },
    tospell: function () {
      S.phase = 'spell';
      S.attemptStart = Date.now();
      S.spellInput = '';
      renderStudy();
    },
    spell: function () {
      var item = currentItem(); if (!item || S.busy) return;
      var inp = $('spellInput');
      var val = inp ? inp.value : '';
      S.spellInput = val;
      var ok = normSpell(val) === normSpell(item.word);
      S.spellOk = ok;
      if (!ok) noteMiss(item, 'spell', val);
      attempt(item, ok ? 'correct' : 'incorrect', 2);
      S.phase = 'spell_fb';
      renderStudy();
    },
    toretry: function () {
      var item = currentItem(); if (!item) return;
      S.options = buildOptions(item);
      S.picked = null;
      S.phase = 'retry';
      renderStudy();
    },
    save: function () { saveFinal(); },
    next: function () {
      if (S.idx + 1 < S.queue.length) {
        S.idx += 1;
        S.phase = 'card';
        S.picked = null;
        S.firstResult = null;
        S.lastSave = null;
        S.typed = '';
        S.typeOk = null;
        S.hintUsed = false;
        S.itemStart = Date.now();
        renderStudy();
        return;
      }
      setAuto(false);
      window.Learn.Session.end();
      if (S.localTimer) { clearInterval(S.localTimer); S.localTimer = null; }
      S.status = 'done';
      renderDone();
      window.Learn.flush().then(refreshPending);
    },
    skip: function () {
      var item = currentItem(); if (!item || S.busy) return;
      S.busy = true;
      window.Learn.skipItem(item.item_id).then(function (res) {
        S.busy = false;
        var st = res && res.status;
        if (st === 'sent' || st === 'queued') {
          S.skipped += 1;
          S.lastSave = { status: st, message: res.message };
          S.phase = 'item_done';
          cachePatch(item.item_id, 'skipped', null);
          renderStudy();
        } else {
          toast('跳过没提交成功：' + ((res && res.message) || '未知错误'));
          renderStudy();
        }
      }).catch(function (e) {
        S.busy = false;
        toast('跳过失败：' + ((e && e.message) || '网络问题'));
        renderStudy();
      });
    }
  };

  function bind() {
    view = $('view');
    function stopPronunciation() { if (window.Speech) window.Speech.stop(); }
    window.addEventListener('pagehide', stopPronunciation);
    document.addEventListener('visibilitychange', function () { if (document.hidden) stopPronunciation(); });
    window.addEventListener('error', function (ev) {
      toast('页面脚本错误：' + ((ev && ev.message) || '未知'), 6000);
    });
    window.addEventListener('unhandledrejection', function (ev) {
      var reason = ev && ev.reason;
      toast('异步错误：' + ((reason && (reason.message || reason.code)) || reason || '未知'), 6000);
    });
    if (!view) { return; }
    view.addEventListener('click', function (ev) {
      var el = ev.target;
      while (el && el !== view) {
        if (el.getAttribute && el.getAttribute('data-act')) break;
        el = el.parentNode;
      }
      if (!el || el === view) return;
      var act = el.getAttribute('data-act');
      var fn = ACT[act];
      if (fn) { ev.preventDefault(); fn(el); }
    });
    view.addEventListener('keydown', function (ev) {
      if (ev.key === 'Enter' && S.phase === 'spell' && ev.target === $('spellInput')) {
        ev.preventDefault();
        ACT.spell();
      }
    });
  }

  function boot() {
    var body = document.body;
    MODE = (body && body.getAttribute('data-mode')) === 'review' ? 'review' : 'today';
    var t = document.getElementById('pageTitle');
    if (t) t.textContent = MODE === 'review' ? '到期复习' : '今日学习';
    var back = $('btnLogout');
    if (back) back.addEventListener('click', function () { window.AppAuth.logout(); });
    window.Learn.Session.onTick = function (sec) {
      S.elapsed = sec;
      S.lastTickSec = sec;
      var el = $('timer');
      if (el) el.textContent = fmt(sec);
    };
    window.Learn.Session.onState = function (state, detail) {
      S.lastState = state;
      // 回前台时 data 层会自动 start 会话；只有正在学习时才允许会话存在
      if ((state === 'started' || state === 'resumed') && S.status !== 'study' && !S.starting) {
        setAuto(false);
        window.Learn.Session.end();
        return;
      }
      if (state === 'session_expired') toast('学习会话已重建，记录会继续保存');
      if (state === 'auth') toast('登录已过期，请重新登录');
      if (state === 'error' && detail) toast('会话异常：' + detail);
    };
    window.Learn.Session.bindEvents();

    window.AppAuth.requireLogin().then(function (user) {
      if (!user) return;
      S.user = user;
      renderTopbar();
      loadTask();
    });
  }

  document.addEventListener('DOMContentLoaded', function () { bind(); boot(); });

  return { boot: boot, state: S };
})();
