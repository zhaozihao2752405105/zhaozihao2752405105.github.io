/* Lumi Words · 专项训练（跨模块薄弱知识点）
   知识点目录与讲解来自数据库静态表（零 AI）；练习由网关按知识点生成并全站缓存。
   结果回报 kp_review，推进「未掌握 → 学习中 → 待巩固 → 已掌握」状态机。 */
(function () {
  var $ = function (id) { return document.getElementById(id); };
  var S = {
    kp: '', info: null, drill: null, idx: 0,
    answers: [], correct: 0, busy: false, started: false, finished: false
  };

  function toast(msg) {
    var t = $('toast');
    if (!t) return;
    t.textContent = msg;
    t.classList.add('show');
    setTimeout(function () { t.classList.remove('show'); }, 2200);
  }

  var STATE_ZH = { 'new': '未掌握', learning: '学习中', reviewing: '待巩固', mastered: '已掌握' };

  function norm(s) {
    return String(s || '').toLowerCase().replace(/[.,!?;:"'’]/g, '').replace(/\s+/g, ' ').trim();
  }

  function esc(s) {
    return String(s == null ? '' : s).replace(/[&<>"]/g, function (c) {
      return { '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;' }[c];
    });
  }

  function head() {
    var info = S.info || {};
    $('drName').textContent = info.name || '专项训练';
    $('drRule').textContent = info.rule || '';
    $('drExample').textContent = info.example || '';
    var st = $('drState');
    if (st) {
      var label = STATE_ZH[info.state] || '未掌握';
      st.textContent = label + (info.streak ? ' · 连续 ' + info.streak + ' 次' : '');
      st.className = 'dr-state st-' + (info.state || 'new');
    }
  }

  function loading(text) {
    $('drBody').innerHTML = '<p class="dr-note">' + esc(text) + '</p>';
  }

  function itemHtml(it, i) {
    var h = '<div class="dr-item" data-i="' + i + '">';
    h += '<p class="dr-q"><span class="dr-n">' + (i + 1) + '</span>' + esc(it.question_zh || '') + '</p>';
    h += '<p class="dr-prompt">' + esc(it.prompt || '') + '</p>';
    if (it.type === 'choice') {
      h += '<div class="dr-opts">';
      (it.options || []).forEach(function (op, k) {
        h += '<button type="button" class="dr-opt" data-act="pick" data-i="' + i + '" data-k="' + k + '">' + esc(op) + '</button>';
      });
      h += '</div>';
    } else {
      h += '<input class="dr-input" id="drIn' + i + '" type="text" inputmode="latin" autocomplete="off" autocapitalize="off" autocorrect="off" spellcheck="false" placeholder="重写这个句子">';
      h += '<button type="button" class="btn dr-submit" data-act="submit" data-i="' + i + '">提交</button>';
    }
    h += '<div class="dr-fb" id="drFb' + i + '" hidden></div></div>';
    return h;
  }

  function renderDrill() {
    var d = S.drill || {};
    var items = d.items || [];
    if (!items.length) { loading('这个知识点还没有练习，稍后再试。'); return; }
    var h = '';
    if (d.intro_zh) h += '<p class="dr-intro">' + esc(d.intro_zh) + '</p>';
    h += '<div class="dr-progress"><span id="drProg">0 / ' + items.length + '</span><span>专项练习</span></div>';
    items.forEach(function (it, i) { h += itemHtml(it, i); });
    h += '<div class="dr-foot" id="drFoot" hidden></div>';
    $('drBody').innerHTML = h;
    S.idx = 0;
  }

  function updateProg() {
    var p = $('drProg');
    if (p) p.textContent = S.answers.filter(Boolean).length + ' / ' + (S.drill.items || []).length;
  }

  function markItem(i, ok, note) {
    var box = document.querySelector('.dr-item[data-i="' + i + '"]');
    var fb = $('drFb' + i);
    if (box) box.classList.add(ok ? 'ok' : 'bad');
    if (fb) {
      fb.hidden = false;
      fb.innerHTML = '<b>' + (ok ? '对了' : '再看一眼') + '</b> ' + esc(note || '');
    }
    if (box) {
      Array.prototype.forEach.call(box.querySelectorAll('button,input'), function (el) { el.disabled = true; });
    }
  }

  function pick(el) {
    if (S.busy) return;
    var i = Number(el.getAttribute('data-i'));
    var k = Number(el.getAttribute('data-k'));
    var it = (S.drill.items || [])[i];
    if (!it || S.answers[i]) return;
    var ok = k === Number(it.answer_index);
    S.answers[i] = true;
    if (ok) S.correct++;
    Array.prototype.forEach.call(document.querySelectorAll('.dr-opt[data-i="' + i + '"]'), function (b) {
      var bk = Number(b.getAttribute('data-k'));
      if (bk === Number(it.answer_index)) b.classList.add('right');
      else if (bk === k) b.classList.add('wrong');
    });
    markItem(i, ok, it.explain_zh || ('正确：' + it.answer_text));
    updateProg();
    maybeFinish();
  }

  function submit(el) {
    if (S.busy) return;
    var i = Number(el.getAttribute('data-i'));
    var it = (S.drill.items || [])[i];
    var input = $('drIn' + i);
    if (!it || !input || S.answers[i]) return;
    if (!input.value.trim()) { toast('先写一个句子'); return; }
    var ok = norm(input.value) === norm(it.answer_text);
    S.answers[i] = true;
    if (ok) S.correct++;
    input.classList.add(ok ? 'right' : 'wrong');
    markItem(i, ok, (ok ? '' : '你写的是「' + input.value.trim() + '」。') + (it.explain_zh || '') + ' 参考答案：' + it.answer_text);
    updateProg();
    maybeFinish();
  }

  function maybeFinish() {
    var total = (S.drill.items || []).length;
    if (S.answers.filter(Boolean).length < total || S.finished) return;
    S.finished = true;
    finish(total);
  }

  function finish(total) {
    var foot = $('drFoot');
    if (foot) {
      foot.hidden = false;
      foot.innerHTML = '<p class="dr-note">这一轮做对 ' + S.correct + ' / ' + total + '。</p>' +
        '<button type="button" class="btn" data-act="again">再练一遍</button>';
    }
  }

  async function report() {
    var total = (S.drill.items || []).length;
    try {
      var r = await window.DB.rpc('kp_review', { p_kp: S.kp, p_correct: S.correct, p_total: total, p_from: 'drill' });
      if (r && r.ok) {
        S.info.state = r.state;
        S.info.streak = r.streak;
        head();
        var next = r.next_check_on ? '（下次检查 ' + r.next_check_on + '）' : '';
        toast('掌握状态：' + (STATE_ZH[r.state] || r.state) + next);
      }
    } catch (e) { toast('结果没保存上，稍后再试'); }
  }

  async function load() {
    loading('正在准备这个知识点…');
    try {
      var info = await window.DB.rpc('kp_get', { p_kp: S.kp });
      if (!info || !info.ok) { $('drBody').innerHTML = '<p class="dr-note">找不到这个知识点。</p>'; return; }
      S.info = info;
      head();
    } catch (e) {
      $('drBody').innerHTML = '<p class="dr-note">读取知识点失败，稍后重试。</p>';
      return;
    }
    // 先生成/取缓存练习
    var got = null;
    try {
      var r = await window.AI.invoke('drill', {
        kp: S.kp, name: S.info.name, rule: S.info.rule, example: S.info.example, level: 4
      }, { requestId: 'drill-' + S.kp + '-' + Math.random().toString(36).slice(2, 8) });
      got = r && r.data;
    } catch (e) {
      got = null;
    }
    if (!got || !(got.items || []).length) {
      $('drBody').innerHTML = '<p class="dr-note">练习生成失败（可能是 AI 预算用完了）。知识点讲解还在，稍后再试一次。</p>';
      return;
    }
    S.drill = got;
    renderDrill();
  }

  document.addEventListener('click', function (e) {
    var t = e.target.closest('[data-act]');
    if (!t) return;
    var act = t.getAttribute('data-act');
    if (act === 'pick') pick(t);
    else if (act === 'submit') submit(t);
    else if (act === 'again') {
      S.answers = []; S.correct = 0; S.finished = false; renderDrill();
    }
  });

  (function boot() {
    var q = new URLSearchParams(location.search);
    S.kp = q.get('kp') || '';
    (async function () {
      try {
        if (window.AppAuth && window.AppAuth.requireLogin) await window.AppAuth.requireLogin();
      } catch (e) {}
      if (!S.kp) { loading('缺少知识点参数，从今日页的「接下来这样练」进来。'); return; }
      await load();
    })();
  })();

  // 离开页面前把未完成的进度也算一次尝试（避免用户白练）
  window.addEventListener('pagehide', function () {
    if (S.finished || !S.answers.filter(Boolean).length) return;
    try { report(); } catch (e) {}
  });

  // 全部做完时回报一次
  var _finish = finish;
  finish = function (total) {
    _finish(total);
    report();
  };
})();