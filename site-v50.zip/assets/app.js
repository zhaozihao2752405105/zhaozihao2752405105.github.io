/* ============================================================
 * assets/app.js —— 第 1 步：登录守卫 + 连接自检（profile + words 两项独立检查）
 * 规则：
 *   1) profile 用当前登录用户会话经 RLS 读取，绝不使用 service_role；
 *   2) profile 读取成功 / words 条数 是两项独立检查，words=0 不算失败；
 *   3) 失败要能区分：权限错误 / 网络错误 / 其他。
 * 第 2 步起本文件会被真正的「今日学习」页面替换。
 * ============================================================ */
(function () {
  var user = null;

  function el(id) { return document.getElementById(id); }

  function classify(err) {
    var m = (err && err.message) || '';
    if (/没有权限|permission denied|row-level security/i.test(m)) return '权限错误（RLS 拦截）：' + m;
    if (/连不上服务器|Failed to fetch|network|NetworkError/i.test(m)) return '网络错误：' + m;
    return m || '未知错误';
  }

  function renderTopbar() {
    var nameEl = el('userName');
    if (!nameEl) return;
    var name = window.AppAuth.displayName(user);
    nameEl.textContent = name ? name + ' · 已登录' : '未登录';
  }

  function render(lines) {
    var box = el('selfCheck');
    if (!box) return;
    box.innerHTML = '';
    lines.forEach(function (item) {
      var p = document.createElement('div');
      p.className = 'check-line' + (item.bad ? ' bad' : '');
      p.textContent = item.text;
      box.appendChild(p);
    });
  }

  async function boot() {
    user = await window.AppAuth.requireLogin();
    if (!user) return;
    renderTopbar();

    var lines = [];
    var modeText = window.DB.mode === 'mock' ? '本地开发 Mock（localStorage）' : '云端（Supabase，当前登录会话）';
    lines.push({ text: '登录账号：' + (user.email || user.id) });
    lines.push({ text: '数据模式：' + modeText });

    // 检查一：读取自己的 profile（走当前用户会话 + RLS）
    try {
      var prof = await window.DB.select('profiles', { id: user.id });
      if (prof && prof.length) {
        var p0 = prof[0];
        lines.push({ text: '个人资料：读取成功（role=' + (p0.role || '?') + '，plan=' + (p0.plan || '?') + '，共 ' + prof.length + ' 条）' });
      } else {
        lines.push({ text: '个人资料：查询成功但没查到自己的档案（应有 1 条，请检查注册触发器）', bad: true });
      }
    } catch (err) {
      lines.push({ text: '个人资料：读取失败 —— ' + classify(err), bad: true });
    }

    // 检查二：读取 words（词库尚未导入时 0 条属正常，不算失败）
    try {
      var words = await window.DB.select('words', { limit: 3 });
      var n = (words || []).length;
      lines.push({ text: '单词数据：读取成功，共 ' + n + ' 条' + (n === 0 ? '（词库尚未导入，属正常，第 2 步导入）' : '') });
    } catch (err) {
      lines.push({ text: '单词数据：读取失败 —— ' + classify(err), bad: true });
    }

    lines.push({ text: '配置版本：' + (window.APP_CONFIG.APP_VERSION || '未知') });
    var h = location.hash || '';
    if (h === '#/test' || h === '#/stats' || h === '#/settings') {
      lines.push({ text: '这个页面还没做（第 5 步统计 / 第 6 步设置）。现在可以直接去「今日学习」。' });
    }
    render(lines);
    // 登录后默认进「今日学习」：本页只是自检页，不再作为首页
    if (!h || h === '#/today') { location.replace('today.html'); return; }
  }

  var btnLogout = document.getElementById('btnLogout');
  if (btnLogout) btnLogout.addEventListener('click', function () { window.AppAuth.logout(); });

  document.addEventListener('DOMContentLoaded', boot);
  if (document.readyState !== 'loading') boot();
})();
