/* assets/ask.js —— 阶段 1：题目下方「问问 AI」
 * 复用：conversation_sessions / conversation_messages / DB.chatStream / 网关 chat_text / 预算幂等
 * 不新建表、不新增网关 kind；上下文只传白名单字段（<=1500 字符），由网关再校验。
 */
(function () {
  'use strict';
  var S = { sid: null, ctx: null, hist: [], busy: false, stream: null, open: false, idle: null, user: null, level: 1, gen: 0 };
  var PREFIX = 'eng45.ask.';

  function refKey() { return PREFIX + String((S.ctx && S.ctx.ref) || 'x'); }
  function loadSid() { try { return sessionStorage.getItem(refKey()); } catch (e) { return null; } }
  function saveSid(v) { try { if (v) sessionStorage.setItem(refKey(), v); else sessionStorage.removeItem(refKey()); } catch (e) {} }
  function esc(s) { return String(s == null ? '' : s).replace(/[&<>"']/g, function (c) { return { '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]; }); }
  function newId() { return 'ask-' + Date.now().toString(36) + '-' + Math.random().toString(36).slice(2, 8); }

  function bubble(role, text) {
    var d = document.createElement('div');
    d.className = 'askmsg ' + (role === 'user' ? 'me' : 'ai');
    d.innerHTML = '<div class="askb">' + esc(text || '') + '</div><div class="askm"></div>';
    return d;
  }
  function log() { return document.getElementById('askLog'); }
  function pushMsg(role, text) { var l = log(); if (!l) return null; var b = bubble(role, text); l.appendChild(b); l.scrollTop = l.scrollHeight; return b; }
  function setText(b, t) { if (!b) return; var x = b.querySelector('.askb'); if (x) x.textContent = t; var l = log(); if (l) l.scrollTop = l.scrollHeight; }
  function setMeta(b, t, bad) { if (!b) return; var m = b.querySelector('.askm'); if (!m) return; m.textContent = t || ''; m.className = 'askm' + (bad ? ' bad' : ''); }

  async function ensureSession() {
    if (S.sid) return S.sid;
    var u = await window.AppAuth.requireLogin();
    S.user = u;
    var row = {
      user_id: u.id,
      mode: 'tutor',
      status: 'active',
      ask_kind: S.ctx.kind,
      ask_ref: String(S.ctx.ref || '').slice(0, 120),
      ask_context: { text: String(S.ctx.context || '').slice(0, 1500), title: String(S.ctx.title || '').slice(0, 80) }
    };
    var rows;
    try {
      rows = await window.DB.insert('conversation_sessions', row);
    } catch (e) {
      // 迁移 014 还没应用时（缺 ask_* 列）自动降级：会话照建，题目归属只在本次页面内有效
      rows = await window.DB.insert('conversation_sessions', { user_id: u.id, mode: 'tutor', status: 'active' });
    }
    var rec = Array.isArray(rows) ? rows[0] : rows;
    if (!rec || !rec.id) throw new Error('创建追问会话失败');
    S.sid = rec.id; saveSid(S.sid);
    return S.sid;
  }

  async function loadHistory() {
    if (!S.sid) return;
    try {
      var rows = await window.DB.select('conversation_messages', { session_id: S.sid, order: 'created_at.asc', limit: 60 });
      S.hist = (rows || []).map(function (m) { return { role: m.role, content: m.content }; }).filter(function (m) { return m.role === 'user' || m.role === 'assistant'; });
      var l = log(); if (!l) return; l.innerHTML = '';
      S.hist.forEach(function (m) { pushMsg(m.role, m.content); });
    } catch (e) { /* 读不到历史不影响新提问 */ }
  }

  function armIdle(b) {
    if (S.idle) clearTimeout(S.idle);
    S.idle = setTimeout(function () {
      if (!S.busy) return;
      S.busy = false;
      if (S.stream) { try { S.stream.abort(); } catch (e) {} }
      setMeta(b, '等待超时：90 秒没有收到 AI 回复，请检查网络后重试。', true);
      updateBtns();
    }, 90000);
  }

  function updateBtns() {
    var send = document.getElementById('askSend'), stop = document.getElementById('askStop');
    if (send) send.disabled = S.busy;
    if (stop) stop.style.display = S.busy ? '' : 'none';
  }

  async function send() {
    var input = document.getElementById('askInput');
    if (!input) return;
    var text = String(input.value || '').trim();
    if (!text) return;
    if (S.busy) return;
    if (text.length > 1200) { alert('一次最多 1200 字'); return; }
    input.value = '';
    S.busy = true; updateBtns();
    if (!S.ctx || !S.ctx.context) { alert('缺少题目上下文，请刷新页面后重试'); S.busy = false; updateBtns(); return; }
    pushMsg('user', text);
    S.hist.push({ role: 'user', content: text });
    var b = pushMsg('assistant', '…');
    var acc = '';
    var myGen = ++S.gen;
    var done = false, aborted = false, errored = false;
    S.markAborted = function () { aborted = true; };
    try {
      var sid = await ensureSession();
      armIdle(b);
      var st = window.DB.chatStream({
        requestId: newId(),
        sessionId: sid,
        mode: 'tutor',
        level: S.level,
        ask: { kind: S.ctx.kind, ref: String(S.ctx.ref || ''), context: String(S.ctx.context || '').slice(0, 1500) },
        messages: S.hist.filter(function (m) { return !m.stopped; }).slice(-10).map(function (m) { return { role: m.role, content: String(m.content || '').slice(0, 1200) }; }),
        onMeta: function () { armIdle(b); },
        onDelta: function (d) {
          armIdle(b);
          if (aborted) return;
          acc += d; setText(b, acc);
        },
        onDone: function (m) {
          if (aborted) return;
          done = true;
          if (S.idle) { clearTimeout(S.idle); S.idle = null; }
          var u = (m && m.usage) || {};
          var bits = [];
          if (u.cost_cny != null) bits.push('本次约 ' + Number(u.cost_cny).toFixed(4) + ' 元');
          if (m && m.meta && m.meta.billing) bits.push(m.meta.billing === 'settled' ? '已结算' : m.meta.billing);
          setMeta(b, bits.join(' · '));
          S.hist.push({ role: 'assistant', content: acc });
        },
        onError: function (code, msg) {
          if (S.idle) { clearTimeout(S.idle); S.idle = null; }
          if (aborted) return;
          errored = true;
          // 会话在服务端已不存在（被清理/换账号）时，本地记住的会话 id 就成了死链：
          // 自动清掉它，用户再发一次就会新建会话，不会一直卡在「会话已失效」。
          if (code === 'session_not_owned') { S.sid = null; saveSid(null); }
          var map = { month_limit: '本月 AI 预算已用完，下月 1 日恢复', daily_limit: '今天 AI 额度已用完，明天再试', rate_limited: '调用太频繁，请稍后再试', not_authenticated: '登录已过期，请重新登录', network: '连不上 AI 服务，请检查网络', session_not_owned: '会话已失效，已自动重置，请再发一次' };
          setMeta(b, map[code] || msg || 'AI 生成失败，请重试', true);
          if (!acc) setText(b, '（这次没有生成成功）');
        }
      });
      S.stream = st;
      armIdle(b);
      await st.promise;
    } catch (e) {
      setMeta(b, '发送失败：' + ((e && e.message) || '未知错误'), true);
    }
    if (S.gen !== myGen) return;
    if (S.idle) { clearTimeout(S.idle); S.idle = null; }
    // 已经显示过具体错误（网络/预算/限流等）时，不要用笼统文案覆盖它
    if (!done && !aborted && !acc && !errored) setMeta(b, navigator.onLine === false ? '连不上 AI 服务，请检查网络后重试' : '没有收到回复，请重试。', true);
    S.busy = false; S.stream = null; updateBtns();
  }

  function stop() {
    if (!S.busy) return;
    for (var i = S.hist.length - 1; i >= 0; i--) { if (S.hist[i].role === 'user') { S.hist[i].stopped = true; break; } }
    if (S.markAborted) { try { S.markAborted(); } catch (e) {} }
    if (S.stream) { try { S.stream.abort(); } catch (e) {} }
    S.busy = false; updateBtns();
    var nodes = document.querySelectorAll('#askLog .askmsg.ai');
    var last = nodes.length ? nodes[nodes.length - 1] : null;
    if (last) setMeta(last, '已停止生成（这条不会保存成完整回答）');
  }

  /* ---------- 语音输入（浏览器自带识别，不经过 AI 网关、不产生 AI 费用） ----------
   * 能力范围：Chrome/Edge 桌面与部分安卓浏览器可用；Safari、内嵌浏览器可能不支持。
   * 识别由浏览器/系统的语音服务完成，因此需要联网；麦克风录音不进入本系统数据库。
   */
  var ASR = window.SpeechRecognition || window.webkitSpeechRecognition || null;
  var V = { rec: null, on: false, base: '', lang: 'zh-CN' };
  try { var savedLang = localStorage.getItem('eng45.ask.asr.lang'); if (savedLang === 'en-US' || savedLang === 'zh-CN') V.lang = savedLang; } catch (e) {}

  function voiceTip(msg, bad) {
    var t = document.getElementById('askVoiceTip');
    if (!t) return;
    if (!msg) { t.style.display = 'none'; t.textContent = ''; return; }
    t.style.display = '';
    t.className = 'asktip' + (bad ? ' bad' : '');
    t.textContent = msg;
  }
  function voiceUI() {
    var mic = document.getElementById('askMic'), lang = document.getElementById('askLang');
    if (mic) { mic.classList.toggle('rec', V.on); mic.textContent = V.on ? '⏹ 结束' : '🎤 语音'; }
    if (lang) { lang.textContent = V.lang === 'en-US' ? 'EN' : '中'; lang.disabled = V.on; }
  }
  function voiceSupported() { return !!ASR && (window.isSecureContext !== false); }
  function stopVoice(silent) {
    var r = V.rec;
    V.on = false; V.rec = null; voiceUI();
    if (r) { try { r.onresult = r.onerror = r.onend = null; r.abort(); } catch (e) {} }
    if (!silent) voiceTip('');
  }
  function startVoice() {
    if (!voiceSupported()) { voiceTip('这个浏览器不支持语音输入，请用键盘输入。', true); return; }
    if (V.on) { stopVoice(); return; }
    var input = document.getElementById('askInput');
    if (!input) return;
    var rec = new ASR();
    V.rec = rec; V.on = true; V.base = String(input.value || '');
    rec.lang = V.lang;
    rec.interimResults = true;
    rec.continuous = false;
    rec.maxAlternatives = 1;
    rec.onresult = function (ev) {
      var fin = '', itm = '';
      for (var i = ev.resultIndex || 0; i < ev.results.length; i++) {
        var t = ev.results[i][0].transcript || '';
        if (ev.results[i].isFinal) fin += t; else itm += t;
      }
      var sep = V.base && !/\s$/.test(V.base) ? ' ' : '';
      input.value = (V.base + sep + fin + itm).slice(0, 1200);
      voiceTip(V.on ? '正在听…说完再点一次按钮结束；也可以直接点发送。' : '');
    };
    rec.onerror = function (ev) {
      var code = (ev && ev.error) || 'unknown';
      var map = {
        'not-allowed': '没有麦克风权限：请点地址栏左侧的图标允许麦克风，然后重试。',
        'service-not-allowed': '浏览器不允许使用语音识别服务，请用键盘输入。',
        'no-speech': '没有听到声音，请靠近麦克风再说一次。',
        'audio-capture': '没有找到麦克风设备，请检查麦克风是否连接。',
        'network': '语音识别服务连不上（可能被网络限制），可以改用键盘输入。',
        'language-not-supported': '这个浏览器不支持所选语言，切换语言后重试。',
        'aborted': ''
      };
      if (map[code] !== '') voiceTip(map[code] || ('语音输入失败：' + code), true);
      stopVoice(true);
    };
    rec.onend = function () { stopVoice(); };
    try {
      rec.start();
      voiceTip('正在听…说完再点一次按钮结束；也可以直接点发送。');
    } catch (e) {
      stopVoice(true);
      voiceTip('麦克风打不开：' + ((e && e.message) || '未知原因'), true);
      return;
    }
    voiceUI();
  }
  function voiceLangToggle() {
    if (V.on) return;
    V.lang = V.lang === 'zh-CN' ? 'en-US' : 'zh-CN';
    try { localStorage.setItem('eng45.ask.asr.lang', V.lang); } catch (e) {}
    voiceUI();
    voiceTip(V.lang === 'en-US' ? '语音识别语言：English（说英文）' : '语音识别语言：中文');
  }

  function endAsk() {
    stopVoice(true);
    S.sid = null; S.hist = []; saveSid(null);
    var l = log(); if (l) l.innerHTML = '<div class="muted small">已结束，这是新的追问。之前的对话还在聊天页的历史里。</div>';
    S.open = true;
  }

  function render(host) {
    var box = document.createElement('section');
    box.className = 'card askcard';
    box.innerHTML =
      '<div class="row between"><div><b>问问 AI</b> <span class="muted small">就问这道题，不离开页面</span></div>' +
      '<button class="btn sm ghost" id="askToggle" type="button">展开</button></div>' +
      '<div id="askPanel" style="display:none;margin-top:10px">' +
      '<div id="askLog" class="asklog"><div class="muted small">可以问：为什么选 B？A 和 C 有什么区别？这句什么意思？换个简单例子。</div></div>' +
      '<div class="row" style="margin-top:8px;gap:8px;flex-wrap:wrap">' +
      '<input id="askInput" class="askinput" type="text" placeholder="输入问题，例如：为什么选 B？" maxlength="1200">' +
      '<button class="btn ghost askmic" id="askMic" type="button" title="语音输入（点一下开始，再点一下结束）" style="display:none">🎤 语音</button>' +
      '<button class="btn sm ghost asklang" id="askLang" type="button" title="切换语音识别语言" style="display:none">中</button>' +
      '<button class="btn" id="askSend" type="button">发送</button>' +
      '<button class="btn ghost" id="askStop" type="button" style="display:none">停止</button>' +
      '</div>' +
      '<div id="askVoiceTip" class="asktip" style="display:none"></div>' +
      '<div class="row end" style="margin-top:6px"><button class="btn sm ghost" id="askEnd" type="button">结束追问</button></div>' +
      '</div>';
    host.appendChild(box);
    var panel = box.querySelector('#askPanel');
    box.querySelector('#askToggle').addEventListener('click', async function () {
      S.open = !S.open;
      panel.style.display = S.open ? '' : 'none';
      box.querySelector('#askToggle').textContent = S.open ? '收起' : '展开';
      if (!S.open) stopVoice(true);
      if (S.open && !S.sid) { S.sid = loadSid(); if (S.sid) await loadHistory(); }
      if (S.open) { var i = box.querySelector('#askInput'); if (i) i.focus(); }
    });
    box.querySelector('#askSend').addEventListener('click', send);
    box.querySelector('#askStop').addEventListener('click', stop);
    box.querySelector('#askEnd').addEventListener('click', endAsk);
    // 语音输入：支持的浏览器才显示按钮；不支持时保留键盘输入，不做假按钮
    var mic = box.querySelector('#askMic'), langBtn = box.querySelector('#askLang');
    if (mic && langBtn && voiceSupported()) {
      mic.style.display = ''; langBtn.style.display = '';
      voiceUI();
      mic.addEventListener('click', startVoice);
      langBtn.addEventListener('click', voiceLangToggle);
    }
    box.querySelector('#askInput').addEventListener('keydown', function (e) { if (e.key === 'Enter' && !e.shiftKey) { e.preventDefault(); send(); } });
    // 已有会话：默认展开并载入历史，刷新后接着问
    (async function () {
      S.sid = loadSid();
      if (!S.sid) return;
      S.open = true; panel.style.display = '';
      box.querySelector('#askToggle').textContent = '收起';
      await loadHistory();
    })();
  }

  /** 在题目卡片后挂一个追问区。
   * ctx = {kind:'grammar|reading|listening|test', ref:'日期:模块:题号', title:'...', context:'白名单文本'}
   */
  function mount(host, ctx) {
    if (!host || !ctx || !ctx.context) return;
    // 同一题重复渲染时先移除旧面板
    var old = host.querySelector('.askcard[data-ref="' + String(ctx.ref).replace(/"/g, '') + '"]');
    if (old) old.remove();
    S.ctx = ctx;
    render(host);
    var made = host.querySelector('.askcard:last-child');
    if (made) made.setAttribute('data-ref', String(ctx.ref || ''));
  }

  // 切走页面/关闭页面时立即停掉麦克风，避免后台一直占用
  document.addEventListener('visibilitychange', function () { if (document.hidden && V.on) stopVoice(true); });
  window.addEventListener('pagehide', function () { if (V.on) stopVoice(true); });

  window.AskUI = { mount: mount, _S: S, voiceSupported: voiceSupported };
})();
